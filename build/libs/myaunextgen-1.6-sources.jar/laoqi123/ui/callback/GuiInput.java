package laoqi123.ui.callback;

import org.lwjgl.glfw.GLFW;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class GuiInput extends class_437 {
    private final String title;
    private final String defaultValue;
    private final Consumer<String> callback;
    private final class_437 caller;
    private class_342 textField;
    private class_4185 buttonOk;

    public GuiInput(String title, String defaultValue, Consumer<String> callback, class_437 caller) {
        super(class_2561.method_43470(title));
        this.title = title;
        this.defaultValue = defaultValue;
        this.callback = callback;
        this.caller = caller;
    }

    public static void prompt(String title, String defaultValue, Consumer<String> callback, class_437 caller) {
        class_310.method_1551().method_1507(new GuiInput(title, defaultValue, callback, caller));
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        textField = new class_342(this.field_22793, centerX - 100, centerY - 10, 200, 20, class_2561.method_43470(""));
        textField.method_1852(defaultValue);
        textField.method_25365(true);
        this.method_25429(textField);

        buttonOk = class_4185.method_46430(class_2561.method_43470("Confirm"), button -> this.onConfirm()).method_46434(centerX - 100, centerY + 20, 95, 20).method_46431();
        this.method_37063(buttonOk);
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> this.onCancel()).method_46434(centerX + 5, centerY + 20, 95, 20).method_46431());
    }

    private void onConfirm() {
        if (callback != null) callback.accept(textField.method_1882());
        this.method_25419();
    }

    private void onCancel() {
        this.method_25419();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            this.onConfirm();
            return true;
        } else if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            this.onCancel();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_25300(this.field_22793, this.title, this.field_22789 / 2, this.field_22790 / 2 - 35, 0xFFFFFF);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(caller);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
