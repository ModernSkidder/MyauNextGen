package laoqi123.ui;

import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_332;

public interface Component {
    void draw(class_332 context, AtomicInteger offset);
    void update(int mousePosX, int mousePosY);
    void mouseDown(int x, int y, int button);
    void mouseReleased(int x, int y, int button);
    void keyTyped(char chatTyped, int keyCode);
    void setComponentStartAt(int newOffsetY);
    int getHeight();
    boolean isVisible();
}
