package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.module.modules.AntiDebuff;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_758.class, priority = 9999)
public abstract class MixinBackgroundRenderer {
    @Inject(
            method = "getFogModifier",
            at = @At("RETURN"),
            cancellable = true
    )
    private static void getFogModifier(class_1297 entity, float tickDelta, CallbackInfoReturnable<?> callbackInfoReturnable) {
        if (Myau.moduleManager != null && entity instanceof class_1309 livingEntity && livingEntity.method_6059(class_1294.field_5919)) {
            AntiDebuff antiDebuff = (AntiDebuff) Myau.moduleManager.modules.get(AntiDebuff.class);
            if (antiDebuff.isEnabled() && antiDebuff.blindness.getValue()) {
                callbackInfoReturnable.setReturnValue(null);
            }
        }
    }
}
