package laoqi123.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1297.class)
public interface EntityAccessor {
    @Accessor("inPowderSnow")
    boolean getIsInWeb();

    @Invoker("getRotationVector")
    class_243 callGetVectorForRotation(float float1, float float2);
}
