package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.event.EventManager;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.LivingUpdateEvent;
import laoqi123.event.impl.MoveInputEvent;
import laoqi123.event.impl.PlayerUpdateEvent;
import laoqi123.event.impl.UpdateEvent;
import laoqi123.management.RotationState;
import laoqi123.module.modules.player.AntiDebuff;
import net.minecraft.class_10185;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import net.minecraft.class_744;
import net.minecraft.class_746;
import laoqi123.module.modules.movement.NoSlow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_746.class, priority = 9999)
public abstract class MixinEntityPlayerSP {
    @Unique
    private static boolean myauLocalPlayerReady() {
        return net.minecraft.class_310.method_1551().field_1724 != null;
    }
    @Unique
    private float overrideYaw = Float.NaN;
    @Unique
    private float overridePitch = Float.NaN;
    @Unique
    private float pendingYaw;
    @Unique
    private float pendingPitch;
    @Shadow
    private float lastYaw;
    @Shadow
    private float lastPitch;
    @Shadow
    public class_744 input;
    @Shadow
    public float renderYaw;
    @Shadow
    public float lastRenderYaw;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onUpdate(CallbackInfo callbackInfo) {
        if (!myauLocalPlayerReady()) return;
        class_1297 self = (class_1297) (Object) this;
        if (self.method_37908().method_22340(class_2338.method_49637(self.method_23317(), 0.0, self.method_23321()))) {
            UpdateEvent event = new UpdateEvent(EventType.PRE, this.lastYaw, this.lastPitch, self.method_36454(), self.method_36455());
            EventManager.call(event);
            RotationState.applyState(event.isRotated() && !self.method_5765(), event.getNewYaw(), event.getNewPitch(), event.getPreYaw(), event.isRotating());
            if (event.isRotated()) {
                this.pendingYaw = self.method_36454();
                this.pendingPitch = self.method_36455();
                this.overrideYaw = event.getNewYaw();
                this.overridePitch = event.getNewPitch();
                // 在 movement 计算之前就应用旋转(move fix):
                // 这样本 tick 的移动方向 == 发送给服务器的 yaw,不会触发 Grim 的 Simulation 判定
                self.method_36456(event.getNewYaw());
                self.method_36457(event.getNewPitch());
            } else {
                this.pendingYaw = Float.NaN;
                this.pendingPitch = Float.NaN;
                this.overrideYaw = Float.NaN;
                this.overridePitch = Float.NaN;
            }
        }
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void postUpdate(CallbackInfo callbackInfo) {
        if (!myauLocalPlayerReady()) return;
        class_1297 self = (class_1297) (Object) this;
        if (self.method_37908().method_22340(class_2338.method_49637(self.method_23317(), 0.0, self.method_23321()))) {
            if (!Float.isNaN(this.pendingYaw) && !Float.isNaN(this.pendingPitch)) {
                this.lastYaw = self.method_36454();
                this.lastPitch = self.method_36455();
                self.method_36456(self.method_36454() + class_3532.method_15393(this.pendingYaw - self.method_36454()));
                self.method_36457(this.pendingPitch);
                self.field_5982 = self.method_36454();
                self.field_6004 = self.method_36455();
                this.lastRenderYaw = self.method_36454() - (this.renderYaw - this.lastRenderYaw) * 2.0F;
                this.renderYaw = self.method_36454();
            }
            EventManager.call(new UpdateEvent(EventType.POST, this.lastYaw, this.lastPitch, self.method_36454(), self.method_36455()));
        }
    }

    @Redirect(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;hasVehicle()Z"
            )
    )
    private boolean onRidding(class_746 clientPlayerEntity) {
        if (!Float.isNaN(this.overrideYaw) && !Float.isNaN(this.overridePitch)) {
            clientPlayerEntity.method_36456(this.overrideYaw);
            clientPlayerEntity.method_36457(this.overridePitch);
        }
        return clientPlayerEntity.method_5765();
    }

    @Inject(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;sendMovementPackets()V"
            )
    )
    private void onMotionUpdate(CallbackInfo callbackInfo) {
        EventManager.call(new PlayerUpdateEvent());
    }

    @Inject(
            method = "tickMovement",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;tickMovement()V"
            )
    )
    private void onLivingUpdate(CallbackInfo callbackInfo) {
        EventManager.call(new LivingUpdateEvent());
    }

    @Inject(
            method = "tickMovement",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/input/Input;tick()V",
                    shift = At.Shift.AFTER
            )
    )
    private void updateMove(CallbackInfo callbackInfo) {
        MoveInputEvent moveInputEvent = new MoveInputEvent();
        EventManager.call(moveInputEvent);
        if (moveInputEvent.isForwardModified()) {
            this.input.field_3905 = moveInputEvent.getForward();
        }
        if (moveInputEvent.isStrafeModified()) {
            this.input.field_3907 = moveInputEvent.getStrafe();
        }
        // 输入被改写时,同步重建 PlayerInput 包:让上报的 forward/strafe 与实际的移动输入一致,
        // 否则 Grim 用包里的输入 + 上报 yaw 预测会和实际移动方向不符
        if (moveInputEvent.isJumpModified() || moveInputEvent.isForwardModified() || moveInputEvent.isStrafeModified()) {
            class_10185 pi = this.input.field_54155;
            this.input.field_54155 = new class_10185(
                    this.input.field_3905 > 0.0f,
                    this.input.field_3905 < 0.0f,
                    this.input.field_3907 > 0.0f,
                    this.input.field_3907 < 0.0f,
                    moveInputEvent.isJumpModified() ? moveInputEvent.getJump() : pi.comp_3163(),
                    pi.comp_3164(),
                    pi.comp_3165()
            );
        }
    }

    @Redirect(
            method = "tickMovement",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"
            )
    )
    private boolean isUsing(class_746 clientPlayerEntity) {
        NoSlow noSlow = (NoSlow) Myau.moduleManager.modules.get(NoSlow.class);
        return (!noSlow.isEnabled() || !noSlow.isAnyActive()) && clientPlayerEntity.method_6115();
    }

    @Redirect(
            method = "tickNausea",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;hasStatusEffect(Lnet/minecraft/registry/entry/RegistryEntry;)Z"
            )
    )
    private boolean checkPotion(class_746 clientPlayerEntity, class_6880<class_1291> statusEffect) {
        if (statusEffect == class_1294.field_5916 && Myau.moduleManager != null) {
            AntiDebuff antiDebuff = (AntiDebuff) Myau.moduleManager.modules.get(AntiDebuff.class);
            if (antiDebuff.isEnabled() && antiDebuff.nausea.getValue()) {
                return false;
            }
        }
        return clientPlayerEntity.method_6059(statusEffect);
    }
}
