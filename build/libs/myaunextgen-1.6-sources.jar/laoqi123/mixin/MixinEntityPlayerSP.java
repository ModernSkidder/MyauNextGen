package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.event.EventManager;
import laoqi123.event.types.EventType;
import laoqi123.events.LivingUpdateEvent;
import laoqi123.events.MoveInputEvent;
import laoqi123.events.PlayerUpdateEvent;
import laoqi123.events.UpdateEvent;
import laoqi123.management.RotationState;
import laoqi123.module.modules.AntiDebuff;
import laoqi123.module.modules.NoSlow;
import net.minecraft.class_10185;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import net.minecraft.class_744;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_746.class, priority = 9999)
public abstract class MixinEntityPlayerSP {
    @Unique
    private static boolean myauLocalPlayerReady() {
        return net.minecraft.class_310.method_1551().field_1724 != null;
    }
    @Unique
    private float overrideYaw = Float.NaN;
    @Unique
    private float overridePitch = Float.NaN;
    @Unique
    private float pendingYaw;
    @Unique
    private float pendingPitch;
    @Shadow
    private float lastYaw;
    @Shadow
    private float lastPitch;
    @Shadow
    public class_744 input;
    @Shadow
    public float renderYaw;
    @Shadow
    public float lastRenderYaw;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onUpdate(CallbackInfo callbackInfo) {
        if (!myauLocalPlayerReady()) return;
        class_1297 self = (class_1297) (Object) this;
        if (self.method_37908().method_22340(class_2338.method_49637(self.method_23317(), 0.0, self.method_23321()))) {
            UpdateEvent event = new UpdateEvent(EventType.PRE, this.lastYaw, this.lastPitch, self.method_36454(), self.method_36455());
            EventManager.call(event);
            RotationState.applyState(event.isRotated() && !self.method_5765(), event.getNewYaw(), event.getNewPitch(), event.getPreYaw(), event.isRotating());
            if (event.isRotated()) {
                this.pendingYaw = self.method_36454();
                this.pendingPitch = self.method_36455();
                this.overrideYaw = event.getNewYaw();
                this.overridePitch = event.getNewPitch();
            } else {
                this.pendingYaw = Float.NaN;
                this.pendingPitch = Float.NaN;
                this.overrideYaw = Float.NaN;
                this.overridePitch = Float.NaN;
            }
        }
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void postUpdate(CallbackInfo callbackInfo) {
        if (!myauLocalPlayerReady()) return;
        class_1297 self = (class_1297) (Object) this;
        if (self.method_37908().method_22340(class_2338.method_49637(self.method_23317(), 0.0, self.method_23321()))) {
            if (!Float.isNaN(this.pendingYaw) && !Float.isNaN(this.pendingPitch)) {
                this.lastYaw = self.method_36454();
                this.lastPitch = self.method_36455();
                self.method_36456(self.method_36454() + class_3532.method_15393(this.pendingYaw - self.method_36454()));
                self.method_36457(this.pendingPitch);
                self.field_5982 = self.method_36454();
                self.field_6004 = self.method_36455();
                this.lastRenderYaw = self.method_36454() - (this.renderYaw - this.lastRenderYaw) * 2.0F;
                this.renderYaw = self.method_36454();
            }
            EventManager.call(new UpdateEvent(EventType.POST, this.lastYaw, this.lastPitch, self.method_36454(), self.method_36455()));
        }
    }

    @Redirect(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;hasVehicle()Z"
            )
    )
    private boolean onRidding(class_746 clientPlayerEntity) {
        if (!Float.isNaN(this.overrideYaw) && !Float.isNaN(this.overridePitch)) {
            clientPlayerEntity.method_36456(this.overrideYaw);
            clientPlayerEntity.method_36457(this.overridePitch);
        }
        return clientPlayerEntity.method_5765();
    }

    @Inject(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;sendMovementPackets()V"
            )
    )
    private void onMotionUpdate(CallbackInfo callbackInfo) {
        EventManager.call(new PlayerUpdateEvent());
    }

    @Inject(
            method = "tickMovement",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;tickMovement()V"
            )
    )
    private void onLivingUpdate(CallbackInfo callbackInfo) {
        EventManager.call(new LivingUpdateEvent());
    }

    @Inject(
            method = "tickMovement",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/input/Input;tick()V",
                    shift = At.Shift.AFTER
            )
    )
    private void updateMove(CallbackInfo callbackInfo) {
        MoveInputEvent moveInputEvent = new MoveInputEvent();
        EventManager.call(moveInputEvent);
        if (moveInputEvent.isJumpModified()) {
            this.input.field_54155 = new class_10185(
                    this.input.field_54155.comp_3159(),
                    this.input.field_54155.comp_3160(),
                    this.input.field_54155.comp_3161(),
                    this.input.field_54155.comp_3162(),
                    moveInputEvent.getJump(),
                    this.input.field_54155.comp_3164(),
                    this.input.field_54155.comp_3165()
            );
        }
        if (moveInputEvent.isForwardModified()) {
            this.input.field_3905 = moveInputEvent.getForward();
        }
        if (moveInputEvent.isStrafeModified()) {
            this.input.field_3907 = moveInputEvent.getStrafe();
        }
    }

    @Redirect(
            method = "tickMovement",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"
            )
    )
    private boolean isUsing(class_746 clientPlayerEntity) {
        NoSlow noSlow = (NoSlow) Myau.moduleManager.modules.get(NoSlow.class);
        return (!noSlow.isEnabled() || !noSlow.isAnyActive()) && clientPlayerEntity.method_6115();
    }

    @Redirect(
            method = "tickNausea",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;hasStatusEffect(Lnet/minecraft/registry/entry/RegistryEntry;)Z"
            )
    )
    private boolean checkPotion(class_746 clientPlayerEntity, class_6880<class_1291> statusEffect) {
        if (statusEffect == class_1294.field_5916 && Myau.moduleManager != null) {
            AntiDebuff antiDebuff = (AntiDebuff) Myau.moduleManager.modules.get(AntiDebuff.class);
            if (antiDebuff.isEnabled() && antiDebuff.nausea.getValue()) {
                return false;
            }
        }
        return clientPlayerEntity.method_6059(statusEffect);
    }
}
