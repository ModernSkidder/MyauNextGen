package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.module.modules.Xray;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2248.class)
public abstract class MixinBlock {
    @Inject(
            method = {"shouldDrawSide(Lnet/minecraft/block/BlockState;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/Direction;)Z"},
            at = {@At("HEAD")},
            cancellable = true
    )
    private static void shouldDrawSide(
            class_2680 state, class_2680 otherState, class_2350 side, CallbackInfoReturnable<Boolean> callbackInfoReturnable
    ) {
        if (Myau.moduleManager != null) {
            Xray xray = (Xray) Myau.moduleManager.modules.get(Xray.class);
            if (xray.isEnabled() && xray.mode.getValue() == 1 && xray.shouldRenderSide(state.method_26204()) && xray.checkBlock(otherState)) {
                callbackInfoReturnable.setReturnValue(true);
            }
        }
    }
}
