package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.module.modules.render.Chams;
import laoqi123.module.modules.render.ViewClip;
import laoqi123.module.modules.render.Xray;
import net.minecraft.class_2338;
import net.minecraft.class_852;
import net.minecraft.class_854;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = {class_852.class}, priority = 9999)
public abstract class MixinVisGraph {
    @Inject(
            method = {"markClosed"},
            at = {@At("HEAD")},
            cancellable = true
    )
    private void markClosed(class_2338 blockPos, CallbackInfo callbackInfo) {
        if (this.isOcclusionBypassActive()) {
            callbackInfo.cancel();
        }
    }

    @Inject(
            method = {"build"},
            at = {@At("HEAD")},
            cancellable = true
    )
    private void build(CallbackInfoReturnable<class_854> callbackInfoReturnable) {
        if (this.isOcclusionBypassActive()) {
            class_854 chunkOcclusionData = new class_854();
            chunkOcclusionData.method_3694(true);
            callbackInfoReturnable.setReturnValue(chunkOcclusionData);
        }
    }

    private boolean isOcclusionBypassActive() {
        return Myau.moduleManager != null
                && (Myau.moduleManager.modules.get(Chams.class).isEnabled()
                        || Myau.moduleManager.modules.get(ViewClip.class).isEnabled()
                        || Myau.moduleManager.modules.get(Xray.class).isEnabled());
    }
}
