package laoqi123.mixin;

import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_759.class)
public interface HeldItemRendererAccessor {
    @Accessor("equipProgressMainHand")
    float getEquippedProgress();

    @Accessor("prevEquipProgressMainHand")
    float getPrevEquippedProgress();
}
