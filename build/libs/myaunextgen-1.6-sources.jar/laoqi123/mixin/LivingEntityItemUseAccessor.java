package laoqi123.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1309.class)
public interface LivingEntityItemUseAccessor {
    @Accessor("activeItemStack")
    class_1799 getItemInUse();

    @Accessor("activeItemStack")
    void setItemInUse(class_1799 itemStack);

    @Accessor("itemUseTimeLeft")
    int getItemInUseCount();

    @Accessor("itemUseTimeLeft")
    void setItemInUseCount(int integer);
}
