package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.event.EventManager;
import laoqi123.event.impl.HitBlockEvent;
import laoqi123.event.impl.LeftClickMouseEvent;
import laoqi123.event.impl.LoadWorldEvent;
import laoqi123.event.impl.ResizeEvent;
import laoqi123.event.impl.RightClickMouseEvent;
import laoqi123.event.impl.SwapItemEvent;
import laoqi123.module.modules.combat.NoHitDelay;
import net.minecraft.class_1661;
import net.minecraft.class_310;
import net.minecraft.class_434;
import net.minecraft.class_636;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_310.class, priority = 9999)
public abstract class MixinMinecraft {
    @Shadow
    public int attackCooldown;
    @Shadow
    public class_636 interactionManager;

    @Inject(
            method = {"tick"},
            at = {@At("RETURN")}
    )
    private void afterWorldTick(CallbackInfo callbackInfo) {
        laoqi123.util.PacketUtil.drainPendingPackets();
    }

    @Inject(
            method = {"joinWorld"},
            at = {@At("HEAD")}
    )
    private void loadWorld(class_638 world, class_434.class_9678 worldEntryReason, CallbackInfo callbackInfo) {
        EventManager.call(new LoadWorldEvent());
    }

    @Inject(
            method = {"onResolutionChanged"},
            at = {@At("RETURN")}
    )
    private void updateFramebufferSize(CallbackInfo callbackInfo) {
        EventManager.call(new ResizeEvent());
    }

    @Inject(
            method = {"doAttack"},
            at = {@At("HEAD")},
            cancellable = true
    )
    private void clickMouse(CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        if (Myau.moduleManager != null && Myau.moduleManager.modules.get(NoHitDelay.class).isEnabled()) {
            this.attackCooldown = 0;
        }
        LeftClickMouseEvent event = new LeftClickMouseEvent();
        EventManager.call(event);
        if (event.isCancelled()) {
            callbackInfoReturnable.cancel();
        }
    }

    @Inject(
            method = {"doItemUse"},
            at = {@At("HEAD")},
            cancellable = true
    )
    private void rightClickMouse(CallbackInfo callbackInfo) {
        RightClickMouseEvent event = new RightClickMouseEvent();
        EventManager.call(event);
        if (event.isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(
            method = {"handleBlockBreaking"},
            at = {@At("HEAD")},
            cancellable = true
    )
    private void sendClickBlockToController(boolean breaking, CallbackInfo callbackInfo) {
        HitBlockEvent event = new HitBlockEvent();
        EventManager.call(event);
        if (event.isCancelled()) {
            callbackInfo.cancel();
            this.interactionManager.method_2925();
        }
    }

    @Redirect(
            method = {"handleInputEvents"},
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/entity/player/PlayerInventory;selectedSlot:I",
                    opcode = 181
            )
    )
    private void changeCurrentItem(class_1661 inventory, int slot) {
        SwapItemEvent event = new SwapItemEvent(slot, 0);
        EventManager.call(event);
        if (!event.isCancelled()) {
            inventory.field_7545 = slot;
        }
    }
}
