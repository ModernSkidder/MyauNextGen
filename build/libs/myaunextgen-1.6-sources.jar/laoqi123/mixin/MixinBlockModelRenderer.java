package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.module.modules.render.BedESP;
import laoqi123.module.modules.render.Xray;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2244;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2742;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_778;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_778.class, priority = 9999)
public abstract class MixinBlockModelRenderer {
    @Inject(
            method = "render(Lnet/minecraft/world/BlockRenderView;Lnet/minecraft/client/render/model/BakedModel;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;ZLnet/minecraft/util/math/random/Random;JI)V",
            at = {@At("HEAD")}
    )
    private void renderBlock(
            class_1920 world,
            class_1087 model,
            class_2680 state,
            class_2338 pos,
            class_4587 matrices,
            class_4588 vertexConsumer,
            boolean cull,
            class_5819 random,
            long seed,
            int overlay,
            CallbackInfo callbackInfo
    ) {
        if (Myau.moduleManager != null) {
            BedESP bedESP = (BedESP) Myau.moduleManager.modules.get(BedESP.class);
            if (bedESP.isEnabled() && state.method_26204() instanceof class_2244 && state.method_11654(class_2244.field_9967) == class_2742.field_12560) {
                bedESP.beds.add(pos.method_10062());
            }
            Xray Xray = (Xray) Myau.moduleManager.modules.get(Xray.class);
            if (Xray.isEnabled() && Xray.isXrayBlock(state)) {
                if (Xray.checkBlock(pos)) {
                    Xray.trackedBlocks.add(pos.method_10062());
                } else {
                    Xray.trackedBlocks.remove(pos);
                }
            }
        }
    }
}
