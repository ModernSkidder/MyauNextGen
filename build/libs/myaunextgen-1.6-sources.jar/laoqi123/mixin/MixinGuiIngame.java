package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.event.EventManager;
import laoqi123.event.impl.Render2DEvent;
import laoqi123.module.modules.player.AutoBlockIn;
import laoqi123.module.modules.misc.NickHider;
import laoqi123.module.modules.player.Scaffold;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_329.class, priority = 9999)
public abstract class MixinGuiIngame {
    @Redirect(
            method = {"tick()V"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/player/PlayerInventory;getMainHandStack()Lnet/minecraft/item/ItemStack;"
            )
    )
    private class_1799 updateTick(class_1661 inventoryPlayer) {
        Scaffold scaffold = (Scaffold) Myau.moduleManager.modules.get(Scaffold.class);
        if (scaffold.isEnabled() && scaffold.spoofItem.getValue()) {
            int slot = scaffold.getSlot();
            if (slot >= 0) {
                return inventoryPlayer.method_5438(slot);
            }
        }
        AutoBlockIn autoBlockIn = (AutoBlockIn) Myau.moduleManager.modules.get(AutoBlockIn.class);
        if (autoBlockIn.itemSpoof.getValue() && autoBlockIn.isEnabled()) {
            int slot = autoBlockIn.getSlot();
            if (slot >= 0) {
                return inventoryPlayer.method_5438(slot);
            }
        }
        return inventoryPlayer.method_7391();
    }

    @Inject(
            method = {"render"},
            at = {@At("RETURN")}
    )
    private void renderGameOverlay(class_332 context, class_9779 tickCounter, CallbackInfo callbackInfo) {
        EventManager.call(new Render2DEvent(context, tickCounter.method_60637(true)));
    }

    @Redirect(
            method = {"renderExperienceBar"},
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;experienceProgress:F"
            )
    )
    private float renderExperience(class_746 entityPlayerSP) {
        if (Myau.moduleManager == null) {
            return entityPlayerSP.field_7510;
        } else {
            NickHider event = (NickHider) Myau.moduleManager.modules.get(NickHider.class);
            return event.isEnabled() && event.level.getValue() ? 0.0F : entityPlayerSP.field_7510;
        }
    }

    @Redirect(
            method = {"renderExperienceLevel"},
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;experienceLevel:I"
            )
    )
    private int renderExperienceLevel(class_746 entityPlayerSP) {
        if (Myau.moduleManager == null) {
            return entityPlayerSP.field_7520;
        } else {
            NickHider event = (NickHider) Myau.moduleManager.modules.get(NickHider.class);
            return event.isEnabled() && event.level.getValue() ? 0 : entityPlayerSP.field_7520;
        }
    }
}
