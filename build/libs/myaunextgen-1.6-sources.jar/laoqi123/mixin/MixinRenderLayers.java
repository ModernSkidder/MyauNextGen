package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.module.modules.render.Xray;
import net.minecraft.class_1921;
import net.minecraft.class_2680;
import net.minecraft.class_4696;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4696.class)
public abstract class MixinRenderLayers {
    @Inject(
            method = {"getBlockLayer(Lnet/minecraft/block/BlockState;)Lnet/minecraft/client/render/RenderLayer;"},
            at = {@At("HEAD")},
            cancellable = true
    )
    private static void getBlockLayer(class_2680 state, CallbackInfoReturnable<class_1921> callbackInfoReturnable) {
        if (Myau.moduleManager != null) {
            Xray xray = (Xray) Myau.moduleManager.modules.get(Xray.class);
            if (xray.isEnabled() && (!xray.shouldRenderSide(state.method_26204()) || xray.mode.getValue() == 0 && !xray.isXrayBlock(state))) {
                callbackInfoReturnable.setReturnValue(class_1921.method_23583());
            }
        }
    }
}
