package laoqi123.mixin;

import laoqi123.module.modules.render.ESP;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = class_761.class, priority = 9999)
public abstract class MixinWorldRenderer {
    @Redirect(
            method = "renderEntities",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;hasOutline(Lnet/minecraft/entity/Entity;)Z")
    )
    private boolean renderEntitiesHasOutline(class_310 client, class_1297 entity) {
        return ESP.shouldOutline(entity) || client.method_27022(entity);
    }

    @Redirect(
            method = "getEntitiesToRender",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;hasOutline(Lnet/minecraft/entity/Entity;)Z")
    )
    private boolean getEntitiesToRenderHasOutline(class_310 client, class_1297 entity) {
        return ESP.shouldOutline(entity) || client.method_27022(entity);
    }

    @Redirect(
            method = "renderEntities",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getTeamColorValue()I")
    )
    private int renderEntitiesOutlineColor(class_1297 entity) {
        return ESP.getOutlineColor(entity);
    }
}
