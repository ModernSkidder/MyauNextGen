package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.module.modules.Scaffold;
import laoqi123.module.modules.Sprint;
import laoqi123.util.player.PlayerUtils;
import net.minecraft.class_1320;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_742;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_742.class, priority = 9999)
public abstract class MixinAbstractClientPlayer extends MixinEntityPlayer {
    @Redirect(
            method = {"getFovMultiplier"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;getAttributeValue(Lnet/minecraft/registry/entry/RegistryEntry;)D"
            )
    )
    private double getFovMultiplier(class_742 livingEntity, class_6880<class_1320> registryEntry) {
        double attributeValue = livingEntity.method_45325(registryEntry);
        if (livingEntity instanceof class_746 && Myau.moduleManager != null) {
            Sprint sprint = (Sprint) Myau.moduleManager.modules.get(Sprint.class);
            return sprint.isEnabled() && sprint.shouldApplyFovFix(livingEntity.method_5996(class_5134.field_23719))
                    ? attributeValue * 1.300000011920929
                    : attributeValue;
        }
        return attributeValue;
    }

    @Inject(method = "getFovMultiplier", at = @At("RETURN"), cancellable = true)
    private void scaffoldKeepFov(boolean changingFov, float tickDelta, CallbackInfoReturnable<Float> cir) {
        if (Myau.moduleManager == null) {
            return;
        }
        Scaffold scaffold = (Scaffold) Myau.moduleManager.modules.get(Scaffold.class);
        if (scaffold.isEnabled() && scaffold.keepFoV.getValue() && PlayerUtils.isMoving()) {
            cir.setReturnValue(scaffold.fovValue.getValue() + PlayerUtils.getMoveSpeedEffectAmplifier() * 0.13F);
        }
    }
}
