package laoqi123.mixin;

import net.minecraft.class_304;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_304.class)
public interface KeyBindingAccessor {
    @Accessor("pressed")
    void setPressed(boolean boolean1);
}
