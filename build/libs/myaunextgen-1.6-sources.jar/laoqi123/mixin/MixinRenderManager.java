package laoqi123.mixin;

import laoqi123.management.RotationState;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_898.class, priority = 9999)
public abstract class MixinRenderManager {
    @Unique
    private float _prevRenderYawOffset;
    @Unique
    private float _renderYawOffset;
    @Unique
    private float _prevRotationYawHead;
    @Unique
    private float _rotationYawHead;
    @Unique
    private float _prevRotationPitch;
    @Unique
    private float _rotationPitch;

    @Inject(
            method = "render(Lnet/minecraft/entity/Entity;DDDFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = {@At("HEAD")}
    )
    private void renderEntityStatic(class_1297 entity, double double2, double double3, double double4, float float5, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo callbackInfo) {
        if (entity instanceof class_746 && RotationState.isRotated(1)) {
            class_746 entityPlayerSP = (class_746) entity;
            this._prevRenderYawOffset = entityPlayerSP.field_6220;
            this._renderYawOffset = entityPlayerSP.field_6283;
            this._prevRotationYawHead = entityPlayerSP.field_6259;
            this._rotationYawHead = entityPlayerSP.field_6241;
            this._prevRotationPitch = entityPlayerSP.field_6004;
            this._rotationPitch = entityPlayerSP.method_36455();
            entityPlayerSP.field_6220 = RotationState.getPrevRenderYawOffset();
            entityPlayerSP.field_6283 = RotationState.getRenderYawOffset();
            entityPlayerSP.field_6259 = RotationState.getPrevRotationYawHead();
            entityPlayerSP.field_6241 = RotationState.getRotationYawHead();
            entityPlayerSP.field_6004 = RotationState.getPrevRotationPitch();
            entityPlayerSP.method_36457(RotationState.getRotationPitch());
        }
    }

    @Inject(
            method = "render(Lnet/minecraft/entity/Entity;DDDFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = {@At("RETURN")}
    )
    private void renderEntityStaticPost(class_1297 entity, double double2, double double3, double double4, float float5, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo callbackInfo) {
        if (entity instanceof class_746 && RotationState.isRotated(1)) {
            class_746 entityPlayerSP = (class_746) entity;
            entityPlayerSP.field_6220 = this._prevRenderYawOffset;
            entityPlayerSP.field_6283 = this._renderYawOffset;
            entityPlayerSP.field_6259 = this._prevRotationYawHead;
            entityPlayerSP.field_6241 = this._rotationYawHead;
            entityPlayerSP.field_6004 = this._prevRotationPitch;
            entityPlayerSP.method_36457(this._rotationPitch);
        }
    }
}
