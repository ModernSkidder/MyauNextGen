package laoqi123.mixin;

import com.mojang.blaze3d.platform.GlStateManager;
import java.io.IOException;
import java.io.InputStream;
import net.minecraft.class_1011;
import net.minecraft.class_10537;
import net.minecraft.class_10539;
import net.minecraft.class_1060;
import net.minecraft.class_1084;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_332;
import net.minecraft.class_425;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_425.class)
public abstract class MixinSplashOverlay {
    private static final class_2960 MYAU_LOADING = class_2960.method_60655("myaunextgen", "textures/gui/loading.png");
    private static final int LOADING_WIDTH = 1920;
    private static final int LOADING_HEIGHT = 1080;

    private static InputStream loadingLogoStream() throws IOException {
        InputStream inputStream = MixinSplashOverlay.class.getClassLoader().getResourceAsStream("assets/myaunextgen/textures/gui/loading.png");
        if (inputStream == null) {
            throw new IOException("assets/myaunextgen/textures/gui/loading.png not found");
        }
        return inputStream;
    }

    @Inject(method = "init", at = @At("HEAD"))
    private static void myauInit(class_1060 textureManager, CallbackInfo ci) {
        textureManager.method_65876(MYAU_LOADING, new class_10537(MYAU_LOADING) {
            @Override
            public class_10539 method_65809(class_3300 resourceManager) throws IOException {
                try (InputStream inputStream = loadingLogoStream()) {
                    return new class_10539(class_1011.method_4309(inputStream), new class_1084(true, true));
                }
            }
        });
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void myauDrawLoading(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        int i = context.method_51421();
        int j = context.method_51443();
        context.method_25302(
            class_1921::method_62277,
            MYAU_LOADING,
            0,
            0,
            0.0F,
            0.0F,
            i,
            j,
            LOADING_WIDTH,
            LOADING_HEIGHT,
            LOADING_WIDTH,
            LOADING_HEIGHT
        );
    }

    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/platform/GlStateManager;_clear(I)V"))
    private static void myauNoClear(int i) {
    }

    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;fill(Lnet/minecraft/client/render/RenderLayer;IIIII)V"))
    private void myauNoBackgroundFill(class_332 context, class_1921 renderLayer, int x1, int y1, int x2, int y2, int color) {
    }

    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Ljava/util/function/Function;Lnet/minecraft/util/Identifier;IIFFIIIIIII)V"))
    private void myauNoMojangLogo(class_332 context, java.util.function.Function<class_2960, class_1921> renderLayers, class_2960 sprite, int x, int y, float u, float v, int width, int height, int regionWidth, int regionHeight, int textureWidth, int textureHeight, int color) {
    }
}
