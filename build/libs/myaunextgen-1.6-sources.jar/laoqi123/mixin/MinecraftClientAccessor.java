package laoqi123.mixin;

import net.minecraft.class_310;
import net.minecraft.class_9779;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_310.class)
public interface MinecraftClientAccessor {
    @Accessor("LOGGER")
    Logger getLogger();

    @Accessor("renderTickCounter")
    class_9779.class_9781 getTimer();

    @Accessor("itemUseCooldown")
    int getRightClickDelayTimer();

    @Accessor("itemUseCooldown")
    void setRightClickDelayTimer(int integer);

    @Accessor("attackCooldown")
    int getAttackCooldown();
}
