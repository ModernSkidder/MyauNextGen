package laoqi123.mixin;

import net.minecraft.class_4184;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_898.class)
public interface EntityRenderDispatcherAccessor {
    @Accessor("camera")
    class_4184 getCamera();
}
