package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.module.modules.AntiObfuscate;
import laoqi123.module.modules.NickHider;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_5348;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value = class_327.class, priority = 9999)
public abstract class MixinFontRenderer {
    @ModifyVariable(
            method = "draw(Ljava/lang/String;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;II)I",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private String renderString(String string) {
        if (Myau.moduleManager == null) {
            return string;
        }
        AntiObfuscate antiObfuscate = (AntiObfuscate) Myau.moduleManager.modules.get(AntiObfuscate.class);
        if (antiObfuscate.isEnabled()) {
            string = antiObfuscate.stripObfuscated(string);
        }
        NickHider nickHider = (NickHider) Myau.moduleManager.modules.get(NickHider.class);
        if (nickHider.isEnabled()) {
            string = nickHider.replaceNick(string);
        }
        return string;
    }

    @ModifyVariable(
            method = "draw(Lnet/minecraft/text/Text;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;II)I",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private class_2561 drawText(class_2561 text) {
        if (Myau.moduleManager == null) {
            return text;
        }
        AntiObfuscate antiObfuscate = (AntiObfuscate) Myau.moduleManager.modules.get(AntiObfuscate.class);
        String string = text.getString();
        if (antiObfuscate.isEnabled()) {
            string = antiObfuscate.stripObfuscated(string);
        }
        NickHider nickHider = (NickHider) Myau.moduleManager.modules.get(NickHider.class);
        if (nickHider.isEnabled()) {
            string = nickHider.replaceNick(string);
        }
        return string.equals(text.getString()) ? text : class_2561.method_43470(string).method_10862(text.method_10866());
    }

    @ModifyVariable(
            method = "getWidth(Lnet/minecraft/text/StringVisitable;)I",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private class_5348 getWidth(class_5348 stringVisitable) {
        if (Myau.moduleManager == null) {
            return stringVisitable;
        }
        AntiObfuscate antiObfuscate = (AntiObfuscate) Myau.moduleManager.modules.get(AntiObfuscate.class);
        String string = stringVisitable.getString();
        if (antiObfuscate.isEnabled()) {
            string = antiObfuscate.stripObfuscated(string);
        }
        NickHider nickHider = (NickHider) Myau.moduleManager.modules.get(NickHider.class);
        if (nickHider.isEnabled()) {
            string = nickHider.replaceNick(string);
        }
        return string.equals(stringVisitable.getString()) ? stringVisitable : class_5348.method_29430(string);
    }

    @ModifyVariable(
            method = "getWidth(Ljava/lang/String;)I",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private String getStringWidth(String string) {
        if (Myau.moduleManager == null) {
            return string;
        }
        AntiObfuscate antiObfuscate = (AntiObfuscate) Myau.moduleManager.modules.get(AntiObfuscate.class);
        if (antiObfuscate.isEnabled()) {
            string = antiObfuscate.stripObfuscated(string);
        }
        NickHider nickHider = (NickHider) Myau.moduleManager.modules.get(NickHider.class);
        return nickHider.isEnabled() ? nickHider.replaceNick(string) : string;
    }
}
