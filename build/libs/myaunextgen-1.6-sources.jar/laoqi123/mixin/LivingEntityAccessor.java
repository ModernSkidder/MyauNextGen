package laoqi123.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_6880;

@Mixin(class_1309.class)
public interface LivingEntityAccessor {
    @Accessor("activeStatusEffects")
    Map<class_6880<class_1291>, class_1293> getActivePotionsMap();

    @Accessor("SPRINTING_SPEED_BOOST")
    class_1322 getSprintingSpeedBoostModifier();

    @Accessor("jumpingCooldown")
    int getJumpTicks();

    @Accessor("jumpingCooldown")
    void setJumpTicks(int integer);

    @Accessor("lastAttackedTicks")
    int getLastAttackedTicks();
}
