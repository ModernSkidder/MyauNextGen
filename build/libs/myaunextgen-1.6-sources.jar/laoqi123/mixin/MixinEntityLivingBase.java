package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.event.EventManager;
import laoqi123.events.StrafeEvent;
import laoqi123.management.RotationState;
import laoqi123.module.modules.movement.Jesus;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_5134;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = class_1309.class, priority = 9999)
public abstract class MixinEntityLivingBase extends MixinEntity {
    @Redirect(method = "jump", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getYaw()F"))
    private float jump(class_1309 entity) {
        return (Object) this instanceof class_746 && RotationState.isActived()
                ? RotationState.getSmoothedYaw()
                : entity.method_36454();
    }

    @Redirect(
            method = "applyMovementInput",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;updateVelocity(FLnet/minecraft/util/math/Vec3d;)V")
    )
    private void applyMovementInput(class_1309 entity, float speed, class_243 movementInput) {
        if ((Object) this instanceof class_746) {
            StrafeEvent event = new StrafeEvent((float) movementInput.field_1352, (float) movementInput.field_1350, speed);
            EventManager.call(event);
            class_243 input = new class_243(event.getStrafe(), movementInput.field_1351, event.getForward());
            boolean actived = RotationState.isActived();
            float yaw = ((class_1297) (Object) this).method_36454();
            if (actived) {
                ((class_1297) (Object) this).method_36456(RotationState.getSmoothedYaw());
            }
            entity.method_5724(event.getFriction(), input);
            if (actived) {
                ((class_1297) (Object) this).method_36456(yaw);
            }
        } else {
            entity.method_5724(speed, movementInput);
        }
    }

    @ModifyVariable(method = "travelInFluid", name = "h", at = @At("STORE"), ordinal = 0)
    private float travelInFluid(float f) {
        if ((Object) this instanceof class_746 && f == (float) ((class_1309) (Object) this).method_45325(class_5134.field_51578)) {
            if (Myau.moduleManager == null) {
                return f;
            }
            Jesus jesus = (Jesus) Myau.moduleManager.modules.get(Jesus.class);
            if (jesus.isEnabled() && (!jesus.groundOnly.getValue() || ((class_1297) (Object) this).method_24828())) {
                return Math.max(f, jesus.speed.getValue());
            }
        }
        return f;
    }
}
