package laoqi123.mixin;

import net.minecraft.class_2817;
import net.minecraft.class_8710;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2817.class)
public interface CustomPayloadC2SPacketAccessor {
    @Accessor("payload")
    class_8710 getData();

    @Accessor("payload")
    void setData(class_8710 data);
}
