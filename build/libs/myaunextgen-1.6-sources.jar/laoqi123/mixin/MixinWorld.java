package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.module.modules.AntiObbyTrap;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1922.class)
public interface MixinWorld {
    @Inject(
            method = {"raycast(Lnet/minecraft/world/RaycastContext;)Lnet/minecraft/util/hit/BlockHitResult;"},
            at = {@At("HEAD")},
            cancellable = true
    )
    default void myauRaycast(class_3959 context, CallbackInfoReturnable<class_3965> callbackInfoReturnable) {
        if (Myau.moduleManager == null) {
            return;
        }
        AntiObbyTrap antiObbyTrap = (AntiObbyTrap) Myau.moduleManager.modules.get(AntiObbyTrap.class);
        if (!antiObbyTrap.isEnabled()) {
            return;
        }
        class_1922 world = (class_1922) (Object) this;
        callbackInfoReturnable.setReturnValue(
                class_1922.<class_3965, class_3959>method_17744(
                        context.method_17750(),
                        context.method_17747(),
                        context,
                        (innerContext, pos) -> {
                            class_2680 blockState = world.method_8320(pos);
                            class_3610 fluidState = world.method_8316(pos);
                            if (antiObbyTrap.isInsideBlock(world, pos)) {
                                if (antiObbyTrap.setAir.getValue() && world instanceof class_1937) {
                                    ((class_1937) world).method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31036);
                                }
                                blockState = class_2246.field_10124.method_9564();
                                fluidState = class_3612.field_15906.method_15785();
                            }
                            class_243 start = innerContext.method_17750();
                            class_243 end = innerContext.method_17747();
                            class_265 blockShape = innerContext.method_17748(blockState, world, pos);
                            class_3965 blockHitResult = world.method_17745(start, end, pos, blockShape, blockState);
                            class_265 fluidShape = innerContext.method_17749(fluidState, world, pos);
                            class_3965 fluidHitResult = fluidShape.method_1092(start, end, pos);
                            double blockDistance = blockHitResult == null
                                    ? Double.MAX_VALUE
                                    : innerContext.method_17750().method_1025(blockHitResult.method_17784());
                            double fluidDistance = fluidHitResult == null
                                    ? Double.MAX_VALUE
                                    : innerContext.method_17750().method_1025(fluidHitResult.method_17784());
                            return blockDistance <= fluidDistance ? blockHitResult : fluidHitResult;
                        },
                        innerContext -> {
                            class_243 end = innerContext.method_17747();
                            class_243 start = innerContext.method_17750().method_1020(end);
                            return class_3965.method_17778(end, class_2350.method_10142(start.field_1352, start.field_1351, start.field_1350), class_2338.method_49638(end));
                        }
                )
        );
    }
}
