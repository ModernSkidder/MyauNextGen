package laoqi123.mixin;

import laoqi123.event.EventManager;
import laoqi123.events.AttackEvent;
import laoqi123.events.CancelUseEvent;
import laoqi123.events.WindowClickEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_636.class, priority = 9999)
public abstract class MixinPlayerControllerMP {

    @Inject(
            method = "attackEntity",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;syncSelectedSlot()V"))
    private void attackEntity(
            class_1657 player, class_1297 target, CallbackInfo callbackInfo
    ) {
        EventManager.call(new AttackEvent(target));
    }

    @Inject(
            method = {"clickSlot"},
            at = {@At("HEAD")},
            cancellable = true
    )
    private void clickSlot(
            int syncId, int slotId, int button, class_1713 actionType, class_1657 player, CallbackInfo callbackInfo
    ) {
        WindowClickEvent event = new WindowClickEvent(syncId, slotId, button, actionType.ordinal());
        EventManager.call(event);
        if (event.isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(
            method = {"stopUsingItem"},
            at = {@At("HEAD")},
            cancellable = true
    )
    private void stopUsingItem(class_1657 player, CallbackInfo callbackInfo) {
        CancelUseEvent event = new CancelUseEvent();
        EventManager.call(event);
        if (event.isCancelled()) {
            callbackInfo.cancel();
        }
    }
}
