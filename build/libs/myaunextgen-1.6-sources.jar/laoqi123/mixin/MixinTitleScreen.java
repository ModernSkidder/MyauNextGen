package laoqi123.mixin;

import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class MixinTitleScreen {
    private static final class_2960 MYAU_BACKGROUND = class_2960.method_60655("myaunextgen", "textures/gui/background.png");
    private static final int BACKGROUND_WIDTH = 1920;
    private static final int BACKGROUND_HEIGHT = 1080;

    @Inject(method = "renderPanoramaBackground", at = @At("HEAD"), cancellable = true)
    private void myauRenderBackground(class_332 context, float delta, CallbackInfo ci) {
        int i = context.method_51421();
        int j = context.method_51443();
        context.method_25302(
            class_1921::method_62277,
            MYAU_BACKGROUND,
            0,
            0,
            0.0F,
            0.0F,
            i,
            j,
            BACKGROUND_WIDTH,
            BACKGROUND_HEIGHT,
            BACKGROUND_WIDTH,
            BACKGROUND_HEIGHT
        );
        ci.cancel();
    }
}
