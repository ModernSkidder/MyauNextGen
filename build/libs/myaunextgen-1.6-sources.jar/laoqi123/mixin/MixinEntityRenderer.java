package laoqi123.mixin;

import laoqi123.Myau;
import laoqi123.data.Box;
import laoqi123.event.EventManager;
import laoqi123.events.PickEvent;
import laoqi123.events.RaytraceEvent;
import laoqi123.events.Render3DEvent;
import laoqi123.module.modules.AutoBlockIn;
import laoqi123.module.modules.GhostHand;
import laoqi123.module.modules.KillAura;
import laoqi123.module.modules.NoHurtCam;
import laoqi123.module.modules.Scaffold;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4599;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

import java.util.function.Predicate;

@Mixin(value = class_757.class, priority = 9999)
public abstract class MixinEntityRenderer {
    @Unique
    private Box<Integer> slot = null;
    @Unique
    private Box<class_1799> using = null;
    @Unique
    private Box<Integer> useCount = null;
    @Shadow
    private class_4599 buffers;
    @Shadow
    private class_310 client;

    @Inject(method = "render", at = @At("HEAD"))
    private void updateCameraAndRender(class_9779 tickCounter, boolean tick, CallbackInfo callbackInfo) {
        if (this.client.field_1724 != null) {
            Scaffold scaffold = (Scaffold) Myau.moduleManager.modules.get(Scaffold.class);
            if (scaffold.isEnabled() && scaffold.spoofItem.getValue()) {
                int slot = scaffold.getSlot();
                if (slot >= 0) {
                    this.slot = new Box<>(this.client.field_1724.method_31548().field_7545);
                    this.client.field_1724.method_31548().field_7545 = slot;
                }
            }
            AutoBlockIn autoBlockIn = (AutoBlockIn) Myau.moduleManager.modules.get(AutoBlockIn.class);
            if (autoBlockIn.isEnabled() && autoBlockIn.itemSpoof.getValue()) {
                int slot = autoBlockIn.getSlot();
                if (slot >= 0) {
                    this.slot = new Box<>(this.client.field_1724.method_31548().field_7545);
                    this.client.field_1724.method_31548().field_7545 = slot;
                }
            }
            KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
            if (killAura.isEnabled() && killAura.isBlocking()) {
                this.using = new Box<>(((LivingEntityItemUseAccessor) this.client.field_1724).getItemInUse());
                ((LivingEntityItemUseAccessor) this.client.field_1724).setItemInUse(this.client.field_1724.method_31548().method_7391());
                this.useCount = new Box<>(((LivingEntityItemUseAccessor) this.client.field_1724).getItemInUseCount());
                ((LivingEntityItemUseAccessor) this.client.field_1724).setItemInUseCount(69000);
            }
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void postUpdateCameraAndRender(class_9779 tickCounter, boolean tick, CallbackInfo callbackInfo) {
        if (this.slot != null) {
            this.client.field_1724.method_31548().field_7545 = this.slot.value;
            this.slot = null;
        }
        if (this.using != null) {
            ((LivingEntityItemUseAccessor) this.client.field_1724).setItemInUse(this.using.value);
            this.using = null;
        }
        if (this.useCount != null) {
            ((LivingEntityItemUseAccessor) this.client.field_1724).setItemInUseCount(this.useCount.value);
            this.useCount = null;
        }
    }

    @Inject(
            method = "renderWorld",
            at = @At("RETURN")
    )
    private void renderWorldPass(class_9779 tickCounter, CallbackInfo callbackInfo) {
        EventManager.call(new Render3DEvent(new class_4587(), this.buffers.method_23000(), tickCounter.method_60637(true)));
    }

    @ModifyConstant(
            method = "tiltViewWhenHurt",
            constant = @Constant(doubleValue = 14.0)
    )
    private double hurtCameraEffect(double value) {
        if (Myau.moduleManager == null) {
            return value;
        } else {
            NoHurtCam noHurtCam = (NoHurtCam) Myau.moduleManager.modules.get(NoHurtCam.class);
            return noHurtCam.isEnabled() ? value * (float) noHurtCam.multiplier.getValue().intValue() / 100.0F : value;
        }
    }

    @ModifyArgs(
            method = "updateCrosshairTarget",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/GameRenderer;findCrosshairTarget(Lnet/minecraft/entity/Entity;DDF)Lnet/minecraft/util/hit/HitResult;"
            )
    )
    private void getMouseOver(Args args) {
        double blockRange = args.get(1);
        RaytraceEvent raytraceEvent = new RaytraceEvent(blockRange);
        EventManager.call(raytraceEvent);
        args.set(1, raytraceEvent.getRange());
        double entityRange = args.get(2);
        PickEvent pickEvent = new PickEvent(entityRange);
        EventManager.call(pickEvent);
        args.set(2, pickEvent.getRange());
    }

    @ModifyArg(
            method = "findCrosshairTarget",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/projectile/ProjectileUtil;raycast(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Box;Ljava/util/function/Predicate;D)Lnet/minecraft/util/hit/EntityHitResult;"
            ),
            index = 4
    )
    private Predicate<class_1297> filterEntities(Predicate<class_1297> predicate) {
        if (Myau.moduleManager == null) {
            return predicate;
        } else {
            GhostHand ghostHand = (GhostHand) Myau.moduleManager.modules.get(GhostHand.class);
            return ghostHand.isEnabled() ? predicate.and(entity -> !ghostHand.shouldSkip(entity)) : predicate;
        }
    }
}
