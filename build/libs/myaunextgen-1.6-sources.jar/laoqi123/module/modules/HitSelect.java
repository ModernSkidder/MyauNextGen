package laoqi123.module.modules;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.events.PacketEvent;
import laoqi123.events.UpdateEvent;
import laoqi123.module.Module;
import laoqi123.mixin.PlayerInteractEntityC2SPacketAccessor;
import laoqi123.property.properties.ModeProperty;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1674;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2848;
import net.minecraft.class_310;

public class HitSelect extends Module {
    private static final class_310 mc = class_310.method_1551();
    
    public final ModeProperty mode = new ModeProperty("mode", 0, new String[]{"Second", "Criticals", "W_Tap"});
    
    private boolean sprintState = false;
    private boolean set = false;
    private double savedSlowdown = 0.0;
    
    private int blockedHits = 0;
    private int allowedHits = 0;

    public HitSelect() {
        super("HitSelect", false);
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        
        if (event.getType() == EventType.POST) {
            this.resetMotion();
        }
    }

    @EventTarget(Priority.HIGHEST)
    public void onPacket(PacketEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.SEND || event.isCancelled()) {
            return;
        }

        if (event.getPacket() instanceof class_2848) {
            class_2848 packet = (class_2848) event.getPacket();
            switch (packet.method_12365()) {
                case field_12981:
                    this.sprintState = true;
                    break;
                case field_12985:
                    this.sprintState = false;
                    break;
                default:
                    break;
            }
            return;
        }

        if (event.getPacket() instanceof class_2824) {
            class_2824 use = (class_2824) event.getPacket();

            final boolean[] isAttack = {false};
            use.method_34209(new class_2824.class_5908() {
                @Override
                public void method_34219(class_1268 hand) {
                }

                @Override
                public void method_34220(class_1268 hand, class_243 pos) {
                }

                @Override
                public void method_34218() {
                    isAttack[0] = true;
                }
            });
            if (!isAttack[0]) {
                return;
            }

            class_1297 target = mc.field_1687.method_8469(((PlayerInteractEntityC2SPacketAccessor) use).getEntityId());
            if (target == null || target instanceof class_1674) {
                return;
            }

            if (!(target instanceof class_1309)) {
                return;
            }

            class_1309 living = (class_1309) target;
            boolean allow = true;

            switch (this.mode.getValue()) {
                case 0: // SECOND
                    allow = this.prioritizeSecondHit(mc.field_1724, living);
                    break;
                case 1: // CRITICALS
                    allow = this.prioritizeCriticalHits(mc.field_1724);
                    break;
                case 2: // WTAP
                    allow = this.prioritizeWTapHits(mc.field_1724, this.sprintState);
                    break;
                default:
                    break;
            }

            if (!allow) {
                event.setCancelled(true);
                this.blockedHits++;
            } else {
                this.allowedHits++;
            }
        }
    }

    private boolean prioritizeSecondHit(class_1309 player, class_1309 target) {
        // If target is already hurt, allow the hit
        if (target.field_6235 != 0) {
            return true;
        }

        // If player hasn't recovered from hurt time, allow the hit
        if (player.field_6235 <= player.field_6254 - 1) {
            return true;
        }

        // If too close, allow the hit
        double dist = player.method_5739(target);
        if (dist < 2.5) {
            return true;
        }

        // If not moving towards each other, allow the hit
        if (!this.isMovingTowards(target, player, 60.0)) {
            return true;
        }

        if (!this.isMovingTowards(player, target, 60.0)) {
            return true;
        }

        // Block the hit and fix motion
        this.fixMotion();
        return false;
    }

    private boolean prioritizeCriticalHits(class_1309 player) {
        // If on ground, allow the hit
        if (player.method_24828()) {
            return true;
        }

        // If hurt, allow the hit
        if (player.field_6235 != 0) {
            return true;
        }

        // If falling, allow the hit (for crits)
        if (player.field_6017 > 0.0f) {
            return true;
        }

        // Block the hit and fix motion
        this.fixMotion();
        return false;
    }

    private boolean prioritizeWTapHits(class_1309 player, boolean sprinting) {
        // If against wall, allow the hit
        if (player.field_5976) {
            return true;
        }

        // If not moving forward, allow the hit
        if (!mc.field_1690.field_1894.method_1434()) {
            return true;
        }

        // If already sprinting, allow the hit
        if (sprinting) {
            return true;
        }

        // Block the hit and fix motion
        this.fixMotion();
        return false;
    }

    private void fixMotion() {
        if (this.set) {
            return;
        }

        KeepSprint keepSprint = (KeepSprint) Myau.moduleManager.modules.get(KeepSprint.class);
        if (keepSprint == null) {
            return;
        }

        try {
            // Save the current slowdown value
            this.savedSlowdown = keepSprint.slowdown.getValue().doubleValue();
            
            // Enable KeepSprint and set slowdown to 0
            if (!keepSprint.isEnabled()) {
                keepSprint.toggle();
            }
            keepSprint.slowdown.setValue(0);
            
            this.set = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void resetMotion() {
        if (!this.set) {
            return;
        }

        KeepSprint keepSprint = (KeepSprint) Myau.moduleManager.modules.get(KeepSprint.class);
        if (keepSprint == null) {
            return;
        }

        try {
            // Restore the original slowdown value
            keepSprint.slowdown.setValue((int) this.savedSlowdown);
            
            // Disable KeepSprint if we enabled it
            if (keepSprint.isEnabled()) {
                keepSprint.toggle();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        this.set = false;
        this.savedSlowdown = 0.0;
    }

    private boolean isMovingTowards(class_1309 source, class_1309 target, double maxAngle) {
        class_243 currentPos = source.method_19538();
        class_243 lastPos = new class_243(source.field_6014, source.field_6036, source.field_5969);
        class_243 targetPos = target.method_19538();

        // Calculate movement vector
        double mx = currentPos.field_1352 - lastPos.field_1352;
        double mz = currentPos.field_1350 - lastPos.field_1350;
        double movementLength = Math.sqrt(mx * mx + mz * mz);

        // If not moving, return false
        if (movementLength == 0.0) {
            return false;
        }

        // Normalize movement vector
        mx /= movementLength;
        mz /= movementLength;

        // Calculate vector to target
        double tx = targetPos.field_1352 - currentPos.field_1352;
        double tz = targetPos.field_1350 - currentPos.field_1350;
        double targetLength = Math.sqrt(tx * tx + tz * tz);

        // If target is at same position, return false
        if (targetLength == 0.0) {
            return false;
        }

        // Normalize target vector
        tx /= targetLength;
        tz /= targetLength;

        // Calculate dot product (cosine of angle between vectors)
        double dotProduct = mx * tx + mz * tz;

        // Check if angle is within threshold
        return dotProduct >= Math.cos(Math.toRadians(maxAngle));
    }

    @Override
    public void onDisabled() {
        this.resetMotion();
        this.sprintState = false;
        this.set = false;
        this.savedSlowdown = 0.0;
        this.blockedHits = 0;
        this.allowedHits = 0;
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.mode.getModeString()};
    }
}
