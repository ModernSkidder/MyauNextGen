package laoqi123.module.modules;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.events.Render2DEvent;
import laoqi123.font.UFontRenderer;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.property.properties.ModeProperty;
import laoqi123.property.properties.PercentProperty;
import laoqi123.util.RenderUtil;
import net.minecraft.class_1293;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public class PotionEffects extends Module {
    private static final class_310 mc = class_310.method_1551();

    public final PercentProperty background = new PercentProperty("Background", 50);
    public final IntProperty offsetX = new IntProperty("OffsetX", 5, -1000, 1000);
    public final IntProperty offsetY = new IntProperty("OffsetY", 80, -1000, 1000);
    public final ModeProperty fontMode = new ModeProperty("font-mode", 0, new String[]{"Minecraft", "Modern"});
    public final BooleanProperty text = new BooleanProperty("Text", true);

    private float currentHeight = 0.0f;
    private UFontRenderer modernFont;

    private UFontRenderer getModernFont() {
        if (modernFont == null) {
            try {
                modernFont = new UFontRenderer("GoogleSans-Regular", 20);
            } catch (Exception e) {
                modernFont = null;
            }
        }
        return modernFont;
    }

    private boolean isModern() {
        return this.fontMode.getValue() == 1 && getModernFont() != null;
    }

    private float getFontHeight() {
        return isModern() ? getModernFont().getHeight() : mc.field_1772.field_2000;
    }

    private int getStringWidth(String str) {
        return isModern() ? getModernFont().getStringWidth(str) : mc.field_1772.method_1727(str);
    }

    private void drawString(class_332 context, String str, float x, float y, int color, boolean shadow) {
        if (isModern()) {
            UFontRenderer fr = getModernFont();
            if (shadow) fr.drawStringWithShadow(str, x, y, color);
            else fr.drawString(str, x, y, color);
        } else {
            context.method_51433(mc.field_1772, str, (int) x, (int) y, color, shadow);
        }
    }

    public PotionEffects() {
        super("PotionEffects", false);
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!this.isEnabled()) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        Collection<class_1293> active = mc.field_1724.method_6026();
        if (active == null || active.isEmpty()) return;

        List<class_1293> potions = new ArrayList<>(active);
        potions.sort(Comparator.comparingInt(class_1293::method_5584).reversed());

        float padding = 5f;
        float fontHeight = getFontHeight();
        float iconSize = 18f;
        float rowHeight = this.text.getValue() ? fontHeight + padding : iconSize + padding;

        String title = "Potions";
        float titleWidth = getStringWidth(title);

        float maxWidth = this.text.getValue() ? (titleWidth + padding * 2) : (iconSize + padding * 2 + 4f);
        float listHeight = 0f;
        float topPadding = padding;
        float bottomPadding = padding;

        for (class_1293 effect : potions) {
            float localWidth;
            if (this.text.getValue()) {
                String potionName = effect.method_5579().comp_349().method_5560().getString();
                String amp = effect.method_5578() > 0 ? " " + class_2561.method_43471("enchantment.level." + (effect.method_5578() + 1)).getString() : "";
                String nameText = potionName + amp;
                String durationText = getDurationString(effect);
                float nameW = getStringWidth(nameText);
                float durW = getStringWidth(durationText);
                localWidth = nameW + durW + padding * 3 + iconSize + 4f;
            } else {
                localWidth = iconSize + padding * 2 + 4f;
            }

            if (localWidth > maxWidth) maxWidth = localWidth;
            listHeight += rowHeight;
        }

        float width = Math.max(maxWidth, 80f);
        float headerHeight = this.text.getValue() ? fontHeight + padding * 2 : 0f;
        float extraTop = this.text.getValue() ? 1.25f + 7.5f : 0f;
        float targetHeight = topPadding + headerHeight + extraTop + listHeight + bottomPadding;

        if (currentHeight <= 0.0f) {
            currentHeight = targetHeight;
        } else {
            float speed = 0.22f;
            currentHeight += (targetHeight - currentHeight) * speed;
        }

        float height = Math.max(headerHeight + 1f, currentHeight);

        float scaledWidth = mc.method_22683().method_4486();
        float scaledHeight = mc.method_22683().method_4502();
        float x = scaledWidth - width - 10 + offsetX.getValue();
        float y = 20 + offsetY.getValue();

        HUD hud = (HUD) Myau.moduleManager.getModule(HUD.class);
        int accent = hud != null ? hud.getColor(System.currentTimeMillis()).getRGB() : 0xFF80FF95;

        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(770, 771, 1, 0);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);

        int bgAlpha = (int) ((float) background.getValue() / 100f * 255);
        int bg = new Color(0, 0, 0, Math.min(255, Math.max(0, bgAlpha))).getRGB();
        RenderUtil.drawRect((int) x, (int) y, (int) (x + width), (int) (y + height), bg);

        float currentY = y + topPadding;

        if (this.text.getValue()) {
            float titleX = x + width / 2f - titleWidth / 2f;
            drawString(event.getContext(), title, titleX, currentY, 0xFFFFFFFF, true);
            currentY += fontHeight + padding * 2;

            float dividerY = currentY;
            Color dividerColor = new Color(accent);
            dividerColor = new Color(
                    Math.max(0, dividerColor.getRed() - 60),
                    Math.max(0, dividerColor.getGreen() - 60),
                    Math.max(0, dividerColor.getBlue() - 60),
                    dividerColor.getAlpha()
            );
            RenderUtil.drawRect((int) (x + 0.5f), (int) (dividerY + 1.5f), (int) (x + width - 0.5f), (int) (dividerY + 1.5f + 1.25f), dividerColor.getRGB());
            currentY = dividerY + 7.5f;
        }

        float iconX = x + padding;
        float textX = x + padding + iconSize + 4f;

        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        float scale = (float) mc.method_22683().method_4495();
        int scissorX = (int) (x * scale);
        int scissorY = (int) ((scaledHeight - (y + height)) * scale);
        int scissorW = (int) (width * scale);
        int scissorH = (int) (height * scale);
        GL11.glScissor(scissorX, scissorY, scissorW, scissorH);

        for (class_1293 effect : potions) {
            float iconDrawY = currentY + (rowHeight - iconSize) / 2f;
            RenderUtil.renderPotionEffect(effect, (int) iconX, (int) iconDrawY);

            if (this.text.getValue()) {
                String potionName = effect.method_5579().comp_349().method_5560().getString();
                String amp = effect.method_5578() > 0 ? " " + class_2561.method_43471("enchantment.level." + (effect.method_5578() + 1)).getString() : "";
                String nameText = potionName + amp;
                String durationText = getDurationString(effect);

                float durW = getStringWidth(durationText);
                drawString(event.getContext(), nameText, textX, currentY, 0xFFFFFFFF, true);
                drawString(event.getContext(), durationText, x + width - padding - durW, currentY, 0xFFFFFFFF, true);
            }

            currentY += rowHeight;
            if (currentY > y + height - padding) break;
        }

        GL11.glDisable(GL11.GL_SCISSOR_TEST);

        RenderSystem.disableBlend();
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
    }

    private static String getDurationString(class_1293 effect) {
        int total = effect.method_5584() / 20;
        if (total >= 3600) {
            return String.format("%d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60);
        }
        return String.format("%d:%02d", total / 60, total % 60);
    }
}
