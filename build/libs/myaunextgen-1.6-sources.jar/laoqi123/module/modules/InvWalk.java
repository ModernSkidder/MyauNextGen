package laoqi123.module.modules;

import com.google.common.base.CaseFormat;
import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.events.PacketEvent;
import laoqi123.events.TickEvent;
import laoqi123.events.UpdateEvent;
import laoqi123.mixin.CloseHandledScreenC2SPacketAccessor;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.property.properties.ModeProperty;
import laoqi123.util.KeyBindUtil;
import laoqi123.util.PacketUtil;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2848;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_490;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class InvWalk extends Module {
    private static final class_310 mc = class_310.method_1551();
    private final Queue<class_2813> clickQueue = new ConcurrentLinkedQueue<>();
    private boolean keysPressed = false;
    private class_2848 pendingStatus = null;
    private int delayTicks = 0;
    private int openDelayTicks = -1;
    private int closeDelayTicks = -1;
    private Map<class_304, Boolean> movementKeys = null;

    private Map<class_304, Boolean> getMovementKeys() {
        if (movementKeys == null) {
            movementKeys = new HashMap<>();
            movementKeys.put(mc.field_1690.field_1894, false);
            movementKeys.put(mc.field_1690.field_1881, false);
            movementKeys.put(mc.field_1690.field_1913, false);
            movementKeys.put(mc.field_1690.field_1849, false);
            movementKeys.put(mc.field_1690.field_1903, false);
            movementKeys.put(mc.field_1690.field_1832, false);
            movementKeys.put(mc.field_1690.field_1867, false);
        }
        return movementKeys;
    }

    public final ModeProperty mode = new ModeProperty("mode", 1, new String[]{"VANILLA", "LEGIT", "HYPIXEL", "LEGIT+"});
    public final BooleanProperty guiEnabled = new BooleanProperty("click-gui", true);
    public final IntProperty openDelay = new IntProperty("open-delay", 0, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty closeDelay = new IntProperty("close-delay", 4, 0, 20, () -> mode.getValue() == 3);
    public final BooleanProperty lockMoveKey = new BooleanProperty("lock-move-dey", false);

    public InvWalk() {
        super("InvWalk", false);
    }

    public void pressMovementKeys(boolean skipSneak) {
        this.getMovementKeys().keySet().stream()
                .filter(key -> !skipSneak || key != mc.field_1690.field_1832)
                .forEach(key -> KeyBindUtil.updateKeyState(key));
        if (Myau.moduleManager.modules.get(Sprint.class).isEnabled()) {
            KeyBindUtil.setKeyBindState(mc.field_1690.field_1867, true);
        }
        this.keysPressed = true;
    }

    public void resetMovementKeys() {
        this.getMovementKeys().replaceAll((k, v) -> false);
    }

    public boolean isSetMovementKeys() {
        return this.getMovementKeys().values().stream().anyMatch(Boolean::booleanValue);
    }

    public void storeMovementKeys() {
        this.getMovementKeys().replaceAll((k, v) -> KeyBindUtil.isKeyDown(k));
    }

    public void restoreMovementKeys() {
        for (Map.Entry<class_304, Boolean> keyBinding : this.getMovementKeys().entrySet()) {
            KeyBindUtil.setKeyBindState(keyBinding.getKey(), keyBinding.getValue());
        }
        if (Myau.moduleManager.modules.get(Sprint.class).isEnabled()) {
            KeyBindUtil.setKeyBindState(mc.field_1690.field_1867, true);
        }
        this.keysPressed = true;
    }

    public boolean canInvWalk() {
        if (!(mc.field_1755 instanceof class_465)) return false;
        if (mc.field_1755 instanceof class_481) return false;

        switch (this.mode.getValue()) {
            case 0: // Vanilla
                return true;
            case 1: // Legit
                if (!(mc.field_1755 instanceof class_490)) return false;
                return this.pendingStatus != null && this.clickQueue.isEmpty();
            case 2: // Hypixel
                return this.delayTicks == 0 && this.clickQueue.isEmpty();
            case 3: // Legit+
                if (!(mc.field_1755 instanceof class_490)) return false;
                return this.closeDelayTicks == -1 && this.clickQueue.isEmpty();
            default:
                return false;
        }
    }

    public boolean temporaryStackIsEmpty() {
        if (!mc.field_1724.field_7498.method_34255().method_7960()) return false;
        if (mc.field_1724.field_7498 instanceof class_1723) {
            class_1723 screenHandler = (class_1723) mc.field_1724.field_7498;
            for (int i = class_1723.field_30804; i < class_1723.field_30805; i++) {
                class_1735 slot = screenHandler.field_7761.get(i);
                if (slot.method_7681()) {
                    return false;
                }
            }
        }
        return true;
    }

    @EventTarget(Priority.LOWEST)
    public void onTick(TickEvent event) {
        if (event.getType() == EventType.PRE) {
            if (this.openDelayTicks >= 0) {
                this.openDelayTicks--;
                return;
            }
            while (!this.clickQueue.isEmpty()) {
                PacketUtil.sendPacketNoEvent(this.clickQueue.poll());
            }
            if (this.closeDelayTicks > 0) {
                if (this.temporaryStackIsEmpty()) {
                    this.closeDelayTicks--;
                }
            } else if (this.closeDelayTicks == 0) {
                if (mc.field_1755 instanceof class_490)
                    PacketUtil.sendPacketNoEvent(new class_2815(0));
                this.closeDelayTicks = -1;
            }
        }
    }

    @EventTarget(Priority.LOWEST)
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) return;

        if (mc.field_1755 instanceof laoqi123.ui.ClickGui && this.guiEnabled.getValue()) {
            this.pressMovementKeys(true);
            return;
        }

        if (this.canInvWalk()) {
            if (this.isSetMovementKeys() && this.lockMoveKey.getValue()) {
                this.restoreMovementKeys();
            } else {
                this.pressMovementKeys(true);
            }
        } else {
            if (this.keysPressed) {
                if (mc.field_1755 != null) {
                    class_304.method_1437();
                } else if (this.isSetMovementKeys()) {
                    this.resetMovementKeys();
                    this.pressMovementKeys(false);
                }
                this.keysPressed = false;
            }
            if (this.pendingStatus != null) {
                PacketUtil.sendPacketNoEvent(this.pendingStatus);
                this.pendingStatus = null;
            }
            if (this.delayTicks > 0) {
                this.delayTicks--;
            }
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.SEND) return;

        if (event.getPacket() instanceof class_2848) {
            this.storeMovementKeys();
            if (this.mode.getValue() == 1 || this.mode.getValue() == 3) {
                class_2848 packet = (class_2848) event.getPacket();
                if (packet.method_12365() == class_2848.class_2849.field_12988) {
                    event.setCancelled(true);
                    if (this.mode.getValue() == 1) {
                        this.pendingStatus = packet;
                    }
                }
            }
        } else if (!(event.getPacket() instanceof class_2813)) {
            if (event.getPacket() instanceof class_2815) {
                class_2815 packet = (class_2815) event.getPacket();
                if (((CloseHandledScreenC2SPacketAccessor) packet).getWindowId() == 0) {
                    if (this.mode.getValue() == 3) {
                        if (!this.clickQueue.isEmpty()) {
                            this.clickQueue.clear();
                        }
                        if (this.openDelayTicks >= 0) {
                            this.openDelayTicks = -1;
                        }
                        if (this.closeDelayTicks >= 0) {
                            this.closeDelayTicks = -1;
                        } else {
                            event.setCancelled(true);
                        }
                    } else if (this.pendingStatus != null) {
                        this.pendingStatus = null;
                        event.setCancelled(true);
                    }
                } else {
                    if (!this.clickQueue.isEmpty()) {
                        this.clickQueue.clear();
                    }
                    if (this.openDelayTicks >= 0) {
                        this.openDelayTicks = -1;
                    }
                    if (this.closeDelayTicks >= 0) {
                        this.closeDelayTicks = -1;
                    }
                }
            }
        } else {
            class_2813 packet = (class_2813) event.getPacket();
            switch (this.mode.getValue()) {
                case 1: // Legit
                    if (packet.method_12194() == 0) {
                        if ((packet.method_12195() == class_1713.field_7796 || packet.method_12195() == class_1713.field_7795) && packet.method_12192() == class_1703.field_30730) {
                            event.setCancelled(true);
                            return;
                        }
                        if (this.pendingStatus != null) {
                            class_304.method_1437();
                            event.setCancelled(true);
                            this.clickQueue.offer(packet);
                        }
                    }
                    break;
                case 2: // Hypixel
                    if ((packet.method_12195() == class_1713.field_7796 || packet.method_12195() == class_1713.field_7795) && packet.method_12192() == class_1703.field_30730) {
                        event.setCancelled(true);
                    } else {
                        class_304.method_1437();
                        event.setCancelled(true);
                        this.clickQueue.offer(packet);
                        this.delayTicks = 8;
                    }
                    break;
                case 3: // Legit+
                    if (packet.method_12194() == 0) {
                        if ((packet.method_12195() == class_1713.field_7796 || packet.method_12195() == class_1713.field_7795) && packet.method_12192() == class_1703.field_30730) {
                            event.setCancelled(true);
                            return;
                        }
                        class_304.method_1437();
                        event.setCancelled(true);
                        this.clickQueue.offer(packet);
                        if (this.closeDelayTicks < 0 && this.openDelayTicks < 0) {
                            this.pendingStatus = new class_2848(mc.field_1724, class_2848.class_2849.field_12988);
                            this.openDelayTicks = openDelay.getValue();
                        }
                        this.closeDelayTicks = closeDelay.getValue();
                    }
                    break;
            }
            if (this.pendingStatus != null) {
                PacketUtil.sendPacketNoEvent(this.pendingStatus);
                this.pendingStatus = null;
            }
        }
    }

    @Override
    public void onDisabled() {
        if (this.keysPressed) {
            if (mc.field_1755 != null) {
                class_304.method_1437();
            }
            this.keysPressed = false;
        }
        if (this.pendingStatus != null) {
            PacketUtil.sendPacketNoEvent(this.pendingStatus);
            this.pendingStatus = null;
        }
        this.delayTicks = 0;
    }

    @Override
    public String[] getSuffix() {
        return new String[]{CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, this.mode.getModeString())};
    }
}
