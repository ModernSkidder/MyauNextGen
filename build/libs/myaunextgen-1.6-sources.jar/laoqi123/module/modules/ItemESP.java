package laoqi123.module.modules;

import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.enums.ChatColors;
import laoqi123.event.EventTarget;
import laoqi123.events.Render3DEvent;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.PercentProperty;
import laoqi123.util.RenderUtil;
import laoqi123.util.TeamUtil;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_7833;
import org.joml.Matrix4fStack;

import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.stream.Collectors;

public class ItemESP extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final PercentProperty opacity = new PercentProperty("opacity", 25);
    public final BooleanProperty outline = new BooleanProperty("outline", false);
    public final BooleanProperty itemCount = new BooleanProperty("item-count", true);
    public final BooleanProperty autoScale = new BooleanProperty("auto-scale", true);
    public final BooleanProperty emeralds = new BooleanProperty("emeralds", true);
    public final BooleanProperty diamonds = new BooleanProperty("diamonds", true);
    public final BooleanProperty goldd = new BooleanProperty("gold", true);
    public final BooleanProperty iron = new BooleanProperty("iron", true);

    private boolean shouldHighlightItem(class_1792 item) {
        return this.emeralds.getValue() && this.isEmeraldItem(item)
                || this.diamonds.getValue() && this.isDiamondItem(item)
                || this.goldd.getValue() && this.isGoldItem(item)
                || this.iron.getValue() && this.isIronItem(item);
    }

    private boolean isEmeraldItem(class_1792 item) {
        class_2248 block = class_2248.method_9503(item);
        return item == class_1802.field_8687 || block == class_2246.field_10234 || block == class_2246.field_10013;
    }

    private boolean isDiamondItem(class_1792 item) {
        class_2248 block = class_2248.method_9503(item);
        return item == class_1802.field_8477
                || item == class_1802.field_8802
                || item == class_1802.field_8377
                || item == class_1802.field_8250
                || item == class_1802.field_8556
                || item == class_1802.field_8527
                || item == class_1802.field_8805
                || item == class_1802.field_8058
                || item == class_1802.field_8348
                || item == class_1802.field_8285
                || block == class_2246.field_10201
                || block == class_2246.field_10442;
    }

    private boolean isGoldItem(class_1792 item) {
        class_2248 block = class_2248.method_9503(item);
        return item == class_1802.field_8695 || item == class_1802.field_8397 || item == class_1802.field_8463 || block == class_2246.field_10205 || block == class_2246.field_10571;
    }

    private boolean isIronItem(class_1792 item) {
        class_2248 block = class_2248.method_9503(item);
        return item == class_1802.field_8620 || block == class_2246.field_10085 || block == class_2246.field_10212;
    }

    private Color getItemColor(class_1792 item) {
        if (this.isEmeraldItem(item)) {
            return new Color(ChatColors.GREEN.toAwtColor());
        } else if (this.isDiamondItem(item)) {
            return new Color(ChatColors.AQUA.toAwtColor());
        } else if (this.isGoldItem(item)) {
            return new Color(ChatColors.YELLOW.toAwtColor());
        } else {
            return this.isIronItem(item) ? new Color(ChatColors.WHITE.toAwtColor()) : new Color(ChatColors.GRAY.toAwtColor());
        }
    }

    private int getItemPriority(class_1792 item) {
        if (this.isEmeraldItem(item)) {
            return 4;
        } else if (this.isDiamondItem(item)) {
            return 3;
        } else if (this.isGoldItem(item)) {
            return 2;
        } else {
            return this.isIronItem(item) ? 1 : 0;
        }
    }

    public ItemESP() {
        super("ItemESP", false);
    }

    @EventTarget
    public void onRender(Render3DEvent event) {
        if (this.isEnabled()) {
            LinkedHashMap<ItemData, Integer> itemMap = new LinkedHashMap<>();
            for (class_1297 entity : TeamUtil.getLoadedEntitiesSorted()) {
                if (entity.field_6012 >= 3
                        && RenderUtil.isInViewFrustum(entity.method_5829(), 0.125)
                        && entity instanceof class_1542) {
                    class_1542 entityItem = (class_1542) entity;
                    class_1799 stack = entityItem.method_6983();
                    if (stack.method_7947() > 0 && this.shouldHighlightItem(stack.method_7909())) {
                        double x = RenderUtil.lerpDouble(entityItem.method_23317(), entityItem.field_6014, event.getPartialTicks());
                        double y = RenderUtil.lerpDouble(entityItem.method_23318(), entityItem.field_6036, event.getPartialTicks());
                        double z = RenderUtil.lerpDouble(entityItem.method_23321(), entityItem.field_5969, event.getPartialTicks());
                        ItemData data = new ItemData(stack.method_7909(), x, y, z);
                        Integer id = itemMap.get(data);
                        itemMap.put(new ItemData(stack.method_7909(), x, y, z), stack.method_7947() + (id == null ? 0 : id));
                    }
                }
            }
            for (Entry<ItemData, Integer> itemEntry : itemMap.entrySet().stream().sorted((entry1, entry2) -> {
                int o = this.getItemPriority(entry1.getKey().item);
                int o2 = this.getItemPriority(entry2.getKey().item);
                return Integer.compare(o, o2);
            }).collect(Collectors.toList())) {
                Color itemColor = this.getItemColor(itemEntry.getKey().item);
                class_243 cameraPos = mc.field_1773.method_19418().method_19326();
                double x = itemEntry.getKey().x - cameraPos.field_1352;
                double y = itemEntry.getKey().y - cameraPos.field_1351;
                double z = itemEntry.getKey().z - cameraPos.field_1350;
                double distance = mc.method_1560().method_19538().method_1022(new class_243(itemEntry.getKey().x, itemEntry.getKey().y, itemEntry.getKey().z));
                double scale = 0.5 + 0.375 * ((Math.max(6.0, this.autoScale.getValue() ? distance : 6.0) - 6.0) / 28.0);
                class_238 axisAlignedBB = new class_238(x - scale * 0.5, y, z - scale * 0.5, x + scale * 0.5, y + scale, z + scale * 0.5);
                RenderUtil.enableRenderState();
                if (this.opacity.getValue() > 0) {
                    RenderUtil.drawFilledBox(
                            axisAlignedBB, itemColor.getRed(), itemColor.getGreen(), itemColor.getBlue()
                    );
                    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
                }
                if (this.outline.getValue()) {
                    RenderUtil.drawBoundingBox(axisAlignedBB, itemColor.getRed(), itemColor.getGreen(), itemColor.getBlue(), 255, 1.5F);
                    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
                }
                RenderUtil.disableRenderState();
                if (this.itemCount.getValue()) {
                    Matrix4fStack matrixStack = RenderSystem.getModelViewStack();
                    matrixStack.pushMatrix();
                    matrixStack.translate((float) x, (float) y + (float) (scale * 0.5), (float) z);
                    matrixStack.rotate(class_7833.field_40716.rotationDegrees(-mc.field_1773.method_19418().method_19330()));
                    float flip = mc.field_1690.method_31044().method_31035() ? -1.0F : 1.0F;
                    matrixStack.rotate(class_7833.field_40714.rotationDegrees(mc.field_1773.method_19418().method_19329() * flip));
                    double fontScale = -0.04375 - 0.0328125 * ((Math.max(6.0, this.autoScale.getValue() ? distance : 6.0) - 6.0) / 28.0);
                    matrixStack.scale((float) fontScale, (float) fontScale, 1.0F);
                    String countText = String.format("%d", itemEntry.getValue());
                    RenderUtil.drawOutlinedString(
                            countText,
                            ((float) mc.field_1772.method_1727(countText) / 2.0F - 0.5F) * -1.0F,
                            ((float) (mc.field_1772.field_2000 / 2) - 0.5F) * -1.0F
                    );
                    matrixStack.popMatrix();
                }
            }
        }
    }

    public static class ItemData {
        private final int hashCode;
        public final class_1792 item;
        public final double x;
        public final double y;
        public final double z;

        public ItemData(class_1792 item, double x, double y, double z) {
            this.item = item;
            this.x = x;
            this.y = y;
            this.z = z;
            this.hashCode = Objects.hash(item, (int) x, (int) y, (int) z);
        }

        @Override
        public boolean equals(Object object) {
            if (this == object) {
                return true;
            } else if (object != null && this.getClass() == object.getClass()) {
                ItemData itemData = (ItemData) object;
                return this.item == itemData.item && (int) this.x == (int) itemData.x && (int) this.y == (int) itemData.y && (int) this.z == (int) itemData.z;
            } else {
                return false;
            }
        }

        @Override
        public int hashCode() {
            return this.hashCode;
        }
    }
}
