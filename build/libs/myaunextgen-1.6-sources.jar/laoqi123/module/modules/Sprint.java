package laoqi123.module.modules;

import laoqi123.event.EventTarget;
import laoqi123.events.TickEvent;
import laoqi123.mixin.LivingEntityAccessor;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.util.KeyBindUtil;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class Sprint extends Module {
    private static final class_310 mc = class_310.method_1551();
    private boolean wasSprinting = false;
    public final BooleanProperty foxFix = new BooleanProperty("fov-fix", true);

    public Sprint() {
        super("Sprint", true, true);
    }

    public boolean shouldApplyFovFix(class_1324 attribute) {
        if (!this.foxFix.getValue()) {
            return false;
        }
        class_1322 attributeModifier = ((LivingEntityAccessor) mc.field_1724).getSprintingSpeedBoostModifier();
        return attribute.method_6199(attributeModifier.comp_2447()) == null && this.wasSprinting;
    }

    public boolean shouldKeepFov(boolean boolean2) {
        return this.foxFix.getValue() && !boolean2 && this.wasSprinting;
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled()) {
            switch (event.getType()) {
                case PRE:
                    if (!mc.field_1690.field_1867.method_1434()) {
                        KeyBindUtil.setKeyBindState(this.getSprintKeyCode(), true);
                    }
                    break;
                case POST:
                    this.wasSprinting = mc.field_1724.method_5624();
            }
        }
    }

    @Override
    public void onDisabled() {
        this.wasSprinting = false;
        KeyBindUtil.updateKeyState(this.getSprintKeyCode());
    }

    private int getSprintKeyCode() {
        return class_3675.method_15981(mc.field_1690.field_1867.method_1428()).method_1444();
    }
}
