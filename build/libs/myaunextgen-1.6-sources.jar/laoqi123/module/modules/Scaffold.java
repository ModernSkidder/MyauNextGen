package laoqi123.module.modules;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.events.HitBlockEvent;
import laoqi123.events.LeftClickMouseEvent;
import laoqi123.events.LivingUpdateEvent;
import laoqi123.events.MoveInputEvent;
import laoqi123.events.Render2DEvent;
import laoqi123.events.RightClickMouseEvent;
import laoqi123.events.SafeWalkEvent;
import laoqi123.events.StrafeEvent;
import laoqi123.events.SwapItemEvent;
import laoqi123.events.UpdateEvent;
import laoqi123.management.RotationState;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.FloatProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.property.properties.ModeProperty;
import laoqi123.property.properties.PercentProperty;
import laoqi123.util.BlockData;
import laoqi123.util.BlockUtil;
import laoqi123.util.ItemUtil;
import laoqi123.util.MoveUtil;
import laoqi123.util.PacketUtil;
import laoqi123.util.PlayerUtil;
import laoqi123.util.RandomUtil;
import laoqi123.util.RotationUtil;
import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1294;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2879;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;

public class Scaffold extends Module {
    private static final class_310 mc = class_310.method_1551();
    private static final double[] placeOffsets = new double[]{
            0.03125,
            0.09375,
            0.15625,
            0.21875,
            0.28125,
            0.34375,
            0.40625,
            0.46875,
            0.53125,
            0.59375,
            0.65625,
            0.71875,
            0.78125,
            0.84375,
            0.90625,
            0.96875
    };

    private int rotationTick = 0;
    private int lastSlot = -1;
    private int blockCount = -1;
    private float yaw = -180.0F;
    private float pitch = 0.0F;
    private boolean canRotate = false;
    private int towerTick = 0;
    private int towerDelay = 0;
    private int stage = 0;
    private int startY = 256;
    private boolean shouldKeepY = false;
    private boolean towering = false;
    private class_2350 targetFacing = null;
    private boolean canplace = false;
    private boolean onairplace = false;
    private boolean pendingFlatDelay = false;
    private int currentFlatTick = 0;
    private boolean wasInAir = false;
    private boolean isSnapping = false;
    private int snapCooldown = 0;
    private int lastRotationTick = 0;
    private int rotationZeroCount = 0;
    private boolean hasPlacedThisJump = false;


    public final ModeProperty rotationMode = new ModeProperty("rotations", 1, new String[]{"NONE", "DEFAULT", "BACKWARDS", "SIDEWAYS", "OFFSET", "SNAP", "HYPIXEL"});
    public final ModeProperty moveFix = new ModeProperty("move-fix", 2, new String[]{"NONE", "SILENT"});
    public final ModeProperty sprintMode = new ModeProperty("sprint", 0, new String[]{"NONE", "VANILLA"});
    public final PercentProperty groundMotion = new PercentProperty("ground-motion", 100);
    public final PercentProperty airMotion = new PercentProperty("air-motion", 100);
    public final PercentProperty speedMotion = new PercentProperty("speed-motion", 100);
    public final BooleanProperty keepYonPress = new BooleanProperty("keep-y-on-press", false, () -> this.keepY.getValue() != 0);
    public final BooleanProperty multiplace = new BooleanProperty("multi-place", true);
    public final BooleanProperty safeWalk = new BooleanProperty("safe-walk", true);
    public final BooleanProperty swing = new BooleanProperty("swing", true);
    public final BooleanProperty itemSpoof = new BooleanProperty("item-spoof", false);
    public final BooleanProperty blockCounter = new BooleanProperty("block-counter", true);
    public final BooleanProperty candiffplace = new BooleanProperty("candiffplace", true);
    public final IntProperty towerFlatTicks = new IntProperty("delay-ticks", 4, 0, 20);
    public final IntProperty AngleDiff = new IntProperty("angle-diff", 50, 0, 180, candiffplace::getValue);
    public final FloatProperty tellyStartRotMinSpeed = new FloatProperty("telly-start-rotation-min-speed", 80.0F, 1.0F, 180.0F, () -> this.keepY.getValue() == 3 || this.keepY.getValue() == 4);
    public final FloatProperty tellyStartRotMaxSpeed = new FloatProperty("telly-start-rotation-max-speed", 85.0F, 1.0F, 180.0F, () -> this.keepY.getValue() == 3 || this.keepY.getValue() == 4);
    public final FloatProperty tellyNormalRotMinSpeed = new FloatProperty("telly-normal-rotation-min-speed", 30.0F, 1.0F, 180.0F, () -> this.keepY.getValue() == 3 || this.keepY.getValue() == 4);
    public final FloatProperty tellyNormalRotMaxSpeed = new FloatProperty("telly-normal-rotation-max-speed", 35.0F, 1.0F, 180.0F, () -> this.keepY.getValue() == 3 || this.keepY.getValue() == 4);
    public final ModeProperty rotationSpeed = new ModeProperty("rotation-speed", 4, new String[]{"1TICK", "2TICK", "3TICK", "4TICK", "NORMAL"});
    public final ModeProperty tower = new ModeProperty("tower", 0, new String[]{"NONE", "VANILLA", "EXTRA", "TELLY", "HYPIXEL"});
    public final ModeProperty keepY = new ModeProperty("keep-y", 0, new String[]{"NONE", "VANILLA", "EXTRA", "TELLY", "EXTRATELLY"});
    public final BooleanProperty spoofItem = new BooleanProperty("Spoof Item", true);
    public final BooleanProperty keepFoV = new BooleanProperty("Keep FoV", true);
    public final FloatProperty fovValue = new FloatProperty("Fov", 1.1F, 1.0F, 2.1F);



    private boolean isSnapDisabled() {
        boolean isKeepYEnabled = this.keepY.getValue() != 0;
        boolean isKeepYActive = isKeepYEnabled && (!this.keepYonPress.getValue() || PlayerUtil.isUsingItem());
        boolean isJumping = PlayerUtil.isJumping();

        return isKeepYActive || isJumping;
    }

    private boolean shouldStopSprint() {
        if (this.isTowering()) {
            return false;
        } else {
            if (this.rotationMode.getValue() == 5 && !this.isSnapDisabled()) {
                return false;
            }
            boolean stage = this.keepY.getValue() == 1 || this.keepY.getValue() == 2 || this.keepY.getValue() == 4;
            return (!stage || this.stage <= 0) && this.sprintMode.getValue() == 0;
        }
    }

    private boolean canPlace() {
        BedNuker bedNuker = (BedNuker) Myau.moduleManager.modules.get(BedNuker.class);
        if (bedNuker.isEnabled() && bedNuker.isReady()) {
            return false;
        } else {
            LongJump longJump = (LongJump) Myau.moduleManager.modules.get(LongJump.class);
            return !longJump.isEnabled() || !longJump.isAutoMode() || longJump.isJumping();
        }
    }

    private class_2350 getBestFacing(class_2338 blockPos1, class_2338 blockPos3) {
        double offset = 0.0;
        class_2350 direction = null;
        for (class_2350 facing : class_2350.values()) {
            if (facing != class_2350.field_11033) {
                class_2338 pos = blockPos1.method_10093(facing);
                if (pos.method_10264() <= blockPos3.method_10264()) {
                    double distance = pos.method_40081((double) blockPos3.method_10263() + 0.5, (double) blockPos3.method_10264() + 0.5, (double) blockPos3.method_10260() + 0.5);
                    if (direction == null || distance < offset || distance == offset && facing == class_2350.field_11036) {
                        offset = distance;
                        direction = facing;
                    }
                }
            }
        }
        return direction;
    }

    private BlockData getBlockData() {
        int startY = class_3532.method_15357(mc.field_1724.method_23318());

        int targetX, targetZ;
        boolean useSnap = this.rotationMode.getValue() == 5 && !this.isSnapDisabled();

        if (useSnap) {
            targetX = class_3532.method_15357(mc.field_1724.method_23317() + mc.field_1724.method_18798().field_1352 * 1);
            targetZ = class_3532.method_15357(mc.field_1724.method_23321() + mc.field_1724.method_18798().field_1350 * 1);
        } else {
            targetX = class_3532.method_15357(mc.field_1724.method_23317());
            targetZ = class_3532.method_15357(mc.field_1724.method_23321());
        }

        class_2338 targetPos = new class_2338(
                targetX,
                (this.stage != 0 && !this.shouldKeepY ? Math.min(startY, this.startY) : startY) - 1,
                targetZ
        );
        if (!BlockUtil.isReplaceable(targetPos)) {
            return null;
        } else {
            double reach = mc.field_1724.method_55754();
            ArrayList<class_2338> positions = new ArrayList<>();
            for (int x = -4; x <= 4; x++) {
                for (int y = -4; y <= 0; y++) {
                    for (int z = -4; z <= 4; z++) {
                        class_2338 pos = targetPos.method_10069(x, y, z);
                        if (!BlockUtil.isReplaceable(pos)
                                && !BlockUtil.isInteractable(pos)
                                && !(
                                mc.field_1724.method_5649((double) pos.method_10263() + 0.5, (double) pos.method_10264() + 0.5, (double) pos.method_10260() + 0.5)
                                        > reach * reach
                        )
                                && (this.stage == 0 || this.shouldKeepY || pos.method_10264() < this.startY)) {
                            for (class_2350 facing : class_2350.values()) {
                                if (facing != class_2350.field_11033) {
                                    class_2338 blockPos = pos.method_10093(facing);
                                    if (BlockUtil.isReplaceable(blockPos)) {
                                        positions.add(pos);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (positions.isEmpty()) {
                return null;
            } else {
                positions.sort(
                        Comparator.comparingDouble(
                                o -> o.method_40081((double) targetPos.method_10263() + 0.5, (double) targetPos.method_10264() + 0.5, (double) targetPos.method_10260() + 0.5)
                        )
                );
                class_2338 blockPos = positions.get(0);
                class_2350 facing = this.getBestFacing(blockPos, targetPos);
                return facing == null ? null : new BlockData(blockPos, facing);
            }
        }
    }

    private void place(class_2338 blockPos, class_2350 direction, class_243 vec3d) {
        if (mc.field_1761 == null) {
            return;
        }
        if (ItemUtil.isHoldingBlock() && this.blockCount > 0) {
            class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, new class_3965(vec3d, direction, blockPos, false));
            if (result.method_23665()) {
                if (mc.field_1761.method_2920() != class_1934.field_9220) {
                    this.blockCount--;
                }
                if (this.swing.getValue()) {
                    mc.field_1724.method_6104(class_1268.field_5808);
                } else {
                    PacketUtil.sendPacket(new class_2879(class_1268.field_5808));
                }
                if (!mc.field_1724.method_24828()) {
                    this.hasPlacedThisJump = true;
                }
            }
        }
    }

    private class_2350 yawToFacing(float yaw) {
        if (yaw < -135.0F || yaw > 135.0F) {
            return class_2350.field_11043;
        } else if (yaw < -45.0F) {
            return class_2350.field_11034;
        } else {
            return yaw < 45.0F ? class_2350.field_11035 : class_2350.field_11039;
        }
    }

    private double distanceToEdge(class_2350 direction) {
        switch (direction) {
            case field_11043:
                return mc.field_1724.method_23321() - Math.floor(mc.field_1724.method_23321());
            case field_11034:
                return Math.ceil(mc.field_1724.method_23317()) - mc.field_1724.method_23317();
            case field_11035:
                return Math.ceil(mc.field_1724.method_23321()) - mc.field_1724.method_23321();
            case field_11039:
            default:
                return mc.field_1724.method_23317() - Math.floor(mc.field_1724.method_23317());
        }
    }

    private float getSpeed() {
        if (!mc.field_1724.method_24828()) {
            return (float) this.airMotion.getValue() / 100.0F;
        } else {
            return MoveUtil.getSpeedLevel() > 0
                    ? (float) this.speedMotion.getValue() / 100.0F
                    : (float) this.groundMotion.getValue() / 100.0F;
        }
    }

    private double getRandomOffset() {
        return 0.2155 - RandomUtil.nextDouble(1.0E-4, 9.0E-4);
    }

    private float getCurrentYaw() {
        return MoveUtil.adjustYaw(
                mc.field_1724.method_36454(), (float) MoveUtil.getForwardValue(), (float) MoveUtil.getLeftValue()
        );
    }

    private boolean isDiagonal(float yaw) {
        float absYaw = Math.abs(yaw % 90.0F);
        return absYaw > 20.0F && absYaw < 70.0F;
    }

    public boolean isTowering() {
        if (this.currentFlatTick > 0) {
            return false;
        }
        if (mc.field_1724.method_24828() && MoveUtil.isForwardPressed() && !PlayerUtil.isAirAbove()) {
            boolean keepY = this.keepY.getValue() == 3 || this.keepY.getValue() == 4;
            boolean tower = this.tower.getValue() == 3 || this.tower.getValue() == 4;
            return keepY && this.stage > 0 || tower && PlayerUtil.isJumping();
        } else {
            return false;
        }
    }

    private boolean isNearEdge(double lookAhead) {
        double px = mc.field_1724.method_23317();
        double py = mc.field_1724.method_23318();
        double pz = mc.field_1724.method_23321();
        float moveYaw = MoveUtil.getMoveYaw();
        double dirX = -Math.sin(moveYaw * Math.PI / 180.0);
        double dirZ =  Math.cos(moveYaw * Math.PI / 180.0);
        int floorY = class_3532.method_15357(py - 1.0);

        for (double dist = 0.2; dist <= lookAhead; dist += 0.3) {
            int checkX = class_3532.method_15357(px + dirX * dist);
            int checkZ = class_3532.method_15357(pz + dirZ * dist);
            class_2338 below = new class_2338(checkX, floorY, checkZ);
            class_2248 block = mc.field_1687.method_8320(below).method_26204();
            if (!BlockUtil.isSolid(block) && !BlockUtil.isInteractable(block)) {
                return true;
            }
        }
        return false;
    }

    public Scaffold() {
        super("Scaffold", false);
    }

    public int getSlot() {
        return this.lastSlot;
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.rotationMode.getModeString()};
    }

    @EventTarget(Priority.HIGH)
    public void onUpdate(UpdateEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            if (mc.field_1724.method_24828()) {
                if (this.wasInAir && this.hasPlacedThisJump) {
                    this.rotationZeroCount++;

                    if (this.rotationZeroCount >= 2) {
                        this.currentFlatTick = this.towerFlatTicks.getValue();
                        this.rotationZeroCount = 0;
                    }
                }
                this.hasPlacedThisJump = false;
                this.wasInAir = false;
            } else {
                this.wasInAir = true;
            }

            if (this.currentFlatTick > 0) {
                this.currentFlatTick--;
            }
            if ((!this.onairplace) && mc.field_1724.method_24828()){
                this.onairplace = true;
            }
            if (this.rotationTick > 0) {
                this.rotationTick--;
            }
            if (this.snapCooldown > 0) {
                this.snapCooldown--;
            }
            if (mc.field_1724.method_24828()) {
                if (this.stage > 0) {
                    this.stage--;
                }
                if (this.stage < 0) {
                    this.stage++;
                }
                if (this.stage == 0
                        && this.keepY.getValue() != 0
                        && (!this.keepYonPress.getValue() || PlayerUtil.isUsingItem())
                        && !PlayerUtil.isJumping()) {
                    this.stage = 1;
                }
                this.startY = this.shouldKeepY ? this.startY : class_3532.method_15357(mc.field_1724.method_23318());
                this.shouldKeepY = false;
                this.towering = false;
            }
            if (this.canPlace()) {
                class_1799 stack = mc.field_1724.method_6047();
                int count = ItemUtil.isBlock(stack) ? stack.method_7947() : 0;
                this.blockCount = Math.min(this.blockCount, count);
                if (this.blockCount <= 0) {
                    int slot = mc.field_1724.method_31548().field_7545;
                    if (this.blockCount == 0) {
                        slot--;
                    }
                    for (int i = slot; i > slot - 9; i--) {
                        int hotbarSlot = (i % 9 + 9) % 9;
                        class_1799 candidate = mc.field_1724.method_31548().method_5438(hotbarSlot);
                        if (ItemUtil.isBlock(candidate)) {
                            mc.field_1724.method_31548().field_7545 = hotbarSlot;
                            this.blockCount = candidate.method_7947();
                            break;
                        }
                    }
                }

                float currentYaw = this.getCurrentYaw();
                float yawDiffTo180 = RotationUtil.wrapAngleDiff(currentYaw - 180.0F, event.getYaw());
                float diagonalYaw = this.isDiagonal(currentYaw)
                        ? yawDiffTo180
                        : RotationUtil.wrapAngleDiff(currentYaw - 135.0F * ((currentYaw + 180.0F) % 90.0F < 45.0F ? 1.0F : -1.0F), event.getYaw());

                boolean useSnap = this.rotationMode.getValue() == 5 && !this.isSnapDisabled();
                int effectiveMode = useSnap ? 5 : (this.rotationMode.getValue() == 5 ? 3 : this.rotationMode.getValue());

                if (useSnap) {
                    BlockData data = this.getBlockData();
                    if (data != null && this.snapCooldown == 0) {
                        this.yaw = RotationUtil.quantizeAngle(diagonalYaw);
                        this.pitch = RotationUtil.quantizeAngle(85.0F);
                        this.canRotate = true;
                        this.isSnapping = true;
                    } else {
                        this.yaw = RotationUtil.quantizeAngle(mc.field_1724.method_36454());
                        this.pitch = RotationUtil.quantizeAngle(mc.field_1724.method_36455());
                        this.canRotate = true;
                        this.isSnapping = false;
                    }
                } else if (!this.canRotate) {
                    switch (effectiveMode) {
                        case 1:
                            if (this.yaw == -180.0F && this.pitch == 0.0F) {
                                this.yaw = RotationUtil.quantizeAngle(diagonalYaw);
                                this.pitch = RotationUtil.quantizeAngle(85.0F);
                            } else {
                                this.yaw = RotationUtil.quantizeAngle(diagonalYaw);
                            }
                            break;
                        case 2:
                            if (this.yaw == -180.0F && this.pitch == 0.0F) {
                                this.yaw = RotationUtil.quantizeAngle(yawDiffTo180);
                                this.pitch = RotationUtil.quantizeAngle(85.0F);
                            } else {
                                this.yaw = RotationUtil.quantizeAngle(yawDiffTo180);
                            }
                            break;
                        case 3:
                            if (this.yaw == -180.0F && this.pitch == 0.0F) {
                                this.yaw = RotationUtil.quantizeAngle(diagonalYaw);
                                this.pitch = RotationUtil.quantizeAngle(85.0F);
                            } else {
                                this.yaw = RotationUtil.quantizeAngle(diagonalYaw);
                            }
                            break;
                        case 4:
                            float roundedYaw = Math.round(currentYaw / 45.0f) * 45.0f;
                            this.yaw = RotationUtil.quantizeAngle(roundedYaw);
                            if (this.pitch == 0.0F || !this.canRotate) {
                                this.pitch = RotationUtil.quantizeAngle(79.3F);
                            }
                            break;
                        case 5:
                            if (this.yaw == -180.0F && this.pitch == 0.0F) {
                                this.yaw = RotationUtil.quantizeAngle(diagonalYaw);
                                this.pitch = RotationUtil.quantizeAngle(85.0F);
                            } else {
                                float targetYaw = this.isDiagonal(currentYaw) ? diagonalYaw : yawDiffTo180;
                                float yawDiff = class_3532.method_15393(targetYaw - this.yaw);
                                float pitchDiff = class_3532.method_15393(85.0F - this.pitch);
                                float yawTolerance = this.rotationTick >= 2
                                        ? RandomUtil.nextFloat(tellyStartRotMinSpeed.getValue(), tellyStartRotMaxSpeed.getValue())
                                        : RandomUtil.nextFloat(tellyNormalRotMinSpeed.getValue(), tellyNormalRotMaxSpeed.getValue());
                                float pitchTolerance = this.rotationTick >= 2
                                        ? RandomUtil.nextFloat(tellyStartRotMinSpeed.getValue(), tellyStartRotMaxSpeed.getValue())
                                        : RandomUtil.nextFloat(tellyNormalRotMinSpeed.getValue(), tellyNormalRotMaxSpeed.getValue());
                                this.yaw = RotationUtil.quantizeAngle(this.yaw + RotationUtil.clampAngle(yawDiff, yawTolerance));
                                this.pitch = RotationUtil.quantizeAngle(this.pitch + RotationUtil.clampAngle(pitchDiff, pitchTolerance));
                            }
                            break;
                    }
                }

                BlockData blockData = this.getBlockData();
                class_243 hitVec = null;
                if (blockData != null) {
                    if (useSnap && !this.isSnapping) {
                    } else {
                        double[] x = placeOffsets;
                        double[] y = placeOffsets;
                        double[] z = placeOffsets;
                        switch (blockData.facing()) {
                            case field_11043: z = new double[]{0.0}; break;
                            case field_11034:  x = new double[]{1.0}; break;
                            case field_11035: z = new double[]{1.0}; break;
                            case field_11039:  x = new double[]{0.0}; break;
                            case field_11033:  y = new double[]{0.0}; break;
                            case field_11036:    y = new double[]{1.0}; break;
                        }
                        float bestYaw = -180.0F;
                        float bestPitch = 0.0F;
                        float bestDiff = 0.0F;
                        for (double dx : x) {
                            for (double dy : y) {
                                for (double dz : z) {
                                    double relX = (double) blockData.pos().method_10263() + dx - mc.field_1724.method_23317();
                                    double relY = (double) blockData.pos().method_10264() + dy - mc.field_1724.method_23318() - (double) mc.field_1724.method_18381(mc.field_1724.method_18376());
                                    double relZ = (double) blockData.pos().method_10260() + dz - mc.field_1724.method_23321();
                                    float baseYaw = RotationUtil.wrapAngleDiff(this.yaw, event.getYaw());
                                    float[] rotations = RotationUtil.getRotationsTo(relX, relY, relZ, baseYaw, this.pitch);
                                    class_239 mop = RotationUtil.rayTrace(rotations[0], rotations[1], mc.field_1724.method_55754(), 1.0F);
                                    if (mop != null
                                            && mop.method_17783() == class_239.class_240.field_1332
                                            && ((class_3965) mop).method_17777().equals(blockData.pos())
                                            && ((class_3965) mop).method_17780() == blockData.facing()) {
                                        float totalDiff = Math.abs(rotations[0] - baseYaw) + Math.abs(rotations[1] - this.pitch);
                                        if (bestYaw == -180.0F && bestPitch == 0.0F || totalDiff < bestDiff) {
                                            bestYaw = rotations[0];
                                            bestPitch = rotations[1];
                                            bestDiff = totalDiff;
                                            hitVec = mop.method_17784();
                                        }
                                    }
                                }
                            }
                        }
                        if (bestYaw != -180.0F || bestPitch != 0.0F) {
                            this.yaw = bestYaw;
                            this.pitch = bestPitch;
                            this.canRotate = true;
                        }
                    }
                }

                boolean isTellyTowering = this.isTowering() && this.tower.getValue() == 3;
                if (this.canRotate && MoveUtil.isForwardPressed() && Math.abs(class_3532.method_15393(yawDiffTo180 - this.yaw)) < 90.0F) {
                    if (!(isTellyTowering && effectiveMode == 3)) {
                        switch (effectiveMode) {
                            case 2:
                                this.yaw = RotationUtil.quantizeAngle(yawDiffTo180);
                                break;
                            case 3:
                                this.yaw = RotationUtil.quantizeAngle(diagonalYaw);
                                break;
                        }
                    }
                }

                if (effectiveMode != 0) {
                    boolean keepYActive = (this.keepY.getValue() != 0) && (this.stage > 0 || this.shouldKeepY);
                    float targetYaw = this.yaw;
                    float targetPitch = this.pitch;
                    if (this.towering && !useSnap
                            && (mc.field_1724.method_18798().field_1351 > 0.0 || mc.field_1724.method_23318() > (double)(this.startY + 1))) {
                        float yawDiff = class_3532.method_15393(this.yaw - event.getYaw());
                        float tolerance = this.rotationTick >= 2
                                ? RandomUtil.nextFloat(tellyStartRotMinSpeed.getValue(), tellyStartRotMaxSpeed.getValue())
                                : RandomUtil.nextFloat(tellyNormalRotMinSpeed.getValue(), tellyNormalRotMaxSpeed.getValue());
                        if (Math.abs(yawDiff) > tolerance) {
                            float clampedYaw = RotationUtil.clampAngle(yawDiff, tolerance);
                            targetYaw = RotationUtil.quantizeAngle(event.getYaw() + clampedYaw);
                            if (!keepYActive && !useSnap
                                    && (mc.field_1724.method_18798().field_1351 > 0.0 || mc.field_1724.method_23318() > (double)(this.startY + 1)) && candiffplace.getValue()){
                                this.rotationTick = 0;
                            } else {
                                this.rotationTick = 1;
                            }
                        }
                    }

                    if (useSnap) {
                        float diffYaw = class_3532.method_15393(targetYaw - event.getYaw());
                        float diffPitch = targetPitch - event.getPitch();
                        float maxSnapDelta = 100.0F;
                        if (Math.abs(diffYaw) > maxSnapDelta) {
                            targetYaw = event.getYaw() + Math.copySign(maxSnapDelta, diffYaw);
                        }
                        if (Math.abs(diffPitch) > maxSnapDelta) {
                            targetPitch = event.getPitch() + Math.copySign(maxSnapDelta, diffPitch);
                        }
                    } else if (this.rotationSpeed.getValue() < 5) {
                        int speedTicks = this.rotationSpeed.getValue() + 1;
                        float diffYaw = class_3532.method_15393(targetYaw - event.getYaw());
                        float diffPitch = targetPitch - event.getPitch();
                        float maxYawDelta = 360.0F / speedTicks;
                        float maxPitchDelta = 360.0F / speedTicks;
                        if (Math.abs(diffYaw) > maxYawDelta) {
                            targetYaw = event.getYaw() + Math.copySign(maxYawDelta, diffYaw);
                        }
                        if (Math.abs(diffPitch) > maxPitchDelta) {
                            targetPitch = event.getPitch() + Math.copySign(maxPitchDelta, diffPitch);
                        }
                    }

                    if (this.isTowering() && !useSnap) {
                        float optimalYaw = this.yaw;
                        float optimalPitch = this.pitch;
                        float yawDelta = class_3532.method_15393(mc.field_1724.method_36454() - event.getYaw());
                        targetYaw = RotationUtil.quantizeAngle(event.getYaw() + yawDelta * RandomUtil.nextFloat(0.98F, 0.99F));
                        targetPitch = RotationUtil.quantizeAngle(RandomUtil.nextFloat(25.0F, 70.0F));
                        this.towering = true;
                        if (this.tower.getValue() == 4) {
                            double yaw1 = Math.toRadians(optimalYaw);
                            double pitch1 = Math.toRadians(optimalPitch);
                            double yaw2 = Math.toRadians(targetYaw);
                            double pitch2 = Math.toRadians(targetPitch);
                            double dx1 = -Math.sin(yaw1) * Math.cos(pitch1);
                            double dy1 = -Math.sin(pitch1);
                            double dz1 =  Math.cos(yaw1) * Math.cos(pitch1);
                            double dx2 = -Math.sin(yaw2) * Math.cos(pitch2);
                            double dy2 = -Math.sin(pitch2);
                            double dz2 =  Math.cos(yaw2) * Math.cos(pitch2);
                            double dot = dx1 * dx2 + dy1 * dy2 + dz1 * dz2;
                            dot = Math.max(-1.0, Math.min(1.0, dot));
                            double angleDiffDeg = Math.toDegrees(Math.acos(dot));
                            double maxDiff = (double) this.AngleDiff.getValue();
                            this.canplace = angleDiffDeg < maxDiff;
                            if (angleDiffDeg < maxDiff) {
                                this.rotationTick = 3;
                            }
                        }
                    }
                    event.setRotation(targetYaw, targetPitch, 3);
                    if (this.moveFix.getValue() == 1) {
                        event.setPervRotation(targetYaw, 3);
                    }
                }

                boolean canSnapPlace = true;
                if (useSnap) {
                    boolean isMoving = Math.abs(mc.field_1724.method_18798().field_1352) > 0.02 || Math.abs(mc.field_1724.method_18798().field_1350) > 0.02;
                    boolean nearEdge = isNearEdge(1.0);
                    boolean isRunningToEdge = isMoving && (PlayerUtil.isAirBelow() || nearEdge);

                    if (this.isSnapping) {
                        float absoluteYawDiff = Math.abs(class_3532.method_15393(this.yaw - event.getYaw()));
                        if (absoluteYawDiff > 45.0F && !isRunningToEdge) {
                            canSnapPlace = false;
                        }
                    } else {
                        if (PlayerUtil.isAirBelow()) {
                            this.isSnapping = true;
                            this.snapCooldown = 0;
                            canSnapPlace = true;
                        } else {
                            canSnapPlace = false;
                        }
                    }
                }

                if ((blockData != null && hitVec != null && this.rotationTick <= 0 && canSnapPlace)) {
                    this.place(blockData.pos(), blockData.facing(), hitVec);

                    if (useSnap) {
                        this.snapCooldown = 1;
                        this.isSnapping = false;
                    }

                    if (this.multiplace.getValue() && !useSnap) {
                        for (int i = 0; i < 2; i++) {
                            blockData = this.getBlockData();
                            if (blockData == null) {
                                break;
                            }
                            class_239 mop = RotationUtil.rayTrace(this.yaw, this.pitch, mc.field_1724.method_55754(), 1.0F);
                            if (mop != null
                                    && mop.method_17783() == class_239.class_240.field_1332
                                    && ((class_3965) mop).method_17777().equals(blockData.pos())
                                    && ((class_3965) mop).method_17780() == blockData.facing()) {
                                this.place(blockData.pos(), blockData.facing(), mop.method_17784());
                            } else {
                                hitVec = BlockUtil.getClickVec(blockData.pos(), blockData.facing());
                                double dx = hitVec.field_1352 - mc.field_1724.method_23317();
                                double dy = hitVec.field_1351 - mc.field_1724.method_23318() - (double) mc.field_1724.method_18381(mc.field_1724.method_18376());
                                double dz = hitVec.field_1350 - mc.field_1724.method_23321();
                                float[] rotations = RotationUtil.getRotationsTo(dx, dy, dz, event.getYaw(), event.getPitch());
                                if (!(Math.abs(rotations[0] - this.yaw) < 120.0F) || !(Math.abs(rotations[1] - this.pitch) < 60.0F)) {
                                    break;
                                }
                                mop = RotationUtil.rayTrace(rotations[0], rotations[1], mc.field_1724.method_55754(), 1.0F);
                                if (mop == null
                                        || mop.method_17783() != class_239.class_240.field_1332
                                        || !((class_3965) mop).method_17777().equals(blockData.pos())
                                        || ((class_3965) mop).method_17780() != blockData.facing()) {
                                    break;
                                }
                                this.place(blockData.pos(), blockData.facing(), mop.method_17784());
                            }
                        }
                    }
                }
                if (this.targetFacing != null && canSnapPlace) {
                    if ((this.rotationTick <= 0) ||(this.rotationTick <= 1 && this.tower.getValue() == 4 && this.canplace && this.onairplace && candiffplace.getValue())) {
                        int playerBlockX = class_3532.method_15357(mc.field_1724.method_23317());
                        int playerBlockY = class_3532.method_15357(mc.field_1724.method_23318());
                        int playerBlockZ = class_3532.method_15357(mc.field_1724.method_23321());
                        class_2338 belowPlayer = new class_2338(playerBlockX, playerBlockY - 1, playerBlockZ);
                        hitVec = BlockUtil.getHitVec(belowPlayer, this.targetFacing, this.yaw, this.pitch);
                        this.place(belowPlayer, this.targetFacing, hitVec);
                        if (useSnap) {
                            this.snapCooldown = 3;
                            this.isSnapping = false;
                        }
                    }
                    this.targetFacing = null;
                } else if ((this.keepY.getValue() == 2 || this.keepY.getValue() == 4) && this.stage > 0 && !mc.field_1724.method_24828() && canSnapPlace) {
                    int nextBlockY = class_3532.method_15357(mc.field_1724.method_23318() + mc.field_1724.method_18798().field_1351);
                    if (nextBlockY <= this.startY && mc.field_1724.method_23318() > (double) (this.startY + 1)) {
                        this.shouldKeepY = true;
                        blockData = this.getBlockData();
                        if ((blockData != null && this.rotationTick <= 0)||(blockData != null && this.rotationTick <= 1 && this.tower.getValue() == 4 && this.canplace && this.onairplace && candiffplace.getValue())) {
                            hitVec = BlockUtil.getHitVec(blockData.pos(), blockData.facing(), this.yaw, this.pitch);
                            this.place(blockData.pos(), blockData.facing(), hitVec);
                            if (useSnap) {
                                this.snapCooldown = 3;
                                this.isSnapping = false;
                            }
                        }
                    }
                }
            }
        }
    }

    @EventTarget
    public void onStrafe(StrafeEvent event) {
        if (this.isEnabled()) {
            if (this.currentFlatTick > 0) {
                this.towerTick = 0;
                this.towerDelay = 0;
                return;
            }
            if (!mc.field_1724.field_5976
                    && mc.field_1724.field_6235 <= 5
                    && !mc.field_1724.method_6059(class_1294.field_5913)
                    && PlayerUtil.isJumping()
                    && ItemUtil.isHoldingBlock()) {
                int yState = (int) (mc.field_1724.method_23318() % 1.0 * 100.0);
                switch (this.tower.getValue()) {
                    case 1:
                        switch (this.towerTick) {
                            case 0:
                                if (mc.field_1724.method_24828()) {
                                    this.towerTick = 1;
                                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, -0.0784000015258789, mc.field_1724.method_18798().field_1350);
                                }
                                return;
                            case 1:
                                if (yState == 0 && PlayerUtil.isAirBelow()) {
                                    this.startY = class_3532.method_15357(mc.field_1724.method_23318());
                                    this.towerTick = 2;
                                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.42F, mc.field_1724.method_18798().field_1350);
                                    if (MoveUtil.isForwardPressed()) {
                                        MoveUtil.setSpeed(MoveUtil.getSpeed(), MoveUtil.getMoveYaw());
                                    } else {
                                        MoveUtil.setSpeed(0.0);
                                        event.setForward(0.0F);
                                        event.setStrafe(0.0F);
                                    }
                                    return;
                                } else {
                                    this.towerTick = 0;
                                    return;
                                }
                            case 2:
                                this.towerTick = 3;
                                mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.75 - mc.field_1724.method_23318() % 1.0, mc.field_1724.method_18798().field_1350);
                                return;
                            case 3:
                                this.towerTick = 1;
                                mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 1.0 - mc.field_1724.method_23318() % 1.0, mc.field_1724.method_18798().field_1350);
                                return;
                            default:
                                this.towerTick = 0;
                                return;
                        }
                    case 2:
                        switch (this.towerTick) {
                            case 0:
                                if (mc.field_1724.method_24828()) {
                                    this.towerTick = 1;
                                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, -0.0784000015258789, mc.field_1724.method_18798().field_1350);
                                }
                                return;
                            case 1:
                                if (yState == 0 && PlayerUtil.isAirBelow()) {
                                    this.startY = class_3532.method_15357(mc.field_1724.method_23318());
                                    if (!MoveUtil.isForwardPressed()) {
                                        this.towerDelay = 2;
                                        MoveUtil.setSpeed(0.0);
                                        event.setForward(0.0F);
                                        event.setStrafe(0.0F);
                                        class_2350 facing = this.yawToFacing(class_3532.method_15393(this.yaw - 180.0F));
                                        double distance = this.distanceToEdge(facing);
                                        if (distance > 0.1) {
                                            if (mc.field_1724.method_24828()) {
                                                class_2382 directionVec = facing.method_62675();
                                                double offset = Math.min(this.getRandomOffset(), distance - 0.05);
                                                double jitter = RandomUtil.nextDouble(0.02, 0.03);
                                                class_238 nextBox = mc.field_1724
                                                        .method_5829()
                                                        .method_989((double) directionVec.method_10263() * (offset - jitter), 0.0, (double) directionVec.method_10260() * (offset - jitter));
                                                if (mc.field_1687.method_18026(nextBox)) {
                                                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, -0.0784000015258789, mc.field_1724.method_18798().field_1350);
                                                    mc.field_1724
                                                            .method_5814(nextBox.field_1323 + (nextBox.field_1320 - nextBox.field_1323) / 2.0, nextBox.field_1322, nextBox.field_1321 + (nextBox.field_1324 - nextBox.field_1321) / 2.0);
                                                }
                                                return;
                                            }
                                        } else {
                                            this.towerTick = 2;
                                            this.targetFacing = facing;
                                            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.42F, mc.field_1724.method_18798().field_1350);
                                        }
                                        return;
                                    } else {
                                        this.towerTick = 2;
                                        this.towerDelay++;
                                        mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.42F, mc.field_1724.method_18798().field_1350);
                                        MoveUtil.setSpeed(MoveUtil.getSpeed(), MoveUtil.getMoveYaw());
                                        return;
                                    }
                                } else {
                                    this.towerTick = 0;
                                    this.towerDelay = 0;
                                    return;
                                }
                            case 2:
                                this.towerTick = 3;
                                mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, mc.field_1724.method_18798().field_1351 - RandomUtil.nextDouble(0.00101, 0.00109), mc.field_1724.method_18798().field_1350);
                                return;
                            case 3:
                                if (this.towerDelay >= 4) {
                                    this.towerTick = 4;
                                    this.towerDelay = 0;
                                } else {
                                    this.towerTick = 1;
                                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 1.0 - mc.field_1724.method_23318() % 1.0, mc.field_1724.method_18798().field_1350);
                                }
                                return;
                            case 4:
                                this.towerTick = 5;
                                return;
                            case 5:
                                if (!PlayerUtil.isAirBelow()) {
                                    this.towerTick = 0;
                                } else {
                                    this.towerTick = 1;
                                    double motionY = mc.field_1724.method_18798().field_1351;
                                    motionY -= 0.08;
                                    motionY *= 0.98F;
                                    motionY -= 0.08;
                                    motionY *= 0.98F;
                                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, motionY, mc.field_1724.method_18798().field_1350);
                                }
                                return;
                            default:
                                this.towerTick = 0;
                                this.towerDelay = 0;
                                return;
                        }
                    case 4:
                        if (mc.field_1724.method_18798().field_1352 == 0 && mc.field_1724.method_18798().field_1350 == 0) {
                            if (yState == 0 && PlayerUtil.isAirBelow() && mc.field_1724.method_24828()) {
                                this.startY = class_3532.method_15357(mc.field_1724.method_23318());
                                mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.42F, mc.field_1724.method_18798().field_1350);
                            }
                            if (!mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 < 0.0) {
                                mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, -0.3F, mc.field_1724.method_18798().field_1350);
                            }
                            this.towerTick = 0;
                            this.towerDelay = 0;
                            return;
                        } else {
                            break;
                        }
                    default:
                        this.towerTick = 0;
                        this.towerDelay = 0;
                }
            } else {
                this.towerTick = 0;
                this.towerDelay = 0;
            }
        }
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (this.isEnabled()) {
            if (this.moveFix.getValue() == 1
                    && RotationState.isActived()
                    && RotationState.getPriority() == 3.0F
                    && MoveUtil.isForwardPressed()) {
                MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
            }
            if (mc.field_1724.method_24828() && this.stage > 0 && MoveUtil.isForwardPressed()) {
                class_10185 pi = mc.field_1724.field_3913.field_54155;
                mc.field_1724.field_3913.field_54155 = new class_10185(pi.comp_3159(), pi.comp_3160(), pi.comp_3161(), pi.comp_3162(), true, pi.comp_3164(), pi.comp_3165());
            }
        }
    }

    @EventTarget
    public void onLivingUpdate(LivingUpdateEvent event) {
        if (this.isEnabled()) {
            float speed = this.getSpeed();
            if (speed != 1.0F) {
                if (mc.field_1724.field_3913.field_3905 != 0.0F && mc.field_1724.field_3913.field_3907 != 0.0F) {
                    mc.field_1724.field_3913.field_3905 = mc.field_1724.field_3913.field_3905 * (1.0F / (float) Math.sqrt(2.0));
                    mc.field_1724.field_3913.field_3907 = mc.field_1724.field_3913.field_3907 * (1.0F / (float) Math.sqrt(2.0));
                }
                mc.field_1724.field_3913.field_3905 *= speed;
                mc.field_1724.field_3913.field_3907 *= speed;
            }
            if (this.shouldStopSprint()) {
                mc.field_1724.method_5728(false);
            }
        }
    }

    @EventTarget
    public void onSafeWalk(SafeWalkEvent event) {
        if (this.isEnabled() && this.safeWalk.getValue()) {
            if (mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 <= 0.0 && PlayerUtil.canMove(mc.field_1724.method_18798().field_1352, mc.field_1724.method_18798().field_1350, -1.0)) {
                event.setSafeWalk(true);
            }
        }
    }

    @EventTarget
    public void onRender(Render2DEvent event) {
        if (this.isEnabled()) {
            if (this.blockCounter.getValue()) {
                int count = 0;
                for (int i = 0; i < 9; i++) {
                    class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                    if (stack != null && stack.method_7947() > 0) {
                        class_1792 item = stack.method_7909();
                        if (item instanceof class_1747) {
                            class_2248 block = ((class_1747) item).method_7711();
                            if (!BlockUtil.isInteractable(block) && BlockUtil.isSolid(block)) {
                                count += stack.method_7947();
                            }
                        }
                    }
                }
                HUD hud = (HUD) Myau.moduleManager.modules.get(HUD.class);
                float scale = hud.scale.getValue();
                String text = String.format("%d block%s left", count, count != 1 ? "s" : "");
                float x = ((float) mc.method_22683().method_4486() / 2.0F + (float) mc.field_1772.field_2000 * 1.5F) / scale;
                float y = (float) mc.method_22683().method_4502() / 2.0F / scale - (float) mc.field_1772.field_2000 / 2.0F + 1.0F;
                int color = (count > 0 ? Color.WHITE.getRGB() : new Color(255, 85, 85).getRGB()) | -1090519040;
                event.getContext().method_51433(mc.field_1772, text, (int) x, (int) y, color, hud.shadow.getValue());
            }
        }
    }

    @EventTarget
    public void onLeftClick(LeftClickMouseEvent event) {
        if (this.isEnabled()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onRightClick(RightClickMouseEvent event) {
        if (this.isEnabled()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onHitBlock(HitBlockEvent event) {
        if (this.isEnabled()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onSwap(SwapItemEvent event) {
        if (this.isEnabled()) {
            this.lastSlot = event.setSlot(this.lastSlot);
            event.setCancelled(true);
        }
    }

    @Override
    public void onEnabled() {
        if (mc.field_1724 != null) {
            this.lastSlot = mc.field_1724.method_31548().field_7545;
        } else {
            this.lastSlot = -1;
        }
        this.blockCount = -1;
        this.rotationTick = 0;
        this.yaw = -180.0F;
        this.pitch = 0.0F;
        this.canRotate = false;
        this.towerTick = 0;
        this.towerDelay = 0;
        this.towering = false;
        this.snapCooldown = 0;
        this.isSnapping = false;
        this.pendingFlatDelay = false;
        this.hasPlacedThisJump = false;
        if (mc.field_1724 != null && !mc.field_1724.method_24828()) {
            this.onairplace = false;
        }
        if (mc.field_1724 != null && mc.field_1724.method_24828()) {
            this.onairplace = true;
        }
        this.lastRotationTick = 0;
        this.rotationZeroCount = 0;
        this.currentFlatTick = 0;

    }

    @Override
    public void onDisabled() {
        if (mc.field_1724 != null && this.lastSlot != -1) {
            mc.field_1724.method_31548().field_7545 = this.lastSlot;
        }
        this.onairplace = false;
    }
}
