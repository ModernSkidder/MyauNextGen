package laoqi123.module.modules;

import com.google.common.base.CaseFormat;
import laoqi123.Myau;
import laoqi123.event.EventManager;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.events.*;
import laoqi123.mixin.EntityAccessor;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.property.properties.ModeProperty;
import laoqi123.property.properties.PercentProperty;
import laoqi123.util.ChatUtil;
import laoqi123.util.KeyBindUtil;
import laoqi123.util.MoveUtil;
import laoqi123.util.PacketUtil;
import laoqi123.util.RayCastUtil;
import laoqi123.util.RotationUtil;
import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2616;
import net.minecraft.class_2645;
import net.minecraft.class_2661;
import net.minecraft.class_2663;
import net.minecraft.class_2664;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2749;
import net.minecraft.class_2767;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3966;
import net.minecraft.class_490;
import net.minecraft.class_5892;
import net.minecraft.class_5900;
import net.minecraft.class_5904;
import net.minecraft.class_7438;
import net.minecraft.class_7439;
import net.minecraft.class_8043;
import net.minecraft.network.packet.c2s.play.*;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;

public class Velocity extends Module {
    private static final class_310 mc = class_310.method_1551();

    private int chanceCounter = 0;
    private boolean pendingExplosion = false;
    private boolean allowNext = true;
    private boolean jumpFlag = false;

    private int rotatoTickCounter = 0;
    private double knockbackX = 0;
    private double knockbackZ = 0;
    private float[] targetRotation = null;
    private int reduceTick = -1;
    private boolean pressed = false;
    private boolean hasReceivedVelocity = false;
    private int ticksSinceVelocity = -1;
    public static boolean extraAttacked = false;
    public static boolean velocityAttacked = false;

    private boolean ShouldJump = false;

    private int slapReduceTicks = 0;
    private int slapAnInt = 0;
    private boolean slot = false;
    private boolean attack = false;
    private boolean swing = false;
    private boolean block = false;
    private boolean inventory = false;
    private boolean dig = false;

    private int attackCooldown = 0;
    private int attackCount = 0;
    private class_1297 attackTarget = null;
    private int attacksRemaining = 0;
    private int flagCooldown = 0;
    private boolean shouldJump = false;
    private int sprintBoostCounter = 0;
    private int hitCounter = 0;
    private boolean isSuspending = false;
    private int suspendTicks = 0;
    private boolean pendingRelease = false;
    private boolean grimSuspending = false;
    private int grimSuspendTicks = 0;
    private boolean grimKnockback = false;
    private boolean polarKb = false;
    private double polarSb = 0;
    private boolean delayActive = false;
    private int delayChanceCounter = 0;
    private int delayTickCount = 0;
    private class_2743 knockbackPacket = null;
    private final Deque<class_2596<?>> packetQueue = new ConcurrentLinkedDeque<>();
    private final Deque<class_2828> movePacketQueue = new ConcurrentLinkedDeque<>();
    private boolean isFlushing = false;
    private float instantAttackProgress = 0.0F;
    private boolean isInstantAttacking = false;
    private boolean shouldFlushMotion = false;

    public final ModeProperty mode = new ModeProperty("mode", 0, new String[]{"Vanilla", "Jump", "Hypixel", "Slap_Attack", "NoXZ", "GrimReduce", "Polar", "Delay"});
    public final ModeProperty polarMode = new ModeProperty("Polar Mode", 0, new String[]{"Reduce", "Cancel10%"}, () -> mode.getValue() == 6);

    public final IntProperty delayTicks = new IntProperty("delay-ticks", 3, 1, 20, () -> mode.getValue() == 7);
    public final PercentProperty delayChance = new PercentProperty("delay-chance", 100, () -> mode.getValue() == 7);

    public final IntProperty attackAmount = new IntProperty("Attack amount", 5, 1, 20, () -> mode.getValue() == 4);
    public final BooleanProperty instantAttack = new BooleanProperty("Instant Attack", false, () -> mode.getValue() == 4);
    public final BooleanProperty sprintStateCheck = new BooleanProperty("Sprint state check", true, () -> mode.getValue() == 4);

    public final PercentProperty chance = new PercentProperty("chance", 100, () -> mode.getValue() <= 1 || mode.getValue() == 7);
    public final PercentProperty horizontal = new PercentProperty("horizontal", 0, () -> mode.getValue() <= 1 || mode.getValue() == 7);
    public final PercentProperty vertical = new PercentProperty("vertical", 100, () -> mode.getValue() <= 1 || mode.getValue() == 7);
    public final PercentProperty explosionHorizontal = new PercentProperty("explosions-horizontal", 100, () -> mode.getValue() <= 1 || mode.getValue() == 7);
    public final PercentProperty explosionVertical = new PercentProperty("explosions-vertical", 100, () -> mode.getValue() <= 1 || mode.getValue() == 7);

    public final BooleanProperty reduce = new BooleanProperty("reduce", true, () -> mode.getValue() == 2);
    public final IntProperty attackTimes = new IntProperty("attack-times", 1, 1, 5, () -> mode.getValue() == 2 && reduce.getValue());
    private final BooleanProperty onlySprinting = new BooleanProperty("only-sprinting", true, () -> mode.getValue() == 2 && reduce.getValue());
    private final BooleanProperty reduceWhenCanAttack = new BooleanProperty("reduce-when-can-attack", true, () -> mode.getValue() == 2 && reduce.getValue());
    public final BooleanProperty hypixelJump = new BooleanProperty("jump", true, () -> mode.getValue() == 2);
    public final BooleanProperty rotate = new BooleanProperty("rotate", false, () -> mode.getValue() == 2);
    public final IntProperty rotateTick = new IntProperty("rotate-ticks", 3, 1, 12, () -> mode.getValue() == 2 && rotate.getValue());

    public final BooleanProperty slapReduce = new BooleanProperty("reduce", true, () -> mode.getValue() == 3);
    public final BooleanProperty tickExactEnable = new BooleanProperty("tickExact", true, () -> mode.getValue() == 3);
    public final IntProperty tick500 = new IntProperty("500", 3, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty tick1000 = new IntProperty("1000", 4, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty tick2000 = new IntProperty("2000", 4, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty tick3000 = new IntProperty("3000", 5, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty tick4000 = new IntProperty("4000", 6, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty tick5000 = new IntProperty("5000", 6, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty tick6000 = new IntProperty("6000", 7, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty tick7000 = new IntProperty("7000", 7, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty tick8000 = new IntProperty("8000", 8, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty tick9000 = new IntProperty("9000", 8, 0, 20, () -> mode.getValue() == 3);
    public final IntProperty tick10000 = new IntProperty("10000", 9, 0, 20, () -> mode.getValue() == 3);

    public final BooleanProperty fakeCheck = new BooleanProperty("fake-check", true);
    public final BooleanProperty debugLog = new BooleanProperty("debug-log", false);
    public final BooleanProperty timer = new BooleanProperty("Timer", false);

    public final IntProperty maxAirTicks = new IntProperty("Max Air Ticks", 12, 4, 20, () -> mode.getValue() == 5);
    public final IntProperty reach = new IntProperty("Reach", 3, 2, 4, () -> mode.getValue() == 5);

    private long lastTimerAttackTime = -1L;
    private long timerEnableAt = -1L;
    private boolean timerEnabledByVelocity = false;
    private boolean timerJumpPending = false;
    private float savedTimerSpeed = 1.0F;

    public Velocity() {
        super("Velocity", false);
    }

    private boolean isInLiquidOrWeb() {
        return mc.field_1724.method_5799() || mc.field_1724.method_5771() || ((EntityAccessor) mc.field_1724).getIsInWeb();
    }

    private boolean canDelay() {
        KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
        return mc.field_1724.method_24828() && (!killAura.isEnabled() || !killAura.shouldAutoBlock());
    }

    private void setJumpInput(boolean jump) {
        class_10185 input = mc.field_1724.field_3913.field_54155;
        mc.field_1724.field_3913.field_54155 = new class_10185(
                input.comp_3159(), input.comp_3160(), input.comp_3161(), input.comp_3162(), jump, input.comp_3164(), input.comp_3165()
        );
    }

    private int getKeyCode(class_304 keyBinding) {
        class_3675.class_306 key = class_3675.method_15981(keyBinding.method_1428());
        int code = key.method_1444();
        return key.method_1442() == class_3675.class_307.field_1672 ? code - 100 : code;
    }

    private void performAttack(class_1309 target) {
        EventManager.call(new AttackEvent(target));
        mc.field_1724.method_6104(class_1268.field_5808);
        PacketUtil.sendPacket(class_2824.method_34206(target, mc.field_1724.method_5715()));
        mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352 * 0.6, mc.field_1724.method_18798().field_1351, mc.field_1724.method_18798().field_1350 * 0.6);
        mc.field_1724.method_5728(false);
    }

    @EventTarget
    public void onKnockback(KnockbackEvent event) {
        if (!this.isEnabled() || event.isCancelled()) {
            this.pendingExplosion = false;
            this.allowNext = true;
            return;
        }

        if (this.mode.getValue() == 6 && this.polarMode.getValue() == 0 && this.polarKb && !this.isInLiquidOrWeb()) {
            event.setX(event.getX() * 0.5);
            event.setZ(event.getZ() * 0.5);
        }

        if (!this.allowNext || !this.fakeCheck.getValue()) {
            this.allowNext = true;
            if (this.pendingExplosion) {
                if (this.mode.getValue() <= 1 || this.mode.getValue() == 7) {
                    this.pendingExplosion = false;
                    if (this.explosionHorizontal.getValue() > 0) {
                        event.setX(event.getX() * (double) this.explosionHorizontal.getValue() / 100.0);
                        event.setZ(event.getZ() * (double) this.explosionHorizontal.getValue() / 100.0);
                    } else {
                        event.setX(mc.field_1724.method_18798().field_1352);
                        event.setZ(mc.field_1724.method_18798().field_1350);
                    }
                    if (this.explosionVertical.getValue() > 0) {
                        event.setY(event.getY() * (double) this.explosionVertical.getValue() / 100.0);
                    } else {
                        event.setY(mc.field_1724.method_18798().field_1351);
                    }
                }
            } else {
                if (this.mode.getValue() <= 1 || this.mode.getValue() == 7) {
                    this.chanceCounter = (this.chanceCounter % 100) + this.chance.getValue();
                    if (this.chanceCounter >= 100) {
                        if (this.mode.getValue() == 1 || this.mode.getValue() == 7) {
                            this.jumpFlag = event.getY() > 0.0;
                        }

                        if (this.horizontal.getValue() > 0) {
                            event.setX(event.getX() * (double) this.horizontal.getValue() / 100.0);
                            event.setZ(event.getZ() * (double) this.horizontal.getValue() / 100.0);
                        } else {
                            event.setX(mc.field_1724.method_18798().field_1352);
                            event.setZ(mc.field_1724.method_18798().field_1350);
                        }
                        if (this.vertical.getValue() > 0) {
                            event.setY(event.getY() * (double) this.vertical.getValue() / 100.0);
                        } else {
                            event.setY(mc.field_1724.method_18798().field_1351);
                        }
                    }
                } else if (this.mode.getValue() == 2) {
                    if (this.rotate.getValue() && event.getY() > 0.0) {
                        this.knockbackX = event.getX();
                        this.knockbackZ = event.getZ();
                        if (Math.abs(this.knockbackX) > 0.01 || Math.abs(this.knockbackZ) > 0.01) {
                            this.rotatoTickCounter = 1;
                        }
                    }
                    this.ticksSinceVelocity = 0;
                    this.hasReceivedVelocity = true;
                }
            }
        }
    }

    @EventTarget
    public void onTickDelay(TickEvent event) {
        if (!this.isEnabled() || this.mode.getValue() != 7) return;
        if (event.getType() != EventType.PRE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (!this.delayActive) return;

        this.delayTickCount++;
        if (this.canDelay() || this.isInLiquidOrWeb() || this.delayTickCount >= this.delayTicks.getValue()) {
            this.releaseDelay();
        }
    }

    private void releaseDelay() {
        this.applyKnockbackPacketNoXZ();
        this.delayActive = false;
        this.delayTickCount = 0;
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) return;

        if (this.ticksSinceVelocity >= 0) {
            this.ticksSinceVelocity++;
        }
        if (this.ticksSinceVelocity >= 10) {
            this.ticksSinceVelocity = -1;
            this.ShouldJump = false;
        }
        this.handleJumpReset();
    }

    private void handleJumpReset() {
        if (!this.ShouldJump) return;

        Scaffold scaffold = (Scaffold) Myau.moduleManager.getModule(Scaffold.class);
        if (mc.field_1724 == null || mc.field_1755 instanceof class_490 || scaffold.isEnabled()) return;
        if (this.ticksSinceVelocity >= 0) {
            if (this.ticksSinceVelocity <= 2 && mc.field_1724.method_24828()) {
                KeyBindUtil.setKeyBindState(this.getKeyCode(mc.field_1690.field_1903), true);
            }
        }
        if (this.ticksSinceVelocity >= 4 && this.ticksSinceVelocity <= 9) {
            KeyBindUtil.setKeyBindState(this.getKeyCode(mc.field_1690.field_1903), this.pressed);
        }
    }

    @EventTarget
    public void onTimerTick(TickEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) return;

        if (!this.timer.getValue()) {
            this.disableVelocityTimer();
            return;
        }
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        Timer timerModule = (Timer) Myau.moduleManager.getModule(Timer.class);
        if (timerModule == null) {
            this.timerEnabledByVelocity = false;
            this.timerEnableAt = -1L;
            return;
        }

        long now = System.currentTimeMillis();
        if (!this.timerEnabledByVelocity) {
            if (this.timerEnableAt != -1L && now >= this.timerEnableAt) {
                this.savedTimerSpeed = timerModule.speed.getValue();
                timerModule.speed.setValue(0.2F);
                timerModule.setEnabled(true);
                this.timerEnabledByVelocity = true;
            }
        } else if (this.lastTimerAttackTime == -1L || now - this.lastTimerAttackTime >= 1500L) {
            timerModule.speed.setValue(this.savedTimerSpeed);
            timerModule.setEnabled(false);
            this.timerEnabledByVelocity = false;
            this.timerEnableAt = -1L;
        }
    }

    private void disableVelocityTimer() {
        if (this.timerEnabledByVelocity) {
            Timer timerModule = (Timer) Myau.moduleManager.getModule(Timer.class);
            if (timerModule != null) {
                timerModule.speed.setValue(this.savedTimerSpeed);
                if (timerModule.isEnabled()) {
                    timerModule.setEnabled(false);
                }
            }
            this.timerEnabledByVelocity = false;
        }
        this.lastTimerAttackTime = -1L;
        this.timerEnableAt = -1L;
        this.timerJumpPending = false;
    }

    @EventTarget
    public void onMove(MoveInputEvent event) {
        boolean isMode1 = this.mode.getValue() == 1;
        boolean isMode2Jump = this.mode.getValue() == 2 && this.hypixelJump.getValue();

        if (this.isEnabled() && this.timer.getValue() && this.timerJumpPending) {
            this.timerJumpPending = false;
            this.setJumpInput(true);
        }

        if (this.isEnabled() && this.mode.getValue() == 4 && this.shouldJump) {
            this.shouldJump = false;
            if (mc.field_1724.method_24828() && mc.field_1724.method_5624()
                    && !mc.field_1724.method_6059(class_1294.field_5913) && !this.isInLiquidOrWeb()) {
                this.setJumpInput(true);
            }
        }

        if (this.isEnabled() && this.jumpFlag && (isMode1 || isMode2Jump || this.mode.getValue() == 7)) {
            this.jumpFlag = false;
            if (mc.field_1724.method_24828() && mc.field_1724.method_5624() && !mc.field_1724.method_6059(class_1294.field_5913) && !this.isInLiquidOrWeb()) {
                this.setJumpInput(true);
            }
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled()) return;

        if (this.mode.getValue() == 2) {
            if (event.getType() == EventType.PRE) {
                if (this.reduce.getValue()) {
                    if (this.velocityAttacked) {
                        KillAura killAura = (KillAura) Myau.moduleManager.getModule(KillAura.class);
                        if (killAura.getTarget() != null && killAura.isEnabled()) {
                            this.performAttack(killAura.getTarget());
                        }
                        velocityAttacked = false;
                    }

                    if (this.hasReceivedVelocity) {
                        if (this.reduceTick >= this.attackTimes.getValue()) {
                            this.reduceTick = 0;
                            this.hasReceivedVelocity = false;
                        }
                        KillAura killAura = (KillAura) Myau.moduleManager.getModule(KillAura.class);
                        if (killAura.getTarget() != null) {
                            if (mc.field_1724.method_5624() || !this.onlySprinting.getValue()) {
                                if (!this.reduceWhenCanAttack.getValue()
                                        || (killAura.getAutoBlock().getBlockTick() == 0 && killAura.getAutoBlock().mode.getValue() == 4)
                                        || (killAura.getAutoBlock().mode.getValue() == 3 && killAura.getAutoBlock().getBlockTick() == 0)) {
                                    this.performAttack(killAura.getTarget());
                                }
                            }
                        }
                        this.reduceTick++;
                    }
                }

                int maxTick = this.rotateTick.getValue();
                if (this.rotatoTickCounter > 0 && this.rotatoTickCounter <= maxTick) {
                    if (this.rotatoTickCounter == 1) {
                        double deltaX = -this.knockbackX;
                        double deltaZ = -this.knockbackZ;
                        this.targetRotation = RotationUtil.getRotationsTo(deltaX, 0, deltaZ, event.getYaw(), event.getPitch());
                    }
                    if (this.targetRotation != null) {
                        event.setRotation(this.targetRotation[0], this.targetRotation[1], 2);
                        event.setPervRotation(this.targetRotation[0], 2);
                    }
                }
            } else if (event.getType() == EventType.POST) {
                int maxTick = this.rotateTick.getValue();
                if (this.rotatoTickCounter > 0 && this.rotatoTickCounter <= maxTick) {
                    this.rotatoTickCounter++;
                    if (this.rotatoTickCounter > maxTick) {
                        this.rotatoTickCounter = 0;
                        this.targetRotation = null;
                        this.knockbackX = 0;
                        this.knockbackZ = 0;
                    }
                }
            }
        }

        if (this.mode.getValue() == 3 && this.slapReduce.getValue() && event.getType() == EventType.PRE) {
            if (this.slapReduceTicks > 0) {
                this.slapReduceTicks--;
                KillAura killAura = (KillAura) Myau.moduleManager.getModule(KillAura.class);
                if (killAura != null && killAura.isEnabled() && killAura.getTarget() != null) {
                    class_1309 target = killAura.getTarget();
                    if (!((EntityAccessor) mc.field_1724).getIsInWeb() && mc.field_1724.method_5624() && MoveUtil.isMoving() && target != mc.field_1724 && !this.badPackets()) {
                        this.performAttack(target);
                        this.slapAnInt++;
                        if (this.debugLog.getValue()) {
                            ChatUtil.sendFormatted(Myau.clientName + "Attack reduce " + this.slapAnInt);
                        }
                    }
                }
            }
        }
    }

    @EventTarget
    public void onUpdateGrimReduce(UpdateEvent event) {
        if (!this.isEnabled() || this.mode.getValue() != 5) return;
        if (event.getType() != EventType.PRE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) {
            this.resetGrimReduce();
            return;
        }

        if (this.grimSuspending) {
            this.grimSuspendTicks++;
            boolean timeout = this.grimSuspendTicks >= this.maxAirTicks.getValue();
            if (mc.field_1724.method_24828() || timeout) {
                boolean grounded = mc.field_1724.method_24828();
                class_1297 target = this.getAttackTargetNoXZ();
                boolean canReduce = grounded && mc.field_1724.method_5624() && this.isValidTargetGrimReduce(target) && !this.badPackets();

                this.releaseGrimReduce();

                if (canReduce) {
                    this.doReduceGrimReduce(target);
                } else if (grounded && mc.field_1724.method_5624()) {
                    mc.field_1724.method_5728(false);
                }
            }
            return;
        }

        if (this.grimKnockback) {
            this.grimKnockback = false;
            if (this.badPackets() || this.isBlockedState()) return;
            if (!mc.field_1724.method_5624()) return;
            class_1297 target = this.getAttackTargetNoXZ();
            if (this.isValidTargetGrimReduce(target)) {
                this.doReduceGrimReduce(target);
            }
        }
    }

    @EventTarget
    public void onStrafeGrimReduce(StrafeEvent event) {
        if (!this.isEnabled() || this.mode.getValue() != 5) return;
        if (mc.field_1724 == null) return;
        if (this.grimSuspending) {
            event.setForward(1.0F);
            event.setStrafe(0.0F);
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (!this.isEnabled() || event.isCancelled()) return;

        if (this.mode.getValue() == 3 && event.getType() == EventType.SEND) {
            class_2596<?> packet = event.getPacket();
            if (packet instanceof class_2868) {
                this.slot = true;
            } else if (packet instanceof class_2879) {
                this.swing = true;
            } else if (packet instanceof class_2824) {
                ((class_2824) packet).method_34209(new class_2824.class_5908() {
                    @Override
                    public void method_34219(class_1268 hand) {
                    }

                    @Override
                    public void method_34220(class_1268 hand, class_243 pos) {
                    }

                    @Override
                    public void method_34218() {
                        Velocity.this.attack = true;
                    }
                });
            } else if (packet instanceof class_2885) {
                this.block = true;
            } else if (packet instanceof class_2886) {
                this.block = true;
            } else if (packet instanceof class_2846) {
                this.block = true;
                this.dig = true;
            } else if (packet instanceof class_2815
                    || packet instanceof class_2813
                    || (packet instanceof class_2848 &&
                            ((class_2848) packet).method_12365() == class_2848.class_2849.field_12988)) {
                this.inventory = true;
            } else if (packet instanceof class_2828) {
                this.resetBadPackets();
            }
        }

        if (event.getType() == EventType.RECEIVE) {
            if (this.mode.getValue() == 0 || this.mode.getValue() == 1) {
                if (event.getPacket() instanceof class_2664) {
                    class_2664 packet = (class_2664) event.getPacket();
                    if (packet.comp_2884().isPresent()) {
                        class_243 kb = packet.comp_2884().get();
                        if (kb.field_1352 != 0.0 || kb.field_1351 != 0.0 || kb.field_1350 != 0.0) {
                            this.pendingExplosion = true;
                            if (this.explosionHorizontal.getValue() == 0 || this.explosionVertical.getValue() == 0) {
                                event.setCancelled(true);
                            }
                            if (this.debugLog.getValue() && mc.field_1724 != null) {
                                ChatUtil.sendFormatted(
                                        String.format(
                                                "%sExplosion (&otick: %d, x: %.2f, y: %.2f, z: %.2f&r)&r",
                                                Myau.clientName,
                                                mc.field_1724.field_6012,
                                                mc.field_1724.method_18798().field_1352 + kb.field_1352,
                                                mc.field_1724.method_18798().field_1351 + kb.field_1351,
                                                mc.field_1724.method_18798().field_1350 + kb.field_1350
                                        )
                                );
                            }
                        }
                    }
                }
            }

            if (event.getPacket() instanceof class_2743) {
                class_2743 packet = (class_2743) event.getPacket();
                if (mc.field_1724 != null && packet.method_11818() == mc.field_1724.method_5628()) {

                    if (this.mode.getValue() == 5) {
                        if (this.grimSuspending) return;
                        if (!this.isPlayerKnockback()) return;
                        if (this.isBlockedState()) return;
                        if (!mc.field_1724.method_24828()) {
                            this.grimSuspending = true;
                            this.grimSuspendTicks = 0;
                            this.knockbackPacket = packet;
                            event.setCancelled(true);
                        } else {
                            this.grimKnockback = true;
                        }
                    }

                    if (this.mode.getValue() == 6) {
                        this.polarKb = true;
                        if (this.polarMode.getValue() == 1) {
                            RayCastUtil.RayCastResult result = RayCastUtil.rayCast(
                                    new RotationUtil.RotationVec(mc.field_1724.method_36454(), mc.field_1724.method_36455()), 2.9F);
                            KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
                            class_1309 target = killAura != null ? killAura.getTarget() : null;
                            if (target != null
                                    && result != null && result.typeOfHit == RayCastUtil.RayCastResult.Type.ENTITY
                                    && result.entityHit instanceof class_1657
                                    && RotationUtil.distanceToEntity(target) > 1
                                    && this.polarSb < 1) {
                                event.setCancelled(true);
                                this.polarSb++;
                            } else {
                                this.polarSb = Math.max(0, this.polarSb - 0.1);
                            }
                        }
                    }

                    if (this.mode.getValue() == 7) {
                        LongJump longJump = (LongJump) Myau.moduleManager.modules.get(LongJump.class);
                        if (!this.delayActive
                                && !this.canDelay()
                                && !this.isInLiquidOrWeb()
                                && !this.pendingExplosion
                                && (!this.allowNext || !this.fakeCheck.getValue())
                                && (longJump == null || !longJump.isEnabled() || !longJump.canStartJump())) {
                            this.delayChanceCounter = this.delayChanceCounter % 100 + this.delayChance.getValue();
                            if (this.delayChanceCounter >= 100) {
                                this.delayActive = true;
                                this.delayTickCount = 0;
                                this.knockbackPacket = packet;
                                event.setCancelled(true);
                                return;
                            }
                        }
                    }

                    if (this.mode.getValue() == 2) {
                        this.hasReceivedVelocity = true;
                        this.ticksSinceVelocity = 0;
                        this.jumpFlag = packet.method_11816() > 0;
                        this.pressed = mc.field_1690.field_1903.method_1434();
                        this.ShouldJump = true;
                    }

                    if (this.mode.getValue() == 3 && this.slapReduce.getValue()) {
                        this.slapReduceTicks = this.calculateSlapTicks(
                                (int) (packet.method_11815() * 8000.0), (int) (packet.method_11819() * 8000.0)
                        );
                        if (this.debugLog.getValue()) {
                            ChatUtil.sendFormatted(Myau.clientName + "Attack reduceTicks: " + this.slapReduceTicks);
                        }
                    }
                    if (this.timer.getValue()) {
                        this.lastTimerAttackTime = System.currentTimeMillis();
                        if (mc.field_1724.method_24828()) {
                            this.timerJumpPending = true;
                        }
                        this.timerEnableAt = this.lastTimerAttackTime + 300L;
                    }
                    if (this.debugLog.getValue()) {
                        ChatUtil.sendFormatted(
                                String.format(
                                        "%sVelocity (&otick: %d, x: %.2f, y: %.2f, z: %.2f&r)&r",
                                        Myau.clientName,
                                        mc.field_1724.field_6012,
                                        packet.method_11815(),
                                        packet.method_11816(),
                                        packet.method_11819()
                                )
                        );
                    }
                }
            }

            if (event.getPacket() instanceof class_2663) {
                class_2663 packet = (class_2663) event.getPacket();
                net.minecraft.class_638 world = mc.field_1687;
                if (world != null && mc.field_1724 != null) {
                    class_1297 entity = packet.method_11469(world);
                    if (entity != null && entity.equals(mc.field_1724) && packet.method_11470() == 2) {
                        this.allowNext = false;
                    }
                }
            }
        }
    }

    private boolean isPlayerKnockback() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return false;
        }
        double radius = this.reach.getValue() + 2.0;
        double radiusSq = radius * radius;
        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724 || !player.method_5805()) continue;
            if (mc.field_1724.method_5858(player) <= radiusSq) {
                return true;
            }
        }
        return false;
    }

    private boolean isBlockedState() {
        if (mc.field_1724 == null) {
            return false;
        }
        return mc.field_1724.method_6101() || this.isInLiquidOrWeb() || this.isOnFireBlock();
    }

    private boolean isOnFireBlock() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return false;
        }
        double x = mc.field_1724.method_23317();
        double z = mc.field_1724.method_23321();
        return mc.field_1687.method_8320(new class_2338((int) x, (int) mc.field_1724.method_23318(), (int) z)).method_27852(class_2246.field_10036)
                || mc.field_1687.method_8320(new class_2338((int) x, (int) (mc.field_1724.method_23318() - 0.2), (int) z)).method_27852(class_2246.field_10036);
    }

    private boolean isValidTargetGrimReduce(class_1297 entity) {
        return entity != null && entity.method_5805() && entity != mc.field_1724;
    }

    private void doReduceGrimReduce(class_1297 target) {
        if (mc.field_1724 == null || target == null || mc.field_1761 == null) return;
        if (!(target instanceof class_1309)) return;
        mc.field_1761.method_2918(mc.field_1724, (class_1309) target);
        mc.field_1724.method_6104(class_1268.field_5808);
        class_243 velocity = mc.field_1724.method_18798();
        mc.field_1724.method_18800(velocity.field_1352 * 0.6, velocity.field_1351, velocity.field_1350 * 0.6);
        mc.field_1724.method_5728(false);
    }

    private void releaseGrimReduce() {
        this.applyKnockbackPacketNoXZ();
        this.grimSuspending = false;
        this.grimSuspendTicks = 0;
    }

    private void resetGrimReduce() {
        this.grimSuspending = false;
        this.grimSuspendTicks = 0;
        this.grimKnockback = false;
    }

    private void resetPolar() {
        this.polarKb = false;
        this.polarSb = 0;
    }

    private void resetDelay() {
        this.delayActive = false;
        this.delayChanceCounter = 0;
        this.delayTickCount = 0;
    }

    private int calculateSlapTicks(int motionX, int motionZ) {
        double kb = Math.hypot(motionX, motionZ);
        if (!tickExactEnable.getValue()) {
            double ticks = 6.43153527E-4 * kb + 2.9419087136;
            int result = (int) Math.round(ticks);
            if (result < 1) result = 1;
            if (result > 10) result = 10;
            return result;
        }
        if (kb <= 500) return tick500.getValue();
        if (kb <= 1000) return tick1000.getValue();
        if (kb <= 2000) return tick2000.getValue();
        if (kb <= 3000) return tick3000.getValue();
        if (kb <= 4000) return tick4000.getValue();
        if (kb <= 5000) return tick5000.getValue();
        if (kb <= 6000) return tick6000.getValue();
        if (kb <= 7000) return tick7000.getValue();
        if (kb <= 8000) return tick8000.getValue();
        if (kb <= 9000) return tick9000.getValue();
        return tick10000.getValue();
    }

    private boolean badPackets() {
        return this.badPackets(false, false, false, false, false, false);
    }

    private boolean badPackets(boolean p1, boolean p2, boolean p3, boolean p4, boolean p5, boolean p6) {
        if (this.slot && !p1) return true;
        if (this.attack && !p2) return true;
        if (this.swing && !p3) return true;
        if (this.block && !p4) return true;
        if (this.inventory && !p5) return true;
        if (this.dig && !p6) return true;
        return false;
    }

    private void resetBadPackets() {
        this.slot = false;
        this.swing = false;
        this.attack = false;
        this.block = false;
        this.inventory = false;
        this.dig = false;
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        this.onDisabled();
    }

    @Override
    public void onEnabled() {
        this.pendingExplosion = false;
        this.allowNext = true;
        this.rotatoTickCounter = 0;
        this.targetRotation = null;
        this.knockbackX = 0;
        this.knockbackZ = 0;
        this.reduceTick = -1;
        this.hasReceivedVelocity = false;
        this.ticksSinceVelocity = -1;
        extraAttacked = false;
        velocityAttacked = false;
        this.jumpFlag = false;
        this.ShouldJump = false;
        this.slapReduceTicks = 0;
        this.slapAnInt = 0;
        this.resetBadPackets();
        this.resetAllNoXZ();
        this.disableVelocityTimer();
    }

    @Override
    public void onDisabled() {
        this.pendingExplosion = false;
        this.allowNext = true;
        this.hasReceivedVelocity = false;
        this.rotatoTickCounter = 0;
        this.targetRotation = null;
        this.knockbackX = 0;
        this.knockbackZ = 0;
        this.reduceTick = -1;
        this.ticksSinceVelocity = -1;
        extraAttacked = false;
        velocityAttacked = false;
        this.jumpFlag = false;
        this.ShouldJump = false;
        this.slapReduceTicks = 0;
        this.slapAnInt = 0;
        this.resetBadPackets();
        this.resetAllNoXZ();
        this.disableVelocityTimer();
    }

    @EventTarget(Priority.HIGHEST)
    public void onPacketNoXZ(PacketEvent event) {
        if (!this.isEnabled() || this.mode.getValue() != 4) return;
        if (event.isCancelled()) return;
        if (this.isFlushing) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (event.getType() == EventType.RECEIVE) {
            if (this.shouldIgnoreNoXZ()) return;
            class_2596<?> packet = event.getPacket();

            if (packet instanceof class_2708) {
                if (this.isSuspending) {
                    this.pendingRelease = true;
                }
                this.flagCooldown = 2;
                this.knockbackPacket = null;
                return;
            }

            if (this.flagCooldown != 0) return;

            if (this.isSuspending) {
                if (!this.isAllowedPacketNoXZ(packet)) {
                    this.packetQueue.add(packet);
                    event.setCancelled(true);
                }
                return;
            }

            if (packet instanceof class_2743 motionPacket) {
                if (motionPacket.method_11818() != mc.field_1724.method_5628()) return;
                double dx = -motionPacket.method_11815();
                double dz = -motionPacket.method_11819();
                if (Math.abs(dx) > 0.01 || Math.abs(dz) > 0.01) {
                    this.hitCounter = 1;
                }
                if (motionPacket.method_11816() > 0) {
                    class_1297 target;
                    this.sprintBoostCounter = this.sprintBoostCounter % 100 + 100;
                    if (this.sprintBoostCounter >= 100) {
                        this.shouldJump = true;
                    }
                    boolean canAttack = this.isValidTargetNoXZ(target = this.getAttackTargetNoXZ()) && mc.field_1724.method_5624();
                    if (!mc.field_1724.method_24828()) {
                        this.isSuspending = true;
                        this.suspendTicks = 0;
                        this.knockbackPacket = motionPacket;
                        event.setCancelled(true);
                    } else if (canAttack) {
                        this.attackTarget = target;
                        this.attacksRemaining = this.attackAmount.getValue();
                    } else {
                        this.isSuspending = true;
                        this.suspendTicks = 0;
                        this.knockbackPacket = motionPacket;
                        event.setCancelled(true);
                    }
                }
            }
        } else if (event.getType() == EventType.SEND) {
            if (this.isSuspending && event.getPacket() instanceof class_2828 movePacket) {
                this.movePacketQueue.add(movePacket);
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onTickNoXZ(TickEvent event) {
        if (!this.isEnabled() || this.mode.getValue() != 4) return;
        if (event.getType() != EventType.PRE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (this.pendingRelease) {
            this.pendingRelease = false;
            this.releaseNoXZ();
        }

        if (this.attackCooldown > 0) {
            this.attackCooldown--;
            if (this.attackCooldown <= 0) {
                this.attackCount = 0;
            }
        }

        if (this.hitCounter > 0) {
            this.hitCounter++;
            if (this.hitCounter > 2) {
                this.hitCounter = 0;
            }
        }

        if (mc.field_1724.method_29504() || this.shouldIgnoreNoXZ()) {
            this.clearTargetNoXZ();
            if (this.isSuspending) {
                this.releaseNoXZ();
            }
            if (this.isInstantAttacking) {
                this.isInstantAttacking = false;
                this.instantAttackProgress = 0.0F;
            }
            return;
        }

        if (this.flagCooldown > 0) {
            this.flagCooldown--;
            this.clearTargetNoXZ();
        }

        if (this.isSuspending) {
            this.suspendTicks++;
            boolean instantAttackEnabled = this.instantAttack.getValue();
            if (instantAttackEnabled && this.instantAttackProgress < 3.0F) {
                this.instantAttackProgress += 0.5F;
                this.instantAttackProgress = Math.min(this.instantAttackProgress, 3.0F);
            }
            boolean onGround = mc.field_1724.method_24828();
            boolean isTimeout = this.suspendTicks >= 12;
            if (onGround || isTimeout) {
                class_1297 target = this.getAttackTargetNoXZ();
                boolean canAttack = this.isValidTargetNoXZ(target);
                boolean sprinting = mc.field_1724.method_5624();
                if (onGround && canAttack && sprinting) {
                    this.isFlushing = true;
                    this.attackTarget = target;
                    this.attacksRemaining = this.attackAmount.getValue();
                    this.sendMovePacketsNoXZ();
                    this.applyKnockbackPacketNoXZ();
                    if (instantAttackEnabled && this.instantAttackProgress > 0.0F) {
                        this.attacksRemaining = (int) this.instantAttackProgress;
                        this.scheduleMotionFlushNoXZ();
                        this.isSuspending = false;
                        this.suspendTicks = 0;
                        this.isFlushing = false;
                        this.isInstantAttacking = true;
                    } else {
                        this.doAttackSequenceNoXZ();
                        this.scheduleMotionFlushNoXZ();
                        this.isSuspending = false;
                        this.suspendTicks = 0;
                        this.isFlushing = false;
                    }
                } else {
                    this.releaseNoXZ();
                    this.instantAttackProgress = 0.0F;
                    if (onGround && mc.field_1724.method_5624()) {
                        mc.field_1724.method_5728(false);
                    }
                }
                return;
            }
            return;
        }

        if (this.isInstantAttacking) {
            this.instantAttackProgress -= 1.0F;
            if (this.instantAttackProgress <= 0.0F) {
                this.instantAttackProgress = 0.0F;
                this.isInstantAttacking = false;
            }
        }

        if (this.attacksRemaining > 0 && this.attackTarget != null) {
            this.doAttackSequenceNoXZ();
        }
    }

    @EventTarget
    public void onUpdateNoXZ(UpdateEvent event) {
        if (!this.isEnabled() || this.mode.getValue() != 4) return;
        if (event.getType() == EventType.POST && this.shouldFlushMotion) {
            class_2596<?> packet;
            while ((packet = this.packetQueue.poll()) != null) {
                PacketUtil.receivePacket(packet);
            }
            this.shouldFlushMotion = false;
        }
    }

    @EventTarget
    public void onStrafeNoXZ(StrafeEvent event) {
        if (!this.isEnabled() || this.mode.getValue() != 4) return;
        if (mc.field_1724 == null) return;
        if (this.hitCounter > 0) {
            event.setForward(1.0F);
        }
    }

    private boolean shouldIgnoreNoXZ() {
        if (mc.field_1724 == null || mc.field_1687 == null) return true;
        if (mc.field_1724.method_29504() || mc.field_1724.method_6032() <= 0.0F) return true;
        if (mc.field_1724.method_7325() || mc.field_1724.method_31549().field_7479) return true;
        if (mc.field_1724.method_5771() || mc.field_1724.method_5809()
                || mc.field_1724.method_5799() || mc.field_1724.method_6101() || mc.field_1724.method_6113()) return true;
        return mc.field_1687.method_8320(mc.field_1724.method_24515()).method_27852(net.minecraft.class_2246.field_10343);
    }

    private double getAABBDistanceNoXZ(class_1297 entity) {
        if (mc.field_1724 == null) {
            return Double.MAX_VALUE;
        }
        class_243 eyePos = mc.field_1724.method_33571();
        class_238 box = entity.method_5829();
        double clampedX = Math.max(box.field_1323, Math.min(eyePos.field_1352, box.field_1320));
        double clampedY = Math.max(box.field_1322, Math.min(eyePos.field_1351, box.field_1325));
        double clampedZ = Math.max(box.field_1321, Math.min(eyePos.field_1350, box.field_1324));
        return eyePos.method_1022(new class_243(clampedX, clampedY, clampedZ));
    }

    private class_1297 getAttackTargetNoXZ() {
        KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
        if (killAura != null && killAura.isEnabled() && killAura.getTarget() != null) {
            return killAura.getTarget();
        }
        if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331) {
            return ((class_3966) mc.field_1765).method_17782();
        }
        return null;
    }

    private boolean isValidTargetNoXZ(class_1297 entity) {
        if (entity == null || !entity.method_5805()) {
            return false;
        }
        if (entity instanceof class_1309 && ((class_1309) entity).method_29504()) {
            return false;
        }
        return this.getAABBDistanceNoXZ(entity) <= 3.7;
    }

    private void doAttackSequenceNoXZ() {
        if (this.attackTarget == null || !this.attackTarget.method_5805()) {
            this.clearTargetNoXZ();
            return;
        }
        if (this.getAABBDistanceNoXZ(this.attackTarget) > 3.7) {
            this.clearTargetNoXZ();
            return;
        }
        this.attackCount = this.attacksRemaining--;
        this.attackCooldown = 2;
        this.doAttackNoXZ(this.attackTarget);
        if (this.attacksRemaining <= 0) {
            this.clearTargetNoXZ();
        }
    }

    private boolean doAttackNoXZ(class_1297 entity) {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return false;
        }
        if (this.sprintStateCheck.getValue() && !mc.field_1724.method_5624()) {
            return false;
        }
        boolean wasSprinting = mc.field_1724.method_5624();
        if (wasSprinting) {
            mc.field_1724.method_5728(false);
        }
        mc.field_1761.method_2918(mc.field_1724, entity);
        mc.field_1724.method_6104(class_1268.field_5808);
        if (wasSprinting) {
            class_243 velocity = mc.field_1724.method_18798();
            mc.field_1724.method_18800(velocity.field_1352 * 0.6, velocity.field_1351, velocity.field_1350 * 0.6);
        }
        return true;
    }

    private void sendMovePacketsNoXZ() {
        class_2828 movePacket;
        while ((movePacket = this.movePacketQueue.poll()) != null) {
            if (mc.method_1562() != null) {
                mc.method_1562().method_52787(movePacket);
            }
        }
    }

    private void applyKnockbackPacketNoXZ() {
        if (this.knockbackPacket != null && mc.method_1562() != null) {
            try {
                ((class_2596<class_2602>) this.knockbackPacket).method_65081(mc.method_1562());
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            this.knockbackPacket = null;
        }
    }

    private void scheduleMotionFlushNoXZ() {
        this.shouldFlushMotion = true;
    }

    private boolean isAllowedPacketNoXZ(class_2596<?> packet) {
        return packet instanceof class_2743
                || packet instanceof class_2749
                || packet instanceof class_2708
                || packet instanceof class_2767
                || packet instanceof class_7438
                || packet instanceof class_5892
                || packet instanceof class_2645
                || packet instanceof class_8043
                || packet instanceof class_5904
                || packet instanceof class_5900
                || packet instanceof class_7439
                || packet instanceof class_2661
                || (packet instanceof class_2616 && ((class_2616) packet).method_11269() != mc.field_1724.method_5628());
    }

    private void releaseNoXZ() {
        this.isFlushing = true;
        this.sendMovePacketsNoXZ();
        this.applyKnockbackPacketNoXZ();
        this.scheduleMotionFlushNoXZ();
        this.isFlushing = false;
        this.isSuspending = false;
        this.suspendTicks = 0;
        this.instantAttackProgress = 0.0F;
        this.isInstantAttacking = false;
    }

    private void clearTargetNoXZ() {
        this.attackTarget = null;
        this.attacksRemaining = 0;
    }

    private void resetSuspensionNoXZ() {
        this.isSuspending = false;
        this.suspendTicks = 0;
        this.knockbackPacket = null;
        this.packetQueue.clear();
        this.movePacketQueue.clear();
        this.isFlushing = false;
        this.instantAttackProgress = 0.0F;
        this.isInstantAttacking = false;
        this.shouldFlushMotion = false;
        this.pendingRelease = false;
    }

    public void resetAllNoXZ() {
        this.clearTargetNoXZ();
        this.flagCooldown = 0;
        this.shouldJump = false;
        this.sprintBoostCounter = 0;
        this.hitCounter = 0;
        this.attackCooldown = 0;
        this.resetSuspensionNoXZ();
        this.resetGrimReduce();
        this.resetPolar();
        this.resetDelay();
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.mode.getModeString()};
    }
}
