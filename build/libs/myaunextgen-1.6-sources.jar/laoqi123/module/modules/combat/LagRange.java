package laoqi123.module.modules.combat;

import laoqi123.Myau;
import laoqi123.enums.BlinkModules;
import laoqi123.event.EventTarget;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.mixin.ClientPlayerInteractionManagerAccessor;
import laoqi123.module.Module;
import laoqi123.module.modules.misc.BedNuker;
import laoqi123.module.modules.render.HUD;
import laoqi123.value.properties.*;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2846;
import net.minecraft.class_2885;
import net.minecraft.class_310;
import laoqi123.util.ItemUtil;
import laoqi123.util.RenderUtil;
import laoqi123.util.RotationUtil;
import laoqi123.util.TeamUtil;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class LagRange extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final ModeValue mode = new ModeValue("Mode", 0, new String[]{"Delay Blink", "Lag"});
    public final IntValue blinkTick = new IntValue("Blink Tick", 3, 0, 10, () -> mode.getValue() == 0);
    public final IntValue delay = new IntValue("Delay", 150, 0, 1000, () -> mode.getValue() == 1);
    public final FloatValue range = new FloatValue("Range", 10.0F, 3.0F, 100.0F);
    public final BooleanValue weaponsOnly = new BooleanValue("Weapons Only", true);
    public final BooleanValue allowTools = new BooleanValue("Allow Tools", false, this.weaponsOnly::getValue);
    public final BooleanValue botCheck = new BooleanValue("Bot Check", true);
    public final BooleanValue teams = new BooleanValue("Teams", true);
    public final ModeValue showPosition = new ModeValue("Show Position", 0, new String[]{"None", "Default", "Hud"});
    private int tickIndex = -1;
    private long delayCounter = 0L;
    private boolean hasTarget = false;
    private class_243 lastPosition = null;
    private class_243 currentPosition = null;

    public LagRange() {
        super("LagRange", false);
    }

    private boolean isValidTarget(class_1657 playerEntity) {
        if (playerEntity != mc.field_1724 && playerEntity != mc.field_1724.method_5854()) {
            if (playerEntity == mc.method_1560() || playerEntity == mc.method_1560().method_5854()) {
                return false;
            } else if (playerEntity.field_6213 > 0) {
                return false;
            } else if (TeamUtil.isFriend(playerEntity)) {
                return false;
            } else {
                return (!this.teams.getValue() || !TeamUtil.isSameTeam(playerEntity)) && (!this.botCheck.getValue() || !TeamUtil.isBot(playerEntity));
            }
        } else {
            return false;
        }
    }

    private boolean shouldResetOnPacket(class_2596<?> packet) {
        if (packet instanceof class_2824) {
            return true;
        } else if (packet instanceof class_2846) {
            return ((class_2846) packet).method_12363() != class_2846.class_2847.field_12974;
        } else if (packet instanceof class_2885) {
            class_1799 item = mc.field_1724.method_6047();
            return item.method_7960() || !(item.method_7909() instanceof class_1829);
        } else {
            return false;
        }
    }

    @EventTarget(Priority.LOW)
    public void onTick(TickEvent event) {
        if (this.isEnabled()) {
            switch (event.getType()) {
                case PRE:
                    KillAura killAura = (KillAura) Myau.moduleManager.getModule(KillAura.class);
                    if (killAura != null && killAura.isEnabled() && killAura.shouldAutoBlock() && mode.getValue() == 0) {
                        Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
                        return;
                    }
                    Myau.lagManager.setDelay(0);
                    this.hasTarget = false;

                    BedNuker bedNuker = (BedNuker) Myau.moduleManager.getModule(BedNuker.class);
                    boolean bedNukerActive = bedNuker != null && bedNuker.isEnabled() && bedNuker.isReady();

                    if ((!bedNukerActive)
                            && !((ClientPlayerInteractionManagerAccessor) mc.field_1761).getIsHittingBlock()
                            && (!mc.field_1724.method_6115() || mc.field_1724.method_6039())
                            && (
                            !this.weaponsOnly.getValue()
                                    || ItemUtil.hasRawUnbreakingEnchant()
                                    || this.allowTools.getValue() && ItemUtil.isHoldingTool()
                    )) {
                        List<class_1657> players = mc.field_1687.method_18456().stream()
                                .map(entity -> (class_1657) entity)
                                .filter(this::isValidTarget)
                                .collect(Collectors.toList());
                        if (players.isEmpty()) {
                            Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
                            this.tickIndex = -1;
                        } else {
                            double height = mc.field_1724.method_5751();
                            class_243 eyePosition = Myau.lagManager.getLastPosition().method_1031(0.0, height, 0.0);
                            class_243 targetEyePosition = new class_243(mc.field_1724.field_6014, mc.field_1724.field_6036 + height, mc.field_1724.field_5969);
                            class_243 playerEyePosition = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318() + height, mc.field_1724.method_23321());
                            for (class_1657 player : players) {
                                double distance = RotationUtil.distanceToBox(player, playerEyePosition);
                                if (!(distance > this.range.getValue())) {
                                    double targetDist = RotationUtil.distanceToBox(player, targetEyePosition);
                                    double eyeDist = RotationUtil.distanceToBox(player, eyePosition);
                                    if (distance < targetDist || distance < eyeDist) {
                                        if (this.tickIndex < 0) {
                                            this.tickIndex = 0;
                                            for (this.delayCounter = this.delayCounter + (long) this.delay.getValue();
                                                 this.delayCounter > 0L;
                                                 this.delayCounter = this.delayCounter - 50
                                            ) {
                                                this.tickIndex++;
                                            }
                                        }
                                        if (mode.getValue() == 1) {
                                            Myau.lagManager.setDelay(this.tickIndex);
                                        }
                                        if (mode.getValue() == 0) {
                                            Myau.blinkManager.setBlinkState(true, BlinkModules.BLINK);
                                            if (Myau.blinkManager.countMovement() > blinkTick.getValue().longValue()) {
                                                Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
                                            }
                                        }
                                        this.hasTarget = true;
                                        return;
                                    }
                                }
                            }
                        }
                    } else {
                        this.tickIndex = -1;
                        Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
                    }
                    if (!hasTarget) {
                        Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
                    }
                    break;
                case POST:
                    class_243 savedPosition = Myau.lagManager.getLastPosition();
                    if (this.currentPosition == null) {
                        this.lastPosition = savedPosition;
                    } else {
                        this.lastPosition = this.currentPosition;
                    }
                    this.currentPosition = savedPosition;
            }
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (this.isEnabled()) {
            if (this.shouldResetOnPacket(event.getPacket())) {
                Myau.lagManager.setDelay(0);
                this.tickIndex = -1;
            }
        }
    }

    @EventTarget(Priority.HIGH)
    public void onRender3D(Render3DEvent event) {
        if (this.isEnabled()) {
            if (this.showPosition.getValue() != 0
                    && !mc.field_1690.method_31044().method_31034()
                    && this.hasTarget
                    && this.lastPosition != null
                    && this.currentPosition != null) {
                Color color = new Color(-1);
                switch (this.showPosition.getValue()) {
                    case 1:
                        color = TeamUtil.getTeamColor(mc.field_1724, 1.0F);
                        break;
                    case 2:
                        HUD hud = (HUD) Myau.moduleManager.getModule(HUD.class);
                        if (hud != null) {
                            color = hud.getColor(System.currentTimeMillis());
                        }
                        break;
                }
                double x = RenderUtil.lerpDouble(this.currentPosition.field_1352, this.lastPosition.field_1352, event.getPartialTicks());
                double y = RenderUtil.lerpDouble(this.currentPosition.field_1351, this.lastPosition.field_1351, event.getPartialTicks());
                double z = RenderUtil.lerpDouble(this.currentPosition.field_1350, this.lastPosition.field_1350, event.getPartialTicks());
                float size = 0.1F;
                float width = mc.field_1724.method_17681();
                float height = mc.field_1724.method_17682();
                class_238 aabb = new class_238(
                        x - (double) width / 2.0,
                        y,
                        z - (double) width / 2.0,
                        x + (double) width / 2.0,
                        y + (double) height,
                        z + (double) width / 2.0
                )
                        .method_1009(size, size, size)
                        .method_989(
                                -mc.field_1773.method_19418().method_19326().field_1352,
                                -mc.field_1773.method_19418().method_19326().field_1351,
                                -mc.field_1773.method_19418().method_19326().field_1350
                        );
                RenderUtil.enableRenderState();
                RenderUtil.drawFilledBox(aabb, color.getRed(), color.getGreen(), color.getBlue());
                RenderUtil.disableRenderState();
            }
        }
    }

    @Override
    public void onDisabled() {
        Myau.lagManager.setDelay(0);
        this.tickIndex = -1;
        this.delayCounter = 0L;
        this.hasTarget = false;
        this.lastPosition = null;
        this.currentPosition = null;
    }

    @Override
    public String[] getSuffix() {
        if (this.mode.getValue() == 1) {
            return new String[]{String.format("%dms", this.delay.getValue())};
        } else {
            return new String[]{blinkTick.getValue().toString()};
        }
    }
}
