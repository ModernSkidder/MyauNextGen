package laoqi123.module.modules.combat;

import com.google.common.base.CaseFormat;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.Myau;
import laoqi123.enums.BlinkModules;
import laoqi123.event.EventManager;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.events.*;
import laoqi123.management.RotationState;
import laoqi123.mixin.ClientPlayerInteractionManagerAccessor;
import laoqi123.mixin.EntityRenderDispatcherAccessor;
import laoqi123.module.Module;
import laoqi123.module.modules.combat.killaura.KillAuraAutoBlock;
import laoqi123.module.modules.combat.killaura.KillAuraFailSwing;
import laoqi123.module.modules.combat.killaura.KillAuraRotation;
import laoqi123.module.modules.combat.killaura.KillAuraTargetSelect;
import laoqi123.module.modules.misc.BedNuker;
import laoqi123.module.modules.player.AutoBlockIn;
import laoqi123.module.modules.player.AutoHeal;
import laoqi123.module.modules.player.Scaffold;
import laoqi123.module.modules.render.HUD;
import laoqi123.property.Property;
import laoqi123.property.properties.*;
import laoqi123.util.*;
import laoqi123.util.clicking.Clicker;
import laoqi123.util.config.Configurable;
import laoqi123.util.rotation.MovementCorrection;
import laoqi123.util.rotation.Rotation;
import laoqi123.util.rotation.RotationWithVector;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1420;
import net.minecraft.class_1429;
import net.minecraft.class_1439;
import net.minecraft.class_1477;
import net.minecraft.class_1510;
import net.minecraft.class_1528;
import net.minecraft.class_1588;
import net.minecraft.class_1614;
import net.minecraft.class_1621;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_286;
import net.minecraft.class_2868;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_742;
import laoqi123.util.config.PropertyProvider;
import org.joml.Matrix4fStack;

import java.awt.*;
import java.util.ArrayList;
import java.util.stream.StreamSupport;

public class KillAura extends Module implements PropertyProvider {
    private static final class_310 mc = class_310.method_1551();
    public final KillAuraAutoBlock autoBlock;
    public final KillAuraTargetSelect targetSelect;
    public final KillAuraFailSwing failSwing;
    private final Configurable rootConfig = new Configurable("KillAura");

    public final FloatProperty swingRange;
    public final FloatProperty attackRange;
    public final IntProperty fov;
    public final IntProperty minCPS;
    public final IntProperty maxCPS;
    public final IntProperty switchDelay;
    public final BooleanProperty keepSprint;
    public final Clicker clicker;
    public final KillAuraRotation rotations;
    public final BooleanProperty throughWalls;
    public final BooleanProperty requirePress;
    public final BooleanProperty allowMining;
    public final BooleanProperty weaponsOnly;
    public final BooleanProperty allowTools;
    public final BooleanProperty inventoryCheck;
    public final BooleanProperty lowTimerCheck;
    public final BooleanProperty botCheck;
    public final BooleanProperty players;
    public final BooleanProperty bosses;
    public final BooleanProperty mobs;
    public final BooleanProperty animals;
    public final BooleanProperty golems;
    public final BooleanProperty silverfish;
    public final BooleanProperty teams;
    public final BooleanProperty shark;
    public ModeProperty showTarget;

    private final TimerUtil timer = new TimerUtil();
    public AttackData target = null;
    private int switchTick = 0;
    private boolean hitRegistered = false;

    public KillAura() {
        super("KillAura", false);
        this.targetSelect = new KillAuraTargetSelect();
        this.autoBlock = new KillAuraAutoBlock(this);
        this.failSwing = new KillAuraFailSwing();
        this.rootConfig.setRunningOverride(this::isEnabled);
        this.rootConfig.addChild(this.targetSelect);
        this.rootConfig.addChild(this.autoBlock);
        this.rootConfig.addChild(this.failSwing);

        this.swingRange = new FloatProperty("Swing Range", 3.5F, 3.0F, 6.0F);
        this.attackRange = new FloatProperty("Attack Range", 3.0F, 3.0F, 6.0F);
        this.fov = new IntProperty("Fov", 360, 30, 360);
        this.minCPS = new IntProperty("Min Aps", 14, 1, 20);
        this.maxCPS = new IntProperty("Max Aps", 14, 1, 20);
        this.keepSprint = new BooleanProperty("KeepSprint", true);
        this.clicker = new Clicker("KillAuraClicker", this.minCPS, this.maxCPS);
        this.rootConfig.addChild(this.clicker);
        this.switchDelay = new IntProperty("Switch Delay", 150, 0, 1000);
        this.rotations = new KillAuraRotation();
        this.rootConfig.addChild(this.rotations);
        this.throughWalls = new BooleanProperty("Through Walls", true);
        this.requirePress = new BooleanProperty("Require Press", false);
        this.allowMining = new BooleanProperty("Allow Mining", false);
        this.weaponsOnly = new BooleanProperty("Weapons Only", false);
        this.allowTools = new BooleanProperty("Allow Tools", false, this.weaponsOnly::getValue);
        this.inventoryCheck = new BooleanProperty("Inventory Check", true);
        this.lowTimerCheck = new BooleanProperty("Low Timer Check", true);
        this.botCheck = new BooleanProperty("Bot Check", true);
        this.players = new BooleanProperty("Players", true);
        this.bosses = new BooleanProperty("Bosses", false);
        this.mobs = new BooleanProperty("Mobs", false);
        this.animals = new BooleanProperty("Animals", false);
        this.golems = new BooleanProperty("Golems", false);
        this.silverfish = new BooleanProperty("Silverfish", false);
        this.teams = new BooleanProperty("Teams", true);
        this.shark = new BooleanProperty("Shark", false);
        this.showTarget = new ModeProperty("Show Target", 0, new String[]{"None", "Default", "Hud", "Scan"});
    }

    public FloatProperty scanThickness = new FloatProperty("ScanThickness", 0.6F, 0.1F, 2.5F, () -> showTarget.getValue() == 3);

    public long getAttackDelayMS() {
        float remainingTicks = (1.0F - mc.field_1724.method_7261(0.0F)) / mc.field_1724.method_7279();
        return Math.max(0L, Math.round(remainingTicks) * 50L);
    }

    private void sendCriticalPackets() {
        double x = mc.field_1724.method_23317();
        double y = mc.field_1724.method_23318();
        double z = mc.field_1724.method_23321();
        boolean horizontalCollision = mc.field_1724.field_5976;
        PacketUtil.sendPacket(new class_2828.class_2829(x, y + 1.0E-10, z, false, horizontalCollision));
        PacketUtil.sendPacket(new class_2828.class_2829(x, y, z, false, horizontalCollision));
    }

    private boolean performAttack(float yaw, float pitch) {
        if (!Myau.playerStateManager.digging && !Myau.playerStateManager.placing) {
            if (this.autoBlock.isPlayerBlocking() && this.autoBlock.mode.getValue() != 1) {
                return false;
            } else if (mc.field_1687.method_54719().method_54748() < 20.0F && lowTimerCheck.getValue()) {
                return false;
            } else {
                if (RotationUtil.rayTrace(this.target.getBox(), yaw, pitch, this.attackRange.getValue()) == null) {
                    if (this.failSwing.isEnabled()
                            && RotationUtil.distanceToEntity(this.target.getEntity())
                            <= (double) this.attackRange.getValue() + this.failSwing.getCurrentAdditionalRange()) {
                        this.failSwing.recordFailedHit(this.target.getEntity());
                    }
                    return false;
                } else {
                    if (this.shark.getValue() && !mc.field_1724.method_24828()) {
                        this.sendCriticalPackets();
                    }
                    AttackEvent event = new AttackEvent(this.target.getEntity());
                    EventManager.call(event);
                    ((ClientPlayerInteractionManagerAccessor) mc.field_1761).callSyncCurrentPlayItem();
                    if (this.keepSprint.getValue()) {
                        PacketUtil.sendPacket(class_2824.method_34206(this.target.getEntity(), mc.field_1724.method_5715()));
                        mc.field_1724.method_6104(class_1268.field_5808);
                    } else if (mc.field_1761.method_2920() != class_1934.field_9219) {
                        PlayerUtil.attackEntity(this.target.getEntity());
                    }
                    this.hitRegistered = true;
                    return true;
                }
            }
        } else {
            return false;
        }
    }

    private boolean canAttack() {
        if (this.inventoryCheck.getValue() && mc.field_1755 != null) {
            return false;
        } else if (!(Boolean) this.weaponsOnly.getValue()
                || ItemUtil.hasRawUnbreakingEnchant()
                || this.allowTools.getValue() && ItemUtil.isHoldingTool()) {
            if (((ClientPlayerInteractionManagerAccessor) mc.field_1761).getIsHittingBlock()) {
                return false;
            } else if ((ItemUtil.isEating() || ItemUtil.isUsingBow()) && PlayerUtil.isUsingItem()) {
                return false;
            } else {
                AutoHeal autoHeal = (AutoHeal) Myau.moduleManager.getModule(AutoHeal.class);
                if (autoHeal.isEnabled() && autoHeal.isSwitching()) {
                    return false;
                } else {
                    BedNuker bedNuker = (BedNuker) Myau.moduleManager.getModule(BedNuker.class);
                    AutoBlockIn autoBlockIn = (AutoBlockIn) Myau.moduleManager.getModule(AutoBlockIn.class);
                    if (bedNuker.isEnabled() && bedNuker.isReady()) {
                        return false;
                    } else if (Myau.moduleManager.getModule(Scaffold.class).isEnabled()) {
                        return false;
                    } else if (autoBlockIn.isEnabled()) {
                        return false;
                    } else if (this.requirePress.getValue()) {
                        return PlayerUtil.isAttacking();
                    } else {
                        return !this.allowMining.getValue() || mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1332 || !PlayerUtil.isAttacking();
                    }
                }
            }
        } else {
            return false;
        }
    }

    private boolean canAutoBlock() {
        return this.autoBlock.canAutoBlock();
    }

    public boolean hasValidTarget() {
        return StreamSupport.stream(mc.field_1687
                .method_18112()
                .spliterator(), false)
                .anyMatch(
                        entity -> entity instanceof class_1309
                                && this.isValidTarget((class_1309) entity)
                                && this.isInBlockRange((class_1309) entity)
                );
    }

    private boolean isValidTarget(class_1309 entityLivingBase) {
        if (!TeamUtil.isEntityLoaded(entityLivingBase)) {
            return false;
        } else if (entityLivingBase != mc.field_1724 && entityLivingBase != mc.field_1724.method_5854()) {
            if (entityLivingBase == mc.method_1560() || entityLivingBase == mc.method_1560().method_5854()) {
                return false;
            } else if (entityLivingBase.field_6213 > 0) {
                return false;
            } else if (RotationUtil.angleToEntity(entityLivingBase) > this.fov.getValue().floatValue()) {
                return false;
            } else if (!this.throughWalls.getValue() && !RotationUtil.hasVisiblePoint(entityLivingBase.method_5829().method_1009(entityLivingBase.method_5871(), entityLivingBase.method_5871(), entityLivingBase.method_5871()))) {
                return false;
            } else if (entityLivingBase instanceof class_742) {
                if (!this.players.getValue()) {
                    return false;
                } else if (TeamUtil.isFriend((class_1657) entityLivingBase)) {
                    return false;
                } else {
                    return (!this.teams.getValue() || !Teams.isKillAuraTeam((class_1657) entityLivingBase)) && (!this.botCheck.getValue() || !TeamUtil.isBot((class_1657) entityLivingBase));
                }
            } else if (entityLivingBase instanceof class_1510 || entityLivingBase instanceof class_1528) {
                return this.bosses.getValue();
            } else if (!(entityLivingBase instanceof class_1588) && !(entityLivingBase instanceof class_1621)) {
                if (entityLivingBase instanceof class_1429
                        || entityLivingBase instanceof class_1420
                        || entityLivingBase instanceof class_1477
                        || entityLivingBase instanceof class_1646) {
                    return this.animals.getValue();
                } else if (!(entityLivingBase instanceof class_1439)) {
                    return false;
                } else {
                    return this.golems.getValue() && (!this.teams.getValue() || !TeamUtil.hasTeamColor(entityLivingBase));
                }
            } else if (!(entityLivingBase instanceof class_1614)) {
                return this.mobs.getValue();
            } else {
                return this.silverfish.getValue() && (!this.teams.getValue() || !TeamUtil.hasTeamColor(entityLivingBase));
            }
        } else {
            return false;
        }
    }

    private boolean isInRange(class_1309 entityLivingBase) {
        return this.isInBlockRange(entityLivingBase) || this.isInSwingRange(entityLivingBase) || this.isInAttackRange(entityLivingBase);
    }

    private boolean isInBlockRange(class_1309 entityLivingBase) {
        return RotationUtil.distanceToEntity(entityLivingBase) <= (double) this.autoBlock.range.getValue();
    }

    private boolean isInSwingRange(class_1309 entityLivingBase) {
        return RotationUtil.distanceToEntity(entityLivingBase) <= (double) this.swingRange.getValue();
    }

    private boolean isBoxInSwingRange(class_238 axisAlignedBB) {
        return RotationUtil.distanceToBox(axisAlignedBB) <= (double) this.swingRange.getValue();
    }

    private boolean isInAttackRange(class_1309 entityLivingBase) {
        return RotationUtil.distanceToEntity(entityLivingBase) <= (double) this.attackRange.getValue();
    }

    private boolean isBoxInAttackRange(class_238 axisAlignedBB) {
        return RotationUtil.distanceToBox(axisAlignedBB) <= (double) this.attackRange.getValue();
    }

    private boolean isPlayerTarget(class_1309 entityLivingBase) {
        return entityLivingBase instanceof class_1657 && TeamUtil.isTarget((class_1657) entityLivingBase);
    }

    public class_1309 getTarget() {
        return this.target != null ? this.target.getEntity() : null;
    }

    public java.util.List<class_1309> getTargets() {
        java.util.List<class_1309> result = new ArrayList<>();
        if (this.target != null && TeamUtil.isEntityLoaded(this.target.getEntity())) {
            result.add(this.target.getEntity());
        }
        if (this.targetSelect.mode.getValue() == 1) {
            for (class_1297 entity : mc.field_1687.method_18112()) {
                if (entity instanceof class_1309) {
                    class_1309 e = (class_1309) entity;
                    if (isValidTarget(e) && isInRange(e) && !result.contains(e)) {
                        result.add(e);
                    }
                }
            }
        }
        return result;
    }

    public boolean isAttackAllowed() {
        Scaffold scaffold = (Scaffold) Myau.moduleManager.getModule(Scaffold.class);
        if (scaffold.isEnabled()) {
            return false;
        } else if (!this.weaponsOnly.getValue()
                || ItemUtil.hasRawUnbreakingEnchant()
                || this.allowTools.getValue() && ItemUtil.isHoldingTool()) {
            return !this.requirePress.getValue() || KeyBindUtil.isKeyDown(mc.field_1690.field_1886);
        } else {
            return false;
        }
    }

    public boolean shouldAutoBlock() {
        return this.autoBlock.shouldAutoBlock();
    }

    public boolean isBlocking() {
        return this.autoBlock.isBlocking();
    }

    public boolean isPlayerBlocking() {
        return this.autoBlock.isPlayerBlocking();
    }

    @EventTarget(Priority.LOW)
    public void onUpdate(UpdateEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            this.clicker.tick();
            boolean attack = this.target != null && this.canAttack();
            boolean inAttackRange = attack;
            KillAuraAutoBlock.BlockResult blockResult = this.autoBlock.updateBlocking(this, attack);
            attack = blockResult.attack;
            boolean swap = blockResult.swap;
            boolean blocked = blockResult.blocked;
            if (this.target != null) {
                RotationWithVector rotationData = this.rotations.findRotation(this.target.getEntity(), this.swingRange.getValue(), this.throughWalls.getValue());
                boolean active = rotationData != null;
                Rotation next = this.rotations.update(active ? rotationData.getRotation() : null, this.target.getEntity(), active);
                if (next != null) {
                    event.setRotation(next.getYaw(), next.getPitch(), 1);
                    MovementCorrection correction = this.rotations.getMovementCorrection();
                    if (correction != MovementCorrection.OFF) {
                        event.setPervRotation(next.getYaw(), 1);
                    }
                    if (correction == MovementCorrection.CHANGE_LOOK) {
                        Myau.rotationManager.setRotation(next.getYaw(), next.getPitch(), 1, true);
                    }
                }
            } else {
                this.rotations.update(null, null, false);
            }
            if (inAttackRange && this.isBoxInSwingRange(this.target.getBox())) {
                boolean attacked = false;
                if (attack) {
                    attacked = this.clicker.click(() -> this.performAttack(event.getNewYaw(), event.getNewPitch()));
                }
                if (swap) {
                    if (attacked) {
                        this.autoBlock.interactAttack(event.getNewYaw(), event.getNewPitch(), this.target);
                    } else {
                        if (!this.autoBlock.isPostBlock()) this.autoBlock.sendUseItem();
                    }
                }
            }
            if (blocked) {
                Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                Myau.blinkManager.setBlinkState(true, BlinkModules.AUTO_BLOCK);
            }
        }
        if (event.getType() == EventType.POST && this.isEnabled()) {
            this.autoBlock.handlePostTick();
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled()) {
            switch (event.getType()) {
                case PRE:
                    this.rotations.tick();
                    if (this.target == null
                            || !this.isValidTarget(this.target.getEntity())
                            || !this.isBoxInAttackRange(this.target.getBox())
                            || !this.isBoxInSwingRange(this.target.getBox())
                            || this.timer.hasTimeElapsed(this.switchDelay.getValue().longValue())) {
                        this.timer.reset();
                        ArrayList<class_1309> targets = new ArrayList<>();
                        for (class_1297 entity : mc.field_1687.method_18112()) {
                            if (entity instanceof class_1309
                                    && this.isValidTarget((class_1309) entity)
                                    && this.isInRange((class_1309) entity)) {
                                targets.add((class_1309) entity);
                            }
                        }
                        if (targets.isEmpty()) {
                            this.target = null;
                        } else {
                            if (targets.stream().anyMatch(this::isInSwingRange)) {
                                targets.removeIf(entityLivingBase -> !this.isInSwingRange(entityLivingBase));
                            }
                            if (targets.stream().anyMatch(this::isInAttackRange)) {
                                targets.removeIf(entityLivingBase -> !this.isInAttackRange(entityLivingBase));
                            }
                            if (targets.stream().anyMatch(this::isPlayerTarget)) {
                                targets.removeIf(entityLivingBase -> !this.isPlayerTarget(entityLivingBase));
                            }
                            targets.sort(
                                    (entityLivingBase1, entityLivingBase2) -> {
                                        int sortBase = 0;
                                        switch (this.targetSelect.sort.getValue()) {
                                            case 1:
                                                sortBase = Float.compare(TeamUtil.getHealthScore(entityLivingBase1), TeamUtil.getHealthScore(entityLivingBase2));
                                                break;
                                            case 2:
                                                sortBase = Integer.compare(entityLivingBase1.field_6235, entityLivingBase2.field_6235);
                                                break;
                                            case 3:
                                                sortBase = Float.compare(
                                                        RotationUtil.angleToEntity(entityLivingBase1),
                                                        RotationUtil.angleToEntity(entityLivingBase2)
                                                );
                                        }
                                        return sortBase != 0
                                                ? sortBase
                                                : Double.compare(RotationUtil.distanceToEntity(entityLivingBase1), RotationUtil.distanceToEntity(entityLivingBase2));
                                    }
                            );
                            if (this.targetSelect.mode.getValue() == 1 && this.hitRegistered) {
                                this.hitRegistered = false;
                                this.switchTick++;
                            }
                            if (this.targetSelect.mode.getValue() == 0 || this.switchTick >= targets.size()) {
                                this.switchTick = 0;
                            }
                            this.target = new AttackData(targets.get(this.switchTick));
                        }
                    }
                    if (this.target != null) {
                        this.target = new AttackData(this.target.getEntity());
                    }
                    break;
                case POST:
                    if (this.isPlayerBlocking() && !mc.field_1724.method_6039()) {
                        mc.field_1724.method_6019(class_1268.field_5808);
                    }
            }
        }
    }

    @EventTarget(Priority.LOWEST)
    public void onPacket(PacketEvent event) {
        if (this.isEnabled() && !event.isCancelled()) {
            if (event.getPacket() instanceof class_2846) {
                class_2846 packet = (class_2846) event.getPacket();
                if (packet.method_12363() == class_2846.class_2847.field_12974) {
                    this.autoBlock.onReleaseUseItem();
                }
            }
            if (event.getPacket() instanceof class_2868) {
                this.autoBlock.onSlotChangePacket();
            }
        }
    }

    @EventTarget
    public void onMove(MoveInputEvent event) {
        if (this.isEnabled()) {
            if (this.rotations.getMovementCorrection() == MovementCorrection.STRICT
                    && RotationState.isActived()
                    && RotationState.getPriority() == 1.0F
                    && MoveUtil.isForwardPressed()) {
                MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
            }
        }
    }

    @EventTarget
    public void onRender(Render3DEvent event) {
        this.failSwing.renderFailedHits();
        if (this.isEnabled() && target != null) {
            if (this.showTarget.getValue() != 0
                    && TeamUtil.isEntityLoaded(this.target.getEntity())
                    && this.isAttackAllowed() && this.showTarget.getValue() != 3) {
                Color color = new Color(-1);
                switch (this.showTarget.getValue()) {
                    case 1:
                        if (this.target.getEntity().field_6235 > 0) {
                            color = new Color(16733525);
                        } else {
                            color = new Color(5635925);
                        }
                        break;
                    case 2:
                        color = ((HUD) Myau.moduleManager.getModule(HUD.class)).getColor(System.currentTimeMillis());
                }
                RenderUtil.enableRenderState();
                RenderUtil.drawEntityBox(this.target.getEntity(), color.getRed(), color.getGreen(), color.getBlue());
                RenderUtil.disableRenderState();
            }
            if (this.showTarget.getValue() == 3) {
                renderScan(event);
            }
        }
    }

    public static class_243 interpolate(class_243 previousVec, class_243 currentVec, float progress) {
        return new class_243(
                previousVec.field_1352 + (currentVec.field_1352 - previousVec.field_1352) * progress,
                previousVec.field_1351 + (currentVec.field_1351 - previousVec.field_1351) * progress,
                previousVec.field_1350 + (currentVec.field_1350 - previousVec.field_1350) * progress
        );
    }

    private void renderScan(Render3DEvent event) {
        if (target == null) return;

        double renderPosX = ((EntityRenderDispatcherAccessor) mc.method_1561()).getCamera().method_19326().field_1352;
        double renderPosY = ((EntityRenderDispatcherAccessor) mc.method_1561()).getCamera().method_19326().field_1351;
        double renderPosZ = ((EntityRenderDispatcherAccessor) mc.method_1561()).getCamera().method_19326().field_1350;
        class_243 interpolated = interpolate(
                new class_243(target.entity.field_6014, target.entity.field_6036, target.entity.field_5969),
                target.entity.method_19538(),
                event.getPartialTicks()
        );

        double height = target.entity.method_17682();
        long time = System.currentTimeMillis();
        double rawAngle = time / 300.0;
        double offset = (Math.sin(rawAngle) + 1) / 2.0 * height;

        double thicknessScale = 1.0 - Math.abs(Math.sin(rawAngle));
        double minScale = 0.15;
        thicknessScale = minScale + (1.0 - minScale) * thicknessScale;

        double x = interpolated.field_1352 - renderPosX;
        double y = interpolated.field_1351 + offset - renderPosY;
        double z = interpolated.field_1350 - renderPosZ;

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.disableCull();

        float radius = 0.6f;
        double baseThickness = scanThickness.getValue();
        double thickness = baseThickness * thicknessScale;
        double halfThick = thickness / 2.0;
        double bottomY = -halfThick;

        int slices = 60;

        Matrix4fStack modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.pushMatrix();
        modelViewStack.translate((float) x, (float) y, (float) z);

        class_289 tessellator = class_289.method_1348();
        for (int i = 0; i < slices; i++) {
            double angle1 = Math.toRadians((i / (double) slices) * 360.0);
            double angle2 = Math.toRadians(((i + 1) / (double) slices) * 360.0);

            double x1 = Math.sin(angle1) * radius;
            double z1 = Math.cos(angle1) * radius;
            double x2 = Math.sin(angle2) * radius;
            double z2 = Math.cos(angle2) * radius;

            Color col1 = ((HUD) Myau.moduleManager.getModule(HUD.class)).getColor((int) (i * 360.0 / slices * 10));
            Color col2 = ((HUD) Myau.moduleManager.getModule(HUD.class)).getColor((int) ((i + 1) * 360.0 / slices * 10));
            int r1 = col1.getRed();
            int g1 = col1.getGreen();
            int b1 = col1.getBlue();
            int r2 = col2.getRed();
            int g2 = col2.getGreen();
            int b2 = col2.getBlue();

            int alphaBottom = 12;
            int alphaTop = 178;

            class_287 bufferBuilder = tessellator.method_60827(class_293.class_5596.field_27380, class_290.field_1576);
            bufferBuilder.method_22912((float) x1, (float) bottomY, (float) z1).method_1336(r1, g1, b1, alphaBottom);
            bufferBuilder.method_22912((float) x1, (float) halfThick, (float) z1).method_1336(r1, g1, b1, alphaTop);
            bufferBuilder.method_22912((float) x2, (float) bottomY, (float) z2).method_1336(r2, g2, b2, alphaBottom);
            bufferBuilder.method_22912((float) x2, (float) halfThick, (float) z2).method_1336(r2, g2, b2, alphaTop);
            class_286.method_43433(bufferBuilder.method_60800());
        }

        modelViewStack.popMatrix();

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    @EventTarget
    public void onLeftClick(LeftClickMouseEvent event) {
        if (this.autoBlock.isBlocking()) {
            event.setCancelled(true);
        } else {
            if (this.isEnabled() && this.target != null && this.canAttack()) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onRightClick(RightClickMouseEvent event) {
        if (this.autoBlock.isBlocking()) {
            event.setCancelled(true);
        } else {
            if (this.isEnabled() && this.target != null && this.canAttack()) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onHitBlock(HitBlockEvent event) {
        if (this.autoBlock.isBlocking()) {
            event.setCancelled(true);
        } else {
            if (this.isEnabled() && this.target != null && this.canAttack()) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onCancelUse(CancelUseEvent event) {
        if (this.autoBlock.isBlocking()) {
            event.setCancelled(true);
        }
    }

    @Override
    public void onEnabled() {
        this.target = null;
        this.switchTick = 0;
        this.hitRegistered = false;
        this.clicker.reset();
        this.autoBlock.reset();
        this.failSwing.reset();
        this.rotations.reset();
    }

    @Override
    public void onDisabled() {
        Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
        this.autoBlock.reset();
        this.failSwing.reset();
    }

    @Override
    public void verifyValue(String mode) {
        if (!this.autoBlock.mode.getName().equals(mode) && !this.autoBlock.aps.getName().equals(mode)) {
            if (this.swingRange.getName().equals(mode)) {
                if (this.swingRange.getValue() < this.attackRange.getValue()) {
                    this.attackRange.setValue(this.swingRange.getValue());
                }
            } else if (this.attackRange.getName().equals(mode)) {
                if (this.swingRange.getValue() < this.attackRange.getValue()) {
                    this.swingRange.setValue(this.attackRange.getValue());
                }
            } else if (this.minCPS.getName().equals(mode)) {
                if (this.minCPS.getValue() > this.maxCPS.getValue()) {
                    this.maxCPS.setValue(this.minCPS.getValue());
                }
            } else {
                if (this.maxCPS.getName().equals(mode) && this.minCPS.getValue() > this.maxCPS.getValue()) {
                    this.minCPS.setValue(this.maxCPS.getValue());
                }
            }
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, this.targetSelect.mode.getModeString())};
    }

    public KillAuraAutoBlock getAutoBlock() {
        return this.autoBlock;
    }

    public KillAuraFailSwing getFailSwing() {
        return this.failSwing;
    }

    @Override
    public java.util.List<Property<?>> getAdditionalProperties() {
        return this.rootConfig.collectProperties();
    }

    public static class AttackData {
        private final class_1309 entity;
        private final class_238 box;
        private final double x;
        private final double y;
        private final double z;

        public AttackData(class_1309 entityLivingBase) {
            this.entity = entityLivingBase;
            double collisionBorderSize = entityLivingBase.method_5871();
            this.box = entityLivingBase.method_5829().method_1009(collisionBorderSize, collisionBorderSize, collisionBorderSize);
            this.x = entityLivingBase.method_23317();
            this.y = entityLivingBase.method_23318();
            this.z = entityLivingBase.method_23321();
        }

        public class_1309 getEntity() {
            return this.entity;
        }

        public class_238 getBox() {
            return this.box;
        }

        public double getX() {
            return this.x;
        }

        public double getY() {
            return this.y;
        }

        public double getZ() {
            return this.z;
        }
    }
}
