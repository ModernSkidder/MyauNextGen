package laoqi123.module.modules.combat;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.TickEvent;
import laoqi123.module.Module;
import laoqi123.module.modules.player.InvWalk;
import laoqi123.value.properties.BooleanValue;
import laoqi123.value.properties.IntValue;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_239;
import net.minecraft.class_310;
import laoqi123.util.ItemUtil;
import laoqi123.util.KeyBindUtil;

public class AutoAnduril extends Module {
    private static final class_310 mc = class_310.method_1551();
    private int previousSlot = -1;
    private int currentSlot = -1;
    private int intervalTick = -1;
    private int holdTick = -1;
    public final IntValue interval = new IntValue("interval", 40, 0, 100);
    public final IntValue hold = new IntValue("hold", 1, 0, 20);
    public final BooleanValue speedCheck = new BooleanValue("speed-check", false);
    public final IntValue debug = new IntValue("debug", 0, 0, 9);

    public AutoAnduril() {
        super("AutoAnduril", false);
    }

    public boolean canSwap() {
        if (mc.field_1765 != null
                && mc.field_1765.method_17783() == class_239.class_240.field_1332
                && KeyBindUtil.isKeyDown(mc.field_1690.field_1886)) return false;
        class_1799 currentItem = mc.field_1724.method_31548().method_5438(mc.field_1724.method_31548().field_7545);
        if (currentItem != null) {
            if (currentItem.method_7909() instanceof class_1747 && KeyBindUtil.isKeyDown(mc.field_1690.field_1904)) return false;
            if (!(currentItem.method_7909() instanceof class_1829) && mc.field_1724.method_6115()) return false;
        }
        InvWalk invWalk = (InvWalk) Myau.moduleManager.modules.get(InvWalk.class);
        return mc.field_1755 == null || mc.field_1755 instanceof laoqi123.ui.ClickGui
                || invWalk.isEnabled() && invWalk.canInvWalk();
    }

    public boolean hasSpeed() {
        if (!speedCheck.getValue()) return false;
        class_1293 potionEffect = mc.field_1724.method_6112(class_1294.field_5904);
        if (potionEffect == null) return false;
        return (potionEffect.method_5578() > 0);
    }

    @EventTarget(Priority.LOWEST)
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            if (this.currentSlot != -1 && this.currentSlot != mc.field_1724.method_31548().field_7545) {
                this.currentSlot = -1;
                this.previousSlot = -1;
                this.intervalTick = interval.getValue();
                this.holdTick = -1;
            }

            if (this.intervalTick > 0) {
                this.intervalTick--;
            } else if (intervalTick == 0) {
                if (canSwap() && !hasSpeed()) {
                    int slot = ItemUtil.findAndurilHotbarSlot(mc.field_1724.method_31548().field_7545);
                    if (debug.getValue() != 0 && slot == -1) slot = debug.getValue() - 1;
                    if (slot != -1 && slot != mc.field_1724.method_31548().field_7545) {
                        this.previousSlot = mc.field_1724.method_31548().field_7545;
                        this.currentSlot = mc.field_1724.method_31548().field_7545 = slot;
                        this.intervalTick = -1;
                        this.holdTick = hold.getValue();
                        return;
                    } else {
                        this.intervalTick = interval.getValue();
                        this.holdTick = -1;
                    }
                }
            }
            if (this.holdTick > 0) {
                this.holdTick--;
            } else if (holdTick == 0) {
                if (this.previousSlot != -1 && canSwap()) {
                    mc.field_1724.method_31548().field_7545 = this.previousSlot;
                    this.previousSlot = -1;
                    this.holdTick = -1;
                    this.intervalTick = interval.getValue();
                }
            }
        }
    }

    @Override
    public void onEnabled() {
        this.previousSlot = -1;
        this.currentSlot = -1;
        this.intervalTick = this.interval.getValue();
        this.holdTick = -1;
    }

    @Override
    public void onDisabled() {
        this.previousSlot = -1;
        this.currentSlot = -1;
        this.intervalTick = -1;
        this.holdTick = -1;
    }
}
