package laoqi123.module.modules.combat;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.*;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.FloatProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.util.PacketUtil;
import laoqi123.util.RenderUtil;
import net.minecraft.class_10264;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2709;
import net.minecraft.class_2716;
import net.minecraft.class_2777;
import net.minecraft.class_310;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ConcurrentLinkedQueue;

public class BackTrack extends Module {

    private static final class_310 mc = class_310.method_1551();

    private final IntProperty trackMs = new IntProperty("TrackMS", 200, 1, 1000);
    private final FloatProperty maxDistance = new FloatProperty("MaxTrackRange", 6.0F, 3.1F, 6.0F);
    private final IntProperty maxTick = new IntProperty("MaxTick", 10, 0, 30);
    private final BooleanProperty renderRealPos = new BooleanProperty("RenderRealPos", true);
    private final BooleanProperty smart = new BooleanProperty("Smart", true);
    private final BooleanProperty onlyHighSpeed = new BooleanProperty("Only On Target High Speed", false);
    private final FloatProperty highSpeedThreshold = new FloatProperty("HighSpeed Threshold", 0.2F, 0.01F, 1.0F, onlyHighSpeed::getValue);

    private final Queue<TimedPacket> packetQueue = new ConcurrentLinkedQueue<>();
    private final List<class_2596<?>> skipPackets = new ArrayList<>();
    private final Deque<class_243> positionHistory = new ConcurrentLinkedDeque<>();
    private final Deque<class_243> recentPositions = new ConcurrentLinkedDeque<>();

    private class_243 realTargetPos;
    private class_243 lastRealTargetPos;
    private class_1657 target;
    private int attackTicks;

    public BackTrack() {
        super("BackTrack", false);
    }

    @Override
    public String[] getSuffix() {
        return new String[]{trackMs.getValue() + "ms"};
    }

    @Override
    public void onEnabled() {
        clearAll();
    }

    @Override
    public void onDisabled() {
        releaseAll();
        clearAll();
    }

    private void clearAll() {
        packetQueue.clear();
        skipPackets.clear();
        positionHistory.clear();
        recentPositions.clear();
        realTargetPos = null;
        lastRealTargetPos = null;
        target = null;
        attackTicks = 0;
    }

    @EventTarget
    public void onAttack(AttackEvent e) {
        if (!isEnabled()) return;

        class_1297 entity = e.getTarget();
        if (!(entity instanceof class_1657)) return;

        class_1657 player = (class_1657) entity;

        if (onlyHighSpeed.getValue()) {
            double dx = player.method_23317() - player.field_6014;
            double dy = player.method_23318() - player.field_6036;
            double dz = player.method_23321() - player.field_5969;
            double speed = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (speed < highSpeedThreshold.getValue()) {
                return;
            }
        }

        if (target != null && player.method_5628() == target.method_5628()) {
            attackTicks = 0;
            return;
        }

        target = player;
        realTargetPos = player.method_19538();
        lastRealTargetPos = realTargetPos;

        positionHistory.clear();
        recentPositions.clear();
        positionHistory.add(realTargetPos);
        recentPositions.add(realTargetPos);

        attackTicks = 0;
    }

    @EventTarget
    public void onTick(TickEvent e) {
        if (!isEnabled() || e.getType() == EventType.POST) return;

        if (target != null) {
            attackTicks++;
        }

        updateTargetLogic();
        processPacketQueue();

        if (packetQueue.isEmpty() && target != null) {
            realTargetPos = target.method_19538();
        }
    }

    private void updateTargetLogic() {
        if (target == null || realTargetPos == null) return;

        try {
            class_243 currentPos = realTargetPos;
            recentPositions.addLast(currentPos);
            if (recentPositions.size() > 5) {
                recentPositions.removeFirst();
            }

            if (recentPositions.size() == 5) {
                class_243 oldestPos = recentPositions.getFirst();
                if (oldestPos.method_1022(currentPos) > 5.0) {
                    resetAndRelease();
                    return;
                }
            }

            positionHistory.addLast(currentPos);
            if (positionHistory.size() > 10) {
                positionHistory.removeFirst();
            }

            boolean tooFar = realTargetPos.method_1022(mc.field_1724.method_19538()) > maxDistance.getValue();
            boolean tickExpired = attackTicks > maxTick.getValue();
            if (tickExpired || tooFar) {
                resetAndRelease();
                return;
            }

            if (smart.getValue() && !positionHistory.isEmpty()) {
                class_243 firstHistory = positionHistory.getFirst();
                double distReal = realTargetPos.method_1022(mc.field_1724.method_19538());
                double distHistory = firstHistory.method_1022(mc.field_1724.method_19538());
                if (distReal <= distHistory) {
                    resetAndRelease();
                    return;
                }
            }

            lastRealTargetPos = realTargetPos;
        } catch (Exception ex) {
            resetAndRelease();
        }
    }

    private void processPacketQueue() {
        long maxDelay = trackMs.getValue();

        while (!packetQueue.isEmpty()) {
            TimedPacket timedPacket = packetQueue.peek();
            if (timedPacket == null) break;

            if (timedPacket.elapsed(maxDelay)) {
                packetQueue.poll();
                class_2596<?> packet = timedPacket.getPacket();
                skipPackets.add(packet);
                PacketUtil.receivePacket(packet);
            } else {
                break;
            }
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (!isEnabled() || target == null || realTargetPos == null || lastRealTargetPos == null)
            return;
        if (!renderRealPos.getValue())
            return;

        float size = target.method_5871();
        double width = target.method_17681() / 2.0 + size;
        double height = target.method_17682() + size;

        class_243 smoothed = getSmoothedPosition(event.getPartialTicks());
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        class_238 aabb = new class_238(
                smoothed.field_1352 - width, smoothed.field_1351, smoothed.field_1350 - width,
                smoothed.field_1352 + width, smoothed.field_1351 + height, smoothed.field_1350 + width
        ).method_989(
                -cameraPos.field_1352,
                -cameraPos.field_1351,
                -cameraPos.field_1350
        );

        RenderUtil.drawFilledBox(aabb, 255, 255, 255);
    }

    private class_243 getSmoothedPosition(float partialTicks) {
        if (positionHistory.isEmpty()) {
            return new class_243(
                    lastRealTargetPos.field_1352 + (realTargetPos.field_1352 - lastRealTargetPos.field_1352) * partialTicks,
                    lastRealTargetPos.field_1351 + (realTargetPos.field_1351 - lastRealTargetPos.field_1351) * partialTicks,
                    lastRealTargetPos.field_1350 + (realTargetPos.field_1350 - lastRealTargetPos.field_1350) * partialTicks
            );
        }

        double totalWeight = 0;
        double x = 0, y = 0, z = 0;

        Object[] history = positionHistory.toArray();
        int size = history.length;
        for (int i = 0; i < size; i++) {
            double weight = (i + 1) / (double) size;
            class_243 pos = (class_243) history[i];
            x += pos.field_1352 * weight;
            y += pos.field_1351 * weight;
            z += pos.field_1350 * weight;
            totalWeight += weight;
        }

        double currentWeight = 3;
        x += realTargetPos.field_1352 * currentWeight;
        y += realTargetPos.field_1351 * currentWeight;
        z += realTargetPos.field_1350 * currentWeight;
        totalWeight += currentWeight;

        return new class_243(x / totalWeight, y / totalWeight, z / totalWeight);
    }

    @EventTarget
    public void onPacket(PacketEvent e) {
        if (!isEnabled() || e.getType() == EventType.SEND) return;

        class_2596<?> packet = e.getPacket();
        if (skipPackets.contains(packet)) {
            skipPackets.remove(packet);
            return;
        }

        if (target == null) return;

        boolean shouldIntercept = false;

        if (packet instanceof class_2777) {
            class_2777 wrapper = (class_2777) packet;
            class_1297 entity = mc.field_1687.method_8469(wrapper.comp_3237());
            if (entity != null && entity.method_5628() == target.method_5628()) {
                Set<class_2709> flags = wrapper.comp_3239();
                class_243 change = wrapper.comp_3238().comp_3148();
                realTargetPos = new class_243(
                        flags.contains(class_2709.field_12400) ? realTargetPos.field_1352 + change.field_1352 : change.field_1352,
                        flags.contains(class_2709.field_12398) ? realTargetPos.field_1351 + change.field_1351 : change.field_1351,
                        flags.contains(class_2709.field_12403) ? realTargetPos.field_1350 + change.field_1350 : change.field_1350
                );
                shouldIntercept = true;
            }
        } else if (packet instanceof class_10264) {
            class_10264 wrapper = (class_10264) packet;
            if (wrapper.comp_3223() == target.method_5628()) {
                realTargetPos = wrapper.comp_3224().comp_3148();
                shouldIntercept = true;
            }
        } else if (packet instanceof class_2716) {
            class_2716 wrapper = (class_2716) packet;
            for (int id : wrapper.method_36548()) {
                if (id == target.method_5628()) {
                    resetAndRelease();
                    return;
                }
            }
        }

        if (shouldIntercept) {
            packetQueue.add(new TimedPacket(packet));
            e.setCancelled(true);
        }
    }

    private void resetAndRelease() {
        target = null;
        realTargetPos = null;
        lastRealTargetPos = null;
        positionHistory.clear();
        recentPositions.clear();
        releaseAll();
    }

    private void releaseAll() {
        while (!packetQueue.isEmpty()) {
            TimedPacket tp = packetQueue.poll();
            if (tp != null) {
                class_2596<?> packet = tp.getPacket();
                skipPackets.add(packet);
                PacketUtil.receivePacket(packet);
            }
        }
    }

    private static class TimedPacket {
        private final class_2596<?> packet;
        private final long time;

        public TimedPacket(class_2596<?> packet) {
            this.packet = packet;
            this.time = System.currentTimeMillis();
        }

        public class_2596<?> getPacket() {
            return packet;
        }

        public boolean elapsed(long delayMs) {
            return System.currentTimeMillis() - time >= delayMs;
        }
    }
}
