package laoqi123.module.modules.combat;

import laoqi123.event.EventTarget;
import laoqi123.event.impl.AttackEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.BooleanValue;
import laoqi123.value.properties.ModeValue;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import laoqi123.util.PacketUtil;

public class MoreKB extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final ModeValue mode = new ModeValue("mode", 0, new String[]{"Legit", "Legit_Fast", "Less_Packet", "Packet", "Double_Packet"});
    public final BooleanValue intelligent = new BooleanValue("intelligent", false);
    public final BooleanValue onlyGround = new BooleanValue("only-ground", true);
    private boolean shouldSprintReset;
    private class_1309 target;

    public MoreKB() {
        super("MoreKB", false);
        this.shouldSprintReset = false;
        this.target = null;
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        class_1297 targetEntity = event.getTarget();
        if (targetEntity != null && targetEntity instanceof class_1309) {
            this.target = (class_1309) targetEntity;
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (this.mode.getValue() == 1) {
            if (this.target != null && this.isMoving()) {
                if ((this.onlyGround.getValue() && mc.field_1724.method_24828()) || !this.onlyGround.getValue()) {
                    mc.field_1724.method_5728(false);
                }
                this.target = null;
            }
            return;
        }
        class_1309 entity = null;
        if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331 && ((class_3966) mc.field_1765).method_17782() instanceof class_1309) {
            entity = (class_1309) ((class_3966) mc.field_1765).method_17782();
        }
        if (entity == null) {
            return;
        }
        double x = mc.field_1724.method_23317() - entity.method_23317();
        double z = mc.field_1724.method_23321() - entity.method_23321();
        float calcYaw = (float) (Math.atan2(z, x) * 180.0 / Math.PI - 90.0);
        float diffY = Math.abs(class_3532.method_15393(calcYaw - entity.method_5791()));
        if (this.intelligent.getValue() && diffY > 120.0F) {
            return;
        }
        if (entity.field_6235 == 10) {
            switch (this.mode.getValue()) {
                case 0:
                    this.shouldSprintReset = true;
                    if (mc.field_1724.method_5624()) {
                        mc.field_1724.method_5728(false);
                        mc.field_1724.method_5728(true);
                    }
                    this.shouldSprintReset = false;
                    break;
                case 2:
                    if (mc.field_1724.method_5624()) {
                        mc.field_1724.method_5728(false);
                    }
                    PacketUtil.sendPacket(new class_2848(mc.field_1724, class_2848.class_2849.field_12981));
                    mc.field_1724.method_5728(true);
                    break;
                case 3:
                    PacketUtil.sendPacket(new class_2848(mc.field_1724, class_2848.class_2849.field_12985));
                    PacketUtil.sendPacket(new class_2848(mc.field_1724, class_2848.class_2849.field_12981));
                    mc.field_1724.method_5728(true);
                    break;
                case 4:
                    PacketUtil.sendPacket(new class_2848(mc.field_1724, class_2848.class_2849.field_12985));
                    PacketUtil.sendPacket(new class_2848(mc.field_1724, class_2848.class_2849.field_12981));
                    PacketUtil.sendPacket(new class_2848(mc.field_1724, class_2848.class_2849.field_12985));
                    PacketUtil.sendPacket(new class_2848(mc.field_1724, class_2848.class_2849.field_12981));
                    mc.field_1724.method_5728(true);
                    break;
            }
        }
    }

    private boolean isMoving() {
        return mc.field_1724.field_3913.field_3905 != 0.0F || mc.field_1724.field_3913.field_3907 != 0.0F;
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.mode.getModeString()};
    }
}
