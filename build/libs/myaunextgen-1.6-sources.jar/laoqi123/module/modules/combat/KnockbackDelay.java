package laoqi123.module.modules.combat;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.LoadWorldEvent;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.UpdateEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.BooleanValue;
import laoqi123.value.properties.IntValue;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_239;
import net.minecraft.class_2596;
import net.minecraft.class_2604;
import net.minecraft.class_2620;
import net.minecraft.class_2653;
import net.minecraft.class_2663;
import net.minecraft.class_2668;
import net.minecraft.class_2716;
import net.minecraft.class_2724;
import net.minecraft.class_2749;
import net.minecraft.class_2761;
import net.minecraft.class_2767;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_7438;
import laoqi123.util.ItemUtil;
import laoqi123.util.PacketUtil;
import laoqi123.util.RandomUtil;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class KnockbackDelay extends Module {
    private static final class_310 mc = class_310.method_1551();

    private final IntValue airDelay = new IntValue("AirDelay", 90, 0, 1000);
    private final IntValue groundDelay = new IntValue("GroundDelay", 0, 0, 1000);
    private final IntValue chance = new IntValue("Chance", 100, 0, 100);
    private final BooleanValue realtimeDamage = new BooleanValue("RealtimeDamage", true);
    private final BooleanValue requireTarget = new BooleanValue("RequireTarget", false);
    private final BooleanValue onlySwords = new BooleanValue("OnlySwords", false);

    private final Queue<TimedPacket> packets = new ConcurrentLinkedQueue<>();
    private boolean blink;

    public KnockbackDelay() {
        super("KnockbackDelay", false);
    }

    @Override
    public String[] getSuffix() {
        return new String[]{airDelay.getValue() + " - " + groundDelay.getValue()};
    }

    @Override
    public void onDisabled() {
        reset();
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (event.getType() != EventType.PRE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.method_1542() || mc.field_1724.field_6012 < 20) return;

        if (mc.field_1755 != null) {
            reset();
            return;
        }

        if (!shouldActivate()) {
            reset();
            return;
        }

        int delay = mc.field_1724.method_24828() ? groundDelay.getValue() : airDelay.getValue();

        if (!packets.isEmpty()) {
            handle(delay);
        }

        if (mc.field_1724 != null && mc.field_1724.field_6235 > 0) {
            blink = true;
        } else if (packets.isEmpty()) {
            blink = false;
        }
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        reset();
    }

    @EventTarget(Priority.HIGHEST)
    public void onPacket(PacketEvent event) {
        if (event.getType() != EventType.RECEIVE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.method_1542() || mc.field_1724.field_6012 < 20 || event.isCancelled()) return;

        class_2596<?> packet = event.getPacket();

        if (packet instanceof class_2724) return;
        if (packet instanceof class_2761) return;
        if (packet instanceof class_2749) return;
        if (packet instanceof class_2716) return;
        if (packet instanceof class_7438) return;
        if (packet instanceof class_2620) return;
        if (packet instanceof class_2653) return;
        if (packet instanceof net.minecraft.class_2661) return;

        if (packet instanceof class_2668) {
            class_2668.class_5402 reason = ((class_2668) packet).method_11491();
            if (reason == class_2668.field_25646
                    || reason == class_2668.field_25647
                    || reason == class_2668.field_25652
                    || reason == class_2668.field_25653) return;
        }

        if (packet instanceof class_2604) {
            if (((class_2604) packet).method_11169() == class_1299.field_6112) return;
        }

        if (packet instanceof class_2767) {
            if ("ambient.weather.thunder".equalsIgnoreCase(((class_2767) packet).method_11894().comp_349().comp_3319().method_12832())) return;
        }

        if (realtimeDamage.getValue() && packet instanceof class_2663) {
            class_2663 statusPacket = (class_2663) packet;
            net.minecraft.class_638 world = mc.field_1687;
            if (statusPacket.method_11470() == 2 && world != null && statusPacket.method_11469(world) == mc.field_1724) {
                return;
            }
        }

        if (blink) {
            event.setCancelled(true);
            packets.add(new TimedPacket(packet, System.currentTimeMillis()));
        }
    }

    private boolean shouldActivate() {
        if (RandomUtil.nextInt(0, 100) > chance.getValue()) return false;

        if (requireTarget.getValue() && findTarget() == null) return false;

        if (onlySwords.getValue() && !ItemUtil.isHoldingSword()) return false;

        return true;
    }

    private void reset() {
        if (!blink) return;
        blink = false;
        flush();
    }

    private void handle(int delay) {
        while (!packets.isEmpty()) {
            TimedPacket wrapper = packets.peek();
            if (wrapper != null && wrapper.elapsed(delay)) {
                packets.poll();
                PacketUtil.receivePacket(wrapper.packet);
            } else {
                break;
            }
        }
    }

    private void flush() {
        TimedPacket wrapper;
        while ((wrapper = packets.poll()) != null) {
            PacketUtil.receivePacket(wrapper.packet);
        }
    }

    private static class TimedPacket {
        private final class_2596<?> packet;
        private final long time;

        public TimedPacket(class_2596<?> packet, long time) {
            this.packet = packet;
            this.time = time;
        }

        public boolean elapsed(int delayMs) {
            return System.currentTimeMillis() - time >= delayMs;
        }
    }

    public class_1297 findTarget() {
        KillAura ka = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
        if (ka != null && ka.isEnabled() && ka.getTarget() != null) {
            return ka.getTarget();
        }

        if (mc.field_1692 != null) return mc.field_1692;

        if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331) {
            return ((class_3966) mc.field_1765).method_17782();
        }

        return null;
    }
}
