package laoqi123.module.modules.combat.antikb;

import java.awt.Color;
import java.util.concurrent.LinkedBlockingDeque;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.impl.LoadWorldEvent;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.Render2DEvent;
import laoqi123.event.impl.StrafeEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.event.types.EventType;
import laoqi123.module.Module;
import laoqi123.module.modules.combat.KillAura;
import laoqi123.module.modules.combat.Velocity;
import laoqi123.module.modules.movement.Stuck;
import laoqi123.util.ChatUtil;
import laoqi123.util.PacketUtil;
import laoqi123.util.PlayerUtil;
import laoqi123.util.RenderUtil;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2616;
import net.minecraft.class_2645;
import net.minecraft.class_2661;
import net.minecraft.class_2678;
import net.minecraft.class_2684;
import net.minecraft.class_2708;
import net.minecraft.class_2724;
import net.minecraft.class_2743;
import net.minecraft.class_2749;
import net.minecraft.class_2767;
import net.minecraft.class_2777;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_5892;
import net.minecraft.class_5900;
import net.minecraft.class_5904;
import net.minecraft.class_6373;
import net.minecraft.class_7438;
import net.minecraft.class_7439;
import net.minecraft.class_8043;

/**
 * NoXZ anti-knockback mode (ported from OpenNilore's NoXZMode).
 * <p>
 * Holds the server→client knockback packet (plus other packets) while the
 * player is airborne, then releases them once the player lands so the X/Z
 * portion of the knockback never carries. Optionally bursts attacks on
 * landing ("instant attack") and renders a suspension progress bar.
 */
public class NoXZMode
        extends AntiKBMode {
    public static NoXZMode INSTANCE;
    public static boolean isAttacking;
    public static boolean handlingVelocity;
    public static boolean velocityHandled;
    public static int attackCount;
    private static final class_310 mc = class_310.method_1551();
    private int attackCooldown = 0;
    private class_1297 attackTarget = null;
    private int attacksRemaining = 0;
    private int flagCooldown = 0;
    private boolean shouldJump = false;
    private int sprintBoostCounter = 0;
    private int hitCounter = 0;
    private boolean isSuspending = false;
    private int delayTicks = 0;
    private class_2743 knockbackPacket = null;
    private final LinkedBlockingDeque<class_2596<class_2602>> packetQueue = new LinkedBlockingDeque();
    private float instantAttackProgress = 0.0f;
    private boolean isInstantAttacking = false;

    @Override
    public boolean isActive() {
        return this.velocityHandled;
    }

    public NoXZMode() {
        INSTANCE = this;
    }

    @Override
    public String getName() {
        return "";
    }

    @Override
    public void onEnable() {
        this.resetAll();
    }

    @Override
    public void onDisable() {
        this.resetAll();
    }

    @Override
    public void onPacket(PacketEvent event) {
        if (event.getType() != EventType.RECEIVE) {
            return;
        }
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        class_2596<?> packet = event.getPacket();
        if (packet instanceof class_2724
                || packet instanceof class_2678) {
            this.resetAll();
            return;
        }
        if (packet instanceof class_2708) {
            if (this.isSuspending) {
                this.release();
            }
            this.resetSuspension();
            if (this.parent.debugLog.getValue()) {
                ChatUtil.sendFormatted("Flag Detected");
            }
            this.flagCooldown = 2;
            return;
        }
        if (this.flagCooldown != 0) {
            return;
        }
        if (this.isSuspending) {
            // Alink 收放包: 自己的移动包与别人的移动包全部暂缓, 落地才释放
            if (packet instanceof class_2684
                    || packet instanceof class_6373
                    || packet instanceof class_2777) {
                this.packetQueue.add((class_2596<class_2602>) packet);
                event.setCancelled(true);
            } else if (!this.isAllowedPacket(packet)) {
                this.packetQueue.add((class_2596<class_2602>) packet);
                event.setCancelled(true);
            }
            return;
        }
        if (packet instanceof class_2743 motionPacket) {
            if (motionPacket.method_11818() != mc.field_1724.method_5628()) {
                return;
            }
            if (!this.canProcess()) {
                if (this.parent.debugLog.getValue()) {
                    ChatUtil.sendFormatted("Alink Wait");
                }
                this.resetAll();
                return;
            }
            double dx = -motionPacket.method_11815();
            double dz = -motionPacket.method_11819();
            if (Math.abs(dx) > 0.01 || Math.abs(dz) > 0.01) {
                this.hitCounter = 1;
            }
            if (motionPacket.method_11816() > 0) {
                this.sprintBoostCounter = this.sprintBoostCounter % 100 + 100;
                if (this.sprintBoostCounter >= 100) {
                    this.shouldJump = true;
                }
                class_1297 target = this.getAttackTarget();
                boolean canAttack = this.isValidTarget(target) && mc.field_1724.method_5624();
                if (!mc.field_1724.method_24828()) {
                    this.enterSuspension(motionPacket);
                    event.setCancelled(true);
                } else if (canAttack) {
                    this.attackTarget = target;
                    this.attacksRemaining = this.getAttackCount(motionPacket);
                } else {
                    this.enterSuspension(motionPacket);
                    event.setCancelled(true);
                    if (this.parent.debugLog.getValue()) {
                        ChatUtil.sendFormatted("Alink Wait");
                    }
                }
            }
        }
    }

    @Override
    public void onLoadWorld(LoadWorldEvent event) {
        this.resetAll();
    }

    @Override
    public void onTick(TickEvent tickEvent) {
        if (mc.field_1724 == null) {
            return;
        }
        if (this.attackCooldown > 0) {
            --this.attackCooldown;
            if (this.attackCooldown <= 0) {
                isAttacking = false;
                attackCount = 0;
                velocityHandled = false;
            }
        }
        if (this.hitCounter > 0) {
            ++this.hitCounter;
            if (this.hitCounter > 2) {
                this.hitCounter = 0;
            }
        }
        if (mc.field_1724.method_29504() || !mc.field_1724.method_5805() || this.shouldIgnore()) {
            this.clearTarget();
            if (this.isSuspending) {
                this.release();
            }
            if (this.isInstantAttacking) {
                this.isInstantAttacking = false;
                this.instantAttackProgress = 0.0f;
                Myau.serverTickRate = 1.0f;
            }
            return;
        }
        if (this.flagCooldown > 0) {
            --this.flagCooldown;
            this.clearTarget();
        }
        if (this.isSuspending) {
            ++this.delayTicks;
            // Alink 超时: 暂缓太久直接放弃, 放行全部暂缓包并重置
            if (this.delayTicks >= this.parent.maxDelayTicks.getValue()) {
                if (this.parent.debugLog.getValue()) {
                    ChatUtil.sendFormatted("Alink Timeout");
                }
                this.resetAll();
                return;
            }
            boolean instantAttackEnabled = this.parent.instantAttack.getValue();
            if (instantAttackEnabled && this.instantAttackProgress < 3.0f) {
                if (this.parent.tickManipulation.getValue()) {
                    // Grim 警告: 0.5x 慢放会触发 Timer/Balance 检查, 默认关闭
                    float tickRate;
                    Myau.serverTickRate = tickRate = 0.5f;
                    this.instantAttackProgress += 1.0f - tickRate;
                } else {
                    this.instantAttackProgress += 1.0f;
                }
                this.instantAttackProgress = Math.min(this.instantAttackProgress, 3.0f);
            }
            if (mc.field_1724.method_24828()) {
                if (this.parent.debugLog.getValue()) {
                    ChatUtil.sendFormatted("ground");
                }
                if (instantAttackEnabled) {
                    Myau.serverTickRate = 1.0f;
                }
                class_1297 target = this.getAttackTarget();
                boolean canAttack = this.isValidTarget(target);
                boolean sprinting = mc.field_1724.method_5624();
                if (canAttack && sprinting) {
                    // 放: 异步放行暂缓的服务器→客户端包(含击退包)
                    this.flushQueue();
                    this.attackTarget = target;
                    this.attacksRemaining = this.getAttackCount(this.knockbackPacket);
                    if (instantAttackEnabled && this.instantAttackProgress > 0.0f) {
                        this.attacksRemaining = (int) this.instantAttackProgress;
                        this.isSuspending = false;
                        handlingVelocity = false;
                        this.delayTicks = 0;
                        this.isInstantAttacking = true;
                        if (this.parent.tickManipulation.getValue()) {
                            // Grim 警告: 4x 爆发会触发 Timer/Balance 检查, 默认关闭
                            Myau.serverTickRate = 4.0f;
                        }
                    } else {
                        this.doAttackSequence(tickEvent);
                        this.isSuspending = false;
                        handlingVelocity = false;
                        this.delayTicks = 0;
                    }
                } else {
                    this.release();
                    if (instantAttackEnabled) {
                        this.instantAttackProgress = 0.0f;
                    }
                    if (mc.field_1724.method_5624()) {
                        mc.field_1724.method_5728(false);
                    }
                }
                return;
            }
            return;
        }
        if (this.isInstantAttacking) {
            this.instantAttackProgress -= 1.0f;
            if (this.instantAttackProgress <= 0.0f) {
                this.instantAttackProgress = 0.0f;
                this.isInstantAttacking = false;
                Myau.serverTickRate = 1.0f;
                if (this.parent.debugLog.getValue()) {
                    ChatUtil.sendFormatted("done");
                }
            }
        }
        if (this.attacksRemaining > 0 && this.attackTarget != null) {
            this.doAttackSequence(tickEvent);
        }
    }

    @Override
    public void onStrafe(StrafeEvent strafeEvent) {
        if (mc.field_1724 == null) {
            return;
        }
        if (this.hitCounter > 0) {
            strafeEvent.setForward(1.0f);
        }
        if (this.shouldJump) {
            this.shouldJump = false;
            // 不在此强置疾跑: mc.player.setSprinting(true) 会在不满足疾跑条件时
            // 强行打开疾跑标志, 触发 Grim Simulation 检查。疾跑交由 Sprint 模块/
            // 原版 updateSprintingState 维护。
        }
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        if (!this.parent.renderBar.getValue()
                || !this.parent.isEnabled()
                || (!handlingVelocity && !velocityHandled)) {
            return;
        }
        int width = mc.method_22683().method_4486();
        int height = mc.method_22683().method_4502();

        float barWidth = 100.0f;
        float barHeight = 2.0f;
        float barX = width / 2.0f - barWidth / 2.0f;
        float barY = height / 2.0f + height * 0.10f;

        // 灰黑色背景(整条)
        RenderUtil.drawRect(barX, barY, barX + barWidth, barY + barHeight,
                new Color(30, 30, 36, 180).getRGB());
        // 青蓝色进度
        float progress = Math.min(1.0f,
                (float) this.delayTicks / Math.max(1, this.parent.maxDelayTicks.getValue()));
        if (progress > 0.0f) {
            RenderUtil.drawRect(barX, barY, barX + barWidth * progress, barY + barHeight,
                    new Color(0, 180, 255, 230).getRGB());
        }
    }

    private void enterSuspension(class_2743 packet) {
        this.isSuspending = true;
        handlingVelocity = true;
        velocityHandled = true;
        this.delayTicks = 0;
        this.knockbackPacket = packet;
        this.packetQueue.add(packet);
    }

    private boolean canProcess() {
        if (!this.parent.requireKillAura.getValue()) {
            return true;
        }
        KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
        return killAura != null && killAura.isEnabled();
    }

    private void resetAll() {
        this.flushQueue();
        this.clearTarget();
        this.flagCooldown = 0;
        this.shouldJump = false;
        this.sprintBoostCounter = 0;
        this.hitCounter = 0;
        this.resetSuspension();
    }

    private void clearTarget() {
        this.attackTarget = null;
        this.attacksRemaining = 0;
    }

    private void resetSuspension() {
        this.isSuspending = false;
        handlingVelocity = false;
        velocityHandled = false;
        this.delayTicks = 0;
        this.knockbackPacket = null;
        this.instantAttackProgress = 0.0f;
        this.isInstantAttacking = false;
        Myau.serverTickRate = 1.0f;
    }

    private void release() {
        this.flushQueue();
        this.resetSuspension();
    }

    private boolean shouldIgnore() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return true;
        }
        if (mc.field_1724.method_29504() || !mc.field_1724.method_5805() || mc.field_1724.method_6032() <= 0.0f) {
            return true;
        }
        if (mc.field_1724.method_7325() || mc.field_1724.method_31549().field_7479) {
            return true;
        }
        if (mc.field_1724.method_5771() || mc.field_1724.method_5809() || mc.field_1724.method_5799()
                || mc.field_1724.method_6101() || mc.field_1724.method_6113()) {
            return true;
        }
        if (mc.field_1687.method_8320(mc.field_1724.method_24515()).method_27852(class_2246.field_10343)) {
            return true;
        }
        Module stuck = Myau.moduleManager.modules.get(Stuck.class);
        return stuck != null && stuck.isEnabled();
    }

    private int getAttackCount(class_2743 motionPacket) {
        if (!this.parent.autoAttackCount.getValue() || motionPacket == null) {
            return this.parent.attackAmount.getValue();
        }
        double velocity = Math.sqrt((double) motionPacket.method_11815() * motionPacket.method_11815()
                + (double) motionPacket.method_11816() * motionPacket.method_11816());
        if (velocity < 1000.0) {
            return 0;
        }
        if (velocity < 2000.0) {
            return 3;
        }
        if (velocity < 10000.0) {
            return 4;
        }
        return 5;
    }

    private double getAABBDistance(class_1297 entity) {
        if (mc.field_1724 == null) {
            return Double.MAX_VALUE;
        }
        class_243 eyePos = mc.field_1724.method_33571();
        class_238 box = entity.method_5829();
        double clampedX = Math.max(box.field_1323, Math.min(eyePos.field_1352, box.field_1320));
        double clampedY = Math.max(box.field_1322, Math.min(eyePos.field_1351, box.field_1325));
        double clampedZ = Math.max(box.field_1321, Math.min(eyePos.field_1350, box.field_1324));
        return eyePos.method_1022(new class_243(clampedX, clampedY, clampedZ));
    }

    private class_1297 getHitResultEntity() {
        if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331
                && ((class_3966) mc.field_1765).method_17782() instanceof class_1309 hitEntity
                && hitEntity != mc.field_1724 && hitEntity.method_5805() && !hitEntity.method_7325()) {
            return hitEntity;
        }
        return null;
    }

    private class_1297 getAttackTarget() {
        KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
        if (killAura != null && killAura.getTarget() != null) {
            return killAura.getTarget();
        }
        return this.getHitResultEntity();
    }

    private boolean isValidTarget(class_1297 entity) {
        if (entity == null || !entity.method_5805()) {
            return false;
        }
        if (entity instanceof class_1309 livingEntity
                && (livingEntity.method_29504() || livingEntity.method_6032() <= 0.0f)) {
            return false;
        }
        double maxReach = 3.7f;
        return !(this.getAABBDistance(entity) > maxReach);
    }

    private void doAttackSequence(TickEvent tickEvent) {
        if (this.attackTarget == null || !this.attackTarget.method_5805()) {
            this.clearTarget();
            return;
        }
        double maxReach = 3.7f;
        if (this.getAABBDistance(this.attackTarget) > maxReach) {
            this.clearTarget();
            return;
        }
        isAttacking = true;
        attackCount = this.attacksRemaining--;
        this.attackCooldown = 2;
        this.doAttack(this.attackTarget);
        if (this.attacksRemaining <= 0) {
            this.clearTarget();
            if (this.parent.instantAttack.getValue()) {
                if (this.parent.debugLog.getValue()) {
                    ChatUtil.sendFormatted("Attack (" + this.parent.attackAmount.getValue() + ")");
                }
            }
        }
    }

    private boolean doAttack(class_1297 entity) {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return false;
        }
        if (this.parent.sprintStateCheck.getValue() && !mc.field_1724.method_5624()) {
            if (this.parent.debugLog.getValue()) {
                ChatUtil.sendFormatted("not sprinting");
            }
            return false;
        }
        boolean wasSprinting = mc.field_1724.method_5624();
        if (wasSprinting) {
            mc.field_1724.method_5728(false);
        }
        PlayerUtil.attackEntity(entity);
        if (wasSprinting) {
            class_243 velocity = mc.field_1724.method_18798();
            mc.field_1724.method_18800(velocity.field_1352 * 0.6, velocity.field_1351, velocity.field_1350 * 0.6);
        }
        if (!this.parent.instantAttack.getValue()) {
            if (this.parent.debugLog.getValue()) {
                ChatUtil.sendFormatted("Attack (" + this.attacksRemaining + ")");
            }
        }
        return true;
    }

    private void flushQueue() {
        class_2596<class_2602> packet;
        while ((packet = this.packetQueue.poll()) != null) {
            PacketUtil.receivePacket(packet);
        }
    }

    private boolean isAllowedPacket(class_2596<?> packet) {
        return packet instanceof class_2743
                || packet instanceof class_2749
                || packet instanceof class_2708
                || packet instanceof class_2724
                || packet instanceof class_2678
                || packet instanceof class_2767
                || packet instanceof class_7438
                || packet instanceof class_5892
                || packet instanceof class_2645
                || packet instanceof class_8043
                || packet instanceof class_5904
                || packet instanceof class_5900
                || packet instanceof class_7439
                || packet instanceof class_2661
                || (packet instanceof class_2616
                        && ((class_2616) packet).method_11269() != mc.field_1724.method_5628());
    }

    static {
        isAttacking = false;
        handlingVelocity = false;
        velocityHandled = false;
        attackCount = 0;
    }
}
