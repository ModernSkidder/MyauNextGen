package laoqi123.module.modules.combat.risevelocity;

import laoqi123.events.MoveInputEvent;
import laoqi123.events.PacketEvent;
import laoqi123.events.PlayerUpdateEvent;
import laoqi123.events.TickEvent;
import laoqi123.module.modules.combat.RiseVelocity;
import laoqi123.util.PacketUtil;
import laoqi123.util.TeamUtil;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2560;
import net.minecraft.class_2596;
import net.minecraft.class_310;

public abstract class RiseVelocityMode {
    protected static final class_310 mc = class_310.method_1551();

    private RiseVelocity parent;

    public abstract String getName();

    public void setParent(RiseVelocity parent) {
        this.parent = parent;
    }

    public RiseVelocity getParent() {
        return this.parent;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onPacketReceive(PacketEvent event) {
    }

    public void onTick(TickEvent event) {
    }

    public void onMoveInput(MoveInputEvent event) {
    }

    public void onPlayerUpdate(PlayerUpdateEvent event) {
    }

    protected int getTicksSinceTeleport() {
        return this.parent.getTicksSinceTeleport();
    }

    protected int getTicksSinceAttack() {
        return this.parent.getTicksSinceAttack();
    }

    protected int getJumpTicks() {
        return this.parent.getJumpTicks();
    }

    protected boolean isInWeb() {
        return mc.field_1687 != null && mc.field_1724 != null
                && mc.field_1687.method_8320(mc.field_1724.method_24515()).method_26204() instanceof class_2560;
    }

    protected void receive(class_2596<?> packet) {
        PacketUtil.receivePacket(packet);
        PacketUtil.drainPendingPackets();
    }

    protected class_1309 getClosestTarget(double range) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return null;
        }
        class_1309 closest = null;
        double bestDistance = range;
        for (net.minecraft.class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1657)) {
                continue;
            }
            class_1657 playerEntity = (class_1657) entity;
            if (playerEntity == mc.field_1724 || !TeamUtil.isEntityLoaded(playerEntity)) {
                continue;
            }
            double distance = mc.field_1724.method_5739(playerEntity);
            if (distance < bestDistance) {
                bestDistance = distance;
                closest = playerEntity;
            }
        }
        return closest;
    }
}