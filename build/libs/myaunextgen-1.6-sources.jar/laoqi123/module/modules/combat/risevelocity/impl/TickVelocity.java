package laoqi123.module.modules.combat.risevelocity.impl;

import laoqi123.event.types.EventType;
import laoqi123.events.PacketEvent;
import laoqi123.events.TickEvent;
import laoqi123.module.modules.combat.risevelocity.RiseVelocityMode;
import laoqi123.property.properties.IntProperty;
import laoqi123.util.PacketUtil;
import net.minecraft.class_10264;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2684;
import net.minecraft.class_2743;
import net.minecraft.class_2777;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class TickVelocity extends RiseVelocityMode {
    public final IntProperty tickDelay = new IntProperty("Tick Delay", 3, 0, 8);

    private final Queue<class_2596<class_2602>> queue = new ConcurrentLinkedQueue<>();
    private int queueTicks;

    @Override
    public String getName() {
        return "Tick";
    }

    @Override
    public void onEnable() {
        this.queue.clear();
        this.queueTicks = 0;
    }

    @Override
    public void onPacketReceive(PacketEvent event) {
        if (event.getType() != EventType.RECEIVE) {
            return;
        }
        class_2596<?> packet = event.getPacket();
        boolean hold = packet instanceof class_2743 velocity
                && velocity.method_11818() == mc.field_1724.method_5628()
                && this.getTicksSinceTeleport() >= 3 && !this.isInWeb();
        hold |= packet instanceof class_2684 || packet instanceof class_2777
                || packet instanceof class_10264;
        if (!hold) {
            return;
        }
        event.setCancelled(true);
        this.queue.offer((class_2596<class_2602>) packet);
    }

    @Override
    public void onTick(TickEvent event) {
        if (event.getType() != EventType.PRE) {
            return;
        }
        if (this.queue.isEmpty()) {
            return;
        }
        this.queueTicks++;
        if (this.queueTicks < this.tickDelay.getValue()) {
            return;
        }
        this.queueTicks = 0;
        class_2596<class_2602> packet;
        while ((packet = this.queue.poll()) != null) {
            PacketUtil.receivePacket(packet);
        }
        PacketUtil.drainPendingPackets();
    }
}