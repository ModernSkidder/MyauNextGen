package laoqi123.module.modules.combat.risevelocity.impl;

import laoqi123.event.types.EventType;
import laoqi123.events.MoveInputEvent;
import laoqi123.events.PacketEvent;
import laoqi123.module.modules.combat.risevelocity.RiseVelocityMode;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.util.PacketUtil;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2743;
import java.util.ArrayList;
import java.util.List;

public class IntaveVelocity extends RiseVelocityMode {
    public final IntProperty startTicks = new IntProperty("Start Ticks", 2, 0, 4);
    public final BooleanProperty alwaysDrain = new BooleanProperty("Always Drain", false);
    public final BooleanProperty waitForLowTicks = new BooleanProperty("Wait For Low Ticks", false);

    private final List<class_2596<class_2602>> delayedPackets = new ArrayList<>();
    private int currentTicks;

    @Override
    public String getName() {
        return "Intave";
    }

    @Override
    public void onEnable() {
        this.delayedPackets.clear();
        this.currentTicks = 0;
    }

    @Override
    public void onPacketReceive(PacketEvent event) {
        if (event.getType() != EventType.RECEIVE) {
            return;
        }
        if (!(event.getPacket() instanceof class_2743 packet)) {
            return;
        }
        if (packet.method_11818() != mc.field_1724.method_5628()) {
            return;
        }
        if (this.getTicksSinceTeleport() < 3 || this.isInWeb()) {
            return;
        }
        event.setCancelled(true);
        this.delayedPackets.add((class_2596<class_2602>) event.getPacket());

        if (this.alwaysDrain.getValue()) {
            this.sendDelayed();
            return;
        }
        if (mc.field_1724.method_24828()) {
            this.sendDelayed();
            return;
        }
        if (!this.waitForLowTicks.getValue()) {
            this.sendDelayed();
            return;
        }
        this.currentTicks++;
        if (this.currentTicks >= this.startTicks.getValue()) {
            this.sendDelayed();
        }
    }

    @Override
    public void onMoveInput(MoveInputEvent event) {
        if (mc.field_1724 == null) {
            return;
        }
        if (!this.delayedPackets.isEmpty() && mc.field_1724.method_24828()) {
            event.setJump(true);
        }
    }

    private void sendDelayed() {
        for (class_2596<class_2602> packet : this.delayedPackets) {
            PacketUtil.receivePacket(packet);
        }
        PacketUtil.drainPendingPackets();
        this.delayedPackets.clear();
        this.currentTicks = 0;
    }
}