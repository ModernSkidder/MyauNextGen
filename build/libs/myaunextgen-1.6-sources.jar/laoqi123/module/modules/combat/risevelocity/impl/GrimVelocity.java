package laoqi123.module.modules.combat.risevelocity.impl;

import laoqi123.event.types.EventType;
import laoqi123.events.MoveInputEvent;
import laoqi123.events.PacketEvent;
import laoqi123.events.TickEvent;
import laoqi123.module.modules.combat.risevelocity.RiseVelocityMode;
import laoqi123.util.PacketUtil;
import net.minecraft.class_10264;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2684;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2777;
import java.util.ArrayList;
import java.util.List;

public class GrimVelocity extends RiseVelocityMode {

    private final List<class_2596<class_2602>> heldPackets = new ArrayList<>();
    private boolean movementFrozen;
    private class_243 motionSaved;
    private boolean dj;
    private boolean flushingPackets;
    private int holdTicks;
    private int reachedTicks;

    @Override
    public String getName() {
        return "Grim";
    }

    @Override
    public void onEnable() {
        this.heldPackets.clear();
        this.movementFrozen = false;
        this.motionSaved = null;
        this.dj = false;
        this.flushingPackets = false;
        this.holdTicks = 0;
        this.reachedTicks = 0;
    }

    @Override
    public void onPacketReceive(PacketEvent event) {
        if (event.getType() != EventType.RECEIVE) {
            return;
        }
        if (this.flushingPackets || this.getTicksSinceTeleport() < 3 || this.isInWeb()) {
            return;
        }
        class_2596<?> packet = event.getPacket();
        if (packet instanceof class_2743 velocity) {
            if (velocity.method_11818() != mc.field_1724.method_5628()) {
                return;
            }
            event.setCancelled(true);
            if (!mc.field_1724.method_24828()) {
                this.heldPackets.add((class_2596<class_2602>) packet);
                this.dj = true;
                if (this.holdTicks > 25) {
                    this.flush();
                }
            } else {
                this.movementFrozen = true;
                if (this.reachedTicks >= 3) {
                    this.flush();
                }
            }
        } else if (packet instanceof class_2684 || packet instanceof class_2777
                || packet instanceof class_10264) {
            if (this.dj) {
                this.heldPackets.add((class_2596<class_2602>) packet);
                event.setCancelled(true);
            }
        } else if (packet instanceof class_2708) {
            this.reachedTicks++;
            if (this.dj) {
                this.heldPackets.add((class_2596<class_2602>) packet);
                event.setCancelled(true);
            }
        }
    }

    @Override
    public void onTick(TickEvent event) {
        if (event.getType() != EventType.PRE) {
            return;
        }
        if (mc.field_1724 == null) {
            return;
        }
        if (this.dj) {
            this.holdTicks++;
            if (this.holdTicks > 25) {
                this.flush();
            }
        }
        boolean active = this.getTicksSinceTeleport() >= 7 && !this.isInWeb();
        if (active || !mc.field_1724.method_24828()) {
            if (this.movementFrozen) {
                mc.field_1724.method_18800(0.0, 0.0, 0.0);
            }
        } else {
            if (!this.heldPackets.isEmpty() || this.movementFrozen || this.dj) {
                if (!this.heldPackets.isEmpty() || this.movementFrozen) {
                    this.flush();
                } else {
                    this.dj = false;
                }
            }
        }
    }

    @Override
    public void onMoveInput(MoveInputEvent event) {
        if (mc.field_1724 == null) {
            return;
        }
        if (this.getTicksSinceTeleport() >= 7 && !this.isInWeb()) {
            if (this.getJumpTicks() > 3 && mc.field_1724.method_24828() && this.dj) {
                mc.field_1724.method_6043();
                this.movementFrozen = true;
                this.dj = false;
                this.flush();
            }
            if (this.movementFrozen) {
                if (this.motionSaved == null) {
                    this.motionSaved = mc.field_1724.method_18798();
                }
                mc.field_1724.method_18800(0.0, 0.0, 0.0);
            } else if (this.motionSaved != null) {
                mc.field_1724.method_18799(this.motionSaved);
                this.motionSaved = null;
            }
        } else if (this.motionSaved != null) {
            this.motionSaved = null;
        }
    }

    private void flush() {
        this.flushingPackets = true;
        for (class_2596<class_2602> packet : this.heldPackets) {
            PacketUtil.receivePacket(packet);
        }
        PacketUtil.drainPendingPackets();
        this.heldPackets.clear();
        this.flushingPackets = false;
        this.reachedTicks = 0;
        this.holdTicks = 0;
        this.dj = false;
        this.movementFrozen = false;
        this.motionSaved = null;
    }
}