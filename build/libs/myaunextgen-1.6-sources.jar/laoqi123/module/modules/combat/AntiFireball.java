package laoqi123.module.modules.combat;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.*;
import laoqi123.management.RotationState;
import laoqi123.module.Module;
import laoqi123.module.modules.render.HUD;
import laoqi123.util.*;
import laoqi123.value.properties.*;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2824;
import net.minecraft.class_2879;
import net.minecraft.class_310;
import net.minecraft.class_3855;
import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AntiFireball extends Module {
    private static final class_310 mc = class_310.method_1551();
    private final ArrayList<class_3855> farList = new ArrayList<>();
    private final ArrayList<class_3855> nearList = new ArrayList<>();
    private class_3855 target = null;
    public final FloatValue range = new FloatValue("range", 5.0F, 3.0F, 8.0F);
    public final IntValue fov = new IntValue("fov", 360, 1, 360);
    public final BooleanValue rotations = new BooleanValue("rotations", true);
    public final BooleanValue swing = new BooleanValue("swing", true);
    public final ModeValue moveFix = new ModeValue("move-fix", 1, new String[]{"NONE", "SILENT", "STRICT"});
    public final ModeValue showTarget = new ModeValue("show-target", 0, new String[]{"NONE", "DEFAULT", "HUD"});

    private boolean isValidTarget(class_3855 entityFireball) {
        return !entityFireball.method_5829().method_1013() && RotationUtil.distanceToEntity(entityFireball) <= (double) this.range.getValue() + 3.0
                && RotationUtil.angleToEntity(entityFireball) <= (float) this.fov.getValue();
    }

    private void doAttackAnimation() {
        if (this.swing.getValue()) {
            mc.field_1724.method_6104(class_1268.field_5808);
        } else {
            PacketUtil.sendPacket(new class_2879(class_1268.field_5808));
        }
    }

    public AntiFireball() {
        super("AntiFireball", false);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            List<class_3855> fireballs = new ArrayList<>();
            for (class_1297 entity : mc.field_1687.method_18112()) {
                if (entity instanceof class_3855) {
                    fireballs.add((class_3855) entity);
                }
            }
            this.farList.removeIf(entityFireball -> !fireballs.contains(entityFireball));
            this.nearList.removeIf(entityFireball -> !fireballs.contains(entityFireball));
            for (class_3855 fireball : fireballs) {
                if (!this.farList.contains(fireball) && !this.nearList.contains(fireball)) {
                    if (RotationUtil.distanceToEntity(fireball) > 3.0) {
                        this.farList.add(fireball);
                    } else {
                        this.nearList.add(fireball);
                    }
                }
            }
            if (mc.field_1724.method_31549().field_7478) {
                this.target = null;
            } else {
                this.target = this.farList.stream().filter(this::isValidTarget).min(Comparator.comparingDouble(RotationUtil::distanceToEntity)).orElse(null);
            }
        }
    }

    @EventTarget(Priority.LOWEST)
    public void onUpdate(UpdateEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            class_3855 fireball = this.target;
            if (TeamUtil.isEntityLoaded(fireball)) {
                float[] rotations = RotationUtil.getRotationsToBox(this.target.method_5829(), event.getYaw(), event.getPitch(), 180.0F, 0.0F);
                if (this.rotations.getValue()
                        && !ItemUtil.isHoldingNonEmpty()
                        && !ItemUtil.isUsingBow()
                        && !ItemUtil.hasHoldItem()) {
                    event.setRotation(rotations[0], rotations[1], 0);
                    event.setPervRotation(this.moveFix.getValue() != 0 ? rotations[0] : mc.field_1724.method_36454(), 0);
                }
                if (!Myau.playerStateManager.attacking && !Myau.playerStateManager.digging && !Myau.playerStateManager.placing) {
                    this.doAttackAnimation();
                    if (RotationUtil.distanceToEntity(this.target) <= (double) this.range.getValue().floatValue()) {
                        PacketUtil.sendPacket(class_2824.method_34206(this.target, mc.field_1724.method_5715()));
                        PlayerUtil.attackEntity(this.target);
                    }
                }
            }
        }
    }

    @EventTarget
    public void onMove(MoveInputEvent event) {
        if (this.isEnabled()) {
            if (this.moveFix.getValue() == 1
                    && RotationState.isActived()
                    && RotationState.getPriority() == 0.0F
                    && MoveUtil.isForwardPressed()) {
                MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
            }
        }
    }

    @EventTarget
    public void onRender(Render3DEvent event) {
        if (this.isEnabled()) {
            if (this.showTarget.getValue() != 0 && TeamUtil.isEntityLoaded(this.target)) {
                Color color = new Color(-1);
                switch (this.showTarget.getValue()) {
                    case 1:
                        double dist = (this.target.method_23317() - this.target.field_6014) * (mc.field_1724.method_23317() - this.target.method_23317())
                                + (this.target.method_23318() - this.target.field_6036)
                                * (mc.field_1724.method_23318() + (double) mc.field_1724.method_18381(mc.field_1724.method_18376()) - this.target.method_23318() - (double) this.target.method_17682() / 2.0)
                                + (this.target.method_23321() - this.target.field_5969) * (mc.field_1724.method_23321() - this.target.method_23321());
                        if (dist < 0.0) {
                            color = new Color(16733525);
                        } else {
                            color = new Color(5635925);
                        }
                        break;
                    case 2:
                        color = ((HUD) Myau.moduleManager.modules.get(HUD.class)).getColor(System.currentTimeMillis());
                }
                RenderUtil.enableRenderState();
                RenderUtil.drawEntityBox(this.target, color.getRed(), color.getGreen(), color.getBlue());
                RenderUtil.disableRenderState();
            }
        }
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        this.farList.clear();
        this.nearList.clear();
    }
}
