package laoqi123.module.modules.combat;

import laoqi123.event.EventTarget;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.AttackEvent;
import laoqi123.event.impl.MoveInputEvent;
import laoqi123.module.Module;
import laoqi123.util.TimerUtil;
import laoqi123.value.properties.FloatValue;
import net.minecraft.class_1294;
import net.minecraft.class_310;

public class Wtap extends Module {
    private static final class_310 mc = class_310.method_1551();
    private final TimerUtil timer = new TimerUtil();
    private boolean active = false;
    private boolean stopForward = false;
    private long delayTicks = 0L;
    private long durationTicks = 0L;
    public final FloatValue delay = new FloatValue("delay", 5.5F, 0.0F, 10.0F);
    public final FloatValue duration = new FloatValue("duration", 1.5F, 1.0F, 5.0F);

    private boolean canTrigger() {
        return !(mc.field_1724.field_3913.field_3905 < 0.8F)
                && !mc.field_1724.field_5976
                && (!((float) mc.field_1724.method_7344().method_7586() <= 6.0F) || mc.field_1724.method_31549().field_7478) && (mc.field_1724.method_5624()
                || !mc.field_1724.method_6115() && !mc.field_1724.method_6059(class_1294.field_5919) && mc.field_1690.field_1867.method_1434());
    }

    public Wtap() {
        super("WTap", false);
    }

    @EventTarget(Priority.LOWEST)
    public void onMoveInput(MoveInputEvent event) {
        if (this.active) {
            if (!this.stopForward && !this.canTrigger()) {
                this.active = false;
                while (this.delayTicks > 0L) {
                    this.delayTicks -= 50L;
                }
                while (this.durationTicks > 0L) {
                    this.durationTicks -= 50L;
                }
            } else if (this.delayTicks > 0L) {
                this.delayTicks -= 50L;
            } else {
                if (this.durationTicks > 0L) {
                    this.durationTicks -= 50L;
                    this.stopForward = true;
                    mc.field_1724.field_3913.field_3905 = 0.0F;
                }
                if (this.durationTicks <= 0L) {
                    this.active = false;
                }
            }
        }
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (this.isEnabled() && !event.isCancelled() && !this.active && this.timer.hasTimeElapsed(500L) && mc.field_1724.method_5624()) {
            this.timer.reset();
            this.active = true;
            this.stopForward = false;
            this.delayTicks = this.delayTicks + (long) (50.0F * this.delay.getValue());
            this.durationTicks = this.durationTicks + (long) (50.0F * this.duration.getValue());
        }
    }
}
