package laoqi123.module.modules.combat.killaura;

import laoqi123.Myau;
import laoqi123.enums.BlinkModules;
import laoqi123.module.modules.combat.KillAura;
import laoqi123.property.properties.*;
import laoqi123.util.PacketUtil;
import laoqi123.util.PlayerUtil;
import laoqi123.util.RotationUtil;
import laoqi123.util.config.ToggleableConfigurable;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2817;
import net.minecraft.class_2824;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8711;
import laoqi123.util.ItemUtil;
import java.util.Random;

public class KillAuraAutoBlock extends ToggleableConfigurable {
    private static final class_310 mc = class_310.method_1551();

    public final ModeProperty mode;
    private final BooleanProperty noSwap;
    private final BooleanProperty test;
    private final IntProperty moreAttackDelay;
    private final IntProperty maxTick;
    private final IntProperty startBlinkTick;
    private final IntProperty stopBlinkTick;
    private final IntProperty swapTick;
    private final IntProperty switchBackTick;
    private final IntProperty stopBlockTick;
    public final IntProperty attackTick;
    private final IntProperty startBlockTick;
    private final BooleanProperty postStartBlock;
    public final BooleanProperty requirePress;
    public final IntProperty aps;
    public final FloatProperty range;

    private boolean blockingState = false;
    private boolean isBlocking = false;
    private boolean fakeBlockState = false;
    private int blockTick = 0;
    private boolean swapped = false;
    private boolean postBlock = false;
    private boolean postSwap = false;
    private int testAttackTick = 0;

    public KillAuraAutoBlock(KillAura module) {
        super("AutoBlock", true);
        this.mode = this.register(new ModeProperty("AutoBlock", 0, new String[]{"None", "Vanilla", "Hypixel", "Legit", "Fake", "Hypixel Test", "Hypixel Custom"}));
        this.noSwap = this.register(new BooleanProperty("NoSwap", true, () -> this.mode.getValue() == 2));
        this.test = this.register(new BooleanProperty("MoreAttack", false, () -> this.mode.getValue() == 2));
        this.moreAttackDelay = this.register(new IntProperty("MoreAttackDelay", 1, 0, 3, () -> this.mode.getValue() == 2 && this.test.getValue()));
        this.maxTick = this.register(new IntProperty("MaxTick", 3, 1, 5, () -> this.mode.getValue() == 6));
        this.startBlinkTick = this.register(new IntProperty("StartBlinkTick", 0, 1, 5, () -> this.mode.getValue() == 6));
        this.stopBlinkTick = this.register(new IntProperty("StopBlinkTick", 2, 1, 5, () -> this.mode.getValue() == 6));
        this.swapTick = this.register(new IntProperty("SwapTick", 2, 1, 5, () -> this.mode.getValue() == 6));
        this.switchBackTick = this.register(new IntProperty("SwitchBackTick", 2, 1, 5, () -> this.mode.getValue() == 6));
        this.stopBlockTick = this.register(new IntProperty("StopBlockTick", 2, 1, 5, () -> this.mode.getValue() == 6));
        this.attackTick = this.register(new IntProperty("AttackTick", 0, 1, 5, () -> this.mode.getValue() == 6));
        this.startBlockTick = this.register(new IntProperty("StartBlockTick", 0, 1, 5, () -> this.mode.getValue() == 6));
        this.postStartBlock = this.register(new BooleanProperty("PostBlock", false, () -> this.mode.getValue() == 6));
        this.requirePress = this.register(new BooleanProperty("AutoBlock Require Press", false));
        this.aps = this.register(new IntProperty("AutoBlock Aps", 10, 1, 20));
        this.range = this.register(new FloatProperty("AutoBlock Range", 6.0F, 3.0F, 8.0F));
    }

    public boolean isBlocking() {
        return this.fakeBlockState && ItemUtil.isHoldingSword();
    }

    public boolean isPlayerBlocking() {
        return (mc.field_1724.method_6115() || this.blockingState) && ItemUtil.isHoldingSword();
    }

    public boolean canAutoBlock() {
        if (!this.running()) {
            return false;
        }
        if (!ItemUtil.isHoldingSword()) {
            return false;
        }
        return !this.requirePress.getValue() || PlayerUtil.isUsingItem();
    }

    public int getBlockTick() {
        return this.blockTick;
    }

    public boolean isPostSwap() {
        return this.postSwap;
    }

    public boolean isPostBlock() {
        return this.postBlock;
    }

    public boolean shouldAutoBlock() {
        if (this.isPlayerBlocking() && this.isBlocking) {
            int mode = this.mode.getValue();
            return !mc.field_1724.method_5799() && !mc.field_1724.method_5771()
                    && (mode == 2 || mode == 3 || mode == 5 || mode == 6 || mode == 7);
        }
        return false;
    }

    public void onReleaseUseItem() {
        this.blockingState = false;
    }

    public void onSlotChangePacket() {
        this.blockingState = false;
        if (this.isBlocking) {
            mc.field_1724.method_6021();
        }
    }

    public void reset() {
        this.blockingState = false;
        this.isBlocking = false;
        this.fakeBlockState = false;
        this.blockTick = 0;
        this.swapped = false;
        this.postBlock = false;
        this.postSwap = false;
    }

    public boolean handlePostTick() {
        boolean handled = false;
        if (this.postSwap) {
            int randomSlot = new Random().nextInt(9);
            while (randomSlot == mc.field_1724.method_31548().field_7545) {
                randomSlot = new Random().nextInt(9);
            }
            PacketUtil.sendPacket(new class_2868(randomSlot));
            PacketUtil.sendPacketNoEvent(new class_2817(new class_8711(class_2960.method_60654("send"))));
            PacketUtil.sendPacket(new class_2868(mc.field_1724.method_31548().field_7545));
            this.stopBlock();
            this.postSwap = false;
            handled = true;
        }
        if (this.postBlock) {
            this.sendUseItem();
            this.postBlock = false;
            handled = true;
        }
        return handled;
    }

    public void sendUseItem() {
        ((laoqi123.mixin.ClientPlayerInteractionManagerAccessor) mc.field_1761).callSyncCurrentPlayItem();
        this.startBlock(mc.field_1724.method_6047());
    }

    public void startBlock(class_1799 itemStack) {
        PacketUtil.sendPacket(new class_2886(class_1268.field_5808, 0, 0.0F, 0.0F));
        mc.field_1724.method_6019(class_1268.field_5808);
        this.blockingState = true;
    }

    public void stopBlock() {
        PacketUtil.sendPacket(new class_2846(class_2846.class_2847.field_12974, class_2338.field_10980, class_2350.field_11033));
        mc.field_1724.method_6021();
        this.blockingState = false;
    }

    public void interactAttack(float yaw, float pitch, KillAura.AttackData targetData) {
        if (targetData != null) {
            class_239 mop = RotationUtil.rayTrace(targetData.getBox(), yaw, pitch, 8.0);
            if (mop != null) {
                ((laoqi123.mixin.ClientPlayerInteractionManagerAccessor) mc.field_1761).callSyncCurrentPlayItem();
                class_243 hitVec = mop.method_17784();
                PacketUtil.sendPacket(
                        class_2824.method_34208(
                                targetData.getEntity(),
                                mc.field_1724.method_5715(),
                                class_1268.field_5808,
                                new class_243(hitVec.field_1352 - targetData.getX(), hitVec.field_1351 - targetData.getY(), hitVec.field_1350 - targetData.getZ())
                        )
                );
                PacketUtil.sendPacket(class_2824.method_34207(targetData.getEntity(), mc.field_1724.method_5715(), class_1268.field_5808));
                PacketUtil.sendPacket(new class_2886(class_1268.field_5808, 0, 0.0F, 0.0F));
                mc.field_1724.method_6019(class_1268.field_5808);
                this.blockingState = true;
            }
        }
    }

    public BlockResult updateBlocking(KillAura module, boolean attack) {
        boolean block = attack && this.canAutoBlock();
        if (!block) {
            Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
            this.isBlocking = false;
            this.fakeBlockState = false;
            this.blockTick = 0;
            return new BlockResult(attack, false, false);
        }

        boolean swap = false;
        boolean blocked = false;
        switch (this.mode.getValue()) {
            case 0:
                if (PlayerUtil.isUsingItem()) {
                    this.isBlocking = true;
                    if (!this.isPlayerBlocking() && !Myau.playerStateManager.digging && !Myau.playerStateManager.placing) {
                        swap = true;
                    }
                } else {
                    this.isBlocking = false;
                    if (this.isPlayerBlocking() && !Myau.playerStateManager.digging && !Myau.playerStateManager.placing) {
                        this.stopBlock();
                    }
                }
                Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                this.fakeBlockState = false;
                break;
            case 1:
                if (module.hasValidTarget()) {
                    if (!this.isPlayerBlocking() && !Myau.playerStateManager.digging && !Myau.playerStateManager.placing) {
                        swap = true;
                    }
                    Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                    this.isBlocking = true;
                    this.fakeBlockState = false;
                } else {
                    Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                    this.isBlocking = false;
                    this.fakeBlockState = false;
                }
                break;
            case 2:
                if (module.hasValidTarget()) {
                    if (!Myau.playerStateManager.digging && !Myau.playerStateManager.placing) {
                        switch (this.blockTick) {
                            case 0:
                                if (!this.isPlayerBlocking()) {
                                    swap = true;
                                }
                                blocked = true;
                                this.blockTick = 1;
                                break;
                            case 1:
                                attack = false;
                                this.blockTick = 2;
                                break;
                            case 2:
                                if (this.isPlayerBlocking()) {
                                    if (!this.noSwap.getValue()) {
                                        int randomSlot = new Random().nextInt(9);
                                        while (randomSlot == mc.field_1724.method_31548().field_7545) {
                                            randomSlot = new Random().nextInt(9);
                                        }
                                        PacketUtil.sendPacket(new class_2868(randomSlot));
                                        PacketUtil.sendPacket(new class_2868(mc.field_1724.method_31548().field_7545));
                                    }
                                    this.stopBlock();
                                }
                                if (this.test.getValue()) {
                                    if (this.testAttackTick >= this.moreAttackDelay.getValue()) {
                                        this.testAttackTick = 0;
                                    } else {
                                        this.testAttackTick++;
                                        attack = false;
                                    }
                                } else {
                                    attack = false;
                                }
                                this.blockTick = 0;
                                break;
                            default:
                                this.blockTick = 0;
                                break;
                        }
                    }
                    this.isBlocking = true;
                    this.fakeBlockState = true;
                } else {
                    int randomSlot = new Random().nextInt(9);
                    while (randomSlot == mc.field_1724.method_31548().field_7545) {
                        randomSlot = new Random().nextInt(9);
                    }
                    PacketUtil.sendPacket(new class_2868(randomSlot));
                    PacketUtil.sendPacket(new class_2868(mc.field_1724.method_31548().field_7545));
                    Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                    this.isBlocking = false;
                    this.fakeBlockState = false;
                }
                break;
            case 3:
                if (module.hasValidTarget()) {
                    if (!Myau.playerStateManager.digging && !Myau.playerStateManager.placing) {
                        switch (this.blockTick) {
                            case 0:
                                if (!this.isPlayerBlocking()) {
                                    swap = true;
                                }
                                this.blockTick = 1;
                                break;
                            case 1:
                                if (this.isPlayerBlocking()) {
                                    this.stopBlock();
                                    attack = false;
                                }
                                if (module.getAttackDelayMS() <= 50L) {
                                    this.blockTick = 0;
                                }
                                break;
                            default:
                                this.blockTick = 0;
                        }
                    }
                    Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                    this.isBlocking = true;
                    this.fakeBlockState = false;
                } else {
                    Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                    this.isBlocking = false;
                    this.fakeBlockState = false;
                }
                break;
            case 4:
                Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                this.isBlocking = false;
                this.fakeBlockState = module.hasValidTarget();
                if (PlayerUtil.isUsingItem()
                        && !this.isPlayerBlocking()
                        && !Myau.playerStateManager.digging
                        && !Myau.playerStateManager.placing) {
                    swap = true;
                }
                break;
            case 5:
                if (module.hasValidTarget()) {
                    if (!Myau.playerStateManager.digging && !Myau.playerStateManager.placing) {
                        switch (this.blockTick) {
                            case 0:
                                blocked = true;
                                if (!this.isPlayerBlocking()) {
                                    swap = true;
                                }
                                this.blockTick = 1;
                                break;
                            case 1:
                                if (this.isPlayerBlocking()) {
                                    int randomSlot = new Random().nextInt(9);
                                    while (randomSlot == mc.field_1724.method_31548().field_7545) {
                                        randomSlot = new Random().nextInt(9);
                                    }
                                    PacketUtil.sendPacket(new class_2868(randomSlot));
                                    PacketUtil.sendPacket(new class_2868(mc.field_1724.method_31548().field_7545));
                                }
                                attack = false;
                                this.blockTick = 2;
                                break;
                            case 2:
                                attack = false;
                                this.stopBlock();
                                if (module.getAttackDelayMS() <= 50L) {
                                    this.blockTick = 0;
                                }
                                break;
                            default:
                                this.blockTick = 0;
                        }
                    }
                    this.isBlocking = true;
                    this.fakeBlockState = true;
                } else {
                    Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                    int randomSlot = new Random().nextInt(9);
                    while (randomSlot == mc.field_1724.method_31548().field_7545) {
                        randomSlot = new Random().nextInt(9);
                    }
                    PacketUtil.sendPacket(new class_2868(randomSlot));
                    PacketUtil.sendPacket(new class_2868(mc.field_1724.method_31548().field_7545));
                    this.isBlocking = false;
                    this.fakeBlockState = false;
                }
                break;
            case 6:
                if (module.hasValidTarget()) {
                    if (!Myau.playerStateManager.digging && !Myau.playerStateManager.placing) {
                        if (this.blockTick + 1 == this.startBlinkTick.getValue()) {
                            blocked = true;
                        }
                        if (this.blockTick + 1 != this.attackTick.getValue()) {
                            attack = false;
                        }
                        if (this.blockTick + 1 == this.startBlockTick.getValue()) {
                            if (!this.isPlayerBlocking()) {
                                swap = true;
                                if (this.postStartBlock.getValue()) {
                                    this.postBlock = true;
                                }
                            }
                        }
                        if (this.blockTick + 1 == this.stopBlinkTick.getValue()) {
                            Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                        }
                        if (this.blockTick + 1 == this.swapTick.getValue()) {
                            int randomSlot = new Random().nextInt(9);
                            while (randomSlot == mc.field_1724.method_31548().field_7545) {
                                randomSlot = new Random().nextInt(9);
                            }
                            PacketUtil.sendPacket(new class_2868(randomSlot));
                            this.swapped = true;
                        }
                        if (this.blockTick + 1 == this.switchBackTick.getValue()) {
                            if (this.swapped) {
                                PacketUtil.sendPacket(new class_2868(mc.field_1724.method_31548().field_7545));
                                this.swapped = false;
                            }
                        }
                        if (this.blockTick + 1 == this.stopBlockTick.getValue()) {
                            if (this.isPlayerBlocking()) {
                                this.stopBlock();
                            }
                        }
                        this.blockTick++;
                        if (this.blockTick >= this.maxTick.getValue() - 1) {
                            this.blockTick = 0;
                        }
                    }
                    this.isBlocking = true;
                    this.fakeBlockState = true;
                } else {
                    if (this.swapped) {
                        PacketUtil.sendPacket(new class_2868(mc.field_1724.method_31548().field_7545));
                        this.swapped = false;
                    }
                    Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                    this.isBlocking = false;
                    this.fakeBlockState = false;
                }
                break;
        }

        return new BlockResult(attack, swap, blocked);
    }

    public static class BlockResult {
        public boolean attack;
        public boolean swap;
        public boolean blocked;

        public BlockResult(boolean attack, boolean swap, boolean blocked) {
            this.attack = attack;
            this.swap = swap;
            this.blocked = blocked;
        }
    }
}
