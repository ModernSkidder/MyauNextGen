package laoqi123.module.modules.combat;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.LeftClickMouseEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.module.Module;
import laoqi123.value.Value;
import laoqi123.value.properties.BooleanValue;
import laoqi123.value.properties.FloatValue;
import laoqi123.util.*;
import laoqi123.util.clicking.Clicker;
import laoqi123.util.config.Configurable;
import laoqi123.util.config.PropertyProvider;
import laoqi123.value.properties.IntValue;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_239;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import java.util.List;
import java.util.Objects;

public class AutoClicker extends Module implements PropertyProvider {
    private static final class_310 mc = class_310.method_1551();
    private final Configurable rootConfig = new Configurable("AutoClicker");
    private boolean clickPending = false;
    private boolean blockHitPending = false;
    private long blockHitDelay = 0L;
    public final IntValue minCPS = new IntValue("min-cps", 8, 1, 20);
    public final IntValue maxCPS = new IntValue("max-cps", 12, 1, 20);
    public final Clicker clicker;
    public final BooleanValue blockHit = new BooleanValue("block-hit", false);
    public final FloatValue blockHitTicks = new FloatValue("block-hit-ticks", 1.5F, 1.0F, 20.0F, this.blockHit::getValue);
    public final BooleanValue weaponsOnly = new BooleanValue("weapons-only", true);
    public final BooleanValue allowTools = new BooleanValue("allow-tools", false, this.weaponsOnly::getValue);
    public final BooleanValue breakBlocks = new BooleanValue("break-blocks", true);
    public final FloatValue range = new FloatValue("range", 3.0F, 3.0F, 8.0F, this.breakBlocks::getValue);
    public final FloatValue hitBoxVertical = new FloatValue("hit-box-vertical", 0.1F, 0.0F, 1.0F, this.breakBlocks::getValue);
    public final FloatValue hitBoxHorizontal = new FloatValue("hit-box-horizontal", 0.2F, 0.0F, 1.0F, this.breakBlocks::getValue);

    public AutoClicker() {
        super("AutoClicker", false);
        this.clicker = new Clicker("AutoClickerClicker", this.minCPS, this.maxCPS);
        this.rootConfig.setRunningOverride(this::isEnabled);
        this.rootConfig.addChild(this.clicker);
    }

    private int getKeyCode(class_304 keyBinding) {
        class_3675.class_306 key = class_3675.method_15981(keyBinding.method_1428());
        int code = key.method_1444();
        return key.method_1442() == class_3675.class_307.field_1672 ? code - 100 : code;
    }

    private long getBlockHitDelay() {
        return (long) (50.0F * this.blockHitTicks.getValue());
    }

    private boolean isBreakingBlock() {
        return mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1332;
    }

    private boolean canClick() {
        if (!this.weaponsOnly.getValue()
                || ItemUtil.hasRawUnbreakingEnchant()
                || this.allowTools.getValue() && ItemUtil.isHoldingTool()) {
            if (this.breakBlocks.getValue() && this.isBreakingBlock() && !this.hasValidTarget()) {
                class_1934 gameType = mc.field_1761.method_2920();
                return gameType != class_1934.field_9215 && gameType != class_1934.field_9220;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    private boolean isValidTarget(class_1657 entityPlayer) {
        if (entityPlayer != mc.field_1724 && entityPlayer != mc.field_1724.method_5854()) {
            if (entityPlayer == mc.method_1560() || entityPlayer == mc.method_1560().method_5854()) {
                return false;
            } else if (entityPlayer.field_6213 > 0) {
                return false;
            } else {
                float borderSize = entityPlayer.method_5871();
                return RotationUtil.rayTrace(entityPlayer.method_5829().method_1009(
                        borderSize + this.hitBoxHorizontal.getValue(),
                        borderSize + this.hitBoxVertical.getValue(),
                        borderSize + this.hitBoxHorizontal.getValue()
                ), mc.field_1724.method_36454(), mc.field_1724.method_36455(), this.range.getValue()) != null;
            }
        } else {
            return false;
        }
    }

    private boolean hasValidTarget() {
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity instanceof class_1657 && this.isValidTarget((class_1657) entity)) {
                return true;
            }
        }
        return false;
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (event.getType() == EventType.PRE) {
            this.clicker.tick();
            if (this.blockHitDelay > 0L) {
                this.blockHitDelay -= 50L;
            }
            if (mc.field_1755 != null) {
                this.clickPending = false;
                this.blockHitPending = false;
            } else {
                if (this.clickPending) {
                    this.clickPending = false;
                    KeyBindUtil.updateKeyState(this.getKeyCode(mc.field_1690.field_1886));
                }
                if (this.blockHitPending) {
                    this.blockHitPending = false;
                    KeyBindUtil.updateKeyState(this.getKeyCode(mc.field_1690.field_1904));
                }
                if (this.isEnabled() && this.canClick() && KeyBindUtil.isKeyDown(mc.field_1690.field_1886)) {
                    if (!mc.field_1724.method_6115()) {
                        this.clicker.click(() -> {
                            KeyBindUtil.setKeyBindState(this.getKeyCode(mc.field_1690.field_1886), false);
                            KeyBindUtil.pressKeyOnce(this.getKeyCode(mc.field_1690.field_1886));
                            this.clickPending = true;
                            return true;
                        });
                    }
                    if (this.blockHit.getValue()
                            && this.blockHitDelay <= 0L
                            && KeyBindUtil.isKeyDown(mc.field_1690.field_1904)
                            && ItemUtil.isHoldingSword()) {
                        this.blockHitPending = true;
                        KeyBindUtil.setKeyBindState(this.getKeyCode(mc.field_1690.field_1904), false);
                        if (!mc.field_1724.method_6115()) {
                            this.blockHitDelay = this.blockHitDelay + this.getBlockHitDelay();
                            KeyBindUtil.pressKeyOnce(this.getKeyCode(mc.field_1690.field_1904));
                        }
                    }
                }
            }
        }
    }

    @EventTarget(Priority.LOWEST)
    public void onCLick(LeftClickMouseEvent event) {
        if (this.isEnabled() && !event.isCancelled()) {
            if (!this.clickPending) {
                this.clicker.itemCooldown.newCooldown();
            }
        }
    }

    @Override
    public void onEnabled() {
        this.blockHitDelay = 0L;
        this.clicker.reset();
    }

    @Override
    public void verifyValue(String mode) {
        if (this.minCPS.getName().equals(mode)) {
            if (this.minCPS.getValue() > this.maxCPS.getValue()) {
                this.maxCPS.setValue(this.minCPS.getValue());
            }
        } else {
            if (this.maxCPS.getName().equals(mode) && this.minCPS.getValue() > this.maxCPS.getValue()) {
                this.minCPS.setValue(this.maxCPS.getValue());
            }
        }
    }

    @Override
    public String[] getSuffix() {
        return Objects.equals(this.minCPS.getValue(), this.maxCPS.getValue())
                ? new String[]{this.minCPS.getValue().toString()}
                : new String[]{String.format("%d-%d", this.minCPS.getValue(), this.maxCPS.getValue())};
    }

    @Override
    public List<Value<?>> getAdditionalProperties() {
        return this.rootConfig.collectProperties();
    }
}
