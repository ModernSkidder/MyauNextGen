package laoqi123.module.modules.combat;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.LeftClickMouseEvent;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.*;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1420;
import net.minecraft.class_1429;
import net.minecraft.class_1439;
import net.minecraft.class_1477;
import net.minecraft.class_1510;
import net.minecraft.class_1528;
import net.minecraft.class_1531;
import net.minecraft.class_1533;
import net.minecraft.class_1588;
import net.minecraft.class_1614;
import net.minecraft.class_1621;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import laoqi123.util.RenderUtil;
import laoqi123.util.TeamUtil;
import java.awt.*;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class HitBox extends Module {
    private static final class_310 mc = class_310.method_1551();
    private class_1297 targetEntity = null;
    private class_243 targetHitVec = null;
    public final FloatValue multiplier = new FloatValue("multiplier", 1.2F, 1.0F, 5.0F);
    public final ModeValue showHitbox = new ModeValue("show-hitbox", 0, new String[]{"NONE", "PLAYERS", "MOBS", "ANIMALS", "ALL"});
    public final ColorValue color = new ColorValue("color", new Color(255, 255, 255).getRGB(), () -> this.showHitbox.getValue() != 0);
    public final BooleanValue teams = new BooleanValue("teams", true, () -> this.showHitbox.getValue() == 1 || this.showHitbox.getValue() == 4);
    public final BooleanValue botCheck = new BooleanValue("bot-check", true, () -> this.showHitbox.getValue() == 1 || this.showHitbox.getValue() == 4);

    public HitBox() {
        super("HitBox", false);
    }

    public static float getExpansion(class_1297 entity) {
        HitBox hitBox = (HitBox) Myau.moduleManager.modules.get(HitBox.class);
        if (hitBox != null && hitBox.isEnabled() && entity instanceof class_1309) {
            return hitBox.multiplier.getValue();
        }
        return 1.0F;
    }

    private void calculateMouseOver(float partialTicks) {
        if (mc.method_1560() != null && mc.field_1687 != null) {
            mc.field_1692 = null;
            class_1297 pointedEntity = null;
            double reach = 3.0;
            class_239 blockHit = mc.method_1560().method_5745(reach, partialTicks, false);
            double distance = reach;
            class_243 eyePos = mc.method_1560().method_5836(partialTicks);
            if (blockHit.method_17783() != class_239.class_240.field_1333) {
                distance = blockHit.method_17784().method_1022(eyePos);
            }
            class_243 lookVec = mc.method_1560().method_5828(partialTicks);
            class_243 reachVec = eyePos.method_1031(lookVec.field_1352 * reach, lookVec.field_1351 * reach, lookVec.field_1350 * reach);
            class_243 hitVec = null;
            float expansion = 1.0F;
            List<class_1297> entities = mc.field_1687.method_8333(
                    mc.method_1560(),
                    mc.method_1560()
                            .method_5829()
                            .method_989(lookVec.field_1352 * reach, lookVec.field_1351 * reach, lookVec.field_1350 * reach)
                            .method_1009(expansion, expansion, expansion),
                    e -> true
            );
            double closestDistance = distance;
            for (class_1297 entity : entities) {
                if (entity.method_5863()) {
                    float collisionSize = (float) ((double) 0.1F * getExpansion(entity));
                    class_238 expandedBox = entity.method_5829().method_1009(collisionSize, collisionSize, collisionSize);
                    Optional<class_243> intercept = expandedBox.method_992(eyePos, reachVec);
                    if (expandedBox.method_1006(eyePos)) {
                        if (0.0 < closestDistance || closestDistance == 0.0) {
                            pointedEntity = entity;
                            hitVec = intercept.orElse(eyePos);
                            closestDistance = 0.0;
                        }
                    } else if (intercept.isPresent()) {
                        double interceptDistance = eyePos.method_1022(intercept.get());
                        if (interceptDistance < closestDistance || closestDistance == 0.0) {
                            if (entity == mc.method_1560().method_5854() && !entity.method_5863()) {
                                if (closestDistance == 0.0) {
                                    pointedEntity = entity;
                                    hitVec = intercept.get();
                                }
                            } else {
                                pointedEntity = entity;
                                hitVec = intercept.get();
                                closestDistance = interceptDistance;
                            }
                        }
                    }
                }
            }
            if (pointedEntity != null && (closestDistance < distance || blockHit.method_17783() == class_239.class_240.field_1333)) {
                this.targetEntity = pointedEntity;
                this.targetHitVec = hitVec;
                if (pointedEntity instanceof class_1309 || pointedEntity instanceof class_1533) {
                    mc.field_1692 = pointedEntity;
                }
            }
        }
    }

    private boolean shouldShowEntity(class_1309 entity) {
        if (entity == mc.field_1724) {
            return false;
        }
        if (entity.field_6213 > 0 || entity instanceof class_1531 || entity.method_5767()) {
            return false;
        }
        if (mc.method_1560().method_5739(entity) > 128.0F) {
            return false;
        }
        if (!RenderUtil.isInViewFrustum(entity.method_5829(), 0.1F)) {
            return false;
        }
        switch (this.showHitbox.getValue()) {
            case 0:
                return false;
            case 1:
                if (entity instanceof class_1657) {
                    class_1657 player = (class_1657) entity;
                    if (TeamUtil.isFriend(player)) {
                        return false;
                    }
                    if (this.teams.getValue() && TeamUtil.isSameTeam(player)) {
                        return false;
                    }
                    if (this.botCheck.getValue() && TeamUtil.isBot(player)) {
                        return false;
                    }
                    return true;
                }
                return false;
            case 2:
                if (entity instanceof class_1510 || entity instanceof class_1528) {
                    return true;
                }
                if (entity instanceof class_1588 || entity instanceof class_1621) {
                    return !(entity instanceof class_1614);
                }
                return false;
            case 3:
                return entity instanceof class_1429
                        || entity instanceof class_1420
                        || entity instanceof class_1477
                        || entity instanceof class_1646
                        || entity instanceof class_1439;
            case 4:
                if (entity instanceof class_1657) {
                    class_1657 player = (class_1657) entity;
                    if (TeamUtil.isFriend(player)) {
                        return false;
                    }
                    if (this.teams.getValue() && TeamUtil.isSameTeam(player)) {
                        return false;
                    }
                    if (this.botCheck.getValue() && TeamUtil.isBot(player)) {
                        return false;
                    }
                }
                return true;
            default:
                return false;
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            this.calculateMouseOver(1.0F);
        }
    }

    @EventTarget(Priority.HIGH)
    public void onLeftClick(LeftClickMouseEvent event) {
        if (this.isEnabled() && !event.isCancelled() && this.targetEntity != null) {
            mc.field_1765 = new class_3966(this.targetEntity, this.targetHitVec);
        }
    }

    @EventTarget
    public void onRender(Render3DEvent event) {
        if (this.isEnabled() && this.showHitbox.getValue() != 0) {
            List<class_1309> entities = StreamSupport.stream(mc.field_1687.method_18112().spliterator(), false)
                    .filter(entity -> entity instanceof class_1309)
                    .map(entity -> (class_1309) entity)
                    .filter(this::shouldShowEntity)
                    .collect(Collectors.toList());
            if (!entities.isEmpty()) {
                RenderUtil.enableRenderState();
                Color renderColor = new Color(this.color.getValue());
                for (class_1309 entity : entities) {
                    float collisionSize = (float) ((double) 0.1F * this.multiplier.getValue());
                    class_238 expandedBox = entity.method_5829().method_1009(collisionSize, collisionSize, collisionSize);
                    double lerpX = RenderUtil.lerpDouble(entity.method_23317(), entity.field_6014, event.getPartialTicks());
                    double lerpY = RenderUtil.lerpDouble(entity.method_23318(), entity.field_6036, event.getPartialTicks());
                    double lerpZ = RenderUtil.lerpDouble(entity.method_23321(), entity.field_5969, event.getPartialTicks());
                    class_243 cameraPos = mc.field_1773.method_19418().method_19326();
                    class_238 offsetBox = new class_238(
                            expandedBox.field_1323 - entity.method_23317() + (lerpX - cameraPos.field_1352),
                            expandedBox.field_1322 - entity.method_23318() + (lerpY - cameraPos.field_1351),
                            expandedBox.field_1321 - entity.method_23321() + (lerpZ - cameraPos.field_1350),
                            expandedBox.field_1320 - entity.method_23317() + (lerpX - cameraPos.field_1352),
                            expandedBox.field_1325 - entity.method_23318() + (lerpY - cameraPos.field_1351),
                            expandedBox.field_1324 - entity.method_23321() + (lerpZ - cameraPos.field_1350)
                    );
                    RenderUtil.drawBoundingBox(offsetBox, renderColor.getRed(), renderColor.getGreen(), renderColor.getBlue(), 150, 1.5F);
                }
                RenderUtil.disableRenderState();
            }
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{String.format("%.1fx", this.multiplier.getValue())};
    }
}
