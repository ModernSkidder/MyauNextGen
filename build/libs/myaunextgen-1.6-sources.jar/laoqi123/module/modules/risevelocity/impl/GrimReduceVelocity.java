package laoqi123.module.modules.risevelocity.impl;

import laoqi123.Myau;
import laoqi123.event.types.EventType;
import laoqi123.events.MoveInputEvent;
import laoqi123.events.PacketEvent;
import laoqi123.events.PlayerUpdateEvent;
import laoqi123.events.TickEvent;
import laoqi123.module.modules.KillAura;
import laoqi123.module.modules.Scaffold;
import laoqi123.module.modules.risevelocity.RiseVelocityMode;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.FloatProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.util.PacketUtil;
import net.minecraft.class_10264;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2684;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2777;
import net.minecraft.class_2824;
import java.util.ArrayList;
import java.util.List;

public class GrimReduceVelocity extends RiseVelocityMode {
    public final IntProperty reduceTicks = new IntProperty("Reduce Ticks", 5, 0, 10);
    public final IntProperty teleportDisable = new IntProperty("Teleport Disable", 3, 1, 10);
    public final IntProperty delayTillGround = new IntProperty("Delay Till Ground", 6, 1, 20);
    public final BooleanProperty extraHit = new BooleanProperty("Extra Hit", true);
    public final BooleanProperty distHit = new BooleanProperty("Distant Hit", true);
    public final BooleanProperty delayPlus = new BooleanProperty("Delay Plus", true);
    public final BooleanProperty rotations = new BooleanProperty("Rotations", true);
    public final BooleanProperty jumpReset = new BooleanProperty("Jump Reset", true);
    public final FloatProperty range = new FloatProperty("Range", 3.0F, 1.0F, 6.0F);

    private final List<class_2596<class_2602>> delayedPackets = new ArrayList<>();
    private boolean dj;
    private boolean flushingPackets;
    private boolean pendingJumpReset;
    private int holdTicks;
    private int groundedTicks;

    @Override
    public String getName() {
        return "Grim Reduce";
    }

    @Override
    public void onEnable() {
        this.delayedPackets.clear();
        this.dj = false;
        this.flushingPackets = false;
        this.pendingJumpReset = false;
        this.holdTicks = 0;
        this.groundedTicks = 0;
    }

    @Override
    public void onPacketReceive(PacketEvent event) {
        if (event.getType() != EventType.RECEIVE) {
            return;
        }
        if (this.flushingPackets || this.getTicksSinceTeleport() < this.teleportDisable.getValue() || this.isInWeb()) {
            return;
        }
        class_2596<?> packet = event.getPacket();
        if (packet instanceof class_2743 velocity) {
            if (velocity.method_11818() != mc.field_1724.method_5628()) {
                return;
            }
            this.pendingJumpReset = true;
            this.delayedPackets.add((class_2596<class_2602>) packet);
            this.dj = true;
            event.setCancelled(true);
        } else if (packet instanceof class_2684 || packet instanceof class_2777
                || packet instanceof class_10264) {
            if (this.dj) {
                this.delayedPackets.add((class_2596<class_2602>) packet);
                event.setCancelled(true);
            }
        } else if (packet instanceof class_2708) {
            if (this.dj) {
                this.delayedPackets.add((class_2596<class_2602>) packet);
                event.setCancelled(true);
            }
        }
    }

    @Override
    public void onTick(TickEvent event) {
        if (event.getType() != EventType.PRE) {
            return;
        }
        class_1657 player = mc.field_1724;
        if (player == null || mc.field_1687 == null) {
            return;
        }
        if (player.method_24828()) {
            this.groundedTicks++;
        } else {
            this.groundedTicks = 0;
        }
        if (this.dj) {
            this.holdTicks++;
            if (this.holdTicks > 25) {
                this.flush();
            }
        }

        KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
        boolean scaffoldEnabled = ((Scaffold) Myau.moduleManager.modules.get(Scaffold.class)).isEnabled();

        class_1309 target;
        if (killAura != null && killAura.isEnabled() && killAura.getTarget() != null) {
            target = killAura.getTarget();
        } else {
            target = this.getClosestTarget(this.range.getValue());
        }
        if (target == null) {
            return;
        }

        if (player.field_6235 < 7 && this.rotations.getValue() && !scaffoldEnabled) {
            this.lookAt(target);
            if (player.field_6235 <= this.reduceTicks.getValue() && player.method_5739(target) > 3.0) {
                player.method_36457((float) (90.0 - Math.random() * 5.0));
            }
        }

        if (player.field_6012 <= 20) {
            return;
        }
        if (player.field_6235 > this.reduceTicks.getValue() + 1) {
            return;
        }
        if (this.getTicksSinceTeleport() <= this.teleportDisable.getValue()) {
            return;
        }
        if (!this.extraHit.getValue()) {
            return;
        }
        if (this.distHit.getValue() && player.method_5739(target) > 2.5) {
            PacketUtil.sendPacket(class_2824.method_34206(target, player.method_5715()));
            player.method_6104(class_1268.field_5808);
        }
        mc.field_1761.method_2918(player, target);
        player.method_6104(class_1268.field_5808);
    }

    @Override
    public void onMoveInput(MoveInputEvent event) {
        if (mc.field_1724 == null) {
            return;
        }
        if (this.pendingJumpReset && this.jumpReset.getValue() && this.dj) {
            event.setJump(true);
        }
        boolean scaffoldEnabled = ((Scaffold) Myau.moduleManager.modules.get(Scaffold.class)).isEnabled();
        if (mc.field_1724.field_6235 < 7 && this.rotations.getValue() && !scaffoldEnabled) {
            class_1309 target = this.getClosestTarget(this.range.getValue());
            if (target != null) {
                event.setForward(1.0F);
                event.setStrafe(0.0F);
            }
        }
    }

    @Override
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mc.field_1724 == null) {
            return;
        }
        if (this.dj && this.shouldFlush()) {
            this.flush();
        }
        this.pendingJumpReset = false;
    }

    private boolean shouldFlush() {
        class_1657 player = mc.field_1724;
        if (!this.dj) {
            return false;
        }
        if (this.delayPlus.getValue()) {
            return this.groundedTicks >= this.delayTillGround.getValue();
        }
        if (player.method_24828()) {
            return true;
        }
        class_1309 target = this.getClosestTarget(this.range.getValue());
        if (target == null) {
            return true;
        }
        return player.method_5739(target) < 2.7 || this.getTicksSinceAttack() <= 1;
    }

    private void flush() {
        this.flushingPackets = true;
        for (class_2596<class_2602> packet : this.delayedPackets) {
            PacketUtil.receivePacket(packet);
        }
        PacketUtil.drainPendingPackets();
        this.delayedPackets.clear();
        this.flushingPackets = false;
        this.dj = false;
        this.holdTicks = 0;
        this.groundedTicks = 0;
    }

    private void lookAt(class_1309 target) {
        class_1657 player = mc.field_1724;
        double deltaX = target.method_23317() - player.method_23317();
        double deltaZ = target.method_23321() - player.method_23321();
        float yaw = (float) (Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0);
        double deltaY = target.method_23318() + target.method_17682() * 0.5 - player.method_23320();
        float pitch = (float) Math.toDegrees(-Math.atan2(deltaY, player.method_5739(target)));
        player.method_36456(yaw);
        player.method_36457(pitch);
    }
}