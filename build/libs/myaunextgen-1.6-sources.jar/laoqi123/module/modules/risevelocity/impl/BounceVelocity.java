package laoqi123.module.modules.risevelocity.impl;

import laoqi123.event.types.EventType;
import laoqi123.events.PacketEvent;
import laoqi123.module.modules.risevelocity.RiseVelocityMode;
import net.minecraft.class_2743;

public class BounceVelocity extends RiseVelocityMode {

    @Override
    public String getName() {
        return "Bounce";
    }

    @Override
    public void onPacketReceive(PacketEvent event) {
        if (event.getType() != EventType.RECEIVE) {
            return;
        }
        if (!(event.getPacket() instanceof class_2743 packet)) {
            return;
        }
        if (packet.method_11818() != mc.field_1724.method_5628()) {
            return;
        }
        if (this.getTicksSinceTeleport() < 3 || this.isInWeb()) {
            return;
        }
        event.setCancelled(true);
        double velocityY = packet.method_11816();
        if (velocityY > 0) {
            double y = 0.42;
            if (velocityY / 8000.0 >= 2.0) {
                y = velocityY / 8000.0;
            }
            mc.field_1724.method_18800(packet.method_11815() / 8000.0, y, packet.method_11819() / 8000.0);
        }
    }
}