package laoqi123.module.modules.risevelocity.impl;

import laoqi123.event.types.EventType;
import laoqi123.events.PacketEvent;
import laoqi123.module.modules.risevelocity.RiseVelocityMode;
import net.minecraft.class_2743;

public class StandardVelocity extends RiseVelocityMode {

    @Override
    public String getName() {
        return "Standard";
    }

    @Override
    public void onPacketReceive(PacketEvent event) {
        if (event.getType() != EventType.RECEIVE) {
            return;
        }
        if (!(event.getPacket() instanceof class_2743 packet)) {
            return;
        }
        if (packet.method_11818() != mc.field_1724.method_5628()) {
            return;
        }
        if (this.getTicksSinceTeleport() < 3 || this.isInWeb()) {
            return;
        }
        event.setCancelled(true);
    }
}