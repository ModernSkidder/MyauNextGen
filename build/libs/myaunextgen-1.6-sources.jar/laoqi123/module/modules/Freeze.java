package laoqi123.module.modules;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.MoveInputEvent;
import laoqi123.events.PacketEvent;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.ModeProperty;
import laoqi123.util.ChatUtil;
import laoqi123.util.PacketUtil;
import net.minecraft.class_10185;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_6374;
import java.util.concurrent.ConcurrentLinkedDeque;

public class Freeze extends Module {
    private static final class_310 mc = class_310.method_1551();

    public final ModeProperty mode = new ModeProperty("mode", 0, new String[]{"Queue", "Cancel", "Stationary"});
    public final BooleanProperty disableOnFlag = new BooleanProperty("disable-on-flag", true);
    public final BooleanProperty notification = new BooleanProperty("notification", false);

    private final ConcurrentLinkedDeque<class_2596<?>> packetQueue = new ConcurrentLinkedDeque<>();
    private boolean dispatching = false;

    public Freeze() {
        super("Freeze", false);
    }

    @Override
    public void onEnabled() {
        packetQueue.clear();
        dispatching = false;
    }

    @Override
    public void onDisabled() {
        dispatching = true;
        while (!packetQueue.isEmpty()) {
            PacketUtil.sendPacket(packetQueue.poll());
        }
        packetQueue.clear();
        dispatching = false;
    }

    @EventTarget
    public void onMove(MoveInputEvent event) {
        if (!this.enabled || mode.getValue() != 2 || mc.field_1724 == null) return;
        mc.field_1724.field_3913.field_54155 = new class_10185(false, false, false, false, false, false, false);
        mc.field_1724.field_3913.field_3907 = 0.0F;
        mc.field_1724.field_3913.field_3905 = 0.0F;
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (!this.enabled || dispatching || mc.field_1724 == null || mc.field_1687 == null) return;

        if (event.getType() == EventType.RECEIVE) {
            if (disableOnFlag.getValue() && event.getPacket() instanceof class_2708) {
                if (notification.getValue()) {
                    ChatUtil.sendFormatted("&cFreeze&r&8: &7Disabled on flag");
                }
                this.setEnabled(false);
            }
            return;
        }

        if (event.getType() != EventType.SEND) return;
        class_2596<?> packet = event.getPacket();

        if (packet instanceof class_2828) {
            event.setCancelled(true);
            if (mode.getValue() == 0) {
                packetQueue.add(packet);
            }
        } else if (mode.getValue() == 2 && packet instanceof class_6374) {
            event.setCancelled(true);
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{mode.getModeString()};
    }
}
