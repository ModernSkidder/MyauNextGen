package laoqi123.module.modules.player;

import laoqi123.event.EventTarget;
import laoqi123.event.types.Priority;
import laoqi123.events.*;
import laoqi123.module.Module;
import laoqi123.util.TimerUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2484;
import net.minecraft.class_310;
import net.minecraft.class_9334;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.PercentProperty;
import laoqi123.property.properties.IntProperty;

public class AutoHeal extends Module {
    private static final class_310 mc = class_310.method_1551();
    private final TimerUtil timer = new TimerUtil();
    private boolean shouldHeal = false;
    private int prevSlot = -1;
    private int hurtTick = 0;
    public final PercentProperty health = new PercentProperty("health", 35);
    public final IntProperty delay = new IntProperty("delay", 4000, 0, 5000);
    public final BooleanProperty regenCheck = new BooleanProperty("regen-check", false);
    public final BooleanProperty hurtCheck = new BooleanProperty("hurt-check", false);
    public final IntProperty hurtTime = new IntProperty("hurt-time", 20, 1, 100, hurtCheck::getValue);

    private int findHealingItem() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack != null && stack.method_65130() != null) {
                String name = stack.method_7964().getString();
                if (stack.method_7909() instanceof class_1747
                        && ((class_1747) stack.method_7909()).method_7711() instanceof class_2484
                        && name.contains("§6")
                        && name.contains("Golden Head")) {
                    return i;
                }
            }
        }
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack != null && stack.method_65130() != null) {
                String name = stack.method_7964().getString();
                if (stack.method_7909() instanceof class_1747
                        && ((class_1747) stack.method_7909()).method_7711() instanceof class_2484
                        && name.matches("\\S+§c's Head")) {
                    return i;
                }
            }
        }
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack != null && stack.method_65130() != null) {
                String name = stack.method_7964().getString();
                if (stack.method_57824(class_9334.field_50075) != null && name.contains("§6Cornucopia")) {
                    return i;
                }
                if (stack.method_57824(class_9334.field_50075) != null
                        && (name.contains("§a") && name.contains("Tasty Soup") || name.contains("§a") && name.contains("Assist Soup"))) {
                    return i;
                }
            }
        }
        return -1;
    }

    private boolean hasRegenEffect() {
        return this.regenCheck.getValue() && mc.field_1724.method_6059(class_1294.field_5924);
    }

    public AutoHeal() {
        super("AutoHeal", false);
    }

    public boolean isSwitching() {
        return this.prevSlot != -1;
    }

    @EventTarget(Priority.HIGH)
    public void onTick(TickEvent event) {
        if (!this.isEnabled()) {
            this.prevSlot = -1;
        } else {
            if (hurtCheck.getValue()){
                if (hurtTick > 0) hurtTick--;
                if (mc.field_1724.field_6235 > 0) {
                    hurtTick = hurtTime.getValue();
                }
            } else {
                hurtTick = 1;
            }
            switch (event.getType()) {
                case PRE:
                    boolean percent = (float) Math.ceil(mc.field_1724.method_6032() + mc.field_1724.method_6067()) / mc.field_1724.method_6063()
                            <= (float) this.health.getValue() / 100.0F;
                    if (this.shouldHeal
                            && percent
                            && !this.hasRegenEffect()
                            && this.timer.hasTimeElapsed(this.delay.getValue())
                            && hurtTick > 0) {
                        int slot = this.findHealingItem();
                        if (slot != -1) {
                            this.prevSlot = mc.field_1724.method_31548().field_7545;
                            mc.field_1724.method_31548().field_7545 = slot;
                            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                            this.timer.reset();
                        }
                    }
                    this.shouldHeal = percent;
                    break;
                case POST:
                    if (this.prevSlot != -1) {
                        mc.field_1724.method_31548().field_7545 = this.prevSlot;
                        this.prevSlot = -1;
                    }
            }
        }
    }

    @EventTarget
    public void onLeftClick(LeftClickMouseEvent event) {
        if (this.isEnabled() && this.isSwitching()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onRightClick(RightClickMouseEvent event) {
        if (this.isEnabled() && this.isSwitching()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onHitBlock(HitBlockEvent event) {
        if (this.isEnabled() && this.isSwitching()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onSwap(SwapItemEvent event) {
        if (this.isEnabled() && this.isSwitching()) {
            event.setCancelled(true);
        }
    }
}
