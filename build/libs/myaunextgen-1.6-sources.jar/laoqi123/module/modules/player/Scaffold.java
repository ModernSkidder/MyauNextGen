package laoqi123.module.modules.player;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.MoveInputEvent;
import laoqi123.event.impl.Render2DEvent;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.event.impl.UpdateEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.BooleanValue;
import laoqi123.value.properties.FloatValue;
import laoqi123.value.properties.IntValue;
import laoqi123.value.properties.ModeValue;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2189;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2879;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import laoqi123.util.BlockData;
import laoqi123.util.InventoryUtil;
import laoqi123.util.MovementUtils;
import laoqi123.util.PacketUtil;
import laoqi123.util.RandomUtils;
import laoqi123.util.RenderUtil;
import laoqi123.util.RotationUtils;
import laoqi123.util.SlotUtils;
import laoqi123.util.player.FallingPlayer;
import laoqi123.util.player.PlayerUtils;
import laoqi123.util.raytrace.ClientRayTraceUtil;
import laoqi123.util.rotation.Rotation;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Scaffold extends Module {
    private static final class_310 mc = class_310.method_1551();

    public final ModeValue mode = new ModeValue("Mode", 0, new String[]{"Telly", "Snap", "Normal"});
    public final BooleanValue alwaysUpdateRot = new BooleanValue("Always Update Rotation", false);
    public final IntValue placeTick = new IntValue("PlaceTick", 1, 1, 5, () -> mode.getValue() == 0);
    public final IntValue rotTick = new IntValue("RotationTick", 1, 1, 5);
    public final BooleanValue noSwing = new BooleanValue("No Swing", false);
    public final BooleanValue eagle = new BooleanValue("Eagle", false);
    public final BooleanValue snap = new BooleanValue("Snap", false);
    public final BooleanValue noUptelly = new BooleanValue("No Uptelly", true);
    public final BooleanValue godBridge = new BooleanValue("GodBridge", false, () -> mode.getValue() == 2);
    public final BooleanValue smoothed = new BooleanValue("Heypixel UpTelly", true, () -> mode.getValue() == 0);
    public final BooleanValue safeMode = new BooleanValue("Safe Mode", false, () -> mode.getValue() == 0 && smoothed.getValue());
    public final BooleanValue testOnGround = new BooleanValue("Test OnGround", false);
    public final BooleanValue fixRotation = new BooleanValue("Fix Rotation", true);
    public final BooleanValue randomSlow = new BooleanValue("SlowUpTelly", false);
    public final BooleanValue spoofItem = new BooleanValue("Spoof Item", true);
    public final BooleanValue keepFoV = new BooleanValue("Keep FoV", true);
    public final FloatValue fovValue = new FloatValue("Fov", 1.1f, 1.0f, 2.1f, () -> keepFoV.getValue());
    public final ModeValue blockSlotMode = new ModeValue("Block Slot Mode", 0, new String[]{"Farthest", "Most Blocks"});
    public final ModeValue jumpMode = new ModeValue("Jump Mode", 0, new String[]{"Normal", "Parkour", "None"});
    public final FloatValue safeDistance = new FloatValue("Clutch Safe Distance", 4.5f, 1f, 5f);
    public final IntValue tellyEagleTick = new IntValue("EagleTick", 1, 1, 5, () -> eagle.getValue());
    public final IntValue keepEagleSneakTick = new IntValue("KeepEagleTick", 1, 1, 5, () -> eagle.getValue());
    public final BooleanValue mark = new BooleanValue("Mark", true);
    public final BooleanValue blockCount = new BooleanValue("BlockCount", true);
    public final ModeValue blockCountStyle = new ModeValue("BlockCount Style", 0, new String[]{"Retro", "Old"}, () -> blockCount.getValue());
    public final IntValue blockCountOffset = new IntValue("BlockCount Y Offset", 0, 0, 200, () -> blockCount.getValue());

    public static final List<class_2248> invalidBlocks = Arrays.asList(
            class_2246.field_10485, class_2246.field_10121, class_2246.field_10034, class_2246.field_10443,
            class_2246.field_10380, class_2246.field_10535, class_2246.field_10102, class_2246.field_10343, class_2246.field_10336,
            class_2246.field_9980, class_2246.field_10181, class_2246.field_27097, class_2246.field_10200,
            class_2246.field_10158, class_2246.field_40284, class_2246.field_10179,
            class_2246.field_10228, class_2246.field_10375, class_2246.field_10523, class_2246.field_10429,
            class_2246.field_10121, class_2246.field_10231, class_2246.field_10411, class_2246.field_10544,
            class_2246.field_10284, class_2246.field_10330, class_2246.field_37554, class_2246.field_42735,
            class_2246.field_40277, class_2246.field_22104, class_2246.field_22105,
            class_2246.field_40262, class_2246.field_40264, class_2246.field_40263, class_2246.field_40266,
            class_2246.field_40265, class_2246.field_40267, class_2246.field_40270, class_2246.field_42738,
            class_2246.field_40271, class_2246.field_40268, class_2246.field_40269);

    private SlotData slot;
    private SlotData blockSlot;
    private int count;
    private int lastCount = 0;
    private int startHotbarCount = 1;
    private boolean canPlace;
    private BlockData blockData;
    private BlockData lastBlockData;
    private int rotateCount = 0;
    private double posY;
    private class_2338 lastPlacePosition = null;
    private int tellyJumpTicks;
    private boolean waitingForEagleSneak;
    private Rotation lastRotation;
    private Rotation rot;
    private int oldSlot;
    private int placeCount = 0;
    private int ups = 0;
    private float serverYaw;
    private float serverPitch;
    private float playerYaw;

    public Scaffold() {
        super("Scaffold", false);
    }

    @Override
    public void onEnabled() {
        placeCount = 0;
        ups = 0;
        if (mc.field_1724 == null) return;
        lastRotation = new Rotation(mc.field_1724.method_36454(), mc.field_1724.method_36455());
        serverYaw = mc.field_1724.method_36454();
        serverPitch = mc.field_1724.method_36455();
        this.slot = new SlotData(mc.field_1724.method_31548().field_7545, class_1268.field_5808);
        this.oldSlot = mc.field_1724.method_31548().field_7545;
        this.blockSlot = null;
        startHotbarCount = Math.max(1, getBlockCountHotbar());
        blockData = null;
        canPlace = true;
        lastPlacePosition = null;
        tellyJumpTicks = 0;
        waitingForEagleSneak = false;
        rot = null;
        ClientRayTraceUtil.updateEyePos();
    }

    @Override
    public void onDisabled() {
        if (mc.field_1724 == null) return;
        mc.field_1724.method_31548().field_7545 = oldSlot;
        mc.field_1690.field_1832.method_23481(false);
        MovementUtils.resetMove();
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (event.getType() != EventType.PRE || !isEnabled() || mc.field_1724 == null) return;
        // 捕获玩家自然朝向(此刻旋转还没被 mixin 应用,getYaw() 仍是真实视角)
        this.playerYaw = mc.field_1724.method_36454();
        ClientRayTraceUtil.updateEyePos();

        this.blockSlot = null;
        if (InventoryUtil.isFullBlock(mc.field_1724.method_6079()) && isValid(mc.field_1724.method_6079().method_7909())) {
            this.blockSlot = new SlotData(SlotUtils.OFFHAND, class_1268.field_5810);
        }
        if (blockSlot == null && blockSlotMode.getValue() != 1) {
            if (InventoryUtil.isFullBlock(mc.field_1724.method_6047()) && isValid(mc.field_1724.method_6047().method_7909())) {
                this.blockSlot = new SlotData(mc.field_1724.method_31548().field_7545, class_1268.field_5808);
            }
        }
        if (blockSlot == null) {
            int hotbarSlot = getHotbarBlockSlot();
            if (hotbarSlot != -1) {
                this.blockSlot = new SlotData(hotbarSlot, class_1268.field_5808);
            }
        }
        if (this.blockSlot == null || blockSlot.check()) return;

        if (mc.field_1724.method_24828()) {
            posY = Math.floor(mc.field_1724.method_23318() - 1);
        }
        if (mc.field_1690.field_1903.method_1434()) {
            posY = mc.field_1724.method_31478() - 1;
        }
        BlockData possible = ClientRayTraceUtil.isIgnoredBlock(mc.field_1687.method_8320(
                new class_2338((int) Math.floor(mc.field_1724.method_23317()), (int) Math.floor(mc.field_1724.method_23318()), (int) Math.floor(mc.field_1724.method_23321())))) ?
                getBlockData(new class_2338((int) Math.floor(mc.field_1724.method_23317()), (int) posY, (int) Math.floor(mc.field_1724.method_23321()))) : null;
        if (possible != null) {
            blockData = possible;
        }
        lastBlockData = possible;

        if (mode.getValue() == 2) {
            canPlace = true;
        } else if (mode.getValue() == 1) {
            canPlace = doesNotContainBlock(1);
        } else {
            canPlace = PlayerUtils.offGroundTicks >= placeTick.getValue();
            if (safeMode.getValue() && testOnGround.getValue() && !canPlace && mc.field_1690.field_1903.method_1434()) {
                canPlace = PlayerUtils.onGroundTicks == 1;
            }
        }

        if (this.blockSlot.hand() == class_1268.field_5808) {
            mc.field_1724.method_31548().field_7545 = this.blockSlot.slot();
        }
        FallingPlayer fallingPlayer = new FallingPlayer(mc.field_1724);
        boolean reachable = true;
        fallingPlayer.calculate(1);
        class_243 nextEyePos = fallingPlayer.getEyePos();
        fallingPlayer.calculate(1);
        BlockData placement = getBlockData(new class_2338((int) Math.floor(mc.field_1724.method_23317()), mc.field_1724.method_31478() - 1, (int) Math.floor(mc.field_1724.method_23321())));
        boolean forceRotation = false;
        if (placement != null) {
            if (safeMode.getValue() && testOnGround.getValue() && PlayerUtils.onGroundTicks == 1 && mc.field_1690.field_1903.method_1434()) {
                forceRotation = true;
            }
            double distance = nextEyePos.method_1022(placement.pos().method_46558());
            if (distance >= safeDistance.getValue() || placement.pos().method_10264() > fallingPlayer.getY()) {
                canPlace = true;
                reachable = false;
                blockData = lastBlockData = placement;
            }
        }
        if (blockData != null) {
            class_238 box = new class_238(this.blockData.pos())
                    .method_35575(this.blockData.pos().method_10264() - 1)
                    .method_35578(this.blockData.pos().method_10264() + 1);
            if (blockData.pos().method_10264() > fallingPlayer.getY() && !box.method_1006(mc.field_1724.method_19538())) {
                canPlace = true;
                reachable = false;
                posY = mc.field_1724.method_31478() - 1;
                blockData = lastBlockData = getBlockData(new class_2338((int) Math.floor(mc.field_1724.method_23317()), (int) Math.floor(posY), (int) Math.floor(mc.field_1724.method_23321())));
            }
        }
        if (!reachable && rotateCount < 8) {
            MovementUtils.cancelMove();
            rotateCount++;
        } else {
            rotateCount = 0;
        }

        rot = getBRot(forceRotation);
        if (rot == null) {
            rot = new Rotation(serverYaw, 75.5f);
        }
        float rotYaw = rot.getYaw();
        float rotPitch = rot.getPitch();
        rotPitch -= RandomUtils.generateRandomFloat(0.001f, 0.003f);
        rotYaw -= RandomUtils.generateRandomFloat(0.0001f, 0.0003f);
        do {
            rotPitch -= RandomUtils.generateRandomFloat(0.001f, 0.003f);
        } while (rotPitch > 90f);
        if (rotPitch < -90f) {
            rotPitch = -90f;
        }
        rot = new Rotation(rotYaw, rotPitch);

        if (didHitBlockFace(blockData, rot)) {
            MovementUtils.resetMove();
            rotateCount = 0;
        }
        if (fixRotation.getValue()) {
            rot = rot.normalize();
        }
        serverYaw = rot.getYaw();
        serverPitch = rot.getPitch();
        event.setRotation(serverYaw, serverPitch, 10);
        // 关键:把旋转喂给 MoveFix(setPervRotation → RotationState.smoothYaw),
        // MixinEntityLivingBase 会用 smoothYaw 让移动跟随旋转,与上报的包 yaw 一致,
        // 否则移动永远按自然朝向而包带着旋转 → Grim Simulation 一直判定异常
        event.setPervRotation(serverYaw, 10);

        if (blockData == null) return;
        if (mc.field_1724.method_7325()) {
            setEnabled(false);
            return;
        }
        place();
        if (mode.getValue() == 0) {
            return;
        }
        if (waitingForEagleSneak) {
            tellyJumpTicks++;
            if (tellyJumpTicks == tellyEagleTick.getValue() && !mc.field_1690.field_1832.method_1434()) {
                mc.field_1690.field_1832.method_23481(true);
            }
            if (tellyJumpTicks == tellyEagleTick.getValue() + keepEagleSneakTick.getValue()) {
                mc.field_1690.field_1832.method_23481(false);
                waitingForEagleSneak = false;
                tellyJumpTicks = 0;
            }
        }
    }

    private Rotation getBRot(boolean forceRotation) {
        Rotation rotation = blockData != null ? RotationUtils.getClosestToBlockFace(blockData.pos(), blockData.facing(), serverYaw, serverPitch) : null;
        if (rotation == null) {
            if (RotationUtils.normalizeYawDiff(mc.field_1724.method_36454() + 100f, serverYaw) < RotationUtils.normalizeYawDiff(mc.field_1724.method_36454() - 100f, serverYaw)) {
                rotation = new Rotation(mc.field_1724.method_36454() + 100f, serverPitch);
            } else {
                rotation = new Rotation(mc.field_1724.method_36454() - 100f, serverPitch);
            }
        }
        if (MovementUtils.cancelMove) {
            rotation = RotationUtils.getClosestToBlockFace(blockData.pos(), blockData.facing(), serverYaw, serverPitch);
            if (rotation == null) {
                rotation = new Rotation(serverYaw, 75.5f);
            }
        }
        float diff = RotationUtils.yawDiffDirectly(rotation.getYaw(), serverYaw);
        if (mode.getValue() == 0) {
            if (mc.field_1690.field_1903.method_1434() && noUptelly.getValue()) {
                return rotation;
            }
            if (mc.field_1690.field_1903.method_1434() && randomSlow.getValue()) {
                ups++;
                if (ups % 2 == 0) {
                    return rotation;
                }
            }
            if (smoothed.getValue() && (PlayerUtils.offGroundTicks < rotTick.getValue() || safeMode.getValue())) {
                if (PlayerUtils.onGroundTicks > 0) {
                    if (safeMode.getValue() && (!testOnGround.getValue() || mc.field_1690.field_1903.method_1434())) {
                        switch (PlayerUtils.onGroundTicks) {
                            case 1: {
                                if (!forceRotation) {
                                    rotation = new Rotation(serverYaw + RotationUtils.smooth(diff, diff / 2f), 75.5f);
                                } else {
                                    Rotation forced = RotationUtils.getClosestToBlockFace(blockData.pos(), blockData.facing(), mc.field_1724.method_36454(), serverPitch);
                                    rotation = forced != null ? forced : new Rotation(serverYaw + RotationUtils.smooth(diff, diff / 2f), 75.5f);
                                }
                                ((laoqi123.mixin.LivingEntityAccessor) mc.field_1724).setJumpTicks(2);
                                break;
                            }
                            case 2: {
                                return new Rotation(mc.field_1724.method_36454(), 75.5f);
                            }
                        }
                    } else {
                        return new Rotation(mc.field_1724.method_36454(), 75.5f);
                    }
                } else {
                    float smooth = PlayerUtils.offGroundTicks == 1 ? 80f : 50.0f;
                    smooth -= RandomUtils.generateRandomFloat(0.001f, 0.005f);
                    rotation = new Rotation(serverYaw + RotationUtils.smooth(diff, smooth), rotation.getPitch());
                }
            } else {
                if (snap.getValue() && mc.field_1690.field_1903.method_1434()) {
                    if (lastBlockData == null || PlayerUtils.offGroundTicks < rotTick.getValue()) {
                        return new Rotation(mc.field_1724.method_36454(), 85.0f + (float) Math.random());
                    }
                } else {
                    if (PlayerUtils.offGroundTicks < rotTick.getValue()) {
                        return new Rotation(mc.field_1724.method_36454(), 85.0f + (float) Math.random());
                    }
                }
            }
        }
        if (lastRotation != null && blockData != null && ClientRayTraceUtil.didHitBlockFace(mc.field_1724, lastRotation.getYaw(), lastRotation.getPitch(), blockData.pos(), blockData.facing(), true)) {
            return lastRotation;
        }
        if (blockData != null && !alwaysUpdateRot.getValue() && PlayerUtils.offGroundTicks >= rotTick.getValue()) {
            if (!ClientRayTraceUtil.didHitBlockFace(mc.field_1724, rotation.getYaw(), rotation.getPitch(), blockData.pos(), blockData.facing(), true) && PlayerUtils.offGroundTicks >= rotTick.getValue()) {
                float lastYaw = lastRotation != null ? lastRotation.getYaw() : rotation.getYaw();
                lastYaw += (float) Math.random();
                return new Rotation(lastYaw, lastRotation != null ? lastRotation.getPitch() : rotation.getPitch());
            }
        }
        lastRotation = rotation;
        return rotation;
    }

    private void place() {
        if (blockData == null || mc.field_1761 == null || !canPlace || rot == null) {
            return;
        }
        class_3965 block = ClientRayTraceUtil.getFacedBlock(rot.getYaw(), rot.getPitch());
        if (!ClientRayTraceUtil.didHitBlockFace(mc.field_1724, rot.getYaw(), rot.getPitch(), blockData.pos(), blockData.facing(), true)) {
            return;
        }
        if (this.blockSlot.hand() == class_1268.field_5808) {
            mc.field_1724.method_31548().field_7545 = this.blockSlot.slot();
        }
        class_1269 result = mc.field_1761.method_2896(mc.field_1724, this.blockSlot.hand(), block);
        if (result == class_1269.field_5812) {
            placeCount++;
            lastPlacePosition = blockData.pos().method_10093(blockData.facing());
            if (PlayerUtils.lastPitchDiff > 0.0d) {
                PlayerUtils.lastPlacePitchDiff = PlayerUtils.lastPitchDiff;
            }
            if (noSwing.getValue()) {
                PacketUtil.sendPacket(new class_2879(this.blockSlot.hand()));
            } else {
                mc.field_1724.method_6104(this.blockSlot.hand());
            }
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (event.getType() != EventType.POST || !isEnabled() || mc.field_1724 == null) return;
        if (waitingForEagleSneak) {
            tellyJumpTicks++;
            if (tellyJumpTicks == tellyEagleTick.getValue() && !mc.field_1690.field_1832.method_1434()) {
                mc.field_1690.field_1832.method_23481(true);
            }
            if (tellyJumpTicks == tellyEagleTick.getValue() + keepEagleSneakTick.getValue()) {
                mc.field_1690.field_1832.method_23481(false);
                waitingForEagleSneak = false;
                tellyJumpTicks = 0;
            }
        }
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (!isEnabled() || mc.field_1724 == null || blockSlot == null || blockSlot.check()) return;
        // 移动输入重写(Southside StrafeFix 同款):
        // 保持玩家想要的移动方向(按自然朝向计算的 forward/strafe),把输入改写成
        // "在上报 yaw(serverYaw) 下产生相同方向"的值 —— 这样回头自救时玩家继续向前移动,
        // 而上报 yaw 与重写后的输入对 Grim 依然自洽(不会往回走,也不会爆 Simulation)
        float forward = mc.field_1724.field_3913.field_3905;
        float strafe = mc.field_1724.field_3913.field_3907;
        if (!MovementUtils.cancelMove && (forward != 0.0f || strafe != 0.0f)) {
            float yawDiff = Math.abs(class_3532.method_15393(serverYaw - this.playerYaw));
            if (yawDiff > 1.0f) {
                double intended = Scaffold.getDirection(this.playerYaw, forward, strafe);
                float bestForward = 0f;
                float bestStrafe = 0f;
                float bestDiff = Float.MAX_VALUE;
                for (float pf = -1f; pf <= 1f; pf += 1f) {
                    for (float ps = -1f; ps <= 1f; ps += 1f) {
                        if (pf == 0f && ps == 0f) continue;
                        double predicted = Scaffold.getDirection(serverYaw, pf, ps);
                        float diff = Math.abs(class_3532.method_15393(
                                (float) Math.toDegrees(predicted) - (float) Math.toDegrees(intended)));
                        if (diff < bestDiff) {
                            bestDiff = diff;
                            bestForward = pf;
                            bestStrafe = ps;
                        }
                    }
                }
                event.setForward(bestForward);
                event.setStrafe(bestStrafe);
            }
        }
        if (PlayerUtils.onGroundTicks > (smoothed.getValue() && safeMode.getValue() && !testOnGround.getValue() ? 1 : 0)
                && !mc.field_1690.field_1903.method_1434() && PlayerUtils.isMoving() && mode.getValue() == 0) {
            switch (jumpMode.getValue()) {
                case 2: {
                    break;
                }
                case 0: {
                    event.setJump(true);
                    break;
                }
                case 1: {
                    double yaw = Math.toRadians(mc.field_1724.method_36454());
                    double forwardX = -Math.sin(yaw);
                    double forwardZ = Math.cos(yaw);
                    class_2338 frontPos1 = new class_2338((int) (mc.field_1724.method_23317() + forwardX), (int) (mc.field_1724.method_23318() - 0.1), (int) (mc.field_1724.method_23321() + forwardZ));
                    class_2338 frontPos2 = new class_2338((int) (mc.field_1724.method_23317() + forwardX * 2), (int) (mc.field_1724.method_23318() - 0.1), (int) (mc.field_1724.method_23321() + forwardZ * 2));
                    if (mc.field_1687.method_8320(frontPos1).method_26204() instanceof class_2189
                            || mc.field_1687.method_8320(frontPos2).method_26204() instanceof class_2189) {
                        event.setJump(true);
                    }
                    break;
                }
            }
            if (eagle.getValue()) {
                waitingForEagleSneak = true;
                tellyJumpTicks = 0;
            }
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (lastPlacePosition != null && mark.getValue()) {
            class_238 box = new class_238(lastPlacePosition);
            RenderUtil.drawBoundingBox(box, 255, 255, 255, 150, 2.0f);
        }
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!isEnabled() || mc.field_1724 == null || !blockCount.getValue()) return;
        int newCount = Math.max(0, getBlockCountHotbar());
        if (newCount > startHotbarCount) {
            startHotbarCount = newCount;
        }
        float centerX = mc.method_22683().method_4486() / 2f;
        float centerY = mc.method_22683().method_4502() / 2f;
        float y = centerY + 15f + blockCountOffset.getValue();
        if (blockCountStyle.getValue() == 1) {
            String text = newCount + " Blocks";
            int x = Math.round(centerX - (mc.field_1772.method_1727(text) / 2f));
            event.getContext().method_51433(mc.field_1772, text, x, Math.round(y), getBlockCountColor(newCount), true);
            lastCount = newCount;
            count = newCount;
            return;
        }
        class_1799 displayStack = getHeldBlockStack();
        String countText = String.valueOf(newCount);
        String label = "Blocks";
        float textWidth = mc.field_1772.method_1727(countText) + 3f + mc.field_1772.method_1727(label);
        float x = centerX - (textWidth + (displayStack.method_7960() ? 0f : 22f)) / 2f;
        float baseY = y + 4f;
        if (!displayStack.method_7960()) {
            event.getContext().method_51427(displayStack, Math.round(x), Math.round(baseY));
            x += 18f;
        }
        event.getContext().method_51433(mc.field_1772, label, Math.round(x), Math.round(baseY + 1), getBlockCountColor(newCount), true);
        x += mc.field_1772.method_1727(label) + 3f;
        event.getContext().method_51433(mc.field_1772, countText, Math.round(x), Math.round(baseY + 1), 0xFFFFFFFF, true);
        lastCount = newCount;
        count = newCount;
    }

    private static boolean didHitBlockFace(BlockData blockData, Rotation rot) {
        return blockData == null || !ClientRayTraceUtil.didHitBlockFace(rot, blockData.pos(), blockData.facing(), true);
    }

    /**
     * 由 yaw + 输入(forward/strafe)计算移动方向角(弧度),与 Southside StrafeFix.getDirection 一致。
     */
    private static double getDirection(float yaw, double forward, double strafe) {
        if (forward < 0.0) {
            yaw += 180.0f;
        }
        float f = 1.0f;
        if (forward < 0.0) {
            f = -0.5f;
        } else if (forward > 0.0) {
            f = 0.5f;
        }
        if (strafe > 0.0) {
            yaw -= 90.0f * f;
        }
        if (strafe < 0.0) {
            yaw += 90.0f * f;
        }
        return Math.toRadians(yaw);
    }

    public boolean doesNotContainBlock(int down) {
        return mc.field_1687.method_8320(PlayerUtils.blockRelativeToPlayer(0, -down, 0)).method_26167();
    }

    private boolean isValid(final class_1792 item) {
        return item instanceof class_1747 && !invalidBlocks.contains(((class_1747) item).method_7711()) && SlotUtils.isGoodForBridging(item);
    }

    private int getHotbarBlockSlot() {
        if (blockSlotMode.getValue() == 1) {
            return getMostBlocksHotbarSlot();
        }
        int slot = -1;
        for (int i = 0; i <= 8; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (InventoryUtil.isFullBlock(stack) && isValid(stack.method_7909())) {
                slot = i;
            }
        }
        return slot;
    }

    private int getMostBlocksHotbarSlot() {
        int selectedSlot = mc.field_1724.method_31548().field_7545;
        int bestSlot = -1;
        int bestCount = -1;
        class_1799 selectedStack = mc.field_1724.method_31548().method_5438(selectedSlot);
        if (InventoryUtil.isFullBlock(selectedStack) && isValid(selectedStack.method_7909())) {
            bestSlot = selectedSlot;
            bestCount = selectedStack.method_7947();
        }
        for (int i = 0; i <= 8; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (InventoryUtil.isFullBlock(stack) && isValid(stack.method_7909()) && stack.method_7947() > bestCount) {
                bestSlot = i;
                bestCount = stack.method_7947();
            }
        }
        return bestSlot;
    }

    private class_1799 getHeldBlockStack() {
        if (mc.field_1724 == null) return class_1799.field_8037;
        class_1799 main = mc.field_1724.method_6047();
        if (isDisplayBlock(main)) return main;
        class_1799 offhand = mc.field_1724.method_6079();
        if (isDisplayBlock(offhand)) return offhand;
        return class_1799.field_8037;
    }

    private boolean isDisplayBlock(class_1799 stack) {
        return stack != null && !stack.method_7960() && isValid(stack.method_7909());
    }

    private int getBlockCountColor(int count) {
        if (count < 16) {
            return 0xFFFF5050;
        }
        if (count < 32) {
            return 0xFFFFDC50;
        }
        return 0xFFFFFFFF;
    }

    public int getBlockCountInventory() {
        int blockCount = 0;
        for (int i = 9; i < 45; ++i) {
            if (mc.field_1724 == null) return -1;
            if (mc.field_1724.method_31548().method_5438(i).method_7946()) {
                class_1799 is = mc.field_1724.method_31548().method_5438(i);
                if (is.method_7909() instanceof class_1747 block) {
                    if (isValid(block)) {
                        blockCount += is.method_7947();
                    }
                }
            }
        }
        return blockCount;
    }

    public int getBlockCountHotbar() {
        if (mc.field_1724 == null) return 0;
        int blockCount = 0;
        for (int i = 0; i <= 8; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() instanceof class_1747 blockItem) {
                if (isValid(blockItem)) {
                    blockCount += stack.method_7947();
                }
            }
        }
        class_1799 offhandStack = mc.field_1724.method_6079();
        if (!offhandStack.method_7960() && offhandStack.method_7909() instanceof class_1747 offhandBlock) {
            if (isValid(offhandBlock)) {
                blockCount += offhandStack.method_7947();
            }
        }
        return blockCount;
    }

    private BlockData getBlockData(class_2338 pos) {
        BlockData data;
        if (getPos(pos) == null) {
            class_2338 blockPos = getBlockPos();
            if (blockPos == null) return null;
            class_2350 direction = getPlaceSide(blockPos);
            if (direction == null) return null;
            data = new BlockData(blockPos, direction);
        } else {
            data = getPos(pos);
        }
        if (ClientRayTraceUtil.isIgnoredBlock(mc.field_1687.method_8320(data.pos().method_10093(data.facing())))) {
            return data;
        }
        return null;
    }

    private class_2350 getPlaceSide(class_2338 blockPos) {
        List<BlockData> blockData = new ArrayList<>();
        class_2338 pos = new class_2338((int) Math.floor(mc.field_1724.method_23317()), (int) Math.floor(mc.field_1724.method_23318()), (int) Math.floor(mc.field_1724.method_23321()));

        if (isAirBlock(blockPos.method_10078()) && !blockPos.method_10078().equals(pos)) {
            blockData.add(new BlockData(blockPos.method_10078(), class_2350.field_11034));
        }
        if (isAirBlock(blockPos.method_10095()) && !blockPos.method_10095().equals(pos)) {
            blockData.add(new BlockData(blockPos.method_10095(), class_2350.field_11043));
        }
        if (isAirBlock(blockPos.method_10072()) && !blockPos.method_10072().equals(pos)) {
            blockData.add(new BlockData(blockPos.method_10072(), class_2350.field_11035));
        }
        if (isAirBlock(blockPos.method_10067()) && !blockPos.method_10067().equals(pos)) {
            blockData.add(new BlockData(blockPos.method_10067(), class_2350.field_11039));
        }
        if (blockData.isEmpty()) return null;

        blockData.sort(Comparator.comparingDouble(vec3 -> vec3.pos().method_10262(pos)));
        blockData.removeIf(blockData1 -> !ClientRayTraceUtil.isIgnoredBlock(mc.field_1687.method_8320(blockData1.pos().method_10093(blockData1.facing()))));
        return blockData.getFirst().facing();
    }

    private class_2338 getBlockPos() {
        class_2338 playerPos = new class_2338((int) Math.floor(mc.field_1724.method_23317()), (int) Math.floor(mc.field_1724.method_23318()), (int) Math.floor(mc.field_1724.method_23321()));
        ArrayList<class_2338> positions = new ArrayList<>();
        Map<class_2338, class_2248> searchBlock = searchBlocks(5);
        for (Map.Entry<class_2338, class_2248> block : searchBlock.entrySet()) {
            if (isPosSolid(block.getKey())) {
                positions.add(block.getKey());
            }
        }
        positions.removeIf(pos -> pos.method_10264() >= playerPos.method_10264());
        if (positions.isEmpty()) return null;
        positions.sort(Comparator.comparingDouble(vec3 -> vec3.method_10262(playerPos)));
        return positions.getFirst();
    }

    public boolean isAirBlock(class_2338 blockPos) {
        return ClientRayTraceUtil.isIgnoredBlock(mc.field_1687.method_8320(blockPos));
    }

    public class_2248 getBlock(class_2338 pos) {
        return mc.field_1687.method_8320(pos).method_26204();
    }

    public Map<class_2338, class_2248> searchBlocks(int radius) {
        Map<class_2338, class_2248> blocks = new HashMap<>();
        if (mc.field_1724 == null) {
            return blocks;
        }
        for (int x = radius; x >= -radius + 1; x--) {
            for (int y = radius; y >= -radius + 1; y--) {
                for (int z = radius; z >= -radius + 1; z--) {
                    class_2338 blockPos = new class_2338(mc.field_1724.method_31477() + x, mc.field_1724.method_31478() + y, mc.field_1724.method_31479() + z);
                    class_2248 block = getBlock(blockPos);
                    if (block != null) {
                        blocks.put(blockPos, block);
                    }
                }
            }
        }
        return blocks;
    }

    public BlockData getPos(class_2338 pos) {
        if (isPosSolid(pos.method_10069(-1, 0, 0))) {
            return new BlockData(pos.method_10069(-1, 0, 0), class_2350.field_11034);
        } else if (isPosSolid(pos.method_10069(1, 0, 0))) {
            return new BlockData(pos.method_10069(1, 0, 0), class_2350.field_11039);
        } else if (isPosSolid(pos.method_10069(0, 0, 1))) {
            return new BlockData(pos.method_10069(0, 0, 1), class_2350.field_11043);
        } else if (isPosSolid(pos.method_10069(0, 0, -1))) {
            return new BlockData(pos.method_10069(0, 0, -1), class_2350.field_11035);
        } else if (isPosSolid(pos.method_10069(0, -1, 0))) {
            return new BlockData(pos.method_10069(0, -1, 0), class_2350.field_11036);
        }
        return null;
    }

    public boolean isPosSolid(class_2338 pos) {
        final class_2248 block = mc.field_1687.method_8320(pos).method_26204();
        if (block instanceof class_2533 || block instanceof class_2323 || block instanceof class_2349) {
            return false;
        }
        return !Arrays.asList(
                class_2246.field_10535,
                class_2246.field_10124,
                class_2246.field_10382,
                class_2246.field_10036,
                class_2246.field_10164,
                class_2246.field_10481,
                class_2246.field_10121,
                class_2246.field_10380,
                class_2246.field_10034,
                class_2246.field_10485,
                class_2246.field_10443,
                class_2246.field_9980,
                class_2246.field_10429,
                class_2246.field_10343,
                class_2246.field_10479,
                class_2246.field_10495,
                class_2246.field_10528,
                class_2246.field_10583,
                class_2246.field_9995,
                class_2246.field_42734,
                class_2246.field_10057,
                class_2246.field_10278,
                class_2246.field_10417,
                class_2246.field_22100,
                class_2246.field_42743,
                class_2246.field_10493,
                class_2246.field_10553,
                class_2246.field_10494,
                class_2246.field_22101,
                class_2246.field_10066,
                class_2246.field_10179,
                class_2246.field_10432
        ).contains(block) && !ClientRayTraceUtil.isIgnoredBlock(mc.field_1687.method_8320(pos));
    }

    public int getSlot() {
        if (blockSlot != null && blockSlot.hand() == class_1268.field_5808 && blockSlot.slot() >= 0 && blockSlot.slot() <= 8) {
            return blockSlot.slot();
        }
        return oldSlot;
    }

    private record SlotData(int slot, class_1268 hand) {
        public boolean check() {
            if (mc.field_1724 == null) {
                return false;
            }
            if (hand.equals(class_1268.field_5810)) {
                var stack = mc.field_1724.method_6079();
                return stack.method_7960() || !(stack.method_7909() instanceof class_1747);
            }
            return mc.field_1724.method_31548().method_5438(slot).method_7960() || !(mc.field_1724.method_31548().method_5438(slot).method_7909() instanceof class_1747);
        }
    }
}
