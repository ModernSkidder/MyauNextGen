package laoqi123.module.modules.player;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.*;
import laoqi123.management.RotationState;
import laoqi123.module.Module;
import laoqi123.value.properties.*;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_7923;
import laoqi123.util.MoveUtil;
import java.awt.*;
import java.util.*;

public class AutoBlockIn extends Module {
    private static final class_310 mc = class_310.method_1551();
    private final Map<String, Integer> BLOCK_SCORE = new HashMap<>();
    private long lastPlaceTime = 0;

    public final FloatValue range = new FloatValue("range", 4.5f, 3.0f, 6.0f);
    public final IntValue speed = new IntValue("speed", 20, 5, 100);
    public final IntValue placeDelay = new IntValue("place-delay", 50, 0, 200);
    public final IntValue rotationTolerance = new IntValue("rotation-tolerance", 25, 5, 100);
    public final BooleanValue itemSpoof = new BooleanValue("item-spoof", true);
    public final BooleanValue showProgress = new BooleanValue("show-progress", true);
    public final ModeValue moveFix = new ModeValue("move-fix", 1, new String[]{"NONE", "SILENT", "STRICT"});

    private float serverYaw;
    private float serverPitch;
    private float progress;
    private float aimYaw;
    private float aimPitch;
    private class_2338 targetBlock;
    private class_2350 targetFacing;
    private class_243 targetHitVec;
    private int lastSlot = -1;

    private static final int[][] DIRS = {{1,0,0}, {0,0,1}, {-1,0,0}, {0,0,-1}};
    private static final double INSET = 0.05;
    private static final double STEP = 0.2;
    private static final double JIT = STEP * 0.1;

    public AutoBlockIn() {
        super("AutoBlockIn", false);

        BLOCK_SCORE.put("obsidian", 0);
        BLOCK_SCORE.put("end_stone", 1);
        BLOCK_SCORE.put("planks", 2);
        BLOCK_SCORE.put("log", 2);
        BLOCK_SCORE.put("glass", 3);
        BLOCK_SCORE.put("stained_glass", 3);
        BLOCK_SCORE.put("hardened_clay", 4);
        BLOCK_SCORE.put("stained_hardened_clay", 4);
        BLOCK_SCORE.put("cloth", 5);
    }

    @Override
    public void onEnabled() {
        if (mc.field_1724 != null) {
            serverYaw = mc.field_1724.method_36454();
            serverPitch = mc.field_1724.method_36455();
            aimYaw = serverYaw;
            aimPitch = serverPitch;
            progress = 0;
            lastSlot = mc.field_1724.method_31548().field_7545;
            targetBlock = null;
            targetFacing = null;
            targetHitVec = null;
            lastPlaceTime = 0;
        }
    }

    @Override
    public void onDisabled() {
        if (lastSlot != -1 && mc.field_1724 != null && mc.field_1724.method_31548().field_7545 != lastSlot) {
            mc.field_1724.method_31548().field_7545 = lastSlot;
        }
        progress = 0;
        targetBlock = null;
        targetFacing = null;
        targetHitVec = null;
    }

    @EventTarget(Priority.HIGH)
    public void onUpdate(UpdateEvent event) {
        if (!isEnabled()) return;
        if (event.getType() != EventType.PRE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (mc.field_1755 != null) {
            return;
        }

        serverYaw = event.getYaw();
        serverPitch = event.getPitch();

        updateProgress();

        int blockSlot = findBestBlockSlot();

        if (blockSlot != -1) {
            if (mc.field_1724.method_31548().field_7545 != blockSlot) {
                mc.field_1724.method_31548().field_7545 = blockSlot;
            }
        }

        class_1799 currentHeld = mc.field_1724.method_31548().method_7391();
        boolean holdingBlock = !currentHeld.method_7960() && currentHeld.method_7909() instanceof class_1747;
        if (!holdingBlock) {
            targetBlock = null;
            targetFacing = null;
            targetHitVec = null;
            return;
        }

        findBestPlacement();

        if (targetBlock != null && targetFacing != null && targetHitVec != null) {
            class_243 eyes = mc.field_1724.method_33571();
            double dx = targetHitVec.field_1352 - eyes.field_1352;
            double dy = targetHitVec.field_1351 - eyes.field_1351;
            double dz = targetHitVec.field_1350 - eyes.field_1350;
            double dist = Math.sqrt(dx * dx + dz * dz);

            float targetYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
            float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, dist));

            targetYaw = class_3532.method_15393(targetYaw);

            float yawDiff = class_3532.method_15393(targetYaw - serverYaw);
            float pitchDiff = targetPitch - serverPitch;

            float maxTurn = speed.getValue().floatValue();
            float yawStep = class_3532.method_15363(yawDiff, -maxTurn, maxTurn);
            float pitchStep = class_3532.method_15363(pitchDiff, -maxTurn, maxTurn);

            aimYaw = serverYaw + yawStep;
            aimPitch = class_3532.method_15363(serverPitch + pitchStep, -90.0f, 90.0f);

            event.setRotation(aimYaw, aimPitch, 6);
            event.setPervRotation(this.moveFix.getValue() != 0 ? aimYaw : mc.field_1724.method_36454(), 6);
        }
    }

    @EventTarget
    public void onMove(MoveInputEvent event) {
        if (this.isEnabled()) {
            if (this.moveFix.getValue() == 1
                    && RotationState.isActived()
                    && RotationState.getPriority() == 6
                    && MoveUtil.isForwardPressed()) {
                MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
            }
        }
    }

    @EventTarget(Priority.HIGH)
    public void onTick(TickEvent event) {
        if (!isEnabled()) return;
        if (event.getType() != EventType.PRE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (mc.field_1755 != null) {
            return;
        }

        if (targetBlock != null && targetFacing != null && targetHitVec != null) {
            if (!withinRotationTolerance(aimYaw, aimPitch)) {
                return;
            }

            long currentTime = System.currentTimeMillis();
            if (currentTime - lastPlaceTime >= placeDelay.getValue()) {
                lastPlaceTime = currentTime;

                class_239 mop = rayTraceBlock(aimYaw, aimPitch, range.getValue());

                if (mop != null
                        && mop.method_17783() == class_239.class_240.field_1332
                        && ((class_3965) mop).method_17777().equals(targetBlock)
                        && ((class_3965) mop).method_17780() == targetFacing) {

                    class_1799 heldStack = mc.field_1724.method_31548().method_7391();
                    if (!heldStack.method_7960() && heldStack.method_7909() instanceof class_1747) {
                        mc.field_1761.method_2896(
                                mc.field_1724,
                                class_1268.field_5808,
                                new class_3965(mop.method_17784(), targetFacing, ((class_3965) mop).method_17777(), false));
                        mc.field_1724.method_6104(class_1268.field_5808);

                        targetBlock = null;
                        targetFacing = null;
                        targetHitVec = null;
                    }
                }
            }
        }
    }

    @EventTarget
    public void onSwap(SwapItemEvent event) {
        if (this.isEnabled()) {
            lastSlot = event.setSlot(lastSlot);
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!isEnabled() || mc.field_1755 != null) return;
        if (!showProgress.getValue()) return;

        class_332 context = event.getContext();
        class_327 textRenderer = mc.field_1772;
        String text = String.format("Blocking: %.0f%%", progress * 100.0F);
        int width = textRenderer.method_1727(text);

        Color color = getProgressColor();

        context.method_51433(
                textRenderer,
                text,
                mc.method_22683().method_4486() / 2 - width / 2,
                mc.method_22683().method_4502() / 5 * 2,
                color.getRGB() & 16777215 | -1090519040,
                true
        );
    }

    private int findBestBlockSlot() {
        int bestSlot = -1;
        int bestScore = Integer.MAX_VALUE;

        for (int slot = 0; slot <= 8; slot++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
            if (stack == null || stack.method_7960()) continue;

            if (stack.method_7909() instanceof class_1747) {
                class_2248 block = ((class_1747) stack.method_7909()).method_7711();
                String blockName = class_7923.field_41175.method_10221(block).method_12832();

                Integer score = BLOCK_SCORE.get(blockName);
                if (score == null) {
                    for (Map.Entry<String, Integer> entry : BLOCK_SCORE.entrySet()) {
                        if (blockName.contains(entry.getKey())) {
                            score = entry.getValue();
                            break;
                        }
                    }
                }
                if (score != null && score < bestScore) {
                    bestScore = score;
                    bestSlot = slot;
                    if (score == 0) break;
                }
            }
        }

        return bestSlot;
    }

    private void findBestPlacement() {
        class_243 playerPos = mc.field_1724.method_19538();
        class_2338 feetPos = class_2338.method_49638(playerPos);

        class_243 eye = mc.field_1724.method_33571();
        double reach = range.getValue().doubleValue();
        double reachSq = reach * reach;
        double rp12 = (reach + 1) * (reach + 1);

        class_2338 roofTarget = feetPos.method_10086(2);

        if (!isAir(roofTarget)) {
            sidesAim(eye, reach, feetPos);
            return;
        }

        List<BlockData> supports = new ArrayList<>();

        int minX = (int) Math.floor(eye.field_1352 - reach);
        int maxX = (int) Math.floor(eye.field_1352 + reach);
        int minY = (int) Math.floor(eye.field_1351 - 1);
        int maxY = (int) Math.floor(eye.field_1351 + reach);
        int minZ = (int) Math.floor(eye.field_1350 - reach);
        int maxZ = (int) Math.floor(eye.field_1350 + reach);

        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    class_2338 p = new class_2338(x, y, z);
                    if (isAir(p)) continue;

                    double dx = (x + 0.5) - eye.field_1352;
                    double dy = (y + 0.5) - eye.field_1351;
                    double dz = (z + 0.5) - eye.field_1350;
                    if (dx*dx + dy*dy + dz*dz > rp12) continue;

                    double d2 = dist2PointAABB(eye, x, y, z);
                    if (d2 > reachSq) continue;

                    class_243 mid = new class_243(x + 0.5, y + 0.5, z + 0.5);
                    class_239 mop = mc.field_1687.method_17742(new class_3959(eye, mid, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, mc.field_1724));
                    if (mop == null) continue;
                    if (mop.method_17783() != class_239.class_240.field_1332) continue;
                    class_3965 blockMop = (class_3965) mop;
                    if (!blockMop.method_17777().equals(p)) continue;

                    supports.add(new BlockData(p, d2));
                }
            }
        }
        if (supports.isEmpty()) {
            sidesAim(eye, reach, feetPos);
            return;
        }
        supports.sort(Comparator.comparingDouble(a -> a.distance));
        for (BlockData bd : supports) {
            if (tryPlaceOnBlock(bd.pos, eye, reach, roofTarget)) {
                return;
            }
        }
        Queue<class_2338> q = new LinkedList<>();
        Map<class_2338, class_2338> parent = new HashMap<>();
        Set<class_2338> visited = new HashSet<>();
        for (BlockData bd : supports) {
            class_2338 sup = bd.pos;
            for (class_2350 f : class_2350.values()) {
                class_2338 node = sup.method_10093(f);
                if (!isAir(node)) continue;
                if (visited.contains(node)) continue;
                visited.add(node);
                parent.put(node, null);
                q.add(node);
            }
        }
        class_2338 endNode = null;
        int nodesSeen = 0;
        while (!q.isEmpty() && nodesSeen < 8964) {
            class_2338 cur = q.poll();
            nodesSeen++;
            if (cur.method_10262(roofTarget) <= 1.5) {
                endNode = cur;
                break;
            }
            for (class_2350 f : class_2350.values()) {
                class_2338 nxt = cur.method_10093(f);
                if (visited.contains(nxt)) continue;
                if (!isAir(nxt)) continue;
                visited.add(nxt);
                parent.put(nxt, cur);
                q.add(nxt);
            }
        }

        if (endNode == null) {
            sidesAim(eye, reach, feetPos);
            return;
        }

        List<class_2338> path = new ArrayList<>();
        for (class_2338 cur = endNode; cur != null; cur = parent.get(cur)) {
            path.add(cur);
        }
        Collections.reverse(path);

        for (class_2338 place : path) {
            if (!isAir(place)) continue;

            boolean placedThis = false;
            for (BlockData bd : supports) {
                class_2338 sup = bd.pos;
                if (!isAdjacent(sup, place)) continue;
                if (tryPlaceOnBlock(sup, eye, reach, place)) {
                    return;
                }
            }
            for (class_2350 f : class_2350.values()) {
                class_2338 sup = place.method_10093(f);
                if (isAir(sup)) continue;
                if (tryPlaceOnBlock(sup, eye, reach, place)) {
                    return;
                }
            }
            if (placedThis) break;
        }
        sidesAim(eye, reach, feetPos);
    }

    private boolean isAdjacent(class_2338 a, class_2338 b) {
        int dx = Math.abs(a.method_10263() - b.method_10263());
        int dy = Math.abs(a.method_10264() - b.method_10264());
        int dz = Math.abs(a.method_10260() - b.method_10260());
        return (dx + dy + dz) == 1;
    }


    private boolean tryPlaceOnBlock(class_2338 supportBlock, class_243 eye, double reach, class_2338 targetPos) {
        // Try all 6 faces of support block
        for (class_2350 facing : class_2350.values()) {
            class_2338 placementPos = supportBlock.method_10093(facing);

            // Check if placement would be at target
            if (!placementPos.equals(targetPos)) continue;

            // Generate candidate hit points on this face
            int n = (int) Math.round(1 / STEP);

            for (int r = 0; r <= n; r++) {
                double v = r * STEP + (Math.random() * JIT * 2 - JIT);
                if (v < 0) v = 0; else if (v > 1) v = 1;

                for (int c = 0; c <= n; c++) {
                    double u = c * STEP + (Math.random() * JIT * 2 - JIT);
                    if (u < 0) u = 0; else if (u > 1) u = 1;

                    class_243 hitPos = getHitPosOnFace(supportBlock, facing, u, v);
                    float[] rot = getRotationsWrapped(eye, hitPos.field_1352, hitPos.field_1351, hitPos.field_1350);

                    class_239 mop = rayTraceBlock(rot[0], rot[1], reach);
                    if (mop != null
                            && mop.method_17783() == class_239.class_240.field_1332
                            && ((class_3965) mop).method_17777().equals(supportBlock)
                            && ((class_3965) mop).method_17780() == facing) {

                        targetBlock = supportBlock;
                        targetFacing = facing;
                        targetHitVec = mop.method_17784();
                        aimYaw = rot[0];
                        aimPitch = rot[1];
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private void sidesAim(class_243 eye, double reach, class_2338 feetPos) {
        List<class_2338> goals = new ArrayList<>();

        for (int[] d : DIRS) {
            class_2338 headPos = feetPos.method_10069(d[0], 1, d[2]);
            if (isAir(headPos)) {
                goals.add(headPos);
            }
        }

        for (int[] d : DIRS) {
            class_2338 feetGoal = feetPos.method_10069(d[0], 0, d[2]);
            if (isAir(feetGoal)) {
                goals.add(feetGoal);
            }
        }

        findBestForGoals(goals, eye, reach);
    }

    private void findBestForGoals(List<class_2338> goals, class_243 eye, double reach) {
        for (class_2338 goal : goals) {
            for (class_2350 facing : class_2350.values()) {
                class_2338 support = goal.method_10093(facing);

                if (isAir(support)) continue;

                class_243 center = new class_243(support.method_10263() + 0.5, support.method_10264() + 0.5, support.method_10260() + 0.5);
                if (eye.method_1022(center) > reach) continue;

                // Try placement
                int n = (int) Math.round(1 / STEP);
                for (int r = 0; r <= n; r++) {
                    double v = r * STEP + (Math.random() * JIT * 2 - JIT);
                    if (v < 0) v = 0; else if (v > 1) v = 1;

                    for (int c = 0; c <= n; c++) {
                        double u = c * STEP + (Math.random() * JIT * 2 - JIT);
                        if (u < 0) u = 0; else if (u > 1) u = 1;

                        class_243 hitPos = getHitPosOnFace(support, facing.method_10153(), u, v);
                        float[] rot = getRotationsWrapped(eye, hitPos.field_1352, hitPos.field_1351, hitPos.field_1350);

                        class_239 mop = rayTraceBlock(rot[0], rot[1], reach);
                        if (mop != null
                                && mop.method_17783() == class_239.class_240.field_1332
                                && ((class_3965) mop).method_17777().equals(support)
                                && ((class_3965) mop).method_17780() == facing.method_10153()) {

                            targetBlock = support;
                            targetFacing = facing.method_10153();
                            targetHitVec = mop.method_17784();
                            aimYaw = rot[0];
                            aimPitch = rot[1];
                            return;
                        }
                    }
                }
            }
        }
    }

    private class_243 getHitPosOnFace(class_2338 block, class_2350 face, double u, double v) {
        double x = block.method_10263() + 0.5;
        double y = block.method_10264() + 0.5;
        double z = block.method_10260() + 0.5;

        switch (face) {
            case field_11033:
                y = block.method_10264() + INSET;
                x = block.method_10263() + u;
                z = block.method_10260() + v;
                break;
            case field_11036:
                y = block.method_10264() + 1.0 - INSET;
                x = block.method_10263() + u;
                z = block.method_10260() + v;
                break;
            case field_11043:
                z = block.method_10260() + INSET;
                x = block.method_10263() + u;
                y = block.method_10264() + v;
                break;
            case field_11035:
                z = block.method_10260() + 1.0 - INSET;
                x = block.method_10263() + u;
                y = block.method_10264() + v;
                break;
            case field_11039:
                x = block.method_10263() + INSET;
                z = block.method_10260() + u;
                y = block.method_10264() + v;
                break;
            case field_11034:
                x = block.method_10263() + 1.0 - INSET;
                z = block.method_10260() + u;
                y = block.method_10264() + v;
                break;
        }

        return new class_243(x, y, z);
    }

    private boolean isAir(class_2338 pos) {
        class_2248 block = mc.field_1687.method_8320(pos).method_26204();
        return mc.field_1687.method_22347(pos)
                || block == class_2246.field_10382
                || block == class_2246.field_10164
                || block == class_2246.field_10036;
    }

    private void updateProgress() {
        class_243 playerPos = mc.field_1724.method_19538();
        class_2338 feetPos = class_2338.method_49638(playerPos);

        int filled = 0;
        int total = 9;

        if (!isAir(feetPos.method_10086(2))) {
            filled++;
        }

        for (int[] d : DIRS) {
            if (!isAir(feetPos.method_10069(d[0], 0, d[2]))) {
                filled++;
            }
            if (!isAir(feetPos.method_10069(d[0], 1, d[2]))) {
                filled++;
            }
        }

        progress = (float) filled / (float) total;
    }

    private Color getProgressColor() {
        if (progress <= 0.33f) {
            return new Color(255, 85, 85);
        } else if (progress <= 0.66f) {
            return new Color(255, 255, 85);
        } else {
            return new Color(85, 255, 85);
        }
    }

    private class_239 rayTraceBlock(float yaw, float pitch, double range) {
        float yawRad = (float) Math.toRadians(yaw);
        float pitchRad = (float) Math.toRadians(pitch);

        double x = -Math.sin(yawRad) * Math.cos(pitchRad);
        double y = -Math.sin(pitchRad);
        double z = Math.cos(yawRad) * Math.cos(pitchRad);

        class_243 start = mc.field_1724.method_33571();
        class_243 end = start.method_1031(x * range, y * range, z * range);

        return mc.field_1687.method_17742(new class_3959(start, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, mc.field_1724));
    }

    private boolean withinRotationTolerance(float targetYaw, float targetPitch) {
        float dy = Math.abs(class_3532.method_15393(targetYaw - serverYaw));
        float dp = Math.abs(class_3532.method_15393(targetPitch - serverPitch));
        return dy <= rotationTolerance.getValue() && dp <= rotationTolerance.getValue();
    }

    private double dist2PointAABB(class_243 p, int x, int y, int z) {
        double minX = x, maxX = x + 1;
        double minY = y, maxY = y + 1;
        double minZ = z, maxZ = z + 1;

        double cx = clamp(p.field_1352, minX, maxX);
        double cy = clamp(p.field_1351, minY, maxY);
        double cz = clamp(p.field_1350, minZ, maxZ);

        double dx = p.field_1352 - cx;
        double dy = p.field_1351 - cy;
        double dz = p.field_1350 - cz;

        return dx*dx + dy*dy + dz*dz;
    }

    private double clamp(double v, double lo, double hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private float[] getRotationsWrapped(class_243 eye, double tx, double ty, double tz) {
        double dx = tx - eye.field_1352;
        double dy = ty - eye.field_1351;
        double dz = tz - eye.field_1350;
        double hd = Math.sqrt(dx*dx + dz*dz);

        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        yaw = normYaw(yaw);

        float pitch = (float) Math.toDegrees(-Math.atan2(dy, hd));

        return new float[]{yaw, pitch};
    }

    private float normYaw(float yaw) {
        yaw = ((yaw % 360f) + 360f) % 360f;
        return (yaw > 180f) ? (yaw - 360f) : yaw;
    }

    public int getSlot() {
        return lastSlot;
    }

    private static class BlockData {
        class_2338 pos;
        double distance;

        BlockData(class_2338 pos, double distance) {
            this.pos = pos;
            this.distance = distance;
        }
    }
}
