package laoqi123.module.modules.player;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.TickEvent;
import laoqi123.mixin.ClientPlayerInteractionManagerAccessor;
import laoqi123.module.Module;
import laoqi123.value.properties.IntValue;
import laoqi123.value.properties.PercentValue;
import net.minecraft.class_239;
import net.minecraft.class_310;

public class SpeedMine extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final PercentValue speed = new PercentValue("speed", 15);
    public final IntValue delay = new IntValue("delay", 0, 0, 4);

    public SpeedMine() {
        super("SpeedMine", false);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            if (!mc.field_1761.method_2920().method_8386()) {
                if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1332) {
                    ((ClientPlayerInteractionManagerAccessor) mc.field_1761)
                            .setBlockHitDelay(Math.min(((ClientPlayerInteractionManagerAccessor) mc.field_1761).getBlockHitDelay(), this.delay.getValue() + 1));
                    if (((ClientPlayerInteractionManagerAccessor) mc.field_1761).getIsHittingBlock()) {
                        float curBlockDamageMP = ((ClientPlayerInteractionManagerAccessor) mc.field_1761).getCurBlockDamageMP();
                        float damage = 0.3F * (this.speed.getValue().floatValue() / 100.0F);
                        if (curBlockDamageMP < damage) {
                            ((ClientPlayerInteractionManagerAccessor) mc.field_1761).setCurBlockDamageMP(damage);
                        }
                    }
                }
            }
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{String.format("%d%%", this.speed.getValue())};
    }
}
