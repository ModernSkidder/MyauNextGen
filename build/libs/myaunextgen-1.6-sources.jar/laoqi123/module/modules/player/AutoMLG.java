package laoqi123.module.modules.player;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.TickEvent;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.FloatProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.util.RandomUtil;
import laoqi123.util.RotationUtil;
import laoqi123.util.rotation.Rotation;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3612;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AutoMLG extends Module {
    private static final class_310 mc = class_310.method_1551();
    private final FloatProperty triggerDistanceSetting = new FloatProperty("Fall distance", 3.0F, 1.0F, 10.0F);
    private final IntProperty predictTicksSetting = new IntProperty("Predict Ticks", 2, 1, 5);
    private final BooleanProperty solidCheckSetting = new BooleanProperty("Solid check", true);
    private final BooleanProperty recoverySetting = new BooleanProperty("Recorvey", true);
    public Rotation targetRotation = null;
    private float accumulatedFall;
    private double lastY;
    private Integer slotToRestore;
    private boolean waterPlaced;
    private boolean recoveryActive;
    private int recoveryDelay;
    private int recoveryCountdown;
    private Integer waterBucketSlot;
    private class_2338 placedWaterPos;
    private boolean readyToPlace;
    private int postPlaceCooldown;
    private int postActionCooldown;
    private int extraCooldown;
    private boolean lookActive;
    private int lookStage;
    private boolean pendingUse;
    private boolean pendingPlace;
    private int lookHoldTicks;
    private float lookCurrentYaw;
    private float lookCurrentPitch;
    private float lookTargetYaw;
    private float lookTargetPitch;
    private float lookRestoreYaw;
    private float lookRestorePitch;

    public AutoMLG() {
        super("AutoMLG", false);
    }

    @Override
    public void onEnabled() {
        this.resetState();
        this.accumulatedFall = 0.0F;
        this.lastY = mc.field_1724 != null ? mc.field_1724.method_23318() : 0.0;
    }

    @Override
    public void onDisabled() {
        this.resetState();
        this.accumulatedFall = 0.0F;
    }

    private void resetState() {
        this.slotToRestore = null;
        this.waterPlaced = false;
        this.recoveryActive = false;
        this.recoveryDelay = 0;
        this.recoveryCountdown = 0;
        this.waterBucketSlot = null;
        this.placedWaterPos = null;
        this.readyToPlace = false;
        this.postPlaceCooldown = 0;
        this.postActionCooldown = 0;
        this.extraCooldown = 0;
        this.lookActive = false;
        this.lookStage = 0;
        this.pendingUse = false;
        this.pendingPlace = false;
        this.lookHoldTicks = 0;
    }

    public boolean isInCooldown() {
        return this.postPlaceCooldown > 0;
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (event.getType() != EventType.PRE) {
            return;
        }
        if (this.lookActive) {
            this.tickLook();
            if (this.lookActive) {
                return;
            }
        }
        if (this.pendingUse) {
            this.doUseItemNow();
            return;
        }
        double deltaY;
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        if (mc.field_1724.method_6128()) {
            return;
        }
        if (mc.field_1724.method_24828() || mc.field_1724.method_31549().field_7479 || mc.field_1724.method_5799() || mc.field_1724.method_5721() || mc.field_1724.method_5771()) {
            this.accumulatedFall = 0.0F;
        } else {
            deltaY = mc.field_1724.method_23318() - this.lastY;
            if (deltaY < 0.0) {
                this.accumulatedFall -= (float) deltaY;
            }
        }
        this.lastY = mc.field_1724.method_23318();
        if (this.postPlaceCooldown > 0) {
            --this.postPlaceCooldown;
        }
        if (this.postActionCooldown > 0) {
            --this.postActionCooldown;
        }
        if (this.extraCooldown > 0) {
            --this.extraCooldown;
        }
        if (this.slotToRestore != null) {
            mc.field_1724.method_31548().field_7545 = this.slotToRestore;
            this.slotToRestore = null;
        }
        if (mc.field_1724.method_24828() || this.accumulatedFall <= 0.0F) {
            this.waterPlaced = false;
            this.readyToPlace = false;
        }
        if (this.recoveryActive) {
            if (this.recoveryDelay > 0) {
                --this.recoveryDelay;
                return;
            }
            if (this.recoveryCountdown-- <= 0) {
                this.recoveryActive = false;
                return;
            }
            if (this.waterBucketSlot == null) {
                this.waterBucketSlot = this.findItemInHotbar(class_1802.field_8550);
                if (this.waterBucketSlot == null) {
                    this.recoveryActive = false;
                    return;
                }
            }
            if (mc.field_1724.method_31548().method_5438(this.waterBucketSlot).method_7909() == class_1802.field_8705) {
                this.recoveryActive = false;
                this.waterBucketSlot = null;
                this.placedWaterPos = null;
                this.postPlaceCooldown = Math.max(this.postPlaceCooldown, 1);
                return;
            }
            if (this.placedWaterPos == null || !this.isWaterSource(this.placedWaterPos)) {
                this.recoveryActive = false;
                this.waterBucketSlot = null;
                this.placedWaterPos = null;
                return;
            }
            Rotation recoveryRotation = this.rotationToBlock(this.placedWaterPos);
            class_3965 recoveryHit = this.raycastFluid(recoveryRotation, 4.5);
            if (recoveryHit.method_17783() == class_239.class_240.field_1333 || !recoveryHit.method_17777().equals(this.placedWaterPos)) {
                this.recoveryActive = false;
                this.waterBucketSlot = null;
                this.placedWaterPos = null;
                return;
            }
            this.setTargetRotation(recoveryRotation);
            this.selectSlot(this.waterBucketSlot);
            this.useItem(recoveryRotation);
            return;
        }
        if (!this.waterPlaced
                && !this.recoveryActive
                && this.placedWaterPos == null
                && this.postPlaceCooldown == 0
                && this.postActionCooldown == 0
                && this.accumulatedFall <= 0.5F
                && this.findItemInHotbar(class_1802.field_8705) < 0) {
            int slot = this.findItemInHotbar(class_1802.field_8550);
            if (slot >= 0) {
                class_2338 bucketPos = this.findBucketPos();
                if (bucketPos != null) {
                    Rotation rotation = this.rotationToBlock(bucketPos);
                    class_3965 hit = this.raycastFluid(rotation, 4.5);
                    if (hit.method_17783() != class_239.class_240.field_1333 && hit.method_17777().equals(bucketPos)) {
                        this.setTargetRotation(rotation);
                        this.selectSlot(slot);
                        this.useItem(rotation);
                        this.postActionCooldown = 8;
                        this.postPlaceCooldown = Math.max(this.postPlaceCooldown, 1);
                        return;
                    }
                }
            }
        }
        if (this.waterPlaced && !this.readyToPlace && mc.field_1724.method_18798().field_1351 < 0.0) {
            deltaY = this.distanceToGround(2.5);
            if (deltaY > 0.0 && deltaY <= 1.05) {
                this.readyToPlace = true;
            }
        }
        if (this.waterPlaced || this.pendingPlace) {
            return;
        }
        if (this.accumulatedFall < (float) this.triggerDistanceSetting.getValue()) {
            return;
        }
        int slot = this.findItemInHotbar(class_1802.field_8705);
        if (slot < 0) {
            return;
        }
        int ticksLeft = this.ticksUntilGround();
        if (ticksLeft <= (int) this.predictTicksSetting.getValue() + this.getLookDownTicks()) {
            if ((boolean) this.solidCheckSetting.getValue() && !this.hasSolidBelow(class_2338.method_49637(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()))) {
                return;
            }
            Rotation rotation = new Rotation(mc.field_1724.method_36454(), 90.0F);
            class_3965 hit = this.raycastSolid(rotation, 5.0);
            if (hit.method_17783() == class_239.class_240.field_1333) {
                return;
            }
            this.placeWaterBucket(slot, true);
        }
    }

    private int getLookDownTicks() {
        float pitchDiff = 90.0F - mc.field_1724.method_36455();
        if (pitchDiff < 0.0F) {
            pitchDiff = 0.0F;
        }
        int lookTicks = (int) Math.ceil((double) (pitchDiff / 30.0F));
        return lookTicks + 1;
    }

    private int ticksUntilGround() {
        if (mc.field_1724.method_18798().field_1351 >= 0.0) {
            return 999;
        }
        double distance = this.distanceToGround(30.0);
        if (distance == Double.POSITIVE_INFINITY) {
            return 999;
        }
        double simulatedDrop = 0.0;
        double simulatedVelocity = mc.field_1724.method_18798().field_1351;
        for (int i = 1; i <= 20; ++i) {
            simulatedDrop += simulatedVelocity;
            simulatedVelocity = (simulatedVelocity - 0.08) * 0.98;
            if (Math.abs(simulatedDrop) >= distance) {
                return i;
            }
        }
        return 999;
    }

    private void useItem(Rotation rotation) {
        if (mc.field_1761 == null || mc.field_1724 == null) {
            return;
        }
        if (rotation == null) {
            return;
        }
        this.lookCurrentYaw = mc.field_1724.method_36454();
        this.lookCurrentPitch = mc.field_1724.method_36455();
        this.lookRestoreYaw = this.lookCurrentYaw;
        this.lookRestorePitch = this.lookCurrentPitch;
        this.lookTargetYaw = rotation.getYaw() + RandomUtil.nextFloat(-3.0F, 3.0F);
        this.lookTargetPitch = Math.clamp(rotation.getPitch() + RandomUtil.nextFloat(-2.0F, 2.0F), -90.0F, 90.0F);
        this.lookStage = 1;
        this.lookHoldTicks = RandomUtil.nextInt(0, 2);
        this.pendingUse = true;
        this.lookActive = true;
    }

    private void tickLook() {
        if (mc.field_1724.method_36454() != this.lookCurrentYaw || mc.field_1724.method_36455() != this.lookCurrentPitch) {
            this.lookActive = false;
            this.lookStage = 0;
            this.pendingUse = false;
            return;
        }
        if (this.lookStage == 1) {
            if (this.moveLookTowards(this.lookTargetYaw, this.lookTargetPitch)) {
                if (this.pendingUse) {
                    this.pendingUse = false;
                    this.doUseItemNow();
                }
                this.lookStage = 2;
            }
        } else if (this.lookStage == 2) {
            if (--this.lookHoldTicks <= 0) {
                this.lookStage = 3;
            }
        } else if (this.lookStage == 3) {
            if (this.moveLookTowards(this.lookRestoreYaw, this.lookRestorePitch)) {
                this.lookActive = false;
                this.lookStage = 0;
            }
        }
    }

    private boolean moveLookTowards(float targetYaw, float targetPitch) {
        float step = RandomUtil.nextFloat(30.0F, 42.0F);
        float yawDiff = class_3532.method_15393(targetYaw - this.lookCurrentYaw);
        float pitchDiff = targetPitch - this.lookCurrentPitch;
        boolean reached = Math.abs(yawDiff) <= step && Math.abs(pitchDiff) <= step;
        if (reached) {
            this.lookCurrentYaw = targetYaw;
            this.lookCurrentPitch = targetPitch;
        } else {
            this.lookCurrentYaw += Math.clamp(yawDiff, -step, step);
            this.lookCurrentPitch += Math.clamp(pitchDiff, -step, step);
        }
        mc.field_1724.method_36456(this.lookCurrentYaw);
        mc.field_1724.method_36457(this.lookCurrentPitch);
        return reached;
    }

    private void doUseItemNow() {
        if (mc.field_1761 != null && mc.field_1724 != null) {
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
        if (this.slotToRestore != null) {
            mc.field_1724.method_31548().field_7545 = this.slotToRestore;
            this.slotToRestore = null;
        }
        if (this.pendingPlace) {
            this.pendingPlace = false;
            this.waterPlaced = true;
            this.recoveryActive = (boolean) this.recoverySetting.getValue();
            this.recoveryDelay = 3;
            this.recoveryCountdown = this.recoveryActive ? 2 : 0;
            this.waterBucketSlot = null;
        }
    }

    private class_2338 findBucketPos() {
        class_2338 playerPos = class_2338.method_49637(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        class_2338 closestPos = null;
        double closestDistSq = Double.POSITIVE_INFINITY;
        for (int dy = -1; dy <= 1; ++dy) {
            for (int dx = -4; dx <= 4; ++dx) {
                for (int dz = -4; dz <= 4; ++dz) {
                    class_2338 candidatePos = playerPos.method_10069(dx, dy, dz);
                    if (!this.isWaterSource(candidatePos)) {
                        continue;
                    }
                    double distSq = mc.field_1724.method_19538().method_1028(
                            (double) candidatePos.method_10263() + 0.5, (double) candidatePos.method_10264() + 0.5, (double) candidatePos.method_10260() + 0.5
                    );
                    if (distSq >= closestDistSq) {
                        continue;
                    }
                    Rotation rotation = this.rotationToBlock(candidatePos);
                    class_3965 hit = this.raycastFluid(rotation, 4.5);
                    if (hit.method_17783() == class_239.class_240.field_1333 || !hit.method_17777().equals(candidatePos)) {
                        continue;
                    }
                    closestPos = candidatePos;
                    closestDistSq = distSq;
                }
            }
        }
        return closestPos;
    }

    private void setTargetRotation(Rotation rotation) {
        this.targetRotation = rotation;
    }

    private void selectSlot(int slot) {
        this.slotToRestore = mc.field_1724.method_31548().field_7545;
        mc.field_1724.method_31548().field_7545 = slot;
    }

    private void placeWaterBucket(int slot, boolean markPlaced) {
        Rotation rotation = new Rotation(mc.field_1724.method_36454(), 90.0F);
        this.setTargetRotation(rotation);
        this.selectSlot(slot);
        this.pendingPlace = markPlaced;
        this.useItem(rotation);
        this.placedWaterPos = this.getPlacementBlockPos(rotation);
        this.lookStage = 1;
        this.lookActive = true;
    }

    private class_2338 getPlacementBlockPos(Rotation rotation) {
        class_3965 hit = this.raycastSolid(rotation, 4.5);
        if (hit.method_17783() == class_239.class_240.field_1333) {
            return null;
        }
        return hit.method_17777().method_10093(hit.method_17780());
    }

    private class_3965 raycastSolid(Rotation rotation, double range) {
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 direction = RotationUtil.getVectorForRotation(rotation.getPitch(), rotation.getYaw());
        class_243 endPos = eyePos.method_1019(direction.method_1021(range));
        return mc.field_1687.method_17742(new class_3959(eyePos, endPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, mc.field_1724));
    }

    private class_3965 raycastFluid(Rotation rotation, double range) {
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 direction = RotationUtil.getVectorForRotation(rotation.getPitch(), rotation.getYaw());
        class_243 endPos = eyePos.method_1019(direction.method_1021(range));
        return mc.field_1687.method_17742(new class_3959(eyePos, endPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1345, mc.field_1724));
    }

    private boolean isWaterSource(class_2338 blockPos) {
        net.minecraft.class_3610 fluidState = mc.field_1687.method_8316(blockPos);
        return fluidState.method_15772() == class_3612.field_15910 && fluidState.method_15771();
    }

    private boolean hasSolidBelow(class_2338 blockPos) {
        return this.isSolidNonMenu(blockPos.method_10074()) || this.isSolidNonMenu(blockPos.method_10087(2));
    }

    private boolean isSolidNonMenu(class_2338 blockPos) {
        net.minecraft.class_2680 blockState = mc.field_1687.method_8320(blockPos);
        boolean hasCollision = !blockState.method_26220(mc.field_1687, blockPos).method_1110();
        boolean noMenu = blockState.method_26196(mc.field_1687, blockPos) == null;
        return hasCollision && noMenu;
    }

    private double distanceToGround(double maxDist) {
        class_243 startPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_5829().field_1322, mc.field_1724.method_23321());
        class_243 endPos = startPos.method_1031(0.0, -maxDist, 0.0);
        class_3965 hit = mc.field_1687.method_17742(new class_3959(startPos, endPos, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, mc.field_1724));
        if (hit.method_17783() == class_239.class_240.field_1333) {
            return Double.POSITIVE_INFINITY;
        }
        return startPos.field_1351 - hit.method_17784().field_1351;
    }

    private int findItemInHotbar(class_1792 item) {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == item) {
                return i;
            }
        }
        return -1;
    }

    private Rotation rotationToBlock(class_2338 blockPos) {
        float[] rotations = RotationUtil.getRotationsTo(
                (double) blockPos.method_10263() + 0.5 - mc.field_1724.method_23317(),
                (double) blockPos.method_10264() + 0.5 - mc.field_1724.method_23318() - (double) mc.field_1724.method_5751(),
                (double) blockPos.method_10260() + 0.5 - mc.field_1724.method_23321(),
                mc.field_1724.method_36454(), mc.field_1724.method_36455()
        );
        return new Rotation(rotations[0], rotations[1]);
    }
}