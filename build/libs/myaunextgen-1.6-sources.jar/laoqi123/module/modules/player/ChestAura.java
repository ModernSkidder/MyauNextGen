package laoqi123.module.modules.player;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.LoadWorldEvent;
import laoqi123.events.MoveInputEvent;
import laoqi123.events.PacketEvent;
import laoqi123.events.UpdateEvent;
import laoqi123.module.Module;
import laoqi123.module.modules.combat.KillAura;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.FloatProperty;
import laoqi123.property.properties.ModeProperty;
import laoqi123.util.BlockUtil;
import laoqi123.util.MoveUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2623;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ChestAura extends Module {
    private static final class_310 mc = class_310.method_1551();
    private static final DecimalFormat df = new DecimalFormat("0.0");

    public final FloatProperty range = new FloatProperty("Range", 4.0f, 1.0f, 6.0f);
    public final BooleanProperty throughWalls = new BooleanProperty("Through Walls", true);
    public final ModeProperty moveFix = new ModeProperty("Move Fix", 1, new String[]{"None", "Silent", "Strict"});

    private final List<class_2338> openedChests = new ArrayList<>();
    private class_2595 targetChest;
    private float[] rotations;
    private boolean isRotating;
    private boolean scaffoldWasEnabled = false;

    public ChestAura() {
        super("ChestAura", false);
    }

    @Override
    public void onEnabled() {
        Scaffold scaffold = (Scaffold) Myau.moduleManager.getModule(Scaffold.class);
        if (scaffold != null && scaffold.isEnabled()) {
            scaffoldWasEnabled = true;
            scaffold.setEnabled(false);
        }
        openedChests.clear();
    }

    @Override
    public void onDisabled() {
        if (scaffoldWasEnabled) {
            Scaffold scaffold = (Scaffold) Myau.moduleManager.getModule(Scaffold.class);
            if (scaffold != null) {
                scaffold.setEnabled(true);
            }
            scaffoldWasEnabled = false;
        }
        targetChest = null;
        isRotating = false;
    }

    @EventTarget
    public void onWorldLoad(LoadWorldEvent event) {
        openedChests.clear();
        scaffoldWasEnabled = false;
    }

    private void addOpenedChest(class_2338 pos) {
        if (!openedChests.contains(pos)) {
            openedChests.add(pos);
        }
        class_2248 block = mc.field_1687.method_8320(pos).method_26204();
        if (block instanceof class_2281) {
            for (class_2350 facing : new class_2350[]{class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039}) {
                class_2338 neighbor = pos.method_10093(facing);
                if (mc.field_1687.method_8320(neighbor).method_26204() == block) {
                    if (!openedChests.contains(neighbor)) {
                        openedChests.add(neighbor);
                    }
                }
            }
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{df.format(range.getValue())};
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (!isEnabled()) return;
        if (event.getPacket() instanceof class_2623) {
            class_2623 packet = (class_2623) event.getPacket();
            if (packet.method_11296() == 1) {
                addOpenedChest(packet.method_11298());
            }
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (!isEnabled()) return;
        if (event.getType() != EventType.PRE) return;

        KillAura killAura = (KillAura) Myau.moduleManager.getModule(KillAura.class);
        if (killAura != null && killAura.isEnabled() && killAura.getTarget() != null) {
            targetChest = null;
            isRotating = false;
            return;
        }

        if (mc.field_1755 instanceof class_465) {
            targetChest = null;
            isRotating = false;
            return;
        }

        for (class_2586 blockEntity : BlockUtil.getBlockEntities()) {
            if (blockEntity instanceof class_2595) {
                class_2595 chest = (class_2595) blockEntity;
                if (class_2595.method_11048(mc.field_1687, chest.method_11016()) > 0) {
                    addOpenedChest(chest.method_11016());
                }
            }
        }

        targetChest = getClosestChest();
        isRotating = false;

        if (targetChest != null) {
            double x = targetChest.method_11016().method_10263() + 0.5 - mc.field_1724.method_23317();
            double y = targetChest.method_11016().method_10264() + 0.5 - mc.field_1724.method_23318() - mc.field_1724.method_5751();
            double z = targetChest.method_11016().method_10260() + 0.5 - mc.field_1724.method_23321();
            double dist = Math.sqrt(x * x + z * z);

            float yaw = (float) (Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
            float pitch = (float) -(Math.atan2(y, dist) * 180.0 / Math.PI);

            rotations = new float[]{yaw, pitch};

            event.setRotation(rotations[0], rotations[1], 1);
            mc.field_1724.method_5847(rotations[0]);
            mc.field_1724.method_5636(rotations[0]);
            isRotating = true;

            if (this.moveFix.getValue() != 0) {
                event.setPervRotation(rotations[0], 1);
            }

            class_2338 pos = targetChest.method_11016();
            class_1269 result = mc.field_1761.method_2896(
                    mc.field_1724,
                    class_1268.field_5808,
                    new class_3965(
                            new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260()),
                            class_2350.field_11036,
                            pos,
                            false
                    )
            );
            if (result != class_1269.field_5811) {
                mc.field_1724.method_6104(class_1268.field_5808);
                addOpenedChest(pos);
            }
        }
    }

    @EventTarget
    public void onMove(MoveInputEvent event) {
        if (!isEnabled()) return;

        KillAura killAura = (KillAura) Myau.moduleManager.getModule(KillAura.class);
        if (killAura != null && killAura.isEnabled() && killAura.getTarget() != null) return;

        if (isRotating && targetChest != null) {
            if (this.moveFix.getValue() == 1 && MoveUtil.isForwardPressed()) {
                MoveUtil.fixStrafe(rotations[0]);
            }
        }
    }

    private class_2595 getClosestChest() {
        List<class_2595> chests = StreamSupport.stream(BlockUtil.getBlockEntities().spliterator(), false)
                .filter(e -> e instanceof class_2595)
                .map(e -> (class_2595) e)
                .filter(e -> !openedChests.contains(e.method_11016()))
                .filter(e -> mc.field_1724.method_5649(
                        e.method_11016().method_10263() + 0.5,
                        e.method_11016().method_10264() + 0.5,
                        e.method_11016().method_10260() + 0.5) <= range.getValue() * range.getValue())
                .filter(e -> throughWalls.getValue() || mc.field_1724.method_6057(
                        new class_1542(mc.field_1687, e.method_11016().method_10263(), e.method_11016().method_10264(), e.method_11016().method_10260(), new class_1799(class_1802.field_8600))))
                .sorted(Comparator.comparingDouble(e -> mc.field_1724.method_5649(
                        e.method_11016().method_10263() + 0.5,
                        e.method_11016().method_10264() + 0.5,
                        e.method_11016().method_10260() + 0.5)))
                .collect(Collectors.toList());

        return chests.isEmpty() ? null : chests.get(0);
    }
}
