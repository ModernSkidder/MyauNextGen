package laoqi123.module.modules.player;

import laoqi123.Myau;
import laoqi123.enums.BlinkModules;
import laoqi123.event.EventManager;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.*;
import laoqi123.module.Module;
import laoqi123.value.properties.FloatValue;
import net.minecraft.class_10185;
import net.minecraft.class_310;
import laoqi123.util.KeyBindUtil;

public class Timer extends Module {
    private static final class_310 mc = class_310.method_1551();

    private static final long cooldown = 100;
    private static long lastTime = 0;

    public final FloatValue speed = new FloatValue("Speed", 1.0F, 0.0F, 10.0F);

    private boolean lastTimerKeyPressed = false;
    private double savedMotionX;
    private double savedMotionY;
    private double savedMotionZ;

    public Timer() {
        super("Timer", false);
    }

    public static boolean canToggle() {
        return System.currentTimeMillis() - lastTime > cooldown;
    }

    @Override
    public void onEnabled() {
        if (mc.field_1724 != null) {
            savedMotionX = mc.field_1724.method_18798().field_1352;
            savedMotionY = mc.field_1724.method_18798().field_1351;
            savedMotionZ = mc.field_1724.method_18798().field_1350;
        }
        lastTimerKeyPressed = true;

        if (speed.getValue() == 0.0F) {
            Myau.blinkManager.setBlinkState(true, BlinkModules.BLINK);
        }
    }

    @Override
    public void onDisabled() {
        lastTime = System.currentTimeMillis();

        if (speed.getValue() == 0.0F) {
            Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
            if (mc.field_1724 != null) {
                mc.field_1724.method_18800(savedMotionX, savedMotionY, savedMotionZ);
            }
        }
    }

    @EventTarget(Priority.HIGHEST)
    public void onUpdate(UpdateEvent event) {
        if (!isEnabled() || event.getType() != EventType.PRE) {
            return;
        }

        if (speed.getValue() == 0.0F) {
            return;
        }
    }

    @EventTarget
    public void onLivingUpdate(LivingUpdateEvent event) {
        if (!isEnabled()) return;

        if (speed.getValue() == 0.0F) {
            mc.field_1724.method_18800(0.0, 0.0, 0.0);
        }
    }

    @EventTarget
    public void onStrafe(StrafeEvent event) {
        if (!isEnabled()) return;

        if (speed.getValue() == 0.0F) {
            event.setForward(0.0f);
            event.setStrafe(0.0f);
        }
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (!isEnabled()) return;

        if (speed.getValue() == 0.0F) {
            mc.field_1724.field_3913.field_3905 = 0.0f;
            mc.field_1724.field_3913.field_3907 = 0.0f;
            class_10185 playerInput = mc.field_1724.field_3913.field_54155;
            mc.field_1724.field_3913.field_54155 = new class_10185(playerInput.comp_3159(), playerInput.comp_3160(), playerInput.comp_3161(), playerInput.comp_3162(), false, false, playerInput.comp_3165());
        }
    }

    @EventTarget(Priority.HIGHEST)
    public void onRender3D(Render3DEvent event) {
        if (!isEnabled() || speed.getValue() != 0.0F) {
            return;
        }

        int timerKey = getKey();
        boolean timerKeyPressed = timerKey != 0 && KeyBindUtil.isKeyDown(timerKey);

        if (timerKeyPressed && !lastTimerKeyPressed && canToggle()) {
            EventManager.call(new KeyEvent(timerKey));
        }
        lastTimerKeyPressed = timerKeyPressed;

        EventManager.call(new TickEvent(EventType.PRE));

        if (mc.field_1724 != null && mc.field_1687 != null) {
            UpdateEvent preEvent = new UpdateEvent(
                    EventType.PRE,
                    mc.field_1724.method_36454(),
                    mc.field_1724.method_36455(),
                    mc.field_1724.method_36454(),
                    mc.field_1724.method_36455()
            );
            EventManager.call(preEvent);

            EventManager.call(new UpdateEvent(
                    EventType.POST,
                    mc.field_1724.method_36454(),
                    mc.field_1724.method_36455(),
                    mc.field_1724.method_36454(),
                    mc.field_1724.method_36455()
            ));
        }

        EventManager.call(new TickEvent(EventType.POST));
    }

    @Override
    public String[] getSuffix() {
        return new String[]{String.format("%.1fx", speed.getValue())};
    }
}
