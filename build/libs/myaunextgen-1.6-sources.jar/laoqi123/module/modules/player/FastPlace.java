package laoqi123.module.modules.player;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.TickEvent;
import laoqi123.mixin.MinecraftClientAccessor;
import laoqi123.module.Module;
import laoqi123.util.BlockUtil;
import laoqi123.util.RotationUtil;
import laoqi123.value.properties.BooleanValue;
import laoqi123.value.properties.FloatValue;
import net.minecraft.class_1747;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class FastPlace extends Module {
    private static final class_310 mc = class_310.method_1551();
    private static final DecimalFormat df = new DecimalFormat("0.0#", new DecimalFormatSymbols(Locale.US));
    private long delayMS = 0L;
    public final FloatValue delay = new FloatValue("delay", 1.0F, 1.0F, 3.0F);
    public final BooleanValue blocksOnly = new BooleanValue("blocks-only", true);
    public final BooleanValue placeFix = new BooleanValue("place-fix", true);
    public final BooleanValue skipObsidian = new BooleanValue("skip-obsidian", true);
    public final BooleanValue skipInteractable = new BooleanValue("skip-interactable", true);

    private boolean canPlace() {
        class_1799 stack = mc.field_1724.method_6047();
        if (stack != null) {
            class_1792 item = stack.method_7909();
            if (item instanceof class_1787) {
                return false;
            }
            if (item instanceof class_1747) {
                class_2248 block = ((class_1747) item).method_7711();
                if (skipObsidian.getValue() && block == class_2246.field_10540) {
                    return false;
                }
                if (skipInteractable.getValue() && BlockUtil.isInteractable(block)) {
                    return false;
                }
                if (!(Boolean) this.placeFix.getValue()) {
                    return true;
                }
                class_239 mop = RotationUtil.rayTrace(
                        mc.field_1724.method_36454(), mc.field_1724.method_36455(), mc.field_1724.method_55754(), 1.0F
                );
                if (mop != null && mop.method_17783() == class_239.class_240.field_1332) {
                    class_3965 blockHit = (class_3965) mop;
                    class_2680 state = block.method_9564();
                    class_2338 placePos = blockHit.method_17777().method_10093(blockHit.method_17780());
                    return mc.field_1687.method_8628(state, placePos, class_3726.method_16195(mc.field_1724)) && state.method_26184(mc.field_1687, placePos);
                }
                return false;
            }
        }
        return !(Boolean) this.blocksOnly.getValue();
    }

    public FastPlace() {
        super("FastPlace", false);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            int rightClickDelayTimer = ((MinecraftClientAccessor) mc).getRightClickDelayTimer();
            if (rightClickDelayTimer == 4) {
                this.delayMS = this.delayMS + (long) (50.0F * this.delay.getValue());
            }
            if (this.delayMS > 0L) {
                this.delayMS = this.delayMS - 50;
            }
            if (this.delayMS <= 0L && rightClickDelayTimer > 1 && this.canPlace()) {
                ((MinecraftClientAccessor) mc).setRightClickDelayTimer(0);
            }
        }
    }

    @Override
    public void onDisabled() {
        this.delayMS = 0L;
    }

    @Override
    public String[] getSuffix() {
        return new String[]{df.format(this.delay.getValue())};
    }
}
