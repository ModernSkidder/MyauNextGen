package laoqi123.module.modules.player;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.TickEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.BooleanValue;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import java.util.Arrays;
import java.util.List;

public class AutoSwap extends Module {
    private static final class_310 mc = class_310.method_1551();
    
    private class_1792 lastItem;
    private int lastSlot = -1;

    public final BooleanValue blocks = new BooleanValue("blocks", true);
    public final BooleanValue projectiles = new BooleanValue("projectiles", true);
    public final BooleanValue pearls = new BooleanValue("pearls", true);
    public final BooleanValue swords = new BooleanValue("swords", true);
    public final BooleanValue tools = new BooleanValue("tools", true);
    public final BooleanValue resources = new BooleanValue("resources", true);

    private final List<String> ALLOWED_BLOCKS = Arrays.asList("stone", "grass", "dirt", "planks", "wool", "wood", "glass", "leaves", "clay", "cloth", "cobblestone", "sand", "gravel", "netherrack");
    private final List<String> PROJECTILES = Arrays.asList("egg", "snowball", "ender_pearl", "fireball");
    private final List<String> PEARLS = Arrays.asList("pearl", "ender_pearl");
    private final List<String> SWORDS = Arrays.asList("sword", "axe");
    private final List<String> TOOLS = Arrays.asList("rod", "pickaxe", "axe", "shovel", "hoe", "flint_and_steel");
    private final List<String> RESOURCES = Arrays.asList("265", "266", "388", "264", "diamond", "gold", "iron", "emerald");

    public AutoSwap() {
        super("AutoSwap", false);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) {
            return;
        }

        if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }

        if (mc.field_1755 != null) {
            return;
        }

        int slot = mc.field_1724.method_31548().field_7545;
        class_1799 held = mc.field_1724.method_31548().method_5438(slot);

        if (this.lastItem != null && slot == this.lastSlot && (held == null || held.method_7947() < 1)) {
            this.swapItem(this.lastItem);
        }

        this.lastItem = held != null ? held.method_7909() : null;
        this.lastSlot = slot;
    }

    private void swapItem(class_1792 lastItem) {
        if (lastItem == null) {
            return;
        }

        String lastId = lastItem.method_7876().toLowerCase();
        boolean isBlock = lastItem instanceof class_1747;
        int current = mc.field_1724.method_31548().field_7545;
        List<String> category = null;

        if (!isBlock) {
            if (this.projectiles.getValue() && containsAny(lastId, PROJECTILES) && !lastId.contains("leggings")) {
                category = PROJECTILES;
            } else if (this.pearls.getValue() && containsAny(lastId, PEARLS)) {
                category = PEARLS;
            } else if (this.swords.getValue() && containsAny(lastId, SWORDS)) {
                category = SWORDS;
            } else if (this.tools.getValue() && containsAny(lastId, TOOLS)) {
                category = TOOLS;
            } else if (this.resources.getValue() && containsAny(lastId, RESOURCES)) {
                category = RESOURCES;
            }
        }

        // Loop through hotbar to find replacement
        for (int offset = 1; offset <= 9; ++offset) {
            int i = (current + offset) % 9;
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);

            if (stack != null && stack.method_7947() >= 1) {
                class_1792 item = stack.method_7909();
                String id = item.method_7876().toLowerCase();

                // Check if it's the same item
                if (item == lastItem) {
                    mc.field_1724.method_31548().field_7545 = i;
                    return;
                }

                // Check for blocks
                if (isBlock && this.blocks.getValue() && isValidBlock(stack)) {
                    mc.field_1724.method_31548().field_7545 = i;
                    return;
                }

                // Check for category matches
                if (category != null) {
                    if (containsAny(id, category) && !id.contains("leggings")) {
                        mc.field_1724.method_31548().field_7545 = i;
                        return;
                    }
                }
            }
        }
    }

    private boolean isValidBlock(class_1799 stack) {
        if (!this.blocks.getValue()) {
            return false;
        }

        if (!(stack.method_7909() instanceof class_1747)) {
            return false;
        }

        String id = stack.method_7909().method_7876().toLowerCase();
        return containsAny(id, ALLOWED_BLOCKS);
    }

    private boolean containsAny(String str, List<String> items) {
        for (String item : items) {
            if (str.contains(item)) {
                return true;
            }
        }
        return false;
    }
}
