package laoqi123.module.modules.player;

import laoqi123.module.Module;
import laoqi123.util.ItemUtil;
import laoqi123.util.TeamUtil;
import laoqi123.value.properties.BooleanValue;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public class GhostHand extends Module {
    public final BooleanValue teamsOnly = new BooleanValue("team-only", true);
    public final BooleanValue ignoreWeapons = new BooleanValue("ignore-weapons", false);

    public GhostHand() {
        super("GhostHand", false);
    }

    public boolean shouldSkip(class_1297 entity) {
        return entity instanceof class_1657
                && !TeamUtil.isBot((class_1657) entity)
                && (!this.teamsOnly.getValue() || TeamUtil.isSameTeam((class_1657) entity))
                && (!this.ignoreWeapons.getValue() || !ItemUtil.hasRawUnbreakingEnchant());
    }
}
