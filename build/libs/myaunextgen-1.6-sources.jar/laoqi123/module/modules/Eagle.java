package laoqi123.module.modules;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.events.MoveInputEvent;
import laoqi123.events.TickEvent;
import laoqi123.module.Module;
import laoqi123.util.ItemUtil;
import laoqi123.util.MoveUtil;
import laoqi123.util.PlayerUtil;
import laoqi123.util.RandomUtil;
import net.minecraft.class_10185;
import net.minecraft.class_310;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.IntProperty;
import java.util.Objects;

public class Eagle extends Module {
    private static final class_310 mc = class_310.method_1551();
    private int sneakDelay = 0;
    public final IntProperty minDelay = new IntProperty("min-delay", 2, 0, 10);
    public final IntProperty maxDelay = new IntProperty("max-delay", 3, 0, 10);
    public final BooleanProperty directionCheck = new BooleanProperty("direction-check", true);
    public final BooleanProperty jumpCheck = new BooleanProperty("jump-check", true);
    public final BooleanProperty pitchCheck = new BooleanProperty("pitch-check", true);
    public final BooleanProperty blocksOnly = new BooleanProperty("blocks-only", true);
    public final BooleanProperty sneakOnly = new BooleanProperty("sneaking-only", false);

    private boolean isSneakingInput() {
        return mc.field_1724.field_3913.field_54155.comp_3164();
    }

    private void setSneakingInput(boolean sneaking) {
        class_10185 input = mc.field_1724.field_3913.field_54155;
        mc.field_1724.field_3913.field_54155 = new class_10185(
                input.comp_3159(), input.comp_3160(), input.comp_3161(), input.comp_3162(), input.comp_3163(), sneaking, input.comp_3165()
        );
    }

    private boolean canMoveSafely() {
        double[] offset = MoveUtil.predictMovement();
        return PlayerUtil.canMove(mc.field_1724.method_18798().field_1352 + offset[0], mc.field_1724.method_18798().field_1350 + offset[1]);
    }

    private boolean shouldSneak() {
        if (this.directionCheck.getValue() && mc.field_1690.field_1894.method_1434()) {
            return false;
        } else if (this.jumpCheck.getValue() && mc.field_1690.field_1903.method_1434()) {
            return false;
        } else if (this.pitchCheck.getValue() && mc.field_1724.method_36455() < 69.0F) {
            return false;
        } else if (sneakOnly.getValue() && !mc.field_1690.field_1832.method_1434()) {
            return false;
        } else {
            return (!this.blocksOnly.getValue() || ItemUtil.isHoldingBlock()) && mc.field_1724.method_24828();
        }
    }

    public Eagle() {
        super("Eagle", false);
    }

    @EventTarget(Priority.LOWEST)
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            if (this.sneakDelay > 0) {
                this.sneakDelay--;
            }
            if (this.sneakDelay == 0 && this.canMoveSafely()) {
                this.sneakDelay = RandomUtil.nextInt(this.minDelay.getValue(), this.maxDelay.getValue() + 1);
            }
        }
    }

    @EventTarget(Priority.LOWEST)
    public void onMoveInput(MoveInputEvent event) {
        if (this.isEnabled() && mc.field_1755 == null) {

            if (sneakOnly.getValue() && mc.field_1690.field_1832.method_1434() && shouldSneak()) {
                setSneakingInput(false);
                mc.field_1724.field_3913.field_3905 /= 0.3F;
                mc.field_1724.field_3913.field_3907 /= 0.3F;
            }

            if (!isSneakingInput()) {
                if (this.shouldSneak() && (this.sneakDelay > 0 || this.canMoveSafely())) {
                    setSneakingInput(true);
                    mc.field_1724.field_3913.field_3907 *= 0.3F;
                    mc.field_1724.field_3913.field_3905 *= 0.3F;
                }
            }
        }
    }

    @Override
    public void onDisabled() {
        this.sneakDelay = 0;
    }

    @Override
    public void verifyValue(String name) {
        switch (name) {
            case "min-delay":
                if (this.minDelay.getValue() > this.maxDelay.getValue()) {
                    this.maxDelay.setValue(this.minDelay.getValue());
                }
                break;
            case "max-delay":
                if (this.minDelay.getValue() > this.maxDelay.getValue()) {
                    this.minDelay.setValue(this.maxDelay.getValue());
                }
        }
    }

    @Override
    public String[] getSuffix() {
        return Objects.equals(this.minDelay.getValue(), this.maxDelay.getValue())
                ? new String[]{this.minDelay.getValue().toString()}
                : new String[]{String.format("%d-%d", this.minDelay.getValue(), this.maxDelay.getValue())};
    }
}
