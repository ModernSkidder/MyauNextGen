package laoqi123.module.modules.movement;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.UpdateEvent;
import laoqi123.mixin.KeyBindingAccessor;
import laoqi123.module.Module;
import net.minecraft.class_310;
import net.minecraft.class_315;

public class AntiAFK extends Module {
    private static final class_310 mc = class_310.method_1551();
    private int lastInput;

    public AntiAFK() {
        super("AntiAFK", false);
    }

    @EventTarget
    public void onUpdate(UpdateEvent event){
        if(event.getType() == EventType.PRE && this.isEnabled()){
            class_315 gameOptions = mc.field_1690;
            if (gameOptions.field_1903.method_1434() || gameOptions.field_1849.method_1434() || gameOptions.field_1894.method_1434() || gameOptions.field_1913.method_1434() || gameOptions.field_1881.method_1434()) {
                lastInput = 0;
            }
            lastInput++;
            if (lastInput < 20 * 10) return;
            if (mc.field_1724.field_6012 % 5 == 0) {
                ((KeyBindingAccessor)mc.field_1690.field_1849).setPressed(false);
                ((KeyBindingAccessor)mc.field_1690.field_1913).setPressed(false);
                ((KeyBindingAccessor)mc.field_1690.field_1903).setPressed(false);
            }
            if (mc.field_1724.field_6012 % 20 == 0) {
                if (mc.field_1724.field_6012 % 40 == 0) {
                    ((KeyBindingAccessor)mc.field_1690.field_1849).setPressed(true);
                } else {
                    ((KeyBindingAccessor)mc.field_1690.field_1913).setPressed(true);
                }
            }
            if (mc.field_1724.field_6012 % 100 == 0) {
                ((KeyBindingAccessor)mc.field_1690.field_1903).setPressed(true);
            }
        }
    }
}
