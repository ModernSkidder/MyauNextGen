package laoqi123.module.modules.movement;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.TickEvent;
import laoqi123.mixin.LivingEntityAccessor;
import laoqi123.module.Module;
import laoqi123.value.properties.IntValue;
import net.minecraft.class_310;

public class NoJumpDelay extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final IntValue delay = new IntValue("delay", 3, 0, 8);

    public NoJumpDelay() {
        super("NoJumpDelay", false);
    }

    @EventTarget(Priority.HIGHEST)
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            ((LivingEntityAccessor) mc.field_1724)
                    .setJumpTicks(Math.min(((LivingEntityAccessor) mc.field_1724).getJumpTicks(), this.delay.getValue() + 1));
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.delay.getValue().toString()};
    }
}
