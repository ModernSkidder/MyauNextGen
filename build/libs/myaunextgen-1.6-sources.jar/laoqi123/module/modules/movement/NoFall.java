package laoqi123.module.modules.movement;

import com.google.common.base.CaseFormat;
import laoqi123.Myau;
import laoqi123.enums.BlinkModules;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.MoveInputEvent;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.event.impl.UpdateEvent;
import laoqi123.management.RotationState;
import laoqi123.mixin.PlayerMoveC2SPacketAccessor;
import laoqi123.module.Module;
import laoqi123.value.properties.BooleanValue;
import laoqi123.value.properties.FloatValue;
import laoqi123.value.properties.IntValue;
import laoqi123.value.properties.ModeValue;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import laoqi123.util.*;

public class NoFall extends Module {
    private static final class_310 mc = class_310.method_1551();
    private final TimerUtil packetDelayTimer = new TimerUtil();
    private final TimerUtil scoreboardResetTimer = new TimerUtil();
    private boolean slowFalling = false;
    private boolean lastOnGround = false;

    public final ModeValue mode = new ModeValue("mode", 0, new String[]{"Packet", "Blink", "No_Ground", "Spoof", "MLG"});

    public final FloatValue distance = new FloatValue("distance", 3.0F, 0.0F, 20.0F);
    public final IntValue delay = new IntValue("delay", 0, 0, 10000);

    public final BooleanValue autoSwitch = new BooleanValue("Auto Switch", true, () -> mode.getValue() == 4);
    public final ModeValue moveFix = new ModeValue("Move Fix", 1, new String[]{"NONE", "SILENT"}, () -> mode.getValue() == 4);
    public final IntValue priority = new IntValue("Priority", 2, 1, 10, () -> mode.getValue() == 4);

    private boolean active = false;
    private boolean onDistance = false;
    private boolean prevOnGround = false;
    private double highestY = 0.0;
    private float originalYaw = 0.0f;
    private boolean firstClickDone = false;
    private boolean secondClickDone = false;
    private int lastSlot = -1;

    private boolean canTrigger() {
        return this.scoreboardResetTimer.hasTimeElapsed(3000) && this.packetDelayTimer.hasTimeElapsed(this.delay.getValue().longValue());
    }

    public NoFall() {
        super("NoFall", false);
    }

    @EventTarget(Priority.HIGH)
    public void onPacket(PacketEvent event) {
        if (event.getType() == EventType.RECEIVE && event.getPacket() instanceof class_2708) {
            if (mode.getValue() == 4) {
                resetMLGState();
                restoreSlot();
            } else {
                this.onDisabled();
            }
        } else if (this.isEnabled() && event.getType() == EventType.SEND && !event.isCancelled()) {
            if (mode.getValue() == 4) return;
            if (event.getPacket() instanceof class_2828) {
                class_2828 packet = (class_2828) event.getPacket();
                switch (this.mode.getValue()) {
                    case 0:
                        if (this.slowFalling) {
                            this.slowFalling = false;
                        } else if (!packet.method_12273()) {
                            class_238 aabb = mc.field_1724.method_5829().method_1009(2.0, 0.0, 2.0);
                            if (PlayerUtil.canFly(this.distance.getValue())
                                    && !PlayerUtil.checkInWater(aabb)
                                    && this.canTrigger()) {
                                this.packetDelayTimer.reset();
                                this.slowFalling = true;
                            }
                        }
                        break;
                    case 1:
                        boolean allowed = !mc.field_1724.method_6101() && !mc.field_1724.method_31549().field_7478 && mc.field_1724.field_6235 == 0;
                        if (Myau.blinkManager.getBlinkingModule() != BlinkModules.NO_FALL) {
                            if (this.lastOnGround
                                    && !packet.method_12273()
                                    && allowed
                                    && PlayerUtil.canFly(this.distance.getValue().intValue())
                                    && mc.field_1724.method_18798().field_1351 < 0.0) {
                                Myau.blinkManager.setBlinkState(false, Myau.blinkManager.getBlinkingModule());
                                Myau.blinkManager.setBlinkState(true, BlinkModules.NO_FALL);
                            }
                        } else if (!allowed) {
                            Myau.blinkManager.setBlinkState(false, BlinkModules.NO_FALL);
                            ChatUtil.sendFormatted(String.format("%s%s: &cFailed player check!&r", Myau.clientName, this.getName()));
                        } else if (PlayerUtil.checkInWater(mc.field_1724.method_5829().method_1009(2.0, 0.0, 2.0))) {
                            Myau.blinkManager.setBlinkState(false, BlinkModules.NO_FALL);
                            ChatUtil.sendFormatted(String.format("%s%s: &cFailed void check!&r", Myau.clientName, this.getName()));
                        } else if (packet.method_12273()) {
                            for (class_2596<?> blinkedPacket : Myau.blinkManager.blinkedPackets) {
                                if (blinkedPacket instanceof class_2828) {
                                    ((PlayerMoveC2SPacketAccessor) blinkedPacket).setOnGround(true);
                                }
                            }
                            Myau.blinkManager.setBlinkState(false, BlinkModules.NO_FALL);
                            this.packetDelayTimer.reset();
                        }
                        this.lastOnGround = packet.method_12273() && allowed && this.canTrigger();
                        break;
                    case 2:
                        ((PlayerMoveC2SPacketAccessor) packet).setOnGround(false);
                        break;
                    case 3:
                        if (!packet.method_12273()) {
                            class_238 aabb = mc.field_1724.method_5829().method_1009(2.0, 0.0, 2.0);
                            if (PlayerUtil.canFly(this.distance.getValue())
                                    && !PlayerUtil.checkInWater(aabb)
                                    && this.canTrigger()) {
                                this.packetDelayTimer.reset();
                                ((PlayerMoveC2SPacketAccessor) packet).setOnGround(true);
                                mc.field_1724.field_6017 = 0.0F;
                            }
                        }
                }
            }
        }
    }

    @EventTarget(Priority.HIGHEST)
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            if (mode.getValue() == 4) return;
            if (ServerUtil.hasPlayerCountInfo()) {
                this.scoreboardResetTimer.reset();
            }
            if (this.mode.getValue() == 0 && this.slowFalling) {
                PacketUtil.sendPacketNoEvent(new class_2828.class_5911(true, false));
                mc.field_1724.field_6017 = 0.0F;
            }
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (!isEnabled() || event.getType() != EventType.PRE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;

        if (mode.getValue() == 4) {
            Module scaffold = Myau.moduleManager.getModule("Scaffold");
            if (scaffold != null && scaffold.isEnabled()) {
                if (active) {
                    restoreSlot();
                    resetMLGState();
                }
                return;
            }

            fallCheck();

            if (!active && onDistance && !mc.field_1724.method_24828()) {
                active = true;
                originalYaw = mc.field_1724.method_36454();
                firstClickDone = false;
                secondClickDone = false;

                if (autoSwitch.getValue()) {
                    lastSlot = mc.field_1724.method_31548().field_7545;
                    int bucketSlot = findWaterBucketSlot();
                    if (bucketSlot != -1) {
                        mc.field_1724.method_31548().field_7545 = bucketSlot;
                    }
                }
            }

            if (active) {
                if (mc.field_1724.method_24828() && !secondClickDone) {
                    performRightClick();
                    secondClickDone = true;
                    active = false;
                    restoreSlot();
                    return;
                }

                if (autoSwitch.getValue()) {
                    class_1799 held = mc.field_1724.method_6047();
                    if (held == null || held.method_7960() || held.method_7909() != class_1802.field_8705) {
                        active = false;
                        restoreSlot();
                        return;
                    }
                }

                event.setRotation(originalYaw, 90.0f, priority.getValue());
                event.setPervRotation(originalYaw, priority.getValue());

                if (!firstClickDone) {
                    double dist = getDistanceToGround();
                    if (dist >= 0 && dist <= 3.0) {
                        performRightClick();
                        firstClickDone = true;
                    }
                }
            }
        }
    }

    @EventTarget
    public void onMove(MoveInputEvent event) {
        if (!isEnabled()) return;
        if (mode.getValue() != 4) return;

        Module scaffold = Myau.moduleManager.getModule("Scaffold");
        if (scaffold != null && scaffold.isEnabled()) {
            return;
        }

        if (active && moveFix.getValue() == 1
                && RotationState.isActived()
                && RotationState.getPriority() == priority.getValue()
                && MoveUtil.isForwardPressed()) {
            MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
        }
    }

    private void fallCheck() {
        boolean onGround = mc.field_1724.method_24828();
        if (onGround) {
            onDistance = false;
            highestY = mc.field_1724.method_23318();
        } else if (prevOnGround) {
            highestY = mc.field_1724.method_23318();
        } else {
            if (highestY - mc.field_1724.method_23318() > 3.0) {
                onDistance = true;
            }
        }
        prevOnGround = onGround;
    }

    private double getDistanceToGround() {
        RotationUtil.RotationVec rotation = new RotationUtil.RotationVec(originalYaw, 90.0f);
        RayCastUtil.RayCastResult result = RayCastUtil.rayCast(rotation, 10.0, 0.0f);
        if (result != null && result.typeOfHit == RayCastUtil.RayCastResult.Type.BLOCK && result.hitVec != null) {
            double footY = mc.field_1724.method_5829().field_1322;
            return footY - result.hitVec.field_1351;
        }
        return -1;
    }

    private void performRightClick() {
        RotationUtil.RotationVec rotation = new RotationUtil.RotationVec(originalYaw, 90.0f);
        RayCastUtil.RayCastResult result = RayCastUtil.rayCast(rotation, 10.0, 0.0f);
        if (result != null && result.typeOfHit == RayCastUtil.RayCastResult.Type.BLOCK && result.hitVec != null) {
            class_2338 blockPos = result.getBlockPos();
            class_2350 sideHit = result.sideHit;
            class_3965 blockHit = new class_3965(result.hitVec, sideHit, blockPos, false);
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, blockHit);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    private int findWaterBucketSlot() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack != null && !stack.method_7960() && stack.method_7909() == class_1802.field_8705) {
                return i;
            }
        }
        return -1;
    }

    private void restoreSlot() {
        if (autoSwitch.getValue() && lastSlot != -1 && mc.field_1724 != null
                && mc.field_1724.method_31548().field_7545 != lastSlot) {
            mc.field_1724.method_31548().field_7545 = lastSlot;
        }
    }

    private void resetMLGState() {
        active = false;
        onDistance = false;
        prevOnGround = false;
        highestY = 0.0;
        firstClickDone = false;
        secondClickDone = false;
    }

    @Override
    public void onEnabled() {
        if (mode.getValue() == 4) {
            resetMLGState();
            if (mc.field_1724 != null) {
                originalYaw = mc.field_1724.method_36454();
                highestY = mc.field_1724.method_23318();
                prevOnGround = mc.field_1724.method_24828();
            }
        } else {
            this.lastOnGround = false;
        }
    }

    @Override
    public void onDisabled() {
        if (mode.getValue() == 4) {
            resetMLGState();
            restoreSlot();
        } else {
            this.lastOnGround = false;
            Myau.blinkManager.setBlinkState(false, BlinkModules.NO_FALL);
            if (this.slowFalling) {
                this.slowFalling = false;
            }
        }
    }

    @Override
    public void verifyValue(String mode) {
        if (this.isEnabled()) {
            this.onDisabled();
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, this.mode.getModeString())};
    }
}
