package laoqi123.module.modules.movement;

import laoqi123.Myau;
import laoqi123.enums.BlinkModules;
import laoqi123.enums.DelayModules;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.LivingUpdateEvent;
import laoqi123.event.impl.MoveInputEvent;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.StrafeEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.event.impl.UpdateEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.IntValue;
import laoqi123.value.properties.ModeValue;
import net.minecraft.class_10185;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2813;
import net.minecraft.class_2827;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2885;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_465;
import laoqi123.util.ItemUtil;
import laoqi123.util.PacketUtil;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Stuck extends Module {
    private static final class_310 mc = class_310.method_1551();

    public final ModeValue mode = new ModeValue("Mode", 0, new String[]{"Vanilla", "Heypixel"});

    public final IntValue stuckTicks = new IntValue("Stuck Ticks", 10, 1, 100);

    private double savedMotionX;
    private double savedMotionY;
    private double savedMotionZ;
    private int tick;
    private boolean using = false;

    private int stage = 0;
    private class_2596<?> heypixelPacket;
    private float lastYaw;
    private float lastPitch;
    private boolean tryDisable = false;
    private final Queue<class_2596<?>> heypixelPackets = new ConcurrentLinkedQueue<>();

    public Stuck() {
        super("Stuck", false, false);
    }

    @Override
    public void setEnabled(boolean enabled) {
        if (mc.field_1724 != null) {
            if (enabled && !this.isEnabled()) {
                if (this.mode.getModeString().equals("Vanilla")) {
                    this.savedMotionX = mc.field_1724.method_18798().field_1352;
                    this.savedMotionY = mc.field_1724.method_18798().field_1351;
                    this.savedMotionZ = mc.field_1724.method_18798().field_1350;
                    this.using = false;
                }
            } else if (!enabled && this.isEnabled()) {
                if (this.mode.getModeString().equals("Vanilla")) {
                    this.tick = 0;
                    this.using = false;
                    Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
                    Myau.delayManager.setDelayState(false, DelayModules.VELOCITY);
                    mc.field_1724.method_18800(this.savedMotionX, this.savedMotionY, this.savedMotionZ);
                } else if (this.mode.getModeString().equals("Heypixel")) {
                    this.stage = 0;
                    this.using = false;
                    this.tryDisable = false;
                    this.heypixelPacket = null;
                    this.heypixelPackets.clear();
                }
            }
        }
        super.setEnabled(enabled);
    }

    @Override
    public void onDisabled() {
        if (mc.field_1724 != null && this.mode.getModeString().equals("Vanilla")) {
            this.using = false;
            Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
            Myau.delayManager.setDelayState(false, DelayModules.VELOCITY);
            mc.field_1724.method_18800(this.savedMotionX, this.savedMotionY, this.savedMotionZ);
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (mc.field_1724 == null) {
            return;
        }
        if (this.mode.getModeString().equals("Vanilla")) {
            Myau.blinkManager.setBlinkState(true, BlinkModules.BLINK);
            class_304.method_1437();
            this.using = true;
            mc.field_1724.method_18800(0.0, 0.0, 0.0);
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (mc.field_1724 == null) {
            return;
        }
        if (event.getType() == EventType.SEND) {
            if (mc.field_1755 instanceof class_465 && event.getPacket() instanceof class_2828) {
                event.setCancelled(true);
            }
            if (this.mode.getModeString().equals("Vanilla")) {
                if (event.getPacket() instanceof class_2813) {
                    Myau.delayManager.delayedPacket.offer((class_2596<class_2602>) event.getPacket());
                    event.setCancelled(true);
                }
            } else if (this.mode.getModeString().equals("Heypixel")) {
                if (event.getPacket() instanceof class_2827 || event.getPacket() instanceof class_2813) {
                    this.heypixelPackets.add(event.getPacket());
                    event.setCancelled(true);
                }
                if (event.getPacket() instanceof class_2885 || event.getPacket() instanceof class_2846) {
                    if (this.stage == 0) {
                        this.heypixelPacket = event.getPacket();
                        this.stage = 1;
                        event.setCancelled(true);
                    }
                }
            }
        } else if (event.getType() == EventType.RECEIVE) {
            if (this.mode.getModeString().equals("Vanilla")) {
                if (event.getPacket() instanceof class_2743 velocityPacket) {
                    if (velocityPacket.method_11818() == mc.field_1724.method_5628()) {
                        Myau.delayManager.setDelayState(true, DelayModules.VELOCITY);
                        this.tick = this.stuckTicks.getValue();
                        Myau.delayManager.delayedPacket.offer(velocityPacket);
                        event.setCancelled(true);
                    }
                }
            } else if (this.mode.getModeString().equals("Heypixel")) {
                if (event.getPacket() instanceof class_2708) {
                    this.flushPackets();
                    this.stage = 3;
                    this.setEnabled(false);
                }
            }
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (this.mode.getModeString().equals("Vanilla")) {
            if (this.tick == this.stuckTicks.getValue()) {
                this.setEnabled(false);
                this.using = true;
            }
            if (this.tick == this.stuckTicks.getValue() + 1) {
                this.setEnabled(true);
                this.tick = 0;
            }
            this.tick++;
        }
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (this.mode.getModeString().equals("Vanilla")) {
            mc.field_1724.field_3913.field_3905 = 0.0f;
            mc.field_1724.field_3913.field_3907 = 0.0f;
            class_10185 playerInput = mc.field_1724.field_3913.field_54155;
            mc.field_1724.field_3913.field_54155 = new class_10185(playerInput.comp_3159(), playerInput.comp_3160(), playerInput.comp_3161(), playerInput.comp_3162(), false, false, playerInput.comp_3165());
        }
    }

    @EventTarget
    public void onLivingUpdate(LivingUpdateEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (this.mode.getModeString().equals("Vanilla")) {
            mc.field_1724.method_18800(0.0, 0.0, 0.0);
        } else if (this.mode.getModeString().equals("Heypixel")) {
            this.update();
        }
    }

    @EventTarget
    public void onStrafe(StrafeEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (this.mode.getModeString().equals("Vanilla")) {
            event.setForward(0.0F);
            event.setStrafe(0.0F);
        }
    }

    private void flushPackets() {
        while (!this.heypixelPackets.isEmpty()) {
            PacketUtil.sendPacketNoEvent(this.heypixelPackets.poll());
        }
    }

    private void updateRotation(float yaw, float pitch) {
        if (mc.field_1724.method_36454() != yaw || mc.field_1724.method_36455() != pitch) {
            PacketUtil.sendPacketNoEvent(new class_2828.class_2831(yaw, pitch, mc.field_1724.method_24828(), mc.field_1724.field_5976));
            mc.field_1724.method_36456(yaw);
            mc.field_1724.method_36457(pitch);
        }
    }

    private boolean shouldRotate() {
        if (this.heypixelPacket instanceof class_2885) {
            class_1799 item = mc.field_1724.method_6047();
            return item != null && !ItemUtil.isEating() && !(item.method_7909() instanceof class_1753);
        }
        if (this.heypixelPacket instanceof class_2846 digPacket) {
            return digPacket.method_12363() == class_2846.class_2847.field_12974
                    && mc.field_1724.method_6115()
                    && mc.field_1724.method_6030().method_7909() instanceof class_1753;
        }
        return false;
    }

    private void update() {
        if (this.stage == 1) {
            this.stage = 2;
            if (this.shouldRotate()) {
                this.updateRotation(mc.field_1724.method_36454(), 89.9f);
            }
            this.flushPackets();
            PacketUtil.sendPacketNoEvent(this.heypixelPacket);
            this.heypixelPackets.clear();
            this.heypixelPacket = null;
        }
    }
}
