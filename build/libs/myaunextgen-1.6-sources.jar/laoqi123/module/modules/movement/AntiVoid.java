package laoqi123.module.modules.movement;

import com.google.common.base.CaseFormat;
import laoqi123.Myau;
import laoqi123.enums.BlinkModules;
import laoqi123.event.EventTarget;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.KeyEvent;
import laoqi123.event.impl.PlayerUpdateEvent;
import laoqi123.module.Module;
import laoqi123.util.PlayerUtil;
import laoqi123.util.RandomUtil;
import laoqi123.value.properties.FloatValue;
import laoqi123.value.properties.ModeValue;
import net.minecraft.class_1776;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class AntiVoid extends Module {
    private static final class_310 mc = class_310.method_1551();
    private boolean isInVoid = false;
    private boolean wasInVoid = false;
    private double[] lastSafePosition = null;
    public final ModeValue mode = new ModeValue("mode", 0, new String[]{"BLINK"});
    public final FloatValue distance = new FloatValue("distance", 5.0F, 0.0F, 16.0F);

    private void resetBlink() {
        Myau.blinkManager.setBlinkState(false, BlinkModules.ANTI_VOID);
        this.lastSafePosition = null;
    }

    private boolean canUseAntiVoid() {
        LongJump longJump = (LongJump) Myau.moduleManager.modules.get(LongJump.class);
        return !longJump.isJumping();
    }

    public AntiVoid() {
        super("AntiVoid", false);
    }

    @EventTarget(Priority.LOWEST)
    public void onUpdate(PlayerUpdateEvent event) {
        if (this.isEnabled()) {
            this.isInVoid = !mc.field_1724.method_31549().field_7478 && PlayerUtil.isInWater();
            if (this.mode.getValue() == 0) {
                if (!this.isInVoid) {
                    this.resetBlink();
                }
                if (this.lastSafePosition != null) {
                    float subWidth = mc.field_1724.method_17681() / 2.0F;
                    float height = mc.field_1724.method_17682();
                    if (PlayerUtil.checkInWater(
                            new class_238(
                                    this.lastSafePosition[0] - (double) subWidth,
                                    this.lastSafePosition[1],
                                    this.lastSafePosition[2] - (double) subWidth,
                                    this.lastSafePosition[0] + (double) subWidth,
                                    this.lastSafePosition[1] + (double) height,
                                    this.lastSafePosition[2] + (double) subWidth
                            )
                    )) {
                        this.resetBlink();
                    }
                }
                if (!this.wasInVoid && this.isInVoid && this.canUseAntiVoid()) {
                    Myau.blinkManager.setBlinkState(false, BlinkModules.AUTO_BLOCK);
                    if (Myau.blinkManager.setBlinkState(true, BlinkModules.ANTI_VOID)) {
                        this.lastSafePosition = new double[]{mc.field_1724.field_6014, mc.field_1724.field_6036, mc.field_1724.field_5969};
                    }
                }
                if (Myau.blinkManager.getBlinkingModule() == BlinkModules.ANTI_VOID
                        && this.lastSafePosition != null
                        && this.lastSafePosition[1] - (double) this.distance.getValue().floatValue() > mc.field_1724.method_23318()) {
                    Myau.blinkManager
                            .blinkedPackets
                            .offerFirst(
                                    new class_2828.class_2829(
                                            this.lastSafePosition[0], this.lastSafePosition[1] - RandomUtil.nextDouble(10.0, 20.0), this.lastSafePosition[2], false, false
                                    )
                            );
                    this.resetBlink();
                }
            }
            this.wasInVoid = this.isInVoid;
        }
    }

    @EventTarget
    public void onKey(KeyEvent event) {
        if (event.getKey() == class_3675.method_15981(mc.field_1690.field_1904.method_1428()).method_1444()) {
            class_1799 currentItem = mc.field_1724.method_31548().method_7391();
            if (currentItem != null && currentItem.method_7909() instanceof class_1776) {
                this.resetBlink();
            }
        }
    }

    @Override
    public void onEnabled() {
        this.isInVoid = false;
        this.wasInVoid = false;
        this.resetBlink();
    }

    @Override
    public void onDisabled() {
        Myau.blinkManager.setBlinkState(false, BlinkModules.ANTI_VOID);
    }

    @Override
    public void verifyValue(String mode) {
        if (this.isEnabled()) {
            this.onDisabled();
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, this.mode.getModeString())};
    }
}
