package laoqi123.module.modules.movement;

import laoqi123.module.Module;
import laoqi123.value.properties.BooleanValue;
import laoqi123.value.properties.PercentValue;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_310;

public class KeepSprint extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final PercentValue slowdown = new PercentValue("slowdown", 0);
    public final BooleanValue groundOnly = new BooleanValue("ground-only", false);
    public final BooleanValue reachOnly = new BooleanValue("reach-only", false);

    public KeepSprint() {
        super("KeepSprint", false);
    }

    public boolean shouldKeepSprint() {
        if (this.groundOnly.getValue() && !mc.field_1724.method_24828()) {
            return false;
        } else {
            class_239 target = mc.field_1765;
            class_1297 viewEntity = mc.method_1560();
            return !this.reachOnly.getValue()
                    || target != null && viewEntity != null && target.method_17784().method_1022(viewEntity.method_5836(1.0F)) > 3.0;
        }
    }
}
