package laoqi123.module.modules.movement;

import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.PercentProperty;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_310;

public class KeepSprint extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final PercentProperty slowdown = new PercentProperty("slowdown", 0);
    public final BooleanProperty groundOnly = new BooleanProperty("ground-only", false);
    public final BooleanProperty reachOnly = new BooleanProperty("reach-only", false);

    public KeepSprint() {
        super("KeepSprint", false);
    }

    public boolean shouldKeepSprint() {
        if (this.groundOnly.getValue() && !mc.field_1724.method_24828()) {
            return false;
        } else {
            class_239 target = mc.field_1765;
            class_1297 viewEntity = mc.method_1560();
            return !this.reachOnly.getValue()
                    || target != null && viewEntity != null && target.method_17784().method_1022(viewEntity.method_5836(1.0F)) > 3.0;
        }
    }
}
