package laoqi123.module.modules.movement;

import laoqi123.event.EventTarget;
import laoqi123.event.impl.MoveInputEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.event.impl.UpdateEvent;
import laoqi123.event.types.EventType;
import laoqi123.management.RotationState;
import laoqi123.mixin.LivingEntityAccessor;
import laoqi123.module.Module;
import laoqi123.util.KeyBindUtil;
import laoqi123.value.properties.BooleanValue;
import net.minecraft.class_10185;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3675;

public class Sprint extends Module {
    private static final class_310 mc = class_310.method_1551();
    private boolean wasSprinting = false;
    private float naturalYaw = 0f;
    public final BooleanValue foxFix = new BooleanValue("fov-fix", true);

    public Sprint() {
        super("Sprint", true, true);
    }

    public boolean shouldApplyFovFix(class_1324 attribute) {
        if (!this.foxFix.getValue()) {
            return false;
        }
        class_1322 attributeModifier = ((LivingEntityAccessor) mc.field_1724).getSprintingSpeedBoostModifier();
        return attribute.method_6199(attributeModifier.comp_2447()) == null && this.wasSprinting;
    }

    public boolean shouldKeepFov(boolean boolean2) {
        return this.foxFix.getValue() && !boolean2 && this.wasSprinting;
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled()) {
            switch (event.getType()) {
                case PRE:
                    if (!mc.field_1690.field_1867.method_1434()) {
                        KeyBindUtil.setKeyBindState(this.getSprintKeyCode(), true);
                    }
                    break;
                case POST:
                    this.wasSprinting = mc.field_1724.method_5624();
            }
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (event.getType() != EventType.PRE || mc.field_1724 == null) return;
        // 玩家 tick HEAD:此刻鼠标已处理、旋转还没被 mixin 应用,getYaw() 是真实自然朝向
        this.naturalYaw = mc.field_1724.method_36454();
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (!isEnabled() || mc.field_1724 == null) return;
        // 移动方向 = MoveFix 实际使用的 yaw(RotationState.smoothYaw,由 setPervRotation 喂入),
        // 而非实体 yaw(旋转只影响包和移动计算,实体 yaw 渲染时是还原后的自然朝向)
        float appliedYaw = RotationState.isActived() ? RotationState.getSmoothedYaw() : mc.field_1724.method_36454();
        // 与玩家自然朝向夹角 >90° = 正在回头/向后移动(如 Scaffold 向后自救):
        // 疾跑方向与移动方向相反会触发 Grim Simulation,这里强制关掉疾跑
        float yawDiff = Math.abs(class_3532.method_15393(appliedYaw - this.naturalYaw));
        if (yawDiff > 90f) {
            class_10185 pi = mc.field_1724.field_3913.field_54155;
            if (pi != null && pi.comp_3165()) {
                mc.field_1724.field_3913.field_54155 = new class_10185(pi.comp_3159(), pi.comp_3160(), pi.comp_3161(), pi.comp_3162(), pi.comp_3163(), pi.comp_3164(), false);
            }
            if (mc.field_1724.method_5624()) {
                mc.field_1724.method_5728(false);
            }
        } else {
            // 向前阶段:主动把疾跑拉回来 —— 原版 updateSprintingState 在陆地上只能"维持"疾跑、
            // 不能重新开启,而疾跑键的 wasPressed 只在边沿触发一次,所以一旦被砍就永远回不来,
            // 结果就是向前变成走路、拉不起速度,在方块上徘徊
            if (!mc.field_1724.method_5624() && mc.field_1724.field_3913.field_3905 > 0.0f && !mc.field_1724.method_5715()) {
                mc.field_1724.method_5728(true);
            }
            if (!mc.field_1690.field_1867.method_1434()) {
                KeyBindUtil.setKeyBindState(this.getSprintKeyCode(), true);
            }
        }
    }

    @Override
    public void onDisabled() {
        this.wasSprinting = false;
        KeyBindUtil.updateKeyState(this.getSprintKeyCode());
    }

    private int getSprintKeyCode() {
        return class_3675.method_15981(mc.field_1690.field_1867.method_1428()).method_1444();
    }
}
