package laoqi123.module.modules.movement;

import com.google.common.base.CaseFormat;
import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.*;
import laoqi123.management.RotationState;
import laoqi123.mixin.EntityAccessor;
import laoqi123.module.Module;
import laoqi123.module.modules.player.Scaffold;
import laoqi123.module.modules.combat.KillAura;
import laoqi123.value.properties.*;
import net.minecraft.class_10185;
import net.minecraft.class_1657;
import net.minecraft.class_304;
import net.minecraft.class_310;
import laoqi123.util.MoveUtil;

public class Speed extends Module {
    private static final class_310 mc = class_310.method_1551();
    private final ModeValue mode = new ModeValue("Mode", 0, new String[]{"TimerBalance", "Normal"});
    public final FloatValue timerBoostMultiplier = new FloatValue("TimerBoostMultiplier", 0.5f, 0.1f, 1f, () -> this.mode.getValue() == 0);
    public final IntValue lowTimerTicks = new IntValue("LowTimerTicks", 6, 1, 10, () -> this.mode.getValue() == 0);
    public final BooleanValue rotation = new BooleanValue("Rotation", false, () -> this.mode.getValue() == 0);
    public final FloatValue multiplier = new FloatValue("Multiplier", 1.0F, 0.0F, 10.0F, () -> this.mode.getValue() == 1);
    public final FloatValue friction = new FloatValue("Friction", 1.0F, 0.0F, 10.0F, () -> this.mode.getValue() == 1);
    public final PercentValue strafe = new PercentValue("Strafe", 0, () -> this.mode.getValue() == 1);

    public Speed() {
        super("Speed", false);
    }

    private int ticks = 0;
    private float yaw = 0f;
    private YawOffsetMode yawOffsetMode = YawOffsetMode.AIR;

    public enum YawOffsetMode {
        GROUND("Ground"),
        AIR("Air"),
        CONSTANT("Constant");

        private final String tag;

        YawOffsetMode(String tag) {
            this.tag = tag;
        }

        public String getTag() {
            return tag;
        }
    }

    private boolean finished = false;

    private void computeGroundYawOffset(class_1657 player) {
        if (player.method_24828()) {
            yaw = getYawOffsetFromKeys();
        } else {
            yaw = 0f;
        }
    }

    private void computeAirYawOffset(class_1657 player) {
        if (!player.method_24828()
                && mc.field_1690.field_1894.method_1434()
                && !mc.field_1690.field_1913.method_1434()
                && !mc.field_1690.field_1849.method_1434()) {
            yaw = -45f;
        } else {
            yaw = 0f;
        }
    }

    private void computeConstantYawOffset(class_1657 player) {
        yaw = getYawOffsetFromKeys();
    }

    private float getYawOffsetFromKeys() {
        class_304 forward = mc.field_1690.field_1894;
        class_304 back = mc.field_1690.field_1881;
        class_304 left = mc.field_1690.field_1913;
        class_304 right = mc.field_1690.field_1849;

        if (forward.method_1434() && left.method_1434()) return 45f;
        if (forward.method_1434() && right.method_1434()) return -45f;
        if (back.method_1434() && left.method_1434()) return 135f;
        if (back.method_1434() && right.method_1434()) return -135f;
        if (back.method_1434()) return 180f;
        if (left.method_1434()) return 90f;
        if (right.method_1434()) return -90f;
        return 0f;
    }

    private boolean canBoost() {
        Scaffold scaffold = (Scaffold) Myau.moduleManager.getModule(Scaffold.class);
        return !scaffold.isEnabled() && MoveUtil.isForwardPressed()
                && mc.field_1724.method_7344().method_7586() > 6
                && !mc.field_1724.method_5715()
                && !mc.field_1724.method_5799()
                && !mc.field_1724.method_5771()
                && !((EntityAccessor) mc.field_1724).getIsInWeb();
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (isEnabled() && this.mode.getValue() == 0 && event.getType() == EventType.PRE) {
            if (canBoost()) {
                if (!mc.field_1724.method_24828()) {
                    if (ticks < lowTimerTicks.getValue() && !finished && mc.field_1724.method_18798().field_1351 < 0) {
                        ticks++;
                        if (ticks == lowTimerTicks.getValue()) {
                            finished = true;
                        }
                    }
                    if (finished) {
                        if (ticks > 0) {
                            ticks--;
                            if (ticks == 0) {
                                finished = false;
                            }
                        }
                    }
                } else {
                    finished = false;
                    ticks = 0;
                }
            } else {
                finished = false;
                ticks = 0;
            }
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (isEnabled() && this.mode.getValue() == 0 && event.getType() == EventType.PRE && rotation.getValue()) {
            if (canBoost() && !Myau.moduleManager.getModule(KillAura.class).isEnabled()) {
                switch (yawOffsetMode) {
                    case GROUND:
                        computeGroundYawOffset(mc.field_1724);
                        break;
                    case AIR:
                        computeAirYawOffset(mc.field_1724);
                        break;
                    case CONSTANT:
                        computeConstantYawOffset(mc.field_1724);
                        break;
                }
                event.setRotation(mc.field_1724.method_36454() - yaw, mc.field_1724.method_36455(), 2);
                event.setPervRotation(mc.field_1724.method_36454() - yaw, 2);
            }
        }
    }

    @EventTarget
    public void onMove(MoveInputEvent event) {
        if (this.isEnabled() && this.mode.getValue() == 0 && rotation.getValue() && canBoost() && !Myau.moduleManager.getModule(KillAura.class).isEnabled()) {
            if (RotationState.isActived() && RotationState.getPriority() == 2.0F && MoveUtil.isForwardPressed()) {
                MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
            }
        }
    }

    @EventTarget(Priority.LOW)
    public void onStrafe(StrafeEvent event) {
        if (this.mode.getValue() == 1) {
            if (this.isEnabled() && this.canBoost()) {
                if (mc.field_1724.method_24828()) {
                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.42F, mc.field_1724.method_18798().field_1350);
                    MoveUtil.setSpeed(
                            MoveUtil.getJumpMotion() * (double) this.multiplier.getValue(),
                            MoveUtil.getMoveYaw()
                    );
                } else {
                    if (this.friction.getValue() != 1.0F) {
                        event.setFriction(event.getFriction() * this.friction.getValue());
                    }
                    if (this.strafe.getValue() > 0) {
                        double speed = MoveUtil.getSpeed();
                        MoveUtil.setSpeed(speed * (double) ((float) (100 - this.strafe.getValue()) / 100.0F), MoveUtil.getDirectionYaw());
                        MoveUtil.addSpeed(
                                speed * (double) ((float) this.strafe.getValue() / 100.0F), MoveUtil.getMoveYaw()
                        );
                        MoveUtil.setSpeed(speed);
                    }
                }
            }
        }
    }

    @Override
    public void onDisabled() {
        finished = false;
        ticks = 0;
    }

    @EventTarget(Priority.LOW)
    public void onLivingUpdate(LivingUpdateEvent event) {
        if (this.mode.getValue() == 1) {
            if (this.isEnabled() && this.canBoost()) {
                class_10185 playerInput = mc.field_1724.field_3913.field_54155;
                mc.field_1724.field_3913.field_54155 = new class_10185(playerInput.comp_3159(), playerInput.comp_3160(), playerInput.comp_3161(), playerInput.comp_3162(), false, playerInput.comp_3164(), playerInput.comp_3165());
            }
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, mode.getModeString())};
    }
}
