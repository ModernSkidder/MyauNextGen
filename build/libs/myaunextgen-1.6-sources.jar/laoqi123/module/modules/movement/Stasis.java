package laoqi123.module.modules.movement;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.LivingUpdateEvent;
import laoqi123.event.impl.MoveInputEvent;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.StrafeEvent;
import laoqi123.event.impl.UpdateEvent;
import laoqi123.module.Module;
import net.minecraft.class_10185;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_310;

public class Stasis extends Module {
    private static final class_310 mc = class_310.method_1551();
    private double savedMotionX;
    private double savedMotionY;
    private double savedMotionZ;

    private int tickCounter;
    private int phase; // 0 = stasis, 1 = release
    private static final int STASIS_TICKS = 45;
    private static final int RELEASE_TICKS = 1;

    public Stasis() {
        super("Stasis", false);
    }

    @Override
    public void onEnabled() {
        if (mc.field_1724 != null) {
            class_243 velocity = mc.field_1724.method_18798();
            savedMotionX = velocity.field_1352;
            savedMotionY = velocity.field_1351;
            savedMotionZ = velocity.field_1350;
        }
        tickCounter = 0;
        phase = 0;
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled()) return;

        tickCounter++;

        if (phase == 0 && tickCounter >= STASIS_TICKS) {
            phase = 1;
            tickCounter = 0;
            mc.field_1724.method_18800(savedMotionX, savedMotionY, savedMotionZ);
        } else if (phase == 1 && tickCounter >= RELEASE_TICKS) {
            phase = 0;
            tickCounter = 0;
            class_243 velocity = mc.field_1724.method_18798();
            savedMotionX = velocity.field_1352;
            savedMotionY = velocity.field_1351;
            savedMotionZ = velocity.field_1350;
        }

        if (phase == 0) {
            mc.field_1724.method_18800(0.0, 0.0, 0.0);
        }
        if (mc.field_1724 != null && mc.field_1724.method_24828()) {
            this.setEnabled(false);
            return;
        }
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (this.isEnabled() && phase == 0) {
            class_10185 input = mc.field_1724.field_3913.field_54155;
            mc.field_1724.field_3913.field_54155 = new class_10185(
                    input.comp_3159(), input.comp_3160(), input.comp_3161(), input.comp_3162(), false, false, input.comp_3165()
            );
            mc.field_1724.field_3913.field_3905 = 0.0f;
            mc.field_1724.field_3913.field_3907 = 0.0f;
        }
    }

    @EventTarget
    public void onLivingUpdate(LivingUpdateEvent event) {
        if (this.isEnabled() && phase == 0) {
            mc.field_1724.method_18800(0.0, 0.0, 0.0);
        }
    }

    @EventTarget
    public void onStrafe(StrafeEvent event) {
        if (this.isEnabled() && phase == 0) {
            event.setForward(0.0f);
            event.setStrafe(0.0f);
        }
    }

    @EventTarget
    public void onSendPacket(PacketEvent e) {
        if (!this.isEnabled()) return;
        if (e.getType() != EventType.SEND) return;
        if (!(e.getPacket() instanceof class_2828)) return;

        if (phase == 1) return;

        if (mc.field_1724 == null || mc.field_1724.field_6235 != 0) {
            return;
        }

        if (!(e.getPacket() instanceof class_2828.class_2831)) {
            e.setCancelled(true);
        }
    }

    @Override
    public void onDisabled() {
        if (mc.field_1724 != null) {
            mc.field_1724.method_18800(savedMotionX, savedMotionY, savedMotionZ);
        }
        tickCounter = 0;
        phase = 0;
    }
}
