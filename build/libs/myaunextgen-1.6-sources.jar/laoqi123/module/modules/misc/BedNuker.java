package laoqi123.module.modules.misc;

import com.google.common.base.CaseFormat;
import laoqi123.Myau;
import laoqi123.enums.ChatColors;
import laoqi123.enums.DelayModules;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.HitBlockEvent;
import laoqi123.event.impl.KnockbackEvent;
import laoqi123.event.impl.LeftClickMouseEvent;
import laoqi123.event.impl.LoadWorldEvent;
import laoqi123.event.impl.MoveInputEvent;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.PlayerUpdateEvent;
import laoqi123.event.impl.Render2DEvent;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.event.impl.RightClickMouseEvent;
import laoqi123.event.impl.SwapItemEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.event.impl.UpdateEvent;
import laoqi123.management.RotationState;
import laoqi123.mixin.ClientPlayerInteractionManagerAccessor;
import laoqi123.module.Module;
import laoqi123.module.modules.player.AutoBlockIn;
import laoqi123.module.modules.render.BedESP;
import laoqi123.module.modules.render.HUD;
import laoqi123.value.properties.*;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2664;
import net.minecraft.class_2680;
import net.minecraft.class_2708;
import net.minecraft.class_2742;
import net.minecraft.class_2743;
import net.minecraft.class_2846;
import net.minecraft.class_2879;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_6880;
import net.minecraft.class_7438;
import net.minecraft.class_746;
import net.minecraft.class_7924;
import laoqi123.util.BlockUtil;
import laoqi123.util.ColorUtil;
import laoqi123.util.ItemUtil;
import laoqi123.util.MoveUtil;
import laoqi123.util.PacketUtil;
import laoqi123.util.PlayerUtil;
import laoqi123.util.RenderUtil;
import laoqi123.util.RotationUtil;
import laoqi123.util.TimerUtil;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class BedNuker extends Module {
    private static final class_310 mc = class_310.method_1551();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private final TimerUtil timer = new TimerUtil();
    private final ArrayList<class_2338> bedWhitelist = new ArrayList<class_2338>();
    private final Color colorRed = new Color(ChatColors.RED.toAwtColor());
    private final Color colorYellow = new Color(ChatColors.YELLOW.toAwtColor());
    private final Color colorGreen = new Color(ChatColors.GREEN.toAwtColor());
    private class_2338 targetBed = null;
    private int breakStage = 0;
    private int tickCounter = 0;
    private float breakProgress = 0.0F;
    private boolean isBed = false;
    private int savedSlot = -1;
    private boolean readyToBreak = false;
    private boolean breaking = false;
    private boolean waitingForStart = false;
    public final ModeValue mode = new ModeValue("mode", 0, new String[]{"LEGIT", "SWAP"});
    public final FloatValue range = new FloatValue("range", 4.5F, 3.0F, 6.0F);
    public final PercentValue speed = new PercentValue("speed", 0);
    public final BooleanValue groundSpeed = new BooleanValue("ground-spoof", false);
    public final ModeValue ignoreVelocity = new ModeValue("ignore-velocity", 0, new String[]{"NONE", "CANCEL", "DELAY"});
    public final BooleanValue surroundings = new BooleanValue("surroundings", true);
    public final BooleanValue toolCheck = new BooleanValue("tool-check", true);
    public final BooleanValue whiteList = new BooleanValue("whitelist", true);
    public final BooleanValue swing = new BooleanValue("swing", true);
    public final ModeValue moveFix = new ModeValue("move-fix", 1, new String[]{"NONE", "SILENT", "STRICT"});
    public final ModeValue showTarget = new ModeValue("show-target", 1, new String[]{"NONE", "DEFAULT", "HUD"});
    public final ModeValue showProgress = new ModeValue("show-progress", 1, new String[]{"NONE", "DEFAULT", "HUD"});

    private void resetBreaking() {
        if (this.targetBed != null) {
            mc.field_1687.method_8517(mc.field_1724.method_5628(), this.targetBed, -1);
        }
        this.targetBed = null;
        this.breakStage = 0;
        this.tickCounter = 0;
        this.breakProgress = 0.0F;
        this.isBed = false;
        this.readyToBreak = false;
        this.breaking = false;
    }

    private float calcProgress() {
        if (this.targetBed == null) {
            return 0.0F;
        } else {
            float progress = this.breakProgress;
            if (this.groundSpeed.getValue()) {
                int slot = ItemUtil.findInventorySlot(mc.field_1724.method_31548().field_7545, mc.field_1687.method_8320(this.targetBed).method_26204());
                progress = (float) this.tickCounter * this.getBreakDelta(mc.field_1687.method_8320(this.targetBed), this.targetBed, slot, true);
            }
            return Math.min(1.0F, progress / (1.0F - 0.3F * ((float) this.speed.getValue().intValue() / 100.0F)));
        }
    }

    private void restoreSlot() {
        if (this.savedSlot != -1) {
            mc.field_1724.method_31548().field_7545 = this.savedSlot;
            this.syncHeldItem();
            this.savedSlot = -1;
        }
    }

    private void syncHeldItem() {
        int currentPlayerItem = ((ClientPlayerInteractionManagerAccessor) mc.field_1761).getCurrentPlayerItem();
        if (mc.field_1724.method_31548().field_7545 != currentPlayerItem) {
            mc.field_1724.method_6075();
        }
        ((ClientPlayerInteractionManagerAccessor) mc.field_1761).callSyncCurrentPlayItem();
    }

    private boolean hasProperTool(class_2248 block) {
        if (!block.method_9564().method_29291()) {
            return true;
        } else {
            for (int i = 0; i < 9; i++) {
                class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                if (!stack.method_7960() && stack.method_7909() instanceof class_1810) {
                    return true;
                }
            }
            return false;
        }
    }

    private class_2350 getHitFacing(class_2338 blockPos) {
        double x = (double) blockPos.method_10263() + 0.5 - mc.field_1724.method_23317();
        double y = (double) blockPos.method_10264() + 0.25 - mc.field_1724.method_23318() - (double) mc.field_1724.method_5751();
        double z = (double) blockPos.method_10260() + 0.5 - mc.field_1724.method_23321();
        float[] rotations = RotationUtil.getRotationsTo(x, y, z, mc.field_1724.method_36454(), mc.field_1724.method_36455());
        class_239 mop = RotationUtil.rayTrace(rotations[0], rotations[1], 8.0, 1.0F);
        return mop instanceof class_3965 ? ((class_3965) mop).method_17780() : class_2350.field_11036;
    }

    private boolean hasAquaAffinity() {
        class_6880<class_1887> entry = mc.field_1687.method_30349().method_30530(class_7924.field_41265).method_10223(class_1893.field_9105.method_29177()).orElse(null);
        return entry != null && class_1890.method_8203(entry, mc.field_1724) > 0;
    }

    private float getDigSpeed(class_2680 blockState, int slot, boolean boolean5) {
        class_1799 item = mc.field_1724.method_31548().method_5438(slot);
        float digSpeed = item.method_7960() ? 1.0F : item.method_7924(blockState);
        if (digSpeed > 1.0F) {
            class_6880<class_1887> entry = mc.field_1687.method_30349().method_30530(class_7924.field_41265).method_10223(class_1893.field_9131.method_29177()).orElse(null);
            int enchantmentLevel = entry == null ? 0 : class_1890.method_8225(entry, item);
            if (enchantmentLevel > 0) {
                digSpeed += (float) (enchantmentLevel * enchantmentLevel + 1);
            }
        }
        if (mc.field_1724.method_6059(class_1294.field_5917)) {
            digSpeed *= 1.0F + (float) (mc.field_1724.method_6112(class_1294.field_5917).method_5578() + 1) * 0.2F;
        }
        if (mc.field_1724.method_6059(class_1294.field_5901)) {
            switch (mc.field_1724.method_6112(class_1294.field_5901).method_5578()) {
                case 0:
                    digSpeed *= 0.3F;
                    break;
                case 1:
                    digSpeed *= 0.09F;
                    break;
                case 2:
                    digSpeed *= 0.0027F;
                    break;
                default:
                    digSpeed *= 8.1E-4F;
            }
        }
        if (mc.field_1724.method_5799() && !this.hasAquaAffinity()) {
            digSpeed /= 5.0F;
        }
        if (!boolean5) {
            digSpeed /= 5.0F;
        }
        return digSpeed;
    }

    boolean canHarvest(class_2248 block, int slot) {
        if (!block.method_9564().method_29291()) {
            return true;
        } else {
            class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
            return !stack.method_7960() && stack.method_7951(block.method_9564());
        }
    }

    private float getBreakDelta(class_2680 blockState, class_2338 blockPos, int slot, boolean boolean5) {
        class_2248 block = blockState.method_26204();
        float hardness = block.method_36555();
        float boost = this.canHarvest(block, slot) ? 30.0F : 100.0F;
        return hardness < 0.0F ? 0.0F : this.getDigSpeed(blockState, slot, boolean5) / hardness / boost;
    }

    private float calcBlockStrength(class_2338 blockPos) {
        class_2680 blockState = mc.field_1687.method_8320(blockPos);
        int slot = ItemUtil.findInventorySlot(mc.field_1724.method_31548().field_7545, blockState.method_26204());
        return this.getBreakDelta(blockState, blockPos, slot, mc.field_1724.method_24828());
    }

    private class_2338 validateBedPlacement(class_2338 bedPosition) {
        class_2680 blockState = mc.field_1687.method_8320(bedPosition);
        if (blockState.method_26204() instanceof class_2244) {
            ArrayList<class_2338> pos = new ArrayList<>();
            class_2742 partType = blockState.method_11654(class_2244.field_9967);
            class_2350 facing = blockState.method_11654(class_2244.field_11177);
            for (class_2338 blockPos : Arrays.asList(bedPosition, bedPosition.method_10093(partType == class_2742.field_12560 ? facing.method_10153() : facing))) {
                for (class_2350 enumFacing : Arrays.asList(class_2350.field_11036, class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039)) {
                    class_2248 block = mc.field_1687.method_8320(blockPos.method_10093(enumFacing)).method_26204();
                    if (BlockUtil.isReplaceable(block.method_9564())) {
                        return null;
                    }
                    if (!(block instanceof class_2244)) {
                        pos.add(blockPos.method_10093(enumFacing));
                    }
                }
            }
            if (!pos.isEmpty()) {
                pos.sort(
                        (blockPos1, blockPos2) -> {
                            int o = Float.compare(this.calcBlockStrength(blockPos2), this.calcBlockStrength(blockPos1));
                            return o != 0
                                    ? o
                                    : Double.compare(
                                    blockPos1.method_46558().method_1028(mc.field_1724.method_23317(), mc.field_1724.method_23318() + (double) mc.field_1724.method_5751(), mc.field_1724.method_23321()),
                                    blockPos2.method_46558().method_1028(mc.field_1724.method_23317(), mc.field_1724.method_23318() + (double) mc.field_1724.method_5751(), mc.field_1724.method_23321())
                            );
                        }
                );
                return pos.get(0);
            }
        }
        return null;
    }

    private class_2338 findNearestBed() {
        return this.findTargetBed(mc.field_1724.method_23317(), mc.field_1724.method_23318() + (double) mc.field_1724.method_5751(), mc.field_1724.method_23321());
    }

    private class_2338 findTargetBed(double x, double y, double z) {
        ArrayList<class_2338> targets = new ArrayList<>();
        int sX = class_3532.method_15357(x);
        int sY = class_3532.method_15357(y);
        int sZ = class_3532.method_15357(z);
        for (int i = sX - 6; i <= sX + 6; i++) {
            for (int j = sY - 6; j <= sY + 6; j++) {
                for (int k = sZ - 6; k <= sZ + 6; k++) {
                    class_2338 newPos = new class_2338(i, j, k);
                    if (!(Boolean) this.whiteList.getValue() || !this.bedWhitelist.contains(newPos)) {
                        class_2248 block = mc.field_1687.method_8320(newPos).method_26204();
                        if (block instanceof class_2244
                                && PlayerUtil.isBlockWithinReach(newPos, x, y, z, this.range.getValue().doubleValue())) {
                            targets.add(newPos);
                        }
                    }
                }
            }
        }
        if (targets.isEmpty()) {
            return null;
        } else {
            targets.sort(
                    Comparator.comparingDouble(
                            blockPos -> blockPos.method_46558().method_1028(mc.field_1724.method_23317(), mc.field_1724.method_23318() + (double) mc.field_1724.method_5751(), mc.field_1724.method_23321())
                    )
            );
            for (class_2338 blockPos : targets) {
                if (this.surroundings.getValue()) {
                    class_2338 pos = this.validateBedPlacement(blockPos);
                    if (pos != null) {
                        class_2248 block = mc.field_1687.method_8320(pos).method_26204();
                        if (this.toolCheck.getValue() && !this.hasProperTool(block)) {
                            continue;
                        }
                        return pos;
                    }
                }
                return blockPos;
            }
            return null;
        }
    }

    private void doSwing() {
        if (this.swing.getValue()) {
            mc.field_1724.method_6104(class_1268.field_5808);
        } else {
            PacketUtil.sendPacket(new class_2879(class_1268.field_5808));
        }
    }

    private Color getProgressColor(int mode) {
        switch (mode) {
            case 1:
                float progress = this.calcProgress();
                if (progress <= 0.5F) {
                    return ColorUtil.interpolate(progress / 0.5F, this.colorRed, this.colorYellow);
                }
                return ColorUtil.interpolate((progress - 0.5F) / 0.5F, this.colorYellow, this.colorGreen);
            case 2:
                return ((HUD) Myau.moduleManager.modules.get(HUD.class)).getColor(System.currentTimeMillis());
            default:
                return new Color(-1);
        }
    }

    public BedNuker() {
        super("BedNuker", false);
    }

    public boolean isReady() {
        return this.targetBed != null && this.readyToBreak;
    }

    public boolean isBreaking() {
        return this.targetBed != null && this.breaking;
    }

    @EventTarget(Priority.HIGH)
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            AutoBlockIn autoBlockIn = (AutoBlockIn) Myau.moduleManager.modules.get(AutoBlockIn.class);
            if (autoBlockIn.isEnabled()) return;
            if (this.targetBed != null) {
                if (mc.field_1687.method_22347(this.targetBed) || !PlayerUtil.canReach(this.targetBed, this.range.getValue().doubleValue())) {
                    this.restoreSlot();
                    this.resetBreaking();
                } else if (!this.isBed) {
                    class_2338 nearestBed = this.findNearestBed();
                    if (nearestBed != null && mc.field_1687.method_8320(nearestBed).method_26204() instanceof class_2244) {
                        this.resetBreaking();
                    }
                }
            }
            if (this.targetBed != null) {
                int slot = ItemUtil.findInventorySlot(mc.field_1724.method_31548().field_7545, mc.field_1687.method_8320(this.targetBed).method_26204());
                if (this.mode.getValue() == 0 && this.savedSlot == -1) {
                    this.savedSlot = mc.field_1724.method_31548().field_7545;
                    mc.field_1724.method_31548().field_7545 = slot;
                    this.syncHeldItem();
                }
                switch (this.breakStage) {
                    case 0:
                        if (!mc.field_1724.method_6115()) {
                            this.doSwing();
                            PacketUtil.sendPacket(
                                    new class_2846(class_2846.class_2847.field_12968, this.targetBed, this.getHitFacing(this.targetBed))
                            );
                            this.doSwing();
                            mc.field_1713.method_3054(this.targetBed, this.getHitFacing(this.targetBed));
                            this.breakStage = 1;
                        }
                        break;
                    case 1:
                        if (this.mode.getValue() == 1) {
                            this.readyToBreak = false;
                        }
                        this.breaking = true;
                        this.tickCounter++;
                        this.breakProgress = this.breakProgress
                                + this.getBreakDelta(mc.field_1687.method_8320(this.targetBed), this.targetBed, slot, mc.field_1724.method_24828());
                        float tick = (float) this.tickCounter;
                        class_2680 blockState = mc.field_1687.method_8320(this.targetBed);
                        boolean canBreak = mc.field_1724.method_24828() && this.groundSpeed.getValue();
                        class_2338 target = this.targetBed;
                        float delta = tick * this.getBreakDelta(blockState, target, slot, canBreak);
                        mc.field_1713.method_3054(this.targetBed, this.getHitFacing(this.targetBed));
                        if (this.breakProgress >= 1.0F - 0.3F * ((float) this.speed.getValue().intValue() / 100.0F)
                                || delta >= 1.0F - 0.3F * ((float) this.speed.getValue().intValue() / 100.0F)) {
                            if (this.mode.getValue() == 1) {
                                this.readyToBreak = true;
                                this.savedSlot = mc.field_1724.method_31548().field_7545;
                                mc.field_1724.method_31548().field_7545 = slot;
                                this.syncHeldItem();
                                if (mc.field_1724.method_6115()) {
                                    this.savedSlot = mc.field_1724.method_31548().field_7545;
                                    mc.field_1724.method_31548().field_7545 = (mc.field_1724.method_31548().field_7545 + 1) % 9;
                                    this.syncHeldItem();
                                }
                            }
                            this.breaking = false;
                            PacketUtil.sendPacket(
                                    new class_2846(class_2846.class_2847.field_12973, this.targetBed, this.getHitFacing(this.targetBed))
                            );
                            this.doSwing();
                            class_2680 blockState_ = mc.field_1687.method_8320(this.targetBed);
                            class_2248 block = blockState_.method_26204();
                            if (!blockState_.method_26215()) {
                                mc.field_1687.method_20290(2001, this.targetBed, class_2248.method_9507(blockState_));
                                mc.field_1687.method_8650(this.targetBed, false);
                            }
                            if (block instanceof class_2244) {
                                this.timer.reset();
                            }
                            this.breakStage = 2;
                        }
                        break;
                    case 2:
                        this.restoreSlot();
                        this.resetBreaking();
                }
                if (this.targetBed != null) {
                    return;
                }
            }
            if (mc.field_1724.method_31549().field_7476 && this.timer.hasTimeElapsed(500)) {
                this.targetBed = this.findNearestBed();
                this.breakStage = 0;
                this.tickCounter = 0;
                this.breakProgress = 0.0F;
                this.isBed = this.targetBed != null && mc.field_1687.method_8320(this.targetBed).method_26204() instanceof class_2244;
                this.restoreSlot();
                if (this.targetBed != null) {
                    this.readyToBreak = true;
                }
            }
            if (this.targetBed == null) {
                Myau.delayManager.setDelayState(false, DelayModules.BED_NUKER);
            }
        }
    }

    @EventTarget(Priority.LOWEST)
    public void onUpdate(UpdateEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            AutoBlockIn autoBlockIn = (AutoBlockIn) Myau.moduleManager.modules.get(AutoBlockIn.class);
            if (autoBlockIn.isEnabled()) return;
            if (this.isReady()) {
                double x = (double) this.targetBed.method_10263() + 0.5 - mc.field_1724.method_23317();
                double y = (double) this.targetBed.method_10264() + 0.5 - mc.field_1724.method_23318() - (double) mc.field_1724.method_5751();
                double z = (double) this.targetBed.method_10260() + 0.5 - mc.field_1724.method_23321();
                float[] rotations = RotationUtil.getRotationsTo(x, y, z, event.getYaw(), event.getPitch());
                event.setRotation(rotations[0], rotations[1], 5);
                event.setPervRotation(this.moveFix.getValue() != 0 ? rotations[0] : mc.field_1724.method_36454(), 5);
            }
        }
    }

    @EventTarget
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (this.isEnabled()) {
            if (this.isBreaking()
                    && !Myau.playerStateManager.attacking
                    && !Myau.playerStateManager.digging
                    && !Myau.playerStateManager.placing
                    && !Myau.playerStateManager.swinging) {
                this.doSwing();
            }
        }
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (this.isEnabled()) {
            if (this.moveFix.getValue() == 1
                    && RotationState.isActived()
                    && RotationState.getPriority() == 5.0F
                    && MoveUtil.isForwardPressed()) {
                MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
            }
        }
    }

    @EventTarget(Priority.HIGH)
    public void onKnockback(KnockbackEvent event) {
        if (this.isEnabled() && !event.isCancelled() && !(event.getY() <= 0.0)) {
            if (this.ignoreVelocity.getValue() == 1 && this.targetBed != null) {
                event.setCancelled(true);
                event.setX(mc.field_1724.method_18798().field_1352);
                event.setY(mc.field_1724.method_18798().field_1351);
                event.setZ(mc.field_1724.method_18798().field_1350);
            }
        }
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (this.isEnabled()) {
            if (this.targetBed != null && (!this.isBed || !this.surroundings.getValue())) {
                if (this.showProgress.getValue() != 0) {
                    HUD hud = (HUD) Myau.moduleManager.modules.get(HUD.class);
                    float scale = hud.scale.getValue();
                    String text = String.format("%d%%", (int) (this.calcProgress() * 100.0F));
                    class_4587 matrices = event.getContext().method_51448();
                    matrices.method_22903();
                    matrices.method_22905(scale, scale, 1.0F);
                    int width = mc.field_1772.method_1727(text);
                    event.getContext().method_51433(
                            mc.field_1772,
                            text,
                            (int) ((float) mc.method_22683().method_4486() / 2.0F / scale - (float) width / 2.0F),
                            (int) ((float) mc.method_22683().method_4502() / 5.0F * 2.0F / scale),
                            this.getProgressColor(this.showProgress.getValue()).getRGB() & 16777215 | -1090519040,
                            hud.shadow.getValue()
                    );
                    matrices.method_22909();
                }
            }
        }
    }

    @EventTarget(Priority.LOW)
    public void onRender3D(Render3DEvent event) {
        if (this.isEnabled() && this.targetBed != null && !mc.field_1687.method_22347(this.targetBed)) {
            mc.field_1687.method_8517(mc.field_1724.method_5628(), this.targetBed, (int) (this.calcProgress() * 10.0F) - 1);
            if (this.showTarget.getValue() != 0) {
                BedESP bedESP = (BedESP) Myau.moduleManager.modules.get(BedESP.class);
                Color color = this.getProgressColor(this.showTarget.getValue());
                RenderUtil.enableRenderState();
                class_2338 target = this.targetBed;
                double newHeight = this.isBed ? bedESP.getHeight() : 1.0;
                int r = color.getRed();
                int g = color.getBlue();
                int b = color.getGreen();
                RenderUtil.drawBlockBox(target, newHeight, r, b, g);
                RenderUtil.disableRenderState();
            }
        }
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        this.waitingForStart = false;
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (!event.isCancelled()) {
            if (event.getPacket() instanceof class_7438) {
                class_7438 packet = (class_7438) event.getPacket();
                String text = null;
                if (packet.comp_1103() != null) {
                    text = packet.comp_1103().getString();
                } else if (packet.comp_1102() != null && packet.comp_1102().comp_1090() != null) {
                    text = packet.comp_1102().comp_1090();
                }
                if (text != null && (text.contains("搂e搂lProtect your bed and destroy the enemy bed") || text.contains("搂e搂lDestroy the enemy bed and then eliminate them"))) {
                    this.waitingForStart = true;
                }
            }
            if (event.getPacket() instanceof class_2708 && this.waitingForStart) {
                this.waitingForStart = false;
                this.bedWhitelist.clear();
                this.scheduler.schedule(() -> {
                    class_746 player = mc.field_1724;
                    if (player == null) {
                        return;
                    }
                    int sX = class_3532.method_15357(player.method_23317());
                    int sY = class_3532.method_15357(player.method_23318() + (double) player.method_5751());
                    int sZ = class_3532.method_15357(player.method_23321());
                    for (int i = sX - 25; i <= sX + 25; i++) {
                        for (int j = sY - 25; j <= sY + 25; j++) {
                            for (int k = sZ - 25; k <= sZ + 25; k++) {
                                class_2338 blockPos = new class_2338(i, j, k);
                                class_2248 block = mc.field_1687.method_8320(blockPos).method_26204();
                                if (block instanceof class_2244) {
                                    this.bedWhitelist.add(blockPos);
                                }
                            }
                        }
                    }
                }, 1L, TimeUnit.SECONDS);
            }
            if (this.isEnabled() && this.targetBed != null && this.ignoreVelocity.getValue() == 2 && Myau.delayManager.getDelayModule() != DelayModules.BED_NUKER) {
                if (event.getPacket() instanceof class_2743) {
                    class_2743 packet = (class_2743) event.getPacket();
                    if (packet.method_11818() == mc.field_1724.method_5628() && packet.method_11816() > 0) {
                        Myau.delayManager.delay(DelayModules.BED_NUKER);
                        Myau.delayManager.delayedPacket.offer(packet);
                        event.setCancelled(true);
                    }
                }
                if (event.getPacket() instanceof class_2664) {
                    class_2664 explosion = (class_2664) event.getPacket();
                    if (explosion.comp_2884().map(v -> v.field_1352 != 0.0 || v.field_1351 != 0.0 || v.field_1350 != 0.0).orElse(false)) {
                        Myau.delayManager.delay(DelayModules.BED_NUKER);
                        Myau.delayManager.delayedPacket.offer(explosion);
                        event.setCancelled(true);
                    }
                }
            }
        }
    }

    @EventTarget
    public void onLeftClick(LeftClickMouseEvent event) {
        if (this.isEnabled()) {
            if (this.isReady() || this.targetBed != null && mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1332) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onRightClick(RightClickMouseEvent event) {
        if (this.isEnabled()) {
            if (this.isReady()) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onHitBlock(HitBlockEvent event) {
        if (this.isEnabled()) {
            if (this.isReady() || this.targetBed != null && mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1332) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onSwap(SwapItemEvent event) {
        if (this.isEnabled()) {
            if (this.savedSlot != -1) {
                event.setCancelled(true);
            }
        }
    }

    @Override
    public void onDisabled() {
        this.resetBreaking();
        this.savedSlot = -1;
        Myau.delayManager.setDelayState(false, DelayModules.BED_NUKER);
    }

    @Override
    public String[] getSuffix() {
        return new String[]{CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, this.mode.getModeString())};
    }
}
