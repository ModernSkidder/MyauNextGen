package laoqi123.module.modules.misc;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.PacketEvent;
import laoqi123.module.Module;
import laoqi123.util.ChatUtil;
import net.minecraft.class_1299;
import net.minecraft.class_243;
import net.minecraft.class_2604;
import net.minecraft.class_310;

public class LightningTracker extends Module {
    private static final class_310 mc = class_310.method_1551();

    private String getDirection(double playerX, double playerZ, double lightningX, double lightningZ) {
        double threshold = Math.sqrt(2.0) - 1.0;
        double xDiff = lightningX - playerX;
        double yDiff = lightningZ - playerZ;
        if (Math.abs(xDiff) > Math.abs(yDiff)) {
            if (Math.abs(yDiff / xDiff) <= threshold) {
                return xDiff > 0.0 ? "E" : "W";
            } else if (xDiff > 0.0) {
                return yDiff > 0.0 ? "SE" : "NE";
            } else {
                return yDiff > 0.0 ? "SW" : "NW";
            }
        } else if (Math.abs(yDiff) > 0.0) {
            if (Math.abs(xDiff / yDiff) <= threshold) {
                return yDiff > 0.0 ? "S" : "N";
            } else if (yDiff > 0.0) {
                return xDiff > 0.0 ? "SE" : "SW";
            } else {
                return xDiff > 0.0 ? "NE" : "NW";
            }
        } else {
            return "?";
        }
    }

    public LightningTracker() {
        super("LightningTracker", false, true);
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (this.isEnabled() && event.getType() == EventType.RECEIVE && event.getPacket() instanceof class_2604) {
            class_2604 packet = (class_2604) event.getPacket();
            if (packet.method_11169() == class_1299.field_6112) {
                double x = packet.method_11175();
                double y = packet.method_11174();
                double z = packet.method_11176();
                double distance = mc.field_1724.method_19538().method_1022(new class_243(x, y, z));
                String direction = this.getDirection(mc.field_1724.method_23317(), mc.field_1724.method_23321(), x, z);
                ChatUtil.sendFormatted(
                        String.format(
                                "&8[&e%s&8] &7X: &f&l%d&r &7Y: &f&l%d&r &7Z: &f&l%d&r &7D: &6&l%d&r &6%s&r",
                                this.getName(),
                                (int) x,
                                (int) y,
                                (int) z,
                                (int) distance,
                                direction
                        )
                );
            }
        }
    }
}
