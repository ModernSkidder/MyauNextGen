package laoqi123.module.modules.misc;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.PacketEvent;
import laoqi123.module.Module;
import laoqi123.util.ChatUtil;
import net.minecraft.class_1299;
import net.minecraft.class_2604;
import net.minecraft.class_2703;
import net.minecraft.class_310;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class AntiStaff extends Module {
    private static final class_310 mc = class_310.method_1551();

    private static final String STAFF_LIST_B64 = "QuermeaQnOaXoOmHj+Wfn+mbqizkuInlm73mnYAs56yZ5qmZLE1lbmdDaGVuMzg4NCxBbmRyZXdrcmlzdCxGaWE5LOaeq+iQp+ael+eEtiznu7/osYbkuYPjgZXjgpMs5oqW6Z+z5Li25bCP5YyqLOaKlumfs19hd2Hpqazljp8sTW5hbUxlb18s5Lit5LqM5bCR5bm0REws5p6V5LiK5Lmm5Li25aGR5pyb5pyILElhbU1vbGluY2VuXywsQ29GdV9fLOaWl+aImOiDnOS9myzlj6rnjqnmlqXlgJks5p6V5LiK5Lmm5Li26Zuq5aScLGFpeXVraSxDYW5keUFwb3N0bGUsY2h1bnlpMSzmtYHlvbHlj6rkvJrlmKTlmKTlmKQscXRlc2RmXzY3NCxxeHRtbGM5OSxTa3lmb3ks56We5Z2R5LmL6YCXLOWco+S4iuiNo+iAgDIzMyzlsI/lhpvlkJvkuLblpKnkvb/kuYvnv7ws5p6V5LiK5Lmm5Li25YKy5a+SLF93aW5uZXJfLFNreV9ZdWFueGlhbw==";

    private static final List<String> STAFF_LIST = new ArrayList<>();

    static {
        String decoded = new String(Base64.getDecoder().decode(STAFF_LIST_B64), StandardCharsets.UTF_8);
        for (String name : decoded.split(",")) {
            STAFF_LIST.add(name);
        }
    }

    public AntiStaff() {
        super("AntiStaff", false);
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.RECEIVE) return;
        if (event.getPacket() instanceof class_2703 packet) {
            if (!packet.method_46327().contains(class_2703.class_5893.field_29136)) return;
            for (class_2703.class_2705 entry : packet.method_46329()) {
                if (entry.comp_1107() != null) {
                    String name = entry.comp_1107().getName();
                    if (name != null && !name.isEmpty() && STAFF_LIST.contains(name)) {
                        this.exitGame();
                        return;
                    }
                }
                if (entry.comp_1111() != null) {
                    String display = entry.comp_1111().getString();
                    if (!display.isEmpty() && STAFF_LIST.contains(display)) {
                        this.exitGame();
                        return;
                    }
                }
            }
        } else if (event.getPacket() instanceof class_2604 packet) {
            if (packet.method_11164() == null || mc.field_1687 == null) return;
            if (packet.method_11169() != class_1299.field_6097) return;
            net.minecraft.class_1297 entity = mc.field_1687.method_8469(packet.method_11167());
            if (entity != null) {
                String name = entity.method_5477().getString();
                if (!name.isEmpty() && STAFF_LIST.contains(name)) {
                    this.exitGame();
                }
            }
        }
    }

    private void exitGame() {
        ChatUtil.sendFormatted("&cStaff detected!");
        if (mc.field_1724 != null && mc.field_1724.field_3944 != null) {
            mc.field_1724.field_3944.method_45731("hub");
        }
    }
}
