package laoqi123.module.modules.misc;

import laoqi123.Myau;
import laoqi123.enums.ChatColors;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.LoadWorldEvent;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.Render2DEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.module.Module;
import laoqi123.util.ChatUtil;
import laoqi123.util.ColorUtil;
import laoqi123.util.SoundUtil;
import laoqi123.util.TeamUtil;
import laoqi123.value.properties.*;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1684;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2708;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_408;
import net.minecraft.class_4587;
import net.minecraft.class_7438;
import net.minecraft.class_746;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class BedTracker extends Module {
    private static final class_310 mc = class_310.method_1551();
    private final ScheduledExecutorService executor;
    private final LinkedHashMap<String, Long> alertCooldowns;
    private final LinkedHashSet<class_1684> trackedPearls;
    private final LinkedHashSet<String> whitelistedPlayers;
    private final Color wBed;
    private final Color rBed;
    private final Color yBed;
    private final Color gBed;
    private class_2338 bedPos;
    private long lastMarcoTime;
    private boolean waiting;
    public final BooleanValue alerts;
    public final IntValue alertRange;
    public final BooleanValue alertOnPearl;
    public final ModeValue alertSound;
    public final IntValue alertFrequency;
    public final BooleanValue marco;
    public final IntValue marcoRange;
    public final BooleanValue marcoOnPreal;
    public final TextValue marcoText;
    public final IntValue marcoDelay;
    public final BooleanValue hud;
    public final ModeValue hudPosX;
    public final ModeValue hudPosY;
    public final IntValue hudOffX;
    public final IntValue hudOffY;
    public final FloatValue hudScale;
    public final BooleanValue hudShadow;

    private void playAlertSound() {
        switch (this.alertSound.getValue()) {
            case 1:
                SoundUtil.playSound("mob.cat.meow");
                break;
            case 2:
                SoundUtil.playSound("random.anvil_land");
        }
    }

    private Color getHudColor(int distance) {
        if (distance < 0) {
            return this.wBed;
        } else if (distance <= 100) {
            return this.gBed;
        } else if (distance <= 114) {
            return ColorUtil.interpolate((float) (114 - distance) / 14.0F, this.yBed, this.gBed);
        } else {
            return distance <= 128 ? ColorUtil.interpolate((float) (128 - distance) / 14.0F, this.rBed, this.yBed) : this.rBed;
        }
    }

    private boolean isBed(class_2338 blockPos) {
        return blockPos != null && mc.field_1687.method_8320(blockPos).method_27852(class_2246.field_10069);
    }

    public BedTracker() {
        super("BedTracker", false, true);
        this.executor = Executors.newScheduledThreadPool(1);
        this.alertCooldowns = new LinkedHashMap<>();
        this.trackedPearls = new LinkedHashSet<>();
        this.whitelistedPlayers = new LinkedHashSet<>();
        this.wBed = new Color(ChatColors.WHITE.toAwtColor());
        this.rBed = new Color(ChatColors.RED.toAwtColor());
        this.yBed = new Color(ChatColors.YELLOW.toAwtColor());
        this.gBed = new Color(ChatColors.GREEN.toAwtColor());
        this.bedPos = null;
        this.lastMarcoTime = -1L;
        this.waiting = false;
        this.alerts = new BooleanValue("alerts", true);
        this.alertRange = new IntValue("alerts-range", 48, 8, 128, this.alerts::getValue);
        this.alertOnPearl = new BooleanValue("alerts-on-pearl", true);
        this.alertSound = new ModeValue("alerts-sound", 1, new String[]{"NONE", "MEOW", "ANVIL"}, () -> this.alerts.getValue() || this.alertOnPearl.getValue());
        this.alertFrequency = new IntValue("alerts-frequency", 5, 1, 30, () -> this.alerts.getValue() || this.alertOnPearl.getValue());
        this.marco = new BooleanValue("macro", false);
        this.marcoRange = new IntValue("macro-range", 24, 8, 128, this.marco::getValue);
        this.marcoOnPreal = new BooleanValue("macro-on-pearl", false);
        this.marcoText = new TextValue("macro-text", "/lobby", () -> this.marco.getValue() || this.marcoOnPreal.getValue());
        this.marcoDelay = new IntValue("macro-delay", 1, 1, 10, () -> this.marco.getValue() || this.marcoOnPreal.getValue());
        this.hud = new BooleanValue("hud", true);
        this.hudPosX = new ModeValue("hud-position-x", 0, new String[]{"LEFT", "MIDDLE", "RIGHT"}, this.hud::getValue);
        this.hudPosY = new ModeValue("hud-position-y", 0, new String[]{"TOP", "MIDDLE", "BOTTOM"}, this.hud::getValue);
        this.hudOffX = new IntValue("hud-offset-x", 2, 0, 255, this.hud::getValue);
        this.hudOffY = new IntValue("hud-offset-y", 2, 0, 255, this.hud::getValue);
        this.hudScale = new FloatValue("hud-scale", 1.0F, 0.5F, 1.5F, this.hud::getValue);
        this.hudShadow = new BooleanValue("hud-shadow", true, this.hud::getValue);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.POST && this.isBed(this.bedPos)) {
            long millis = System.currentTimeMillis();
            boolean pearl = false;
            boolean marco = false;
            for (class_1297 entity : mc.field_1687.method_18112()) {
                if (entity instanceof class_1684) {
                    class_1684 enderPearl = (class_1684) entity;
                    if (!this.trackedPearls.contains(enderPearl)) {
                        this.trackedPearls.add(enderPearl);
                        if (this.alertOnPearl.getValue()) {
                            ChatUtil.sendFormatted(String.format("%s%s: &fDetected &5Ender Pearl&r &e&l!", Myau.clientName, this.getName()));
                            pearl = true;
                        }
                        if (this.marcoOnPreal.getValue() && this.lastMarcoTime + (long) this.marcoDelay.getValue() * 1000L <= millis) {
                            this.lastMarcoTime = millis;
                            marco = true;
                        }
                    }
                }
            }
            for (class_1657 player : StreamSupport.stream(mc.field_1687
                    .method_18112()
                    .spliterator(), false)
                    .filter(entity -> entity instanceof class_1657)
                    .map(entity -> (class_1657) entity)
                    .filter(entityPlayer -> !TeamUtil.isBot(entityPlayer) && !this.whitelistedPlayers.contains(entityPlayer.method_5477()))
                    .collect(Collectors.toList())) {
                if (TeamUtil.isSameTeam(player)) {
                    this.whitelistedPlayers.add(player.method_5477().getString());
                } else {
                    double distance = Math.sqrt(player.method_5649((double) this.bedPos.method_10263() + 0.5, (double) this.bedPos.method_10264() + 0.5, (double) this.bedPos.method_10260() + 0.5));
                    String name = player.method_5477().getString();
                    String text = player.method_5476().getString();
                    class_1799 item = player.method_6047();
                    boolean isPearl = item != null && item.method_31574(class_1802.field_8634);
                    if (this.alerts.getValue() && distance < (double) this.alertRange.getValue()) {
                        Long cooldown = this.alertCooldowns.get(name);
                        if (cooldown == null || cooldown + (long) this.alertFrequency.getValue() * 1000L <= millis) {
                            this.alertCooldowns.put(name, millis);
                            ChatUtil.sendFormatted(
                                    String.format("%s%s: %s&r &fis %d blocks away from your bed &e&l!", Myau.clientName, this.getName(), text, (int) distance + 1)
                            );
                            pearl = true;
                        }
                    }
                    if (this.alertOnPearl.getValue() && isPearl) {
                        Long cooldown = this.alertCooldowns.get(name);
                        if (cooldown == null || cooldown + (long) this.alertFrequency.getValue() * 1000L <= millis) {
                            this.alertCooldowns.put(name, millis);
                            ChatUtil.sendFormatted(
                                    String.format("%s%s: %s&r &fhas &5Ender Pearl&r &e&l!", Myau.clientName, this.getName(), text)
                            );
                            pearl = true;
                        }
                    }
                    if ((
                            this.marco.getValue() && distance < (double) this.marcoRange.getValue()
                                    || this.marcoOnPreal.getValue() && isPearl
                    )
                            && this.lastMarcoTime + (long) this.marcoDelay.getValue() * 1000L <= millis) {
                        this.lastMarcoTime = millis;
                        marco = true;
                    }
                }
            }
            if (pearl) {
                this.playAlertSound();
            }
            if (marco) {
                ChatUtil.sendRaw(
                        String.format(
                                ChatColors.formatColor("%s%s: &fRunning &6%s&r"),
                                ChatColors.formatColor(Myau.clientName),
                                this.getName(),
                                this.marcoText.getValue()
                        )
                );
                ChatUtil.sendMessage(this.marcoText.getValue());
            }
        }
    }

    @EventTarget(Priority.LOW)
    public void onRender(Render2DEvent event) {
        if (this.isEnabled() && this.hud.getValue()) {
            if (mc.field_1687 != null && mc.field_1724 != null && !mc.field_1705.method_53531().method_53536()) {
                if (mc.field_1755 == null || mc.field_1755 instanceof class_408) {
                    int distanceSq = 0;
                    boolean hasBed = this.isBed(this.bedPos);
                    if (hasBed) {
                        double xDiff = mc.field_1724.method_23317() - (double) this.bedPos.method_10263();
                        double zDiff = mc.field_1724.method_23321() - (double) this.bedPos.method_10260();
                        distanceSq = (int) Math.sqrt(xDiff * xDiff + zDiff * zDiff) + 1;
                    }
                    String text = ChatColors.formatColor(
                            String.format(
                                    "&fBed: %s%s",
                                    !hasBed ? "&cfalse&r" : "&atrue&r",
                                    !hasBed ? "" : String.format(" &7| &fDistance: &r%d%s", distanceSq, distanceSq >= 128 ? " &c&l!" : "")
                            )
                    );
                    float width = (float) mc.field_1772.method_1727(text);
                    float height = (float) mc.field_1772.field_2000 - 1.0F;
                    float scale = (float) this.hudOffX.getValue() / this.hudScale.getValue();
                    switch (this.hudPosX.getValue()) {
                        case 0:
                            scale++;
                            break;
                        case 1:
                            scale += (float) mc.method_22683().method_4486() / this.hudScale.getValue() / 2.0F - width / 2.0F;
                            break;
                        case 2:
                            scale = (scale + 1.0F) * -1.0F;
                            scale += (float) mc.method_22683().method_4486() / this.hudScale.getValue() - width;
                    }
                    float offset = (float) this.hudOffY.getValue() / this.hudScale.getValue();
                    switch (this.hudPosY.getValue()) {
                        case 0:
                            offset++;
                            break;
                        case 1:
                            offset += (float) mc.method_22683().method_4502() / this.hudScale.getValue() / 2.0F - height / 2.0F;
                            break;
                        case 2:
                            offset = (offset + 1.0F) * -1.0F;
                            offset += (float) mc.method_22683().method_4502() / this.hudScale.getValue() - height;
                    }
                    class_4587 matrices = event.getContext().method_51448();
                    matrices.method_22903();
                    matrices.method_22905(this.hudScale.getValue(), this.hudScale.getValue(), 1.0F);
                    matrices.method_46416(scale, offset, 0.0F);
                    event.getContext().method_51433(mc.field_1772, text, 0, 0, this.getHudColor(distanceSq).getRGB(), this.hudShadow.getValue());
                    matrices.method_22909();
                }
            }
        }
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        this.waiting = false;
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (this.isEnabled()) {
            if (event.getPacket() instanceof class_7438) {
                class_7438 packet = (class_7438) event.getPacket();
                String msg = null;
                if (packet.comp_1103() != null) {
                    msg = packet.comp_1103().getString();
                } else if (packet.comp_1102() != null && packet.comp_1102().comp_1090() != null) {
                    msg = packet.comp_1102().comp_1090();
                }
                if (msg != null && (msg.contains("§e§lProtect your bed and destroy the enemy bed") || msg.contains("§e§lDestroy the enemy bed and then eliminate them"))) {
                    this.alertCooldowns.clear();
                    this.trackedPearls.clear();
                    this.whitelistedPlayers.clear();
                    this.bedPos = null;
                    this.waiting = true;
                }
            }
            if (event.getPacket() instanceof class_2708 && this.waiting) {
                this.waiting = false;
                this.executor
                        .schedule(
                                () -> {
                                    class_746 player = mc.field_1724;
                                    if (player == null) {
                                        return;
                                    }
                                    int x = class_3532.method_15357(player.method_23317());
                                    int y = class_3532.method_15357(player.method_23318() + (double) player.method_5751());
                                    int z = class_3532.method_15357(player.method_23321());
                                    for (int i = x - 25; i <= x + 25; i++) {
                                        for (int j = y - 25; j <= y + 25; j++) {
                                            for (int k = z - 25; k <= z + 25; k++) {
                                                class_2338 blockPos = new class_2338(i, j, k);
                                                if (this.isBed(blockPos)) {
                                                    this.bedPos = blockPos;
                                                    ChatUtil.sendFormatted(
                                                            String.format(
                                                                    "%s%s: &fWhitelisted your bed at (%d, %d, %d) &a&l!",
                                                                    Myau.clientName,
                                                                    this.getName(),
                                                                    this.bedPos.method_10263(),
                                                                    this.bedPos.method_10264(),
                                                                    this.bedPos.method_10260()
                                                            )
                                                    );
                                                    SoundUtil.playSound("note.pling");
                                                    return;
                                                }
                                            }
                                        }
                                    }
                                },
                                3000L,
                                TimeUnit.MILLISECONDS
                        );
            }
        }
    }

    @Override
    public void onDisabled() {
        this.alertCooldowns.clear();
        this.trackedPearls.clear();
        this.whitelistedPlayers.clear();
        this.bedPos = null;
    }
}
