package laoqi123.module.modules.misc;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.TickEvent;
import laoqi123.module.Module;
import laoqi123.property.properties.IntProperty;
import laoqi123.util.KeyBindUtil;
import net.minecraft.class_310;
import net.minecraft.class_465;

public class InventoryClicker extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final IntProperty triggerTicks = new IntProperty("ticks", 2, 0, 20);
    public int ticks;

    public InventoryClicker() {
        super("InventoryClicker", false);
    }

    @Override
    public String[] getSuffix() {
        return new String[]{triggerTicks.getValue().toString() + " ticks"};
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled() && mc.field_1724 != null && event.getType() == EventType.PRE) {
            if (mc.field_1755 instanceof class_465) {
                class_465<?> screen = ((class_465<?>) mc.field_1755);
                final int mouseX = (int) (mc.field_1729.method_1603() * screen.field_22789 / mc.method_22683().method_4489());
                final int mouseY = (int) (screen.field_22790 - mc.field_1729.method_1604() * screen.field_22790 / mc.method_22683().method_4506() - 1);
                if (KeyBindUtil.isKeyDown(mc.field_1690.field_1886)) {
                    ticks++;
                    if(ticks > triggerTicks.getValue())
                    {
                        screen.method_25402(mouseX, mouseY, 0);
                    }
                }else {
                    ticks = 0;
                }
            }
        }
    }
}
