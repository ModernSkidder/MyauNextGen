package laoqi123.module.modules.misc;

import laoqi123.module.Module;
import laoqi123.value.properties.BooleanValue;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3726;

public class AntiObbyTrap extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final BooleanValue setAir = new BooleanValue("set-air", true);

    public AntiObbyTrap() {
        super("AntiObbyTrap", false);
    }

    public boolean isInsideBlock(class_1922 world, class_2338 blockPos) {
        class_2680 blockState = world.method_8320(blockPos);
        if (blockState.method_51367() && blockState.method_26234(world, blockPos)) {
            class_243 hitVec = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318() + (double) mc.field_1724.method_18381(mc.field_1724.method_18376()), mc.field_1724.method_23321());
            return blockState.method_26194(world, blockPos, class_3726.method_16195(mc.field_1724)).method_1107().method_1006(hitVec);
        } else {
            return false;
        }
    }
}
