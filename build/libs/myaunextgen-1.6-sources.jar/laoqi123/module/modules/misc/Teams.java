package laoqi123.module.modules.misc;

import laoqi123.module.Module;
import laoqi123.value.properties.ModeValue;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_268;
import net.minecraft.class_310;
import net.minecraft.class_640;
import laoqi123.util.TeamUtil;
import java.util.Objects;

public class Teams extends Module {
    private static final class_310 mc = class_310.method_1551();
    public static Teams INSTANCE;
    public final ModeValue mode = new ModeValue("Mode", 1, new String[]{"Color", "Scoreboard"});

    public Teams() {
        super("Teams", false);
        INSTANCE = this;
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.mode.getModeString()};
    }

    public static boolean isSameTeam(class_1297 entity) {
        Teams teams = INSTANCE;
        if (teams == null || !teams.isEnabled()) {
            return false;
        }
        if (!(entity instanceof class_1657)) {
            return false;
        }
        if (teams.mode.getValue() == 0) {
            return entity.method_22861() == mc.field_1724.method_22861();
        }
        String team = Teams.getTeam(entity);
        String selfTeam = Teams.getTeam(mc.field_1724);
        return Objects.equals(team, selfTeam);
    }

    public static boolean isKillAuraTeam(class_1657 player) {
        Teams teams = INSTANCE;
        if (teams != null && teams.isEnabled()) {
            return Teams.isSameTeam(player);
        }
        return TeamUtil.isSameTeam(player);
    }

    public static String getTeam(class_1297 entity) {
        class_640 playerInfo = mc.method_1562().method_2871(entity.method_5667());
        if (playerInfo == null) {
            return null;
        }
        class_268 team = playerInfo.method_2955();
        return team == null ? null : team.method_1197();
    }
}