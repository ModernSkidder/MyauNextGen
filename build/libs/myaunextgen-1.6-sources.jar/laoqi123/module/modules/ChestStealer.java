package laoqi123.module.modules;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.UpdateEvent;
import laoqi123.events.WindowClickEvent;
import laoqi123.module.Module;
import laoqi123.util.ChatUtil;
import laoqi123.util.ItemUtil;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.util.RandomUtil;
import net.minecraft.class_10192;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

public class ChestStealer extends Module {
    private static final class_310 mc = class_310.method_1551();
    private int clickDelay = 0;
    private int oDelay = 0;
    private boolean inChest = false;
    private boolean warnedFull = false;
    public final IntProperty minDelay = new IntProperty("min-delay", 1, 0, 20);
    public final IntProperty maxDelay = new IntProperty("max-delay", 2, 0, 20);
    public final IntProperty openDelay = new IntProperty("open-delay", 1, 0, 20);
    public final BooleanProperty autoClose = new BooleanProperty("auto-close", false);
    public final BooleanProperty nameCheck = new BooleanProperty("name-check", true);
    public final BooleanProperty skipTrash = new BooleanProperty("skip-trash", true);
    public final BooleanProperty moreArmor = new BooleanProperty("more-armor", false);
    public final BooleanProperty moreSword = new BooleanProperty("more-sword", false);

    private boolean isValidGameMode() {
        class_1934 gameType = mc.field_1761.method_2920();
        return gameType == class_1934.field_9215 || gameType == class_1934.field_9216;
    }

    private boolean isDiamondMaterial(class_1799 itemStack) {
        class_2960 id = class_7923.field_41178.method_10221(itemStack.method_7909());
        return id.method_12836().equals("minecraft") && id.method_12832().startsWith("diamond_");
    }

    private boolean isIronMaterial(class_1799 itemStack) {
        class_2960 id = class_7923.field_41178.method_10221(itemStack.method_7909());
        return id.method_12836().equals("minecraft") && id.method_12832().startsWith("iron_");
    }

    private boolean isMoreArmor(class_1799 itemStack) {
        if (itemStack == null || itemStack.method_7960()) return false;
        if (!this.moreArmor.getValue()) return false;
        if (!(itemStack.method_7909() instanceof class_1738)) return false;
        if (isDiamondMaterial(itemStack)) return true;
        return isIronMaterial(itemStack) && itemStack.method_7942();
    }

    private boolean hasFireAspect(class_1799 itemStack) {
        for (class_6880<class_1887> entry : itemStack.method_58657().method_57534()) {
            if (entry.method_40225(class_1893.field_9124)) {
                return true;
            }
        }
        return false;
    }

    private boolean isMoreSword(class_1799 itemStack) {
        if (itemStack == null || itemStack.method_7960()) return false;
        if (!this.moreSword.getValue()) return false;
        if (!(itemStack.method_7909() instanceof class_1829)) return false;
        class_2960 id = class_7923.field_41178.method_10221(itemStack.method_7909());
        boolean diamond = id.method_12836().equals("minecraft") && id.method_12832().equals("diamond_sword");
        boolean iron = id.method_12836().equals("minecraft") && id.method_12832().equals("iron_sword");
        if (diamond) return true;
        if (hasFireAspect(itemStack)) return true;
        return iron && itemStack.method_7942();
    }

    private int getArmorType(class_1799 itemStack) {
        class_10192 equippable = itemStack.method_57824(class_9334.field_54196);
        if (equippable == null) return -1;
        class_1304 slot = equippable.comp_3174();
        switch (slot) {
            case field_6169:
                return 0;
            case field_6174:
                return 1;
            case field_6172:
                return 2;
            case field_6166:
                return 3;
            default:
                return -1;
        }
    }

    private boolean isInvManagerRequire(class_1799 itemStack) {
        if (itemStack == null || itemStack.method_7960()) return false;
        InvManager invManager = (InvManager) Myau.moduleManager.modules.get(InvManager.class);
        if (ItemUtil.ItemType.Block.contains(itemStack)) {
            return !invManager.isEnabled() || ItemUtil.findInventorySlot(ItemUtil.ItemType.Block) < invManager.blocks.getValue();
        }
        if (ItemUtil.ItemType.Projectile.contains(itemStack)) {
            return !invManager.isEnabled() || ItemUtil.findInventorySlot(ItemUtil.ItemType.Projectile) < invManager.projectiles.getValue();
        }
        if (ItemUtil.ItemType.FishRod.contains(itemStack)) {
            return ItemUtil.findInventorySlot(ItemUtil.ItemType.Projectile) == 0;
        }
        if (ItemUtil.ItemType.Arrow.contains(itemStack)) {
            return !invManager.isEnabled() || ItemUtil.findInventorySlot(ItemUtil.ItemType.Arrow) < invManager.arrow.getValue();
        }
        if (ItemUtil.ItemType.FireCharge.contains(itemStack)) {
            return !invManager.isEnabled() || ItemUtil.findInventorySlot(ItemUtil.ItemType.FireCharge) < invManager.fireCharges.getValue();
        }
        if (ItemUtil.ItemType.WindCharge.contains(itemStack)) {
            return !invManager.isEnabled() || ItemUtil.findInventorySlot(ItemUtil.ItemType.WindCharge) < invManager.windCharges.getValue();
        }
        if (ItemUtil.ItemType.Mace.contains(itemStack)) {
            return !invManager.isEnabled() || ItemUtil.findInventorySlot(ItemUtil.ItemType.Mace) < invManager.mace.getValue();
        }
        return false;
    }

    private void shiftClick(int windowId, int slotId) {
        mc.field_1761.method_2906(windowId, slotId, 0, class_1713.field_7794, mc.field_1724);
    }

    public ChestStealer() {
        super("ChestStealer", false);
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (event.getType() == EventType.PRE) {
            if (this.clickDelay > 0) {
                this.clickDelay--;
            }
            if (this.oDelay > 0) {
                this.oDelay--;
            }
            if (!(mc.field_1755 instanceof class_465)) {
                this.inChest = false;
            } else {
                class_1703 container = ((class_465<?>) mc.field_1755).method_17577();
                if (!(container instanceof net.minecraft.class_1707)) {
                    this.inChest = false;
                } else {
                    if (!this.inChest) {
                        this.inChest = true;
                        this.warnedFull = false;
                        this.oDelay = this.openDelay.getValue() + 1;
                    }
                    if (this.oDelay <= 0 && this.clickDelay <= 0) {
                        if (this.isEnabled() && this.isValidGameMode()) {
                            class_1263 inventory = ((net.minecraft.class_1707) container).method_7629();
                            if (this.nameCheck.getValue()) {
                                String rawName = mc.field_1755.method_25440().getString();
                                String cleanName = rawName.replaceAll("(?i)§[0-9a-fklmnor]", "").trim();
                                String localizedChest = class_2561.method_43471("container.chest").getString();
                                String localizedDouble = class_2561.method_43471("container.chestDouble").getString();
                                String cleanLocalizedChest = localizedChest.replaceAll("(?i)§[0-9a-fklmnor]", "").trim();
                                String cleanLocalizedDouble = localizedDouble.replaceAll("(?i)§[0-9a-fklmnor]", "").trim();

                                boolean matches = cleanName.equalsIgnoreCase("Chest")
                                        || cleanName.equalsIgnoreCase("Large Chest")
                                        || cleanName.equalsIgnoreCase(cleanLocalizedChest)
                                        || cleanName.equalsIgnoreCase(cleanLocalizedDouble);

                                if (!matches) {
                                    return;
                                }
                            }
                            if (mc.field_1724.method_31548().method_7376() == -1) {
                                if (!this.warnedFull) {
                                    ChatUtil.sendFormatted(String.format("%s%s: &cYour inventory is full!&r", Myau.clientName, this.getName()));
                                    this.warnedFull = true;
                                }
                                if (this.autoClose.getValue()) {
                                    mc.field_1724.method_7346();
                                }
                            } else {
                                boolean isZeroDelay = this.minDelay.getValue() == 0 && this.maxDelay.getValue() == 0;
                                int maxIterations = isZeroDelay ? 5 : 1;
                                int stolen = 0;
                                while (stolen < maxIterations) {
                                    if (!trySteal(container, inventory)) {
                                        break;
                                    }
                                    stolen++;
                                    if (!isZeroDelay) {
                                        break;
                                    }
                                    if (mc.field_1724.method_31548().method_7376() == -1) {
                                        if (this.autoClose.getValue()) {
                                            mc.field_1724.method_7346();
                                        }
                                        break;
                                    }
                                    if (!(mc.field_1755 instanceof class_465)) {
                                        break;
                                    }
                                    container = ((class_465<?>) mc.field_1755).method_17577();
                                    if (!(container instanceof net.minecraft.class_1707)) {
                                        break;
                                    }
                                    inventory = ((net.minecraft.class_1707) container).method_7629();
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean trySteal(class_1703 container, class_1263 inventory) {
        if (this.skipTrash.getValue()) {
            int bestSword = -1;
            double bestDamage = 0.0;
            int[] bestArmorSlots = new int[]{-1, -1, -1, -1};
            double[] bestArmorProtection = new double[]{0.0, 0.0, 0.0, 0.0};
            int bestPickaxeSlot = -1;
            float bestPickaxeEfficiency = 1.0F;
            int bestShovelSlot = -1;
            float bestShovelEfficiency = 1.0F;
            int bestAxeSlot = -1;
            float bestAxeEfficiency = 1.0F;
            int bestBow = -1;
            double bestBowDamage = 0.0;
            for (int i = 0; i < inventory.method_5439(); i++) {
                if (container.method_7611(i).method_7681()) {
                    class_1799 stack = container.method_7611(i).method_7677();
                    net.minecraft.class_1792 item = stack.method_7909();
                    if (item instanceof class_1829) {
                        double damage = ItemUtil.getAttackBonus(stack);
                        if (bestSword == -1 || damage > bestDamage) {
                            bestSword = i;
                            bestDamage = damage;
                        }
                    } else if (item instanceof class_1738) {
                        int armorType = getArmorType(stack);
                        if (armorType >= 0) {
                            double protectionLevel = ItemUtil.getArmorProtection(stack);
                            if (bestArmorSlots[armorType] == -1 || protectionLevel > bestArmorProtection[armorType]) {
                                bestArmorSlots[armorType] = i;
                                bestArmorProtection[armorType] = protectionLevel;
                            }
                        }
                    } else if (item instanceof net.minecraft.class_1810) {
                        float efficiency = ItemUtil.getToolEfficiency(stack);
                        if (bestPickaxeSlot == -1 || efficiency > bestPickaxeEfficiency) {
                            bestPickaxeSlot = i;
                            bestPickaxeEfficiency = efficiency;
                        }
                    } else if (item instanceof net.minecraft.class_1821) {
                        float efficiency = ItemUtil.getToolEfficiency(stack);
                        if (bestShovelSlot == -1 || efficiency > bestShovelEfficiency) {
                            bestShovelSlot = i;
                            bestShovelEfficiency = efficiency;
                        }
                    } else if (item instanceof net.minecraft.class_1743) {
                        float efficiency = ItemUtil.getToolEfficiency(stack);
                        if (bestAxeSlot == -1 || efficiency > bestAxeEfficiency) {
                            bestAxeSlot = i;
                            bestAxeEfficiency = efficiency;
                        }
                    } else if (item instanceof net.minecraft.class_1753) {
                        double damage = ItemUtil.getBowAttackBonus(stack);
                        if (bestBow == -1 || damage > bestBowDamage) {
                            bestBow = i;
                            bestBowDamage = damage;
                        }
                    }
                }
            }
            int swordInInventorySlot = ItemUtil.findSwordInInventorySlot(0, true);
            double damage = swordInInventorySlot != -1 ? ItemUtil.getAttackBonus(mc.field_1724.method_31548().method_5438(swordInInventorySlot)) : 0.0;
            if (bestDamage > damage) {
                this.shiftClick(container.field_7763, bestSword);
                return true;
            }
            for (int i = 0; i < 4; i++) {
                int slot = ItemUtil.findArmorInventorySlot(i, true);
                double protectionLevel = slot != -1
                        ? ItemUtil.getArmorProtection(mc.field_1724.method_31548().method_5438(slot))
                        : 0.0;
                if (bestArmorProtection[i] > protectionLevel) {
                    this.shiftClick(container.field_7763, bestArmorSlots[i]);
                    return true;
                }
            }
            int pickaxeSlot = ItemUtil.findInventorySlot("pickaxe", 0, true);
            float pickaxeEfficiency = pickaxeSlot != -1 ? ItemUtil.getToolEfficiency(mc.field_1724.method_31548().method_5438(pickaxeSlot)) : 1.0F;
            if (bestPickaxeEfficiency > pickaxeEfficiency) {
                this.shiftClick(container.field_7763, bestPickaxeSlot);
                return true;
            }
            int shovelSlot = ItemUtil.findInventorySlot("shovel", 0, true);
            float shovelEfficiency = shovelSlot != -1 ? ItemUtil.getToolEfficiency(mc.field_1724.method_31548().method_5438(shovelSlot)) : 1.0F;
            if (bestShovelEfficiency > shovelEfficiency) {
                this.shiftClick(container.field_7763, bestShovelSlot);
                return true;
            }
            int axeSlot = ItemUtil.findInventorySlot("axe", 0, true);
            float efficiency = axeSlot != -1 ? ItemUtil.getToolEfficiency(mc.field_1724.method_31548().method_5438(axeSlot)) : 1.0F;
            if (bestAxeEfficiency > efficiency) {
                this.shiftClick(container.field_7763, bestAxeSlot);
                return true;
            }
            int bowSlot = ItemUtil.findBowInventorySlot(0, true);
            double bowDamage = bowSlot != -1 ? ItemUtil.getBowAttackBonus(mc.field_1724.method_31548().method_5438(bowSlot)) : 0.0;
            if (bestBowDamage > bowDamage) {
                this.shiftClick(container.field_7763, bestBow);
                return true;
            }
        }
        for (int i = 0; i < inventory.method_5439(); i++) {
            if (container.method_7611(i).method_7681()) {
                class_1799 stack = container.method_7611(i).method_7677();
                if (!this.skipTrash.getValue() || !ItemUtil.isNotSpecialItem(stack) || isMoreArmor(stack) || isMoreSword(stack) || isInvManagerRequire(stack)) {
                    this.shiftClick(container.field_7763, i);
                    return true;
                }
            }
        }
        if (this.autoClose.getValue()) {
            mc.field_1724.method_7346();
        }
        return false;
    }

    @EventTarget
    public void onWindowClick(WindowClickEvent event) {
        if (minDelay.getValue() == 0 && maxDelay.getValue() == 0) {
            clickDelay = 0;
        } else {
            int newMin = Math.max(0, minDelay.getValue() - 1);
            int newMax = Math.max(0, maxDelay.getValue() - 1);
            clickDelay = RandomUtil.nextInt(newMin + 1, newMax + 1);
        }
    }

    @Override
    public void verifyValue(String mode) {
        switch (mode) {
            case "min-delay":
                if (this.minDelay.getValue() > this.maxDelay.getValue()) {
                    this.maxDelay.setValue(this.minDelay.getValue());
                }
                break;
            case "max-delay":
                if (this.minDelay.getValue() > this.maxDelay.getValue()) {
                    this.minDelay.setValue(this.maxDelay.getValue());
                }
        }
    }
}
