package laoqi123.module.modules;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.events.MoveInputEvent;
import laoqi123.events.UpdateEvent;
import laoqi123.management.RotationState;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.FloatProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.util.ItemUtil;
import laoqi123.util.MoveUtil;
import laoqi123.util.PacketUtil;
import laoqi123.util.TeamUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1771;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1823;
import net.minecraft.class_243;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_745;
import java.util.ArrayList;
import java.util.Comparator;

public class AutoProjectiles extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final FloatProperty range = new FloatProperty("Range", 8.0F, 3.0F, 15.0F);
    public final IntProperty amount = new IntProperty("Amount", 1, 1, 10);
    public final BooleanProperty prediction = new BooleanProperty("Prediction", true);
    public final BooleanProperty teams = new BooleanProperty("Teams", true);
    public final BooleanProperty weaponOnly = new BooleanProperty("WeaponOnly", true);

    private class_1309 target = null;
    private int lastSlot = -1;
    private long lastThrowTime = 0L;
    private int throwState = 0;
    private int throwsRemaining = 0;
    private boolean hasRotated = false;
    private SmartPredictor smartPredictor = new SmartPredictor();

    public AutoProjectiles() {
        super("AutoProjectiles", false);
    }

    private boolean isValidTarget(class_1309 entity) {
        if (entity == mc.field_1724 || entity.field_6213 > 0) {
            return false;
        }
        if (!(entity instanceof class_745)) {
            return false;
        }
        double distance = mc.field_1724.method_5739(entity);
        if (distance > this.range.getValue()) {
            return false;
        }
        class_1657 player = (class_1657) entity;
        if (TeamUtil.isFriend(player)) {
            return false;
        }
        return !this.teams.getValue() || !TeamUtil.isSameTeam(player);
    }

    private class_1309 getTarget() {
        ArrayList<class_1309> targets = new ArrayList<>();
        for (Object obj : mc.field_1687.method_18112()) {
            if (obj instanceof class_1309) {
                class_1309 entity = (class_1309) obj;
                if (isValidTarget(entity)) {
                    targets.add(entity);
                }
            }
        }
        if (targets.isEmpty()) {
            return null;
        }
        targets.sort(Comparator.comparingDouble(entity -> mc.field_1724.method_5739(entity)));

        class_1309 newTarget = targets.get(0);
        if (this.target != newTarget) {
            this.smartPredictor = new SmartPredictor();
        }

        return newTarget;
    }

    private boolean hasProjectile() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (isProjectile(stack)) {
                return true;
            }
        }
        return false;
    }

    private boolean isProjectile(class_1799 stack) {
        if (stack == null) return false;
        class_1792 item = stack.method_7909();
        return item instanceof class_1823 || item instanceof class_1771;
    }

    private int getProjectileSlot() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (isProjectile(stack)) {
                return i;
            }
        }
        return -1;
    }

    private class_243 predictPosition(class_1309 target) {
        long currentTime = System.currentTimeMillis();
        smartPredictor.addPosition(new class_243(target.method_23317(), target.method_23318(), target.method_23321()), currentTime);

        if (!this.prediction.getValue()) {
            return new class_243(target.method_23317(), target.method_23318() + target.method_5751(), target.method_23321());
        }

        double rawPing = mc.method_1562().method_2871(mc.field_1724.method_5667()).method_2959();
        double networkDelay = rawPing / 1000.0;

        double clientProcessingDelay = 0.02;
        double serverProcessingDelay = 0.01;
        double packetDelay = networkDelay * 0.5;

        double distance = mc.field_1724.method_5739(target);
        final double PROJECTILE_SPEED = 20.0;
        final double GRAVITY = 0.03;

        double horizontalDistance = Math.sqrt(
                Math.pow(target.method_23317() - mc.field_1724.method_23317(), 2) +
                        Math.pow(target.method_23321() - mc.field_1724.method_23321(), 2)
        );
        double verticalDistance = (target.method_23318() + target.method_5751()) - (mc.field_1724.method_23318() + mc.field_1724.method_5751());

        double horizontalTime = horizontalDistance / PROJECTILE_SPEED;
        double verticalTime = calculateVerticalFlightTime(verticalDistance, PROJECTILE_SPEED, GRAVITY);
        double actualFlightTime = Math.max(horizontalTime, verticalTime);

        double totalDelayCompensation = networkDelay + clientProcessingDelay + serverProcessingDelay + packetDelay;

        if (rawPing > 100) {
            totalDelayCompensation += (rawPing - 100) / 1000.0 * 0.8;
        }

        double basePredictionTime = actualFlightTime + totalDelayCompensation;

        class_243 velocity = smartPredictor.getCurrentVelocity();
        double targetSpeed = Math.sqrt(velocity.field_1352 * velocity.field_1352 + velocity.field_1350 * velocity.field_1350);

        if (targetSpeed > 0.2) {
            basePredictionTime += targetSpeed * 0.1;
        }

        double distanceFactor = Math.min(1.2, distance / 10.0);
        double finalPredictionTime = basePredictionTime * distanceFactor;

        class_243 predictedPos = smartPredictor.predictNextPosition(finalPredictionTime);

        return new class_243(predictedPos.field_1352, predictedPos.field_1351 + target.method_5751(), predictedPos.field_1350);
    }

    private double calculateVerticalFlightTime(double verticalDistance, double initialSpeed, double gravity) {
        double verticalComponent = initialSpeed * 0.2;

        if (verticalDistance >= 0) {
            double discriminant = verticalComponent * verticalComponent + 2 * gravity * verticalDistance;
            if (discriminant < 0) return 0;
            return (verticalComponent + Math.sqrt(discriminant)) / gravity;
        } else {
            double discriminant = verticalComponent * verticalComponent - 2 * gravity * verticalDistance;
            if (discriminant < 0) return 0;
            return (Math.sqrt(discriminant) - verticalComponent) / gravity;
        }
    }

    private long calculateSmartDelay() {
        if (target == null) return 800L;

        double distance = mc.field_1724.method_5739(target);

        if (distance <= 3.5) {
            return 0L;
        } else if (distance <= 3.8) {
            return 20L;
        } else if (distance <= 4.0) {
            return 70L;
        } else if (distance <= 4.5) {
            return 100L;
        } else if (distance <= 5.0) {
            return 200L;
        } else if (distance <= 10.0) {
            return 500L;
        } else {
            return 800L;
        }
    }

    private float[] getRotationsToPosition(class_243 position) {
        double deltaX = position.field_1352 - mc.field_1724.method_23317();
        double deltaY = position.field_1351 - mc.field_1724.method_23318() - mc.field_1724.method_5751();
        double deltaZ = position.field_1350 - mc.field_1724.method_23321();
        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        float yaw = (float) (Math.atan2(deltaZ, deltaX) * 180.0 / Math.PI) - 90.0F;
        float pitch = (float) -(Math.atan2(deltaY, horizontalDistance) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }

    private void switchToProjectile() {
        int projectileSlot = this.getProjectileSlot();
        if (projectileSlot != -1) {
            this.lastSlot = mc.field_1724.method_31548().field_7545;
            mc.field_1724.method_31548().field_7545 = projectileSlot;
        }
    }

    private void switchBack() {
        if (this.lastSlot != -1) {
            mc.field_1724.method_31548().field_7545 = lastSlot;
            this.lastSlot = -1;
        }
    }

    private void throwProjectile() {
        int projectileSlot = this.getProjectileSlot();
        if (projectileSlot != -1) {
            class_1799 projectileStack = mc.field_1724.method_31548().method_5438(projectileSlot);
            if (isProjectile(projectileStack)) {
                PacketUtil.sendPacket(new class_2886(class_1268.field_5808, 0, 0.0F, 0.0F));
            }
        }
    }

    @EventTarget(Priority.HIGH)
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) {
            return;
        }

        if (weaponOnly.getValue() && !ItemUtil.isHoldingSword()) {
            if (this.throwState != 0 || this.lastSlot != -1) {
                this.switchBack();
            }
            this.target = null;
            this.throwState = 0;
            this.throwsRemaining = 0;
            this.hasRotated = false;
            return;
        }

        if (!this.hasProjectile()) {
            this.target = null;
            this.throwState = 0;
            this.throwsRemaining = 0;
            this.hasRotated = false;
            this.switchBack();
            return;
        }

        if (this.throwState == 0) {
            this.target = this.getTarget();
            if (this.target == null) {
                return;
            }

            KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
            if (killAura != null && killAura.isEnabled()) {
                double distance = mc.field_1724.method_5739(this.target);
                if (distance <= killAura.attackRange.getValue()) {
                    return;
                }
            }

            if (System.currentTimeMillis() - this.lastThrowTime < this.calculateSmartDelay()) {
                return;
            }

            this.throwsRemaining = this.amount.getValue();
            this.throwState = 1;
            this.hasRotated = false;
        }

        if (this.throwState == 1) {
            this.switchToProjectile();
            this.throwState = 2;
        } else if (this.throwState == 2) {
            if (this.throwsRemaining > 0) {
                class_243 predictedPos = this.predictPosition(this.target);
                float[] rotations = this.getRotationsToPosition(predictedPos);

                event.setRotation(rotations[0], rotations[1], 2);
                event.setPervRotation(rotations[0], 2);
                this.hasRotated = true;
                this.throwState = 3;
            } else {
                this.throwState = 4;
            }
        } else if (this.throwState == 3) {
            this.throwProjectile();
            this.throwsRemaining--;

            if (this.throwsRemaining > 0) {
                this.throwState = 2;
            } else {
                this.throwState = 4;
            }
        } else if (this.throwState == 4) {
            this.switchBack();
            this.target = null;
            this.throwState = 0;
            this.hasRotated = false;
            this.lastThrowTime = System.currentTimeMillis();
        }
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (weaponOnly.getValue() && !ItemUtil.isHoldingSword()) {
            return;
        }
        if (this.hasRotated && RotationState.isActived() && RotationState.getPriority() == 2.0F && MoveUtil.isForwardPressed()) {
            MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
        }
    }

    @Override
    public void onEnabled() {
        this.target = null;
        this.lastSlot = -1;
        this.lastThrowTime = 0L;
        this.throwState = 0;
        this.throwsRemaining = 0;
        this.hasRotated = false;
    }

    @Override
    public void onDisabled() {
        this.switchBack();
        this.target = null;
        this.throwState = 0;
        this.throwsRemaining = 0;
        this.hasRotated = false;
    }

    private static class SmartPredictor {
        private final class_243[] positions = new class_243[20];
        private final long[] timestamps = new long[20];
        private final double[] movementPatterns = new double[4];
        private int index = 0;
        private double strafeFrequency = 0.0;
        private double jumpFrequency = 0.0;
        private long lastDirectionChange = 0L;
        private class_243 lastDirection = new class_243(0, 0, 0);
        private boolean isStrafing = false;
        private boolean isJumping = false;

        public void addPosition(class_243 pos, long time) {
            positions[index] = pos;
            timestamps[index] = time;

            if (index > 0) {
                analyzeMovementPattern();
            }

            index = (index + 1) % positions.length;
        }

        private void analyzeMovementPattern() {
            if (index < 2) return;

            int currentIdx = index;
            int prevIdx = (index - 1 + positions.length) % positions.length;

            class_243 currentPos = positions[currentIdx];
            class_243 prevPos = positions[prevIdx];

            if (currentPos == null || prevPos == null) return;

            class_243 movement = new class_243(
                    currentPos.field_1352 - prevPos.field_1352,
                    currentPos.field_1351 - prevPos.field_1351,
                    currentPos.field_1350 - prevPos.field_1350
            );

            if (Math.abs(movement.field_1352) > 0.01) {
                if (movement.field_1352 > 0) movementPatterns[0] += 0.1;
                else movementPatterns[1] += 0.1;
            }

            if (Math.abs(movement.field_1350) > 0.01) {
                if (movement.field_1350 > 0) movementPatterns[2] += 0.1;
                else movementPatterns[3] += 0.1;
            }

            for (int i = 0; i < movementPatterns.length; i++) {
                movementPatterns[i] *= 0.95;
            }

            class_243 currentDirection = normalizeMovement(movement);
            if (lastDirection.method_1033() > 0) {
                double dotProduct = lastDirection.field_1352 * currentDirection.field_1352 +
                        lastDirection.field_1350 * currentDirection.field_1350;
                if (dotProduct < 0.3) {
                    lastDirectionChange = timestamps[currentIdx];
                    strafeFrequency = Math.min(1.0, strafeFrequency + 0.2);
                    isStrafing = true;
                }
            }
            lastDirection = currentDirection;

            if (movement.field_1351 > 0.1) {
                jumpFrequency = Math.min(1.0, jumpFrequency + 0.15);
                isJumping = true;
            } else {
                jumpFrequency *= 0.9;
                isJumping = false;
            }

            if (System.currentTimeMillis() - lastDirectionChange > 500) {
                isStrafing = false;
                strafeFrequency *= 0.8;
            }
        }

        private class_243 normalizeMovement(class_243 movement) {
            double length = Math.sqrt(movement.field_1352 * movement.field_1352 + movement.field_1350 * movement.field_1350);
            if (length < 0.001) return new class_243(0, 0, 0);
            return new class_243(movement.field_1352 / length, 0, movement.field_1350 / length);
        }

        public class_243 predictNextPosition(double predictionTime) {
            if (index < 3) return positions[(index - 1 + positions.length) % positions.length];

            class_243 currentPos = positions[(index - 1 + positions.length) % positions.length];
            class_243 velocity = getCurrentVelocity();
            class_243 acceleration = getCurrentAcceleration();

            class_243 basePredict = new class_243(
                    currentPos.field_1352 + velocity.field_1352 * predictionTime + 0.5 * acceleration.field_1352 * predictionTime * predictionTime,
                    currentPos.field_1351 + velocity.field_1351 * predictionTime + 0.5 * acceleration.field_1351 * predictionTime * predictionTime,
                    currentPos.field_1350 + velocity.field_1350 * predictionTime + 0.5 * acceleration.field_1350 * predictionTime * predictionTime
            );

            class_243 behaviorPredict = predictBehaviorChange(currentPos, velocity, predictionTime);

            double baseWeight = Math.max(0.3, 1.0 - strafeFrequency);
            double behaviorWeight = strafeFrequency;

            return new class_243(
                    basePredict.field_1352 * baseWeight + behaviorPredict.field_1352 * behaviorWeight,
                    basePredict.field_1351 * baseWeight + behaviorPredict.field_1351 * behaviorWeight,
                    basePredict.field_1350 * baseWeight + behaviorPredict.field_1350 * behaviorWeight
            );
        }

        private class_243 predictBehaviorChange(class_243 currentPos, class_243 velocity, double predictionTime) {
            class_243 predicted = currentPos;
            double reactionTime = 0.3;
            if (isStrafing && predictionTime > reactionTime) {
                double timeSinceLastChange = (System.currentTimeMillis() - lastDirectionChange) / 1000.0;
                if (timeSinceLastChange > 0.8 && Math.random() < strafeFrequency) {
                    class_243 oppositeVel = new class_243(-velocity.field_1352 * 0.8, velocity.field_1351, -velocity.field_1350 * 0.8);
                    predicted = new class_243(
                            currentPos.field_1352 + oppositeVel.field_1352 * (predictionTime - reactionTime),
                            currentPos.field_1351 + oppositeVel.field_1351 * (predictionTime - reactionTime),
                            currentPos.field_1350 + oppositeVel.field_1350 * (predictionTime - reactionTime)
                    );
                } else {
                    class_243 continuedVel = new class_243(velocity.field_1352 * 0.9, velocity.field_1351, velocity.field_1350 * 0.9);
                    predicted = new class_243(
                            currentPos.field_1352 + continuedVel.field_1352 * predictionTime,
                            currentPos.field_1351 + continuedVel.field_1351 * predictionTime,
                            currentPos.field_1350 + continuedVel.field_1350 * predictionTime
                    );
                }
            } else {
                double totalPattern = movementPatterns[0] + movementPatterns[1] + movementPatterns[2] + movementPatterns[3];
                if (totalPattern > 0) {
                    double xTendency = (movementPatterns[0] - movementPatterns[1]) / totalPattern;
                    double zTendency = (movementPatterns[2] - movementPatterns[3]) / totalPattern;

                    class_243 tendencyVel = new class_243(
                            velocity.field_1352 + xTendency * 0.5,
                            velocity.field_1351 + (isJumping ? jumpFrequency * 0.3 : 0),
                            velocity.field_1350 + zTendency * 0.5
                    );

                    predicted = new class_243(
                            currentPos.field_1352 + tendencyVel.field_1352 * predictionTime,
                            currentPos.field_1351 + tendencyVel.field_1351 * predictionTime,
                            currentPos.field_1350 + tendencyVel.field_1350 * predictionTime
                    );
                }
            }

            return predicted;
        }

        private class_243 getCurrentVelocity() {
            if (index < 2) return new class_243(0, 0, 0);

            int currentIdx = (index - 1 + positions.length) % positions.length;
            int prevIdx = (index - 2 + positions.length) % positions.length;

            if (positions[currentIdx] == null || positions[prevIdx] == null) {
                return new class_243(0, 0, 0);
            }

            long timeDiff = timestamps[currentIdx] - timestamps[prevIdx];
            if (timeDiff <= 0) return new class_243(0, 0, 0);

            double deltaX = positions[currentIdx].field_1352 - positions[prevIdx].field_1352;
            double deltaY = positions[currentIdx].field_1351 - positions[prevIdx].field_1351;
            double deltaZ = positions[currentIdx].field_1350 - positions[prevIdx].field_1350;

            double timeInSeconds = timeDiff / 1000.0;
            return new class_243(deltaX / timeInSeconds, deltaY / timeInSeconds, deltaZ / timeInSeconds);
        }

        private class_243 getCurrentAcceleration() {
            if (index < 3) return new class_243(0, 0, 0);

            class_243 vel1 = getVelocityBetween((index - 1 + positions.length) % positions.length,
                    (index - 2 + positions.length) % positions.length);
            class_243 vel2 = getVelocityBetween((index - 2 + positions.length) % positions.length,
                    (index - 3 + positions.length) % positions.length);

            int currentIdx = (index - 1 + positions.length) % positions.length;
            int prevIdx = (index - 2 + positions.length) % positions.length;

            long timeDiff = timestamps[currentIdx] - timestamps[prevIdx];
            if (timeDiff <= 0) return new class_243(0, 0, 0);

            double timeInSeconds = timeDiff / 1000.0;
            return new class_243(
                    (vel1.field_1352 - vel2.field_1352) / timeInSeconds,
                    (vel1.field_1351 - vel2.field_1351) / timeInSeconds,
                    (vel1.field_1350 - vel2.field_1350) / timeInSeconds
            );
        }

        private class_243 getVelocityBetween(int idx1, int idx2) {
            if (positions[idx1] == null || positions[idx2] == null) {
                return new class_243(0, 0, 0);
            }

            long timeDiff = timestamps[idx1] - timestamps[idx2];
            if (timeDiff <= 0) return new class_243(0, 0, 0);

            double deltaX = positions[idx1].field_1352 - positions[idx2].field_1352;
            double deltaY = positions[idx1].field_1351 - positions[idx2].field_1351;
            double deltaZ = positions[idx1].field_1350 - positions[idx2].field_1350;

            double timeInSeconds = timeDiff / 1000.0;
            return new class_243(deltaX / timeInSeconds, deltaY / timeInSeconds, deltaZ / timeInSeconds);
        }
    }
}
