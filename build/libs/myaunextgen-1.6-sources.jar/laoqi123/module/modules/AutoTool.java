package laoqi123.module.modules;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.TickEvent;
import laoqi123.module.Module;
import laoqi123.util.ItemUtil;
import laoqi123.util.KeyBindUtil;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.util.TeamUtil;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public class AutoTool extends Module {
    private static final class_310 mc = class_310.method_1551();
    private int currentToolSlot = -1;
    private int previousSlot = -1;
    private int tickDelayCounter = 0;
    public final IntProperty switchDelay = new IntProperty("delay", 0, 0, 5);
    public final BooleanProperty switchBack = new BooleanProperty("switch-back", true);
    public final BooleanProperty sneakOnly = new BooleanProperty("sneak-only", true);

    public AutoTool() {
        super("AutoTool", false);
    }

    public boolean isKillAura() {
        KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
        if (!killAura.isEnabled()) return false;
        return TeamUtil.isEntityLoaded(killAura.getTarget()) && killAura.isAttackAllowed();
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            if (this.currentToolSlot != -1 && this.currentToolSlot != mc.field_1724.method_31548().field_7545) {
                this.currentToolSlot = -1;
                this.previousSlot = -1;
            }
            if (mc.field_1765 != null
                    && mc.field_1765.method_17783() == class_239.class_240.field_1332
                    && mc.field_1690.field_1886.method_1434()
                    && !mc.field_1724.method_6115()
                    && !isKillAura()) {
                if (this.tickDelayCounter >= this.switchDelay.getValue()
                        && (!(Boolean) this.sneakOnly.getValue() || KeyBindUtil.isKeyDown(mc.field_1690.field_1832))) {
                    int slot = ItemUtil.findInventorySlot(
                            mc.field_1724.method_31548().field_7545, mc.field_1687.method_8320(((class_3965) mc.field_1765).method_17777()).method_26204()
                    );
                    if (mc.field_1724.method_31548().field_7545 != slot) {
                        if (this.previousSlot == -1) {
                            this.previousSlot = mc.field_1724.method_31548().field_7545;
                        }
                        mc.field_1724.method_31548().field_7545 = this.currentToolSlot = slot;
                    }
                }
                this.tickDelayCounter++;
            } else {
                if (this.switchBack.getValue() && this.previousSlot != -1) {
                    mc.field_1724.method_31548().field_7545 = this.previousSlot;
                }
                this.currentToolSlot = -1;
                this.previousSlot = -1;
                this.tickDelayCounter = 0;
            }
        }
    }

    @Override
    public void onDisabled() {
        this.currentToolSlot = -1;
        this.previousSlot = -1;
        this.tickDelayCounter = 0;
    }
}
