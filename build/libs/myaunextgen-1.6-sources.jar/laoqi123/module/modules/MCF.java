package laoqi123.module.modules;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.events.KeyEvent;
import laoqi123.module.Module;
import laoqi123.util.ChatUtil;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;

public class MCF extends Module {
    private static final class_310 mc = class_310.method_1551();

    public MCF() {
        super("MCF", false, true);
    }

    @EventTarget
    public void onKey(KeyEvent event) {
        if (this.isEnabled() && event.getKey() == -98) {
            if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331 && ((class_3966) mc.field_1765).method_17782() instanceof class_1657) {
                String hitName = ((class_3966) mc.field_1765).method_17782().method_5477().getString();
                if (!Myau.friendManager.isFriend(hitName)) {
                    Myau.friendManager.add(hitName);
                    ChatUtil.sendFormatted(String.format("%sAdded &o%s&r to your friend list&r", Myau.clientName, hitName));
                } else {
                    Myau.friendManager.remove(hitName);
                    ChatUtil.sendFormatted(String.format("%sRemoved &o%s&r from your friend list&r", Myau.clientName, hitName));
                }
            }
        }
    }
}
