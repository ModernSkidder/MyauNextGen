package laoqi123.module.modules;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.StrafeEvent;
import laoqi123.events.UpdateEvent;
import laoqi123.module.Module;
import laoqi123.property.properties.FloatProperty;
import laoqi123.util.KeyBindUtil;
import laoqi123.util.MoveUtil;
import net.minecraft.class_310;

public class Fly extends Module {
    private static final class_310 mc = class_310.method_1551();
    private double verticalMotion = 0.0;
    public final FloatProperty hSpeed = new FloatProperty("horizontal-speed", 1.0F, 0.0F, 100.0F);
    public final FloatProperty vSpeed = new FloatProperty("vertical-speed", 1.0F, 0.0F, 100.0F);

    public Fly() {
        super("Fly", false);
    }

    @EventTarget
    public void onStrafe(StrafeEvent event) {
        if (this.isEnabled()) {
            if (mc.field_1724.method_23318() % 1.0 != 0.0) {
                mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, this.verticalMotion, mc.field_1724.method_18798().field_1350);
            }
            MoveUtil.setSpeed(0.0);
            event.setFriction((float) MoveUtil.getBaseMoveSpeed() * this.hSpeed.getValue());
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (this.isEnabled() && event.getType() == EventType.PRE) {
            this.verticalMotion = 0.0;
            if (mc.field_1755 == null) {
                if (KeyBindUtil.isKeyDown(mc.field_1690.field_1903)) {
                    this.verticalMotion = this.verticalMotion + this.vSpeed.getValue().doubleValue() * 0.42F;
                }
                if (KeyBindUtil.isKeyDown(mc.field_1690.field_1832)) {
                    this.verticalMotion = this.verticalMotion - this.vSpeed.getValue().doubleValue() * 0.42F;
                }
                mc.field_1690.field_1832.method_23481(false);
            }
        }
    }

    @Override
    public void onDisabled() {
        if (mc.field_1724 != null) {
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.0, mc.field_1724.method_18798().field_1350);
        }
        MoveUtil.setSpeed(0.0);
        mc.field_1690.field_1832.method_23481(KeyBindUtil.isKeyDown(mc.field_1690.field_1832));
    }
}
