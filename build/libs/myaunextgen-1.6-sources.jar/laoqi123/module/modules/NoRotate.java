package laoqi123.module.modules;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.LoadWorldEvent;
import laoqi123.events.PacketEvent;
import laoqi123.module.Module;
import laoqi123.util.PacketUtil;
import laoqi123.util.RandomUtil;
import laoqi123.util.RotationUtil;
import net.minecraft.class_2708;
import net.minecraft.class_2709;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_7438;
import java.util.Set;

public class NoRotate extends Module {
    private static final class_310 mc = class_310.method_1551();
    private boolean reset = false;

    public NoRotate() {
        super("NoRotate", false);
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (this.isEnabled() && event.getType() == EventType.RECEIVE && !event.isCancelled() && mc.field_1724 != null && mc.field_1687 != null) {
            if (mc.field_1724.method_36454() != -180.0F || mc.field_1724.method_36455() != 0.0F) {
                if (event.getPacket() instanceof class_7438) {
                    class_7438 chatPacket = (class_7438) event.getPacket();
                    String msg = chatPacket.comp_1103() != null ? chatPacket.comp_1103().getString() : chatPacket.comp_1102().comp_1090();
                    if (msg.contains("§e§lProtect your bed and destroy the enemy beds.") || msg.contains("§eYou will respawn in §r§c1 §r§esecond!")) {
                        this.reset = true;
                    }
                }
                if (event.getPacket() instanceof class_2708) {
                    if (this.reset) {
                        this.reset = false;
                        return;
                    }
                    class_2708 packet = (class_2708) event.getPacket();
                    event.setCancelled(true);
                    double x = packet.comp_3228().comp_3148().field_1352;
                    double y = packet.comp_3228().comp_3148().field_1351;
                    double z = packet.comp_3228().comp_3148().field_1350;
                    float yaw = packet.comp_3228().comp_3150();
                    float pitch = packet.comp_3228().comp_3151();
                    Set<class_2709> flags = packet.comp_3229();
                    if (flags.contains(class_2709.field_12400)) {
                        x += mc.field_1724.method_23317();
                    } else {
                        mc.field_1724.method_18800(0.0, mc.field_1724.method_18798().field_1351, mc.field_1724.method_18798().field_1350);
                    }
                    if (flags.contains(class_2709.field_12398)) {
                        y += mc.field_1724.method_23318();
                    } else {
                        mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.0, mc.field_1724.method_18798().field_1350);
                    }
                    if (flags.contains(class_2709.field_12403)) {
                        z += mc.field_1724.method_23321();
                    } else {
                        mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, mc.field_1724.method_18798().field_1351, 0.0);
                    }
                    if (flags.contains(class_2709.field_12397)) {
                        pitch += mc.field_1724.method_36455();
                    }
                    if (flags.contains(class_2709.field_12401)) {
                        yaw += mc.field_1724.method_36454();
                    }
                    mc.field_1724
                            .method_5641(
                                    x,
                                    y,
                                    z,
                                    RotationUtil.quantizeAngle(mc.field_1724.method_36454() + RandomUtil.nextFloat(-0.01F, 0.01F)),
                                    RotationUtil.quantizeAngle(mc.field_1724.method_36455() + RandomUtil.nextFloat(-0.01F, 0.01F))
                            );
                    PacketUtil.sendPacketNoEvent(
                            new class_2828.class_2830(
                                    mc.field_1724.method_23317(), mc.field_1724.method_5829().field_1322, mc.field_1724.method_23321(), yaw % 360.0F, pitch % 360.0F, false, mc.field_1724.field_5976
                            )
                    );
                }
            }
        }
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        this.reset = false;
    }

    @Override
    public void onDisabled() {
        this.reset = false;
    }
}
