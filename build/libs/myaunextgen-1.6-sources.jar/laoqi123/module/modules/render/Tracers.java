package laoqi123.module.modules.render;

import laoqi123.Myau;
import laoqi123.enums.ChatColors;
import laoqi123.event.EventTarget;
import laoqi123.events.Render2DEvent;
import laoqi123.events.Render3DEvent;
import laoqi123.module.Module;
import laoqi123.util.RenderUtil;
import laoqi123.util.RotationUtil;
import laoqi123.util.TeamUtil;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.PercentProperty;
import laoqi123.property.properties.ModeProperty;
import laoqi123.property.properties.IntProperty;
import java.awt.*;
import java.util.stream.Collectors;

public class Tracers extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final ModeProperty colorMode = new ModeProperty("color", 0, new String[]{"DEFAULT", "TEAMS", "HUD"});
    public final BooleanProperty drawLines = new BooleanProperty("lines", true);
    public final BooleanProperty drawArrows = new BooleanProperty("arrows", false);
    public final PercentProperty opacity = new PercentProperty("opacity", 100);
    public final IntProperty distance = new IntProperty("distance", 512, 0, 512);
    public final BooleanProperty showPlayers = new BooleanProperty("players", true);
    public final BooleanProperty showFriends = new BooleanProperty("friends", true);
    public final BooleanProperty showEnemies = new BooleanProperty("enemies", true);
    public final BooleanProperty showBots = new BooleanProperty("bots", false);

    private boolean shouldRender(class_1657 entityPlayer) {
        if (entityPlayer.field_6213 > 0) {
            return false;
        } else if (mc.method_1560().method_5739(entityPlayer) > (float) this.distance.getValue()) {
            return false;
        } else if (entityPlayer != mc.field_1724 && entityPlayer != mc.method_1560()) {
            if (TeamUtil.isBot(entityPlayer)) {
                return this.showBots.getValue();
            } else if (TeamUtil.isFriend(entityPlayer)) {
                return this.showFriends.getValue();
            } else {
                return TeamUtil.isTarget(entityPlayer) ? this.showEnemies.getValue() : this.showPlayers.getValue();
            }
        } else {
            return false;
        }
    }

    private Color getEntityColor(class_1657 entityPlayer, float alpha) {
        if (TeamUtil.isFriend(entityPlayer)) {
            Color color = Myau.friendManager.getColor();
            return new Color((float) color.getRed() / 255.0F, (float) color.getGreen() / 255.0F, (float) color.getBlue() / 255.0F, alpha);
        } else if (TeamUtil.isTarget(entityPlayer)) {
            Color color = Myau.targetManager.getColor();
            return new Color((float) color.getRed() / 255.0F, (float) color.getGreen() / 255.0F, (float) color.getBlue() / 255.0F, alpha);
        } else {
            switch (this.colorMode.getValue()) {
                case 0:
                    return TeamUtil.getTeamColor(entityPlayer, alpha);
                case 1:
                    int teamColor = TeamUtil.isSameTeam(entityPlayer) ? ChatColors.BLUE.toAwtColor() : ChatColors.RED.toAwtColor();
                    return new Color(teamColor & Color.WHITE.getRGB() | (int) (alpha * 255.0F) << 24, true);
                case 2:
                    int color = ((HUD) Myau.moduleManager.modules.get(HUD.class)).getColor(System.currentTimeMillis()).getRGB();
                    return new Color(color & Color.WHITE.getRGB() | (int) (alpha * 255.0F) << 24, true);
                default:
                    return new Color(1.0F, 1.0F, 1.0F, alpha);
            }
        }
    }

    public Tracers() {
        super("Tracers", false);
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (this.isEnabled() && this.drawLines.getValue()) {
            RenderUtil.enableRenderState();
            class_243 position;
            float partialTicks = mc.method_61966().method_60637(true);
            if (mc.field_1690.method_31044() == class_5498.field_26664) {
                position = new class_243(0.0, 0.0, 1.0)
                        .method_1037(
                                (float) (
                                        -Math.toRadians(
                                                RenderUtil.lerpFloat(
                                                        mc.method_1560().method_36455(),
                                                        mc.method_1560().field_6004,
                                                        partialTicks
                                                )
                                        )
                                )
                        )
                        .method_1024(
                                (float) (
                                        -Math.toRadians(
                                                RenderUtil.lerpFloat(
                                                        mc.method_1560().method_36454(),
                                                        mc.method_1560().field_5982,
                                                        partialTicks
                                                )
                                        )
                                )
                        );
            } else {
                position = new class_243(0.0, 0.0, 0.0)
                        .method_1037((float) (-Math.toRadians(mc.field_1773.method_19418().method_19329())))
                        .method_1024((float) (-Math.toRadians(mc.field_1773.method_19418().method_19330())));
            }
            position = new class_243(position.field_1352, position.field_1351 + (double) mc.method_1560().method_5751(), position.field_1350);
            for (class_1657 player : TeamUtil.getLoadedEntitiesSorted().stream().filter(entity -> entity instanceof class_1657 && this.shouldRender((class_1657) entity)).map(class_1657.class::cast).collect(Collectors.toList())) {
                Color color = this.getEntityColor(player, (float) this.opacity.getValue() / 100.0F);
                double x = RenderUtil.lerpDouble(player.method_23317(), player.field_6014, event.getPartialTicks());
                double y = RenderUtil.lerpDouble(player.method_23318(), player.field_6036, event.getPartialTicks()) - (player.method_5715() ? 0.125 : 0.0);
                double z = RenderUtil.lerpDouble(player.method_23321(), player.field_5969, event.getPartialTicks());
                RenderUtil.drawLine3D(
                        position,
                        x,
                        y + (double) player.method_5751(),
                        z,
                        (float) color.getRed() / 255.0F,
                        (float) color.getGreen() / 255.0F,
                        (float) color.getBlue() / 255.0F,
                        (float) color.getAlpha() / 255.0F,
                        1.5F
                );
            }
            RenderUtil.disableRenderState();
        }
    }

    @EventTarget
    public void onRender(Render2DEvent event) {
        if (this.isEnabled() && this.drawArrows.getValue()) {
            for (class_1657 player : TeamUtil.getLoadedEntitiesSorted().stream().filter(entity -> entity instanceof class_1657 && this.shouldRender((class_1657) entity)).map(class_1657.class::cast).collect(Collectors.toList())) {
                float yawBetween = RotationUtil.getYawBetween(
                        RenderUtil.lerpDouble(mc.field_1724.method_23317(), mc.field_1724.field_6014, event.getPartialTicks()),
                        RenderUtil.lerpDouble(mc.field_1724.method_23321(), mc.field_1724.field_5969, event.getPartialTicks()),
                        RenderUtil.lerpDouble(player.method_23317(), player.field_6014, event.getPartialTicks()),
                        RenderUtil.lerpDouble(player.method_23321(), player.field_5969, event.getPartialTicks())
                );
                if (mc.field_1690.method_31044() == class_5498.field_26666) {
                    yawBetween += 180.0F;
                }
                float arrowDirX = (float) Math.sin(Math.toRadians(yawBetween));
                float arrowDirY = (float) Math.cos(Math.toRadians(yawBetween)) * -1.0F;
                float opacity = this.opacity.getValue().floatValue() / 100.0F;
                yawBetween = Math.abs(class_3532.method_15393(yawBetween));
                if (yawBetween < 30.0F) {
                    opacity = 0.0F;
                } else if (yawBetween < 60.0F) {
                    opacity *= (yawBetween - 30.0F) / 30.0F;
                }
                HUD hud = (HUD) Myau.moduleManager.modules.get(HUD.class);
                float scale = hud.scale.getValue();
                RenderUtil.enableRenderState();
                RenderUtil.drawTriangle(
                        (float) mc.method_22683().method_4486() / 2.0F + scale * (55.0F * arrowDirX + 1.0F),
                        (float) mc.method_22683().method_4502() / 2.0F + scale * (55.0F * arrowDirY + 1.0F),
                        (float) (Math.atan2(arrowDirY, arrowDirX) + Math.PI),
                        10.0F * scale,
                        this.getEntityColor(player, opacity).getRGB()
                );
                RenderUtil.disableRenderState();
            }
        }
    }
}
