package laoqi123.module.modules.render;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.impl.Render2DEvent;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.IntValue;
import net.minecraft.class_1799;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2506;
import net.minecraft.class_2680;
import net.minecraft.class_2742;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import laoqi123.util.RenderUtil;
import org.joml.Vector4d;

import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class BedPlates extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final IntValue range = new IntValue("Range", 1, 1, 7);

    private final List<BedRenderData> renderDataList = new ArrayList<>();

    public BedPlates() {
        super("BedPlates", false);
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        this.renderDataList.clear();
        if (!this.isEnabled() || mc.field_1724 == null || mc.field_1687 == null) return;

        BedESP bedESP = (BedESP) Myau.moduleManager.modules.get(BedESP.class);
        if (bedESP == null || bedESP.beds.isEmpty()) return;

        double screenScale = mc.method_22683().method_4495();

        for (class_2338 bedPos : bedESP.beds) {
            class_2680 state = mc.field_1687.method_8320(bedPos);
            if (!(state.method_26204() instanceof class_2244)) continue;
            if (state.method_11654(class_2244.field_9967) != class_2742.field_12560) continue;

            class_2338 footPos = bedPos.method_10093(state.method_11654(class_2244.field_11177).method_10153());
            class_2680 footState = mc.field_1687.method_8320(footPos);
            if (!(footState.method_26204() instanceof class_2244)) continue;

            double minX = Math.min(bedPos.method_10263(), footPos.method_10263());
            double minY = bedPos.method_10264();
            double minZ = Math.min(bedPos.method_10260(), footPos.method_10260());
            double maxX = Math.max(bedPos.method_10263(), footPos.method_10263()) + 1.0;
            double maxY = bedPos.method_10264() + 1.0;
            double maxZ = Math.max(bedPos.method_10260(), footPos.method_10260()) + 1.0;

            Vector4d pos = RenderUtil.projectToScreen(new class_238(minX, minY, minZ, maxX, maxY, maxZ), screenScale);

            if (pos == null) continue;

            float screenX = (float) ((pos.x + pos.z) / 2.0);
            float screenY = (float) pos.y - 30;

            List<BlockEntry> blocks = collectProtectionBlocks(bedPos, footPos);
            if (blocks.isEmpty()) continue;

            blocks.sort((a, b) -> Float.compare(b.hardness, a.hardness));

            float itemSize = 16;
            float padding = 2;
            float totalWidth = blocks.size() * (itemSize + padding) + padding;
            float bgHeight = itemSize + padding * 2;

            double centerX = (bedPos.method_10263() + footPos.method_10263()) / 2.0 + 0.5;
            double centerY = bedPos.method_10264() + 0.5;
            double centerZ = (bedPos.method_10260() + footPos.method_10260()) / 2.0 + 0.5;
            float dist = (float) Math.sqrt(mc.field_1724.method_5649(centerX, centerY, centerZ));

            renderDataList.add(new BedRenderData(screenX - totalWidth / 2, screenY - bgHeight / 2, totalWidth, bgHeight, blocks, dist));
        }
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (this.renderDataList.isEmpty()) return;
        class_332 context = event.getContext();

        for (BedRenderData data : this.renderDataList) {
            float dist = data.dist;
            float scale = class_3532.method_15363(1.0f / (1.0f + dist * 0.08f) * 1.5f, 0.4f, 2.0f);

            float cx = data.bgX + data.totalWidth / 2;
            float cy = data.bgY + data.bgHeight / 2;

            float width = data.totalWidth * scale;
            float height = data.bgHeight * scale;
            float x = cx - width / 2;
            float y = cy - height / 2;

            context.method_25294((int) x, (int) y, (int) (x + width), (int) (y + height), new Color(0, 0, 0, 110).getRGB());

            float itemX = x + 2 * scale;
            float itemY = y + 2 * scale;

            for (BlockEntry entry : data.blocks) {
                RenderUtil.renderItemInGUI(new class_1799(entry.block.method_8389()), (int) itemX, (int) itemY);
                itemX += 18 * scale;
            }
        }

        this.renderDataList.clear();
    }

    private static final class_2248[] ALLOWED_BLOCKS = {
            class_2246.field_10446,
            class_2246.field_10415,
            class_2246.field_10033,
            class_2246.field_10087,
            class_2246.field_10471,
            class_2246.field_9983,
            class_2246.field_10161,
            class_2246.field_10431,
            class_2246.field_10540,
            class_2246.field_10225
    };

    private boolean isBlockAllowed(class_2248 block) {
        for (class_2248 allowed : ALLOWED_BLOCKS) {
            if (block == allowed) {
                return true;
            }
        }
        return false;
    }

    private List<BlockEntry> collectProtectionBlocks(class_2338 head, class_2338 foot) {
        Map<class_2248, BlockEntry> blockMap = new LinkedHashMap<>();
        int centerX = (head.method_10263() + foot.method_10263()) / 2;
        int centerY = head.method_10264();
        int centerZ = (head.method_10260() + foot.method_10260()) / 2;
        int r = range.getValue();

        for (int dx = -r; dx <= r; dx++) {
            for (int dy = 0; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (r == 1 && Math.abs(dx) + Math.abs(dz) > 1) continue;

                    class_2338 pos = new class_2338(centerX + dx, centerY + dy, centerZ + dz);
                    class_2248 block = mc.field_1687.method_8320(pos).method_26204();

                    if (!isBlockAllowed(block)) continue;

                    class_2248 displayBlock = block instanceof class_2506 ? class_2246.field_10033 : block;
                    if (blockMap.containsKey(displayBlock)) continue;

                    float hardness = block.method_36555();
                    blockMap.put(displayBlock, new BlockEntry(displayBlock, hardness < 0 ? 100 : hardness));
                }
            }
        }
        return new ArrayList<>(blockMap.values());
    }

    private static class BlockEntry {
        final class_2248 block;
        final float hardness;
        BlockEntry(class_2248 block, float hardness) {
            this.block = block;
            this.hardness = hardness;
        }
    }

    private static class BedRenderData {
        float bgX, bgY, totalWidth, bgHeight;
        List<BlockEntry> blocks;
        float dist;
        BedRenderData(float x, float y, float w, float h, List<BlockEntry> b, float d) {
            this.bgX = x;
            this.bgY = y;
            this.totalWidth = w;
            this.bgHeight = h;
            this.blocks = b;
            this.dist = d;
        }
    }
}
