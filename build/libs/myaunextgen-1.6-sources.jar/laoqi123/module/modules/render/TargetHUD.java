package laoqi123.module.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.Myau;
import laoqi123.enums.ChatColors;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.PacketEvent;
import laoqi123.events.Render2DEvent;
import laoqi123.font.UFontRenderer;
import laoqi123.module.Module;
import laoqi123.mixin.PlayerInteractEntityC2SPacketAccessor;
import laoqi123.module.modules.combat.KillAura;
import laoqi123.property.properties.*;
import laoqi123.util.ColorUtil;
import laoqi123.util.RenderUtil;
import laoqi123.util.RotationUtil;
import laoqi123.util.TeamUtil;
import laoqi123.util.TimerUtil;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2824;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_640;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class TargetHUD extends Module {
    private static final class_310 mc = class_310.method_1551();
    private static final DecimalFormat healthFormat = new DecimalFormat("0.0", new DecimalFormatSymbols(Locale.US));
    private static final DecimalFormat diffFormat = new DecimalFormat("+0.0;-0.0", new DecimalFormatSymbols(Locale.US));
    private static final float FIXED_BAR_WIDTH = 130f;
    private static final float ANIMATION_SPEED = 0.1f;

    private final TimerUtil lastAttackTimer = new TimerUtil();
    private final TimerUtil animTimer = new TimerUtil();
    private final TimerUtil scaleAnimTimer = new TimerUtil();
    private final TimerUtil targetLostTimer = new TimerUtil();
    private class_1309 lastTarget = null;
    private class_1309 target = null;
    private class_2960 headTexture = null;
    private float oldHealth = 0.0F;
    private float newHealth = 0.0F;
    private float maxHealth = 0.0F;
    private float scaleAnimation = 0.0F;
    private boolean isAnimatingOut = false;
    private boolean targetLost = false;
    private class_1309 lastRenderTarget = null;

    private final Map<Integer, Float> displayHealths = new HashMap<>();
    private final Map<Integer, Float> delayedHealths = new HashMap<>();
    private final Map<Integer, class_2960> headTextures = new HashMap<>();
    private final Map<Integer, Float> entityAlphas = new HashMap<>();
    private final Map<Integer, class_1309> entityCache = new HashMap<>();
    private final TimerUtil healthDelayTimer = new TimerUtil();

    private boolean dragging = false;
    private int dragStartX = 0;
    private int dragStartY = 0;
    private int dragStartOffX = 0;
    private int dragStartOffY = 0;
    private boolean positionLocked = true;

    private UFontRenderer modernFont;

    public final ModeProperty style = new ModeProperty("Style", 0, new String[]{"Myau", "Adjust"});
    public final ModeProperty fontMode = new ModeProperty("font-mode", 0, new String[]{"Minecraft", "Modern"});
    public final ModeProperty color = new ModeProperty("color", 0, new String[]{"DEFAULT", "HUD"});
    public final ModeProperty posX = new ModeProperty("position-x", 1, new String[]{"LEFT", "MIDDLE", "RIGHT"});
    public final ModeProperty posY = new ModeProperty("position-y", 1, new String[]{"TOP", "MIDDLE", "BOTTOM"});
    public final FloatProperty scale = new FloatProperty("scale", 1.0F, 0.5F, 1.5F);
    public final IntProperty offX = new IntProperty("offset-x", 0, -500, 500);
    public final IntProperty offY = new IntProperty("offset-y", 40, -500, 500);
    public final PercentProperty background = new PercentProperty("background", 25);
    public final BooleanProperty head = new BooleanProperty("head", true);
    public final BooleanProperty indicator = new BooleanProperty("indicator", true);
    public final BooleanProperty outline = new BooleanProperty("outline", false);
    public final BooleanProperty animations = new BooleanProperty("animations", true);
    public final BooleanProperty shadow = new BooleanProperty("shadow", true);
    public final BooleanProperty kaOnly = new BooleanProperty("ka-only", true);
    public final BooleanProperty chatPreview = new BooleanProperty("chat-preview", false);
    public final BooleanProperty trackTarget = new BooleanProperty("track-target", false);
    public final ModeProperty trackingMode = new ModeProperty("tracking-mode", 0, new String[]{"TOP", "MIDDLE", "LEFT", "RIGHT"}, trackTarget::getValue);
    public final BooleanProperty distanceScale = new BooleanProperty("distance-scale", true, trackTarget::getValue);

    public TargetHUD() {
        super("TargetHUD", false, true);
    }

    @Override
    public void onDisabled() {
        this.target = null;
        this.lastRenderTarget = null;
        this.lastTarget = null;
        this.isAnimatingOut = false;
        this.targetLost = false;
        this.scaleAnimation = 0.0F;
        this.entityAlphas.clear();
        this.entityCache.clear();
        this.displayHealths.clear();
        this.delayedHealths.clear();
        this.headTextures.clear();
        this.dragging = false;
    }

    private interface FontDrawer {
        int getWidth(String text);

        void draw(String text, float x, float y, int color, boolean shadow);
    }

    private FontDrawer getFontRenderer(class_332 context) {
        if (fontMode.getValue() == 1) {
            if (modernFont == null) {
                try {
                    modernFont = new UFontRenderer("GoogleSans-Regular", 20);
                } catch (Exception e) {
                    modernFont = null;
                }
            }
            if (modernFont != null) {
                return new FontDrawer() {
                    @Override
                    public int getWidth(String text) {
                        return modernFont.getStringWidth(text);
                    }

                    @Override
                    public void draw(String text, float x, float y, int color, boolean shadow) {
                        modernFont.drawString(text, x, y, color, shadow);
                    }
                };
            }
        }
        return new FontDrawer() {
            @Override
            public int getWidth(String text) {
                return mc.field_1772.method_1727(text);
            }

            @Override
            public void draw(String text, float x, float y, int color, boolean shadow) {
                context.method_51433(mc.field_1772, text, Math.round(x), Math.round(y), color, shadow);
            }
        };
    }

    private static float sx(float localX, float posX, float barTotalWidth, float finalScale) {
        return posX + barTotalWidth / 2.0F + (localX - barTotalWidth / 2.0F) * finalScale;
    }

    private static float sy(float localY, float posY, float finalScale) {
        return posY + 13.5F + (localY - 13.5F) * finalScale;
    }

    private class_1309 resolveTarget() {
        KillAura killAura = (KillAura) Myau.moduleManager.getModule(KillAura.class);
        if (killAura != null && killAura.isEnabled() && killAura.isAttackAllowed() && TeamUtil.isEntityLoaded(killAura.getTarget())) {
            return killAura.getTarget();
        } else if (!this.kaOnly.getValue()
                && !this.lastAttackTimer.hasTimeElapsed(1500L)
                && TeamUtil.isEntityLoaded(this.lastTarget)) {
            return this.lastTarget;
        } else {
            return this.chatPreview.getValue() && mc.field_1755 instanceof class_408 ? mc.field_1724 : null;
        }
    }

    private List<class_1309> resolveTargets() {
        List<class_1309> result = new ArrayList<>();
        KillAura killAura = (KillAura) Myau.moduleManager.getModule(KillAura.class);
        if (killAura != null && killAura.isEnabled() && killAura.isAttackAllowed()) {
            List<class_1309> kaTargets = killAura.getTargets();
            if (kaTargets != null) {
                for (class_1309 t : kaTargets) {
                    if (TeamUtil.isEntityLoaded(t)) result.add(t);
                }
            }
        }
        if (result.isEmpty() && chatPreview.getValue() && mc.field_1755 instanceof class_408) {
            result.add(mc.field_1724);
        }
        return result;
    }

    private class_2960 getSkin(class_1309 entity) {
        if (entity instanceof class_1657 && mc.method_1562() != null) {
            class_640 info = mc.method_1562().method_2874(entity.method_5477().getString());
            if (info != null && info.method_52810() != null) {
                return info.method_52810().comp_1626();
            }
        }
        return null;
    }

    private Color getTargetColor(class_1309 entity) {
        if (entity instanceof class_1657) {
            if (TeamUtil.isFriend((class_1657) entity)) {
                return Myau.friendManager.getColor();
            }
            if (TeamUtil.isTarget((class_1657) entity)) {
                return Myau.targetManager.getColor();
            }
        }
        switch (this.color.getValue()) {
            case 0:
                if (!(entity instanceof class_1657)) {
                    return new Color(-1);
                }
                return TeamUtil.getTeamColor((class_1657) entity, 1.0F);
            case 1:
                HUD hud = (HUD) Myau.moduleManager.getModule(HUD.class);
                if (hud != null) {
                    int rgb = hud.getColor(System.currentTimeMillis()).getRGB();
                    return new Color(rgb);
                }
                return new Color(-1);
            default:
                return new Color(-1);
        }
    }

    private boolean isLeftMouseDown() {
        return GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    @EventTarget
    public void onRender(Render2DEvent event) {
        if (!this.isEnabled() || mc.field_1724 == null) return;

        if (style.getValue() == 1) {
            renderAdjustMode(event.getContext());
            return;
        }

        class_1309 currentTarget = this.resolveTarget();

        if (currentTarget != null) {
            targetLost = false;
            if (!isAnimatingOut) {
                if (this.target != currentTarget) {
                    if (this.target == null) {
                        scaleAnimTimer.reset();
                    }
                    this.target = currentTarget;
                    this.lastRenderTarget = currentTarget;
                    this.headTexture = null;
                    this.animTimer.setTime();
                    this.maxHealth = this.target.method_6063() / 2.0F;
                    float heal = this.target.method_6032() / 2.0F;
                    this.oldHealth = heal;
                    this.newHealth = heal;
                }
                updateScaleAnimation();

                renderMyauMode(event.getContext());
            }
        } else if (this.target != null) {
            if (!targetLost) {
                targetLost = true;
                targetLostTimer.reset();
            }

            if (targetLostTimer.hasTimeElapsed(50L)) {
                isAnimatingOut = true;
                scaleAnimTimer.reset();
                this.target = null;
            } else {
                renderMyauMode(event.getContext());
            }
        }

        if (isAnimatingOut) {
            updateScaleAnimation();
            if (scaleAnimation > 0.0F && lastRenderTarget != null) {
                this.target = lastRenderTarget;
                renderMyauMode(event.getContext());
                this.target = null;
            } else if (scaleAnimation <= 0.0F) {
                isAnimatingOut = false;
                targetLost = false;
                lastRenderTarget = null;
            }
        }
    }

    private void updateScaleAnimation() {
        long elapsedTime = scaleAnimTimer.getElapsedTime();
        float animationDuration = 200.0F;

        if (!isAnimatingOut) {
            scaleAnimation = Math.min(elapsedTime / animationDuration, 1.0F);
        } else {
            scaleAnimation = Math.max(1.0F - (elapsedTime / animationDuration), 0.0F);
        }
        scaleAnimation = easeOutQuart(scaleAnimation);
    }

    private float easeOutQuart(float t) {
        return 1.0F - (float) Math.pow(1.0F - t, 4.0F);
    }

    private void renderMyauMode(class_332 context) {
        FontDrawer fr = getFontRenderer(context);
        float health = (mc.field_1724.method_6032() + mc.field_1724.method_6067()) / 2.0F;
        float abs = this.target.method_6067() / 2.0F;
        float heal = this.target.method_6032() / 2.0F;

        if (!this.animations.getValue() || this.animTimer.hasTimeElapsed(150L)) {
            this.oldHealth = this.newHealth;
            this.newHealth = heal;
            this.maxHealth = this.target.method_6063() / 2.0F;
            if (this.oldHealth != this.newHealth) {
                this.animTimer.reset();
            }
        }

        class_2960 resourceLocation = this.getSkin(this.target);
        if (resourceLocation != null) {
            this.headTexture = resourceLocation;
        }

        float elapsedTime = (float) Math.min(Math.max(this.animTimer.getElapsedTime(), 0L), 150L);
        float healthRatio = Math.min(Math.max(RenderUtil.lerpFloat(this.newHealth, this.oldHealth, elapsedTime / 150.0F) / this.maxHealth, 0.0F), 1.0F);
        Color targetColor = this.getTargetColor(this.target);
        Color healthBarColor = this.color.getValue() == 0 ? ColorUtil.getHealthBlend(healthRatio) : targetColor;
        float healthDeltaRatio = Math.min(Math.max((health - heal + 1.0F) / 2.0F, 0.0F), 1.0F);
        Color healthDeltaColor = ColorUtil.getHealthBlend(healthDeltaRatio);

        int scaledWidth = mc.method_22683().method_4486();
        int scaledHeight = mc.method_22683().method_4502();
        String targetNameText = ChatColors.formatColor(String.format("&r%s&r", TeamUtil.stripName(this.target)));
        int targetNameWidth = fr.getWidth(targetNameText);
        String healthText = ChatColors.formatColor(
                String.format("&r&f%s%s\u2764&r", healthFormat.format(heal), abs > 0.0F ? "&6" : "&c")
        );
        int healthTextWidth = fr.getWidth(healthText);
        String statusText = ChatColors.formatColor(String.format("&r&l%s&r", heal == health ? "D" : (heal < health ? "W" : "L")));
        int statusTextWidth = fr.getWidth(statusText);
        String healthDiffText = ChatColors.formatColor(
                String.format("&r%s&r", heal == health ? "0.0" : diffFormat.format(health - heal))
        );
        int healthDiffWidth = fr.getWidth(healthDiffText);

        float barContentWidth = Math.max(
                (float) targetNameWidth + (this.indicator.getValue() ? 2.0F + (float) statusTextWidth + 2.0F : 0.0F),
                (float) healthTextWidth + (this.indicator.getValue() ? 2.0F + (float) healthDiffWidth + 2.0F : 0.0F)
        );
        float headIconOffset = this.head.getValue() && this.headTexture != null ? 25.0F : 0.0F;
        float barTotalWidth = Math.max(headIconOffset + 70.0F, headIconOffset + 2.0F + barContentWidth + 2.0F);

        float posX = this.offX.getValue().floatValue() / this.scale.getValue();
        switch (this.posX.getValue()) {
            case 1:
                posX += (float) scaledWidth / this.scale.getValue() / 2.0F - barTotalWidth / 2.0F;
                break;
            case 2:
                posX *= -1.0F;
                posX += (float) scaledWidth / this.scale.getValue() - barTotalWidth;
                break;
            default:
                break;
        }

        float posY = this.offY.getValue().floatValue() / this.scale.getValue();
        switch (this.posY.getValue()) {
            case 1:
                posY += (float) scaledHeight / this.scale.getValue() / 2.0F - 13.5F;
                break;
            case 2:
                posY *= -1.0F;
                posY += (float) scaledHeight / this.scale.getValue() - 27.0F;
                break;
            default:
                break;
        }

        int mouseX = (int) (mc.field_1729.method_1603() * scaledWidth / mc.method_22683().method_4489());
        int mouseY = (int) (scaledHeight - mc.field_1729.method_1604() * scaledHeight / mc.method_22683().method_4506() - 1);

        float renderX = posX * this.scale.getValue();
        float renderY = posY * this.scale.getValue();
        float renderWidth = barTotalWidth * this.scale.getValue();
        float renderHeight = 27.0F * this.scale.getValue();

        this.positionLocked = !(mc.field_1755 instanceof class_408);

        if (!this.positionLocked) {
            if (isLeftMouseDown() && !this.dragging) {
                if (mouseX >= renderX && mouseX <= renderX + renderWidth
                        && mouseY >= renderY && mouseY <= renderY + renderHeight) {
                    this.dragging = true;
                    this.dragStartX = mouseX;
                    this.dragStartY = mouseY;
                    this.dragStartOffX = this.offX.getValue();
                    this.dragStartOffY = this.offY.getValue();
                }
            } else if (!isLeftMouseDown()) {
                this.dragging = false;
            }

            if (this.dragging) {
                int deltaX = mouseX - this.dragStartX;
                int deltaY = mouseY - this.dragStartY;
                if (this.posX.getValue() == 2) deltaX = -deltaX;
                if (this.posY.getValue() == 2) deltaY = -deltaY;
                this.offX.setValue(this.dragStartOffX + deltaX);
                this.offY.setValue(this.dragStartOffY + deltaY);
            }
        }

        float finalScale = this.scale.getValue() * scaleAnimation;

        RenderUtil.enableRenderState();
        int backgroundColor = new Color(0.0F, 0.0F, 0.0F, (float) this.background.getValue() / 100.0F).getRGB();
        float x0 = sx(0.0F, posX, barTotalWidth, finalScale);
        float y0 = sy(0.0F, posY, finalScale);
        float x1 = sx(barTotalWidth, posX, barTotalWidth, finalScale);
        float y1 = sy(27.0F, posY, finalScale);
        RenderUtil.drawRect(x0, y0, x1, y1, backgroundColor);
        if (this.outline.getValue()) {
            int outlineColor = targetColor.getRGB();
            RenderUtil.drawLine(x0, y0, x1, y0, 1.5F, outlineColor);
            RenderUtil.drawLine(x1, y0, x1, y1, 1.5F, outlineColor);
            RenderUtil.drawLine(x1, y1, x0, y1, 1.5F, outlineColor);
            RenderUtil.drawLine(x0, y1, x0, y0, 1.5F, outlineColor);
        }
        float healthX0 = sx(headIconOffset + 2.0F, posX, barTotalWidth, finalScale);
        RenderUtil.drawRect(healthX0, sy(22.0F, posY, finalScale), sx(barTotalWidth - 2.0F, posX, barTotalWidth, finalScale), sy(25.0F, posY, finalScale),
                ColorUtil.darker(healthBarColor, 0.2F).getRGB());
        RenderUtil.drawRect(healthX0, sy(22.0F, posY, finalScale),
                sx(headIconOffset + 2.0F + healthRatio * (barTotalWidth - 2.0F - headIconOffset - 2.0F), posX, barTotalWidth, finalScale), sy(25.0F, posY, finalScale),
                healthBarColor.getRGB());
        RenderUtil.disableRenderState();

        RenderUtil.enableRenderState();
        fr.draw(targetNameText, sx(headIconOffset + 2.0F, posX, barTotalWidth, finalScale), sy(2.0F, posY, finalScale), -1, this.shadow.getValue());
        fr.draw(healthText, sx(headIconOffset + 2.0F, posX, barTotalWidth, finalScale), sy(12.0F, posY, finalScale), -1, this.shadow.getValue());

        if (this.indicator.getValue()) {
            fr.draw(statusText, sx(barTotalWidth - 2.0F - (float) statusTextWidth, posX, barTotalWidth, finalScale), sy(2.0F, posY, finalScale),
                    healthDeltaColor.getRGB(), this.shadow.getValue());
            fr.draw(healthDiffText, sx(barTotalWidth - 2.0F - (float) healthDiffWidth, posX, barTotalWidth, finalScale), sy(12.0F, posY, finalScale),
                    ColorUtil.darker(healthDeltaColor, 0.8F).getRGB(), this.shadow.getValue());
        }

        if (this.head.getValue() && this.headTexture != null) {
            int hx = Math.round(sx(2.0F, posX, barTotalWidth, finalScale));
            int hy = Math.round(sy(2.0F, posY, finalScale));
            int hs = Math.round(23.0F * finalScale);
            context.method_25290(class_1921::method_62277, this.headTexture, hx, hy, 8.0F, 8.0F, hs, hs, 64, 64);
            context.method_25290(class_1921::method_62277, this.headTexture, hx, hy, 40.0F, 8.0F, hs, hs, 64, 64);
        }
        RenderUtil.disableRenderState();
    }

    private void renderAdjustMode(class_332 context) {
        List<class_1309> activeTargets = resolveTargets();
        Set<Integer> activeIds = new HashSet<>();

        for (class_1309 t : activeTargets) {
            int id = t.method_5628();
            activeIds.add(id);
            entityAlphas.putIfAbsent(id, 0f);
            entityCache.put(id, t);
            entityAlphas.put(id, Math.min(1f, entityAlphas.get(id) + ANIMATION_SPEED));
            displayHealths.putIfAbsent(id, t.method_6032());
            delayedHealths.putIfAbsent(id, t.method_6032());
            if (headTextures.get(id) == null) {
                headTextures.put(id, getSkin(t));
            }
        }

        Iterator<Map.Entry<Integer, Float>> iter = entityAlphas.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<Integer, Float> entry = iter.next();
            int id = entry.getKey();
            if (!activeIds.contains(id)) {
                float newAlpha = Math.max(0f, entry.getValue() - ANIMATION_SPEED);
                if (newAlpha <= 0f) {
                    iter.remove();
                    entityCache.remove(id);
                    displayHealths.remove(id);
                    delayedHealths.remove(id);
                    headTextures.remove(id);
                } else {
                    entry.setValue(newAlpha);
                }
            }
        }

        if (entityAlphas.isEmpty() && !(mc.field_1755 instanceof class_408)) return;

        List<Map.Entry<Integer, Float>> sortedEntries = new ArrayList<>(entityAlphas.entrySet());
        sortedEntries.sort((a, b) -> {
            class_1309 ea = entityCache.get(a.getKey());
            class_1309 eb = entityCache.get(b.getKey());
            if (ea == null) return 1;
            if (eb == null) return -1;
            return Double.compare(RotationUtil.distanceToEntity(ea), RotationUtil.distanceToEntity(eb));
        });

        int renderedCount = 0;

        float s = scale.getValue();
        float barW = FIXED_BAR_WIDTH * s;
        int rows = (sortedEntries.size() + 1) / 2;
        float totalWidth = sortedEntries.size() >= 2 ? barW * 2 + 4 * s : barW;
        float totalHeight = rows * 37f * s + (rows - 1) * 4f * s;

        int scaledWidth = mc.method_22683().method_4486();
        int scaledHeight = mc.method_22683().method_4502();
        int mouseX = (int) (mc.field_1729.method_1603() * scaledWidth / mc.method_22683().method_4489());
        int mouseY = (int) (scaledHeight - mc.field_1729.method_1604() * scaledHeight / mc.method_22683().method_4506() - 1);

        positionLocked = !(mc.field_1755 instanceof class_408);

        float x = offX.getValue().floatValue();
        float y = offY.getValue().floatValue();

        if (!positionLocked) {
            if (isLeftMouseDown() && !dragging) {
                if (mouseX >= x && mouseX <= x + totalWidth && mouseY >= y && mouseY <= y + totalHeight) {
                    dragging = true;
                    dragStartX = mouseX;
                    dragStartY = mouseY;
                    dragStartOffX = offX.getValue();
                    dragStartOffY = offY.getValue();
                }
            } else if (!isLeftMouseDown()) {
                dragging = false;
            }
            if (dragging) {
                offX.setValue(dragStartOffX + mouseX - dragStartX);
                offY.setValue(dragStartOffY + mouseY - dragStartY);
                x = offX.getValue().floatValue();
                y = offY.getValue().floatValue();
            }
        }

        List<float[]> targetRects = new ArrayList<>();
        renderedCount = 0;

        for (Map.Entry<Integer, Float> entry : sortedEntries) {
            int id = entry.getKey();
            float alpha = entry.getValue();
            if (alpha <= 0.01f) continue;

            class_1309 target = entityCache.get(id);
            if (target == null) continue;

            int row = renderedCount / 2, col = renderedCount % 2;
            float ox = x + col * (barW + 4 * s);
            float oy = y + row * 37f * s + row * 4f * s;
            float barH = 37f * s;

            targetRects.add(new float[]{ox, oy, barW, barH});
            renderedCount++;
        }

        if (targetRects.isEmpty()) return;

        int bg = new Color(0, 0, 0, (int) ((float) background.getValue() / 100f * 255 * Math.min(1f, entityAlphas.values().stream().max(Float::compare).orElse(0f)))).getRGB();
        for (float[] rect : targetRects) {
            RenderUtil.drawRect(rect[0], rect[1], rect[0] + rect[2], rect[1] + rect[3], bg);
        }

        FontDrawer font = getFontRenderer(context);
        renderedCount = 0;

        for (Map.Entry<Integer, Float> entry : sortedEntries) {
            int id = entry.getKey();
            float alpha = entry.getValue();
            if (alpha <= 0.01f) continue;

            class_1309 target = entityCache.get(id);
            if (target == null) continue;

            int row = renderedCount / 2, col = renderedCount % 2;
            float ox = x + col * (barW + 4 * s);
            float oy = y + row * 37f * s + row * 4f * s;
            float barH = 37f * s;
            float padding = 2f * s;

            float health = target.method_6032(), maxHealth = target.method_6063();
            float disp = displayHealths.getOrDefault(id, health);
            float del = delayedHealths.getOrDefault(id, health);

            if (health < disp) { disp = health; healthDelayTimer.reset(); }
            else { disp += (health - disp) / 4f; if (Math.abs(disp - health) < 0.01f) disp = health; }
            if (healthDelayTimer.hasTimeElapsed(200L)) {
                del += (disp - del) / 4f; if (Math.abs(del - disp) < 0.01f) del = disp;
            }
            displayHealths.put(id, disp);
            delayedHealths.put(id, del);

            if (headTextures.get(id) == null) {
                headTextures.put(id, getSkin(target));
            }
            class_2960 skin = headTextures.get(id);

            float dispWidth = (barW - padding * 2) * (disp / maxHealth);
            float delWidth = (barW - padding * 2) * (del / maxHealth);

            String sheesh = healthFormat.format(Math.abs(mc.field_1724.method_6032() - health));
            String healthDiff = mc.field_1724.method_6032() < health ? "-" + sheesh : "+" + sheesh;

            HUD hud = (HUD) Myau.moduleManager.getModule(HUD.class);
            Color leftC = hud != null ? new Color(hud.custom1.getValue()) : Color.WHITE;
            Color rightC = hud != null ? new Color(hud.custom2.getValue()) : Color.WHITE;

            float barLeft = ox + padding, barRight = ox + barW - padding;
            float barTop = oy + barH - 6f * s, barBottom = oy + barH - 2f * s;
            float barWidth = barRight - barLeft;

            RenderUtil.enableRenderState();
            RenderUtil.drawRect(barLeft, barTop, barRight, barBottom, ColorUtil.darker(new Color(0, 0, 0, (int)(100 * alpha)), 0.3f).getRGB());
            for (int i = 0; i < (int) delWidth; i++) {
                float prog = (float) i / barWidth;
                Color blended = ColorUtil.interpolate(prog, leftC, rightC);
                RenderUtil.drawRect(barLeft + i, barTop, barLeft + i + 1, barBottom, new Color(blended.getRed(), blended.getGreen(), blended.getBlue(), (int)(128 * alpha)).getRGB());
            }
            for (int i = 0; i < (int) dispWidth; i++) {
                float prog = (float) i / barWidth;
                Color blended = ColorUtil.interpolate(prog, leftC, rightC);
                RenderUtil.drawRect(barLeft + i, barTop, barLeft + i + 1, barBottom, new Color(blended.getRed(), blended.getGreen(), blended.getBlue(), (int)(255 * alpha)).getRGB());
            }
            RenderUtil.disableRenderState();

            RenderUtil.enableRenderState();
            font.draw(target.method_5477().getString(), (int)(ox + padding + 28f * s), (int)(oy + 3f * s), new Color(255, 255, 255, (int)(255 * alpha)).getRGB(), false);
            font.draw(healthDiff, (int)(ox + barW - padding - font.getWidth(healthDiff)), (int)(oy + barH - 14f * s - padding), new Color(200, 200, 200, (int)(255 * alpha)).getRGB(), false);

            if (head.getValue() && skin != null) {
                RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);
                int hx = Math.round(ox + padding);
                int hy = Math.round(oy + padding);
                int hs = Math.round(26f * s);
                context.method_25290(class_1921::method_62277, skin, hx, hy, 8.0F, 8.0F, hs, hs, 64, 64);
                context.method_25290(class_1921::method_62277, skin, hx, hy, 40.0F, 8.0F, hs, hs, 64, 64);
                RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            }

            List<class_1799> items = new ArrayList<>();
            class_1799 held = target.method_6047();
            if (!held.method_7960()) items.add(held);
            for (int index = 3; index >= 0; index--) {
                class_1304 slot;
                switch (index) {
                    case 3:
                        slot = class_1304.field_6169;
                        break;
                    case 2:
                        slot = class_1304.field_6174;
                        break;
                    case 1:
                        slot = class_1304.field_6172;
                        break;
                    default:
                        slot = class_1304.field_6166;
                        break;
                }
                class_1799 stack = target.method_6118(slot);
                if (!stack.method_7960()) items.add(stack);
            }
            float itemX = ox + 28f * s + padding;
            for (class_1799 stack : items) {
                float itemScale = 0.7f * s;
                renderHudItem(context, stack, itemX, oy + 14f * s + padding, itemScale, alpha);
                itemX += 12f * s;
            }
            RenderUtil.disableRenderState();

            renderedCount++;
        }
    }

    private void renderHudItem(class_332 context, class_1799 stack, float x, float y, float itemScale, float alpha) {
        if (stack == null || stack.method_7960()) return;

        float clampedAlpha = Math.max(0.0F, Math.min(1.0F, alpha));
        class_1799 renderStack = clampedAlpha < 0.99F ? stripGlintForAlpha(stack) : stack;

        var matrices = context.method_51448();
        matrices.method_22903();
        matrices.method_46416(x, y, 0.0F);
        matrices.method_22905(itemScale, itemScale, 1.0F);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, clampedAlpha);
        context.method_51427(renderStack, 0, 0);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        matrices.method_22909();
    }

    private class_1799 stripGlintForAlpha(class_1799 stack) {
        if (!stack.method_7958()) return stack;
        class_1799 copy = stack.method_7972();
        copy.method_57381(class_9334.field_49633);
        copy.method_57381(class_9334.field_49643);
        return copy;
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getType() == EventType.SEND && event.getPacket() instanceof class_2824) {
            class_2824 packet = (class_2824) event.getPacket();
            int entityId = ((PlayerInteractEntityC2SPacketAccessor) packet).getEntityId();
            class_1297 entity = mc.field_1687 != null ? mc.field_1687.method_8469(entityId) : null;
            if (entity instanceof class_1309 && !(entity instanceof class_1531)) {
                this.lastAttackTimer.reset();
                this.lastTarget = (class_1309) entity;
            }
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{style.getModeString()};
    }

    public class_1309 getTarget() {
        return this.target;
    }
}
