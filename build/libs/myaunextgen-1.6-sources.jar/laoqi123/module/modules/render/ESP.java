package laoqi123.module.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.types.Priority;
import laoqi123.event.impl.Render2DEvent;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.BooleanValue;
import laoqi123.value.properties.ModeValue;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1686;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import laoqi123.util.RenderUtil;
import laoqi123.util.TeamUtil;
import org.joml.Matrix4f;
import org.joml.Vector4d;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ESP extends Module {
    private static final class_310 mc = class_310.method_1551();
    private boolean outline = true;
    private boolean glow = true;

    public final ModeValue mode = new ModeValue("mode", 0, new String[]{"Outlined 2D", "Glow"});
    public final BooleanValue skeleton = new BooleanValue("skeleton", false);
    public final BooleanValue players = new BooleanValue("players", true);
    public final BooleanValue mobs = new BooleanValue("mobs", false);
    public final BooleanValue animals = new BooleanValue("animals", false);
    public final BooleanValue items = new BooleanValue("items", false);
    public final BooleanValue arrows = new BooleanValue("arrows", true);
    public final BooleanValue showHealthBar = new BooleanValue("show-health-bar", true);
    public final ModeValue healthBarPosition = new ModeValue("health-bar-position", 0, new String[]{"Bottom", "Top", "Left", "Right"});

    private final Map<class_1297, Vector4d> entityBoxPositions = new HashMap<>();
    private final List<Vector4d> projectedPoints = new ArrayList<>();

    public ESP() {
        super("ESP", false);
    }

    public boolean isOutlineEnabled() {
        return this.outline;
    }

    public boolean isGlowEnabled() {
        return this.glow;
    }

    private boolean shouldShowEntity(class_1297 entity) {
        if (entity == mc.field_1724) return false;
        if (entity instanceof class_1657 && this.players.getValue()) return true;
        if (entity instanceof class_1429 && this.animals.getValue()) return true;
        if (entity instanceof class_1308 && this.mobs.getValue()) return true;
        if (entity instanceof class_1542 && this.items.getValue()) return true;
        if (entity instanceof class_1667 || entity instanceof class_1686) return this.arrows.getValue();
        return false;
    }

    private boolean isInRange(class_1297 entity) {
        return mc.field_1724.method_5739(entity) * mc.field_1724.method_5739(entity) < 10000.0;
    }

    private Color getEntityColor(class_1297 entity) {
        if (entity instanceof class_1657 player) {
            if (TeamUtil.isFriend(player)) {
                return Myau.friendManager.getColor();
            } else if (TeamUtil.isTarget(player)) {
                return Myau.targetManager.getColor();
            }
            return TeamUtil.getTeamColor(player, 1.0F);
        }
        return new Color(-1);
    }

    public static boolean shouldOutline(class_1297 entity) {
        if (Myau.moduleManager == null) return false;
        ESP esp = (ESP) Myau.moduleManager.modules.get(ESP.class);
        if (esp == null || !esp.isEnabled() || esp.mode.getValue() != 1) return false;
        if (!esp.shouldShowEntity(entity)) return false;
        return esp.isInRange(entity);
    }

    public static int getOutlineColor(class_1297 entity) {
        if (Myau.moduleManager == null) return entity.method_22861();
        ESP esp = (ESP) Myau.moduleManager.modules.get(ESP.class);
        if (esp != null) {
            return esp.getEntityColor(entity).getRGB();
        }
        return entity.method_22861();
    }

    @EventTarget(Priority.HIGH)
    public void onRender(Render3DEvent event) {
        if (!this.isEnabled() || mc.field_1687 == null || mc.field_1724 == null) return;
        if (this.mode.getValue() != 0) {
            this.entityBoxPositions.clear();
            return;
        }
        this.entityBoxPositions.clear();
        double scaleFactor = mc.method_22683().method_4495();
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!this.shouldShowEntity(entity) || !this.isInRange(entity)) continue;
            Vector4d proj = RenderUtil.projectToScreen(entity, scaleFactor);
            if (proj == null) continue;
            if (proj.z <= 0.0 || proj.w <= 0.0) continue;
            this.entityBoxPositions.put(entity, proj);
        }
    }

    @EventTarget(Priority.HIGH)
    public void onRender2D(Render2DEvent event) {
        if (!this.isEnabled() || this.mode.getValue() != 0 || this.entityBoxPositions.isEmpty()) return;
        Matrix4f matrix4f = event.getContext().method_51448().method_23760().method_23761();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShader(class_10142.field_53876);
        class_287 builder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        for (Map.Entry<class_1297, Vector4d> entry : this.entityBoxPositions.entrySet()) {
            Vector4d v = entry.getValue();
            if (v.z <= 0.0 || v.w <= 0.0) continue;
            Color color = this.getEntityColor(entry.getKey());
            float x1 = (float) v.x;
            float y1 = (float) v.y;
            float x2 = x1 + (float) v.z;
            float y2 = y1 + (float) v.w;
            this.drawFilledRect2D(builder, matrix4f, x1, y1, x2, y2, color);
            if (entry.getKey() instanceof net.minecraft.class_1309 le && this.showHealthBar.getValue()) {
                this.drawHealthBar(builder, matrix4f, le, v, color);
            }
        }
        class_286.method_43433(builder.method_60800());
        RenderSystem.disableBlend();
    }

    private void drawFilledRect2D(class_287 builder, Matrix4f matrix4f, float x1, float y1, float x2, float y2, Color color) {
        RenderUtil.drawQuad(builder, matrix4f, x1 - 1.0F, y1, x1 + 0.5F, y2 + 0.5F, Color.BLACK);
        RenderUtil.drawQuad(builder, matrix4f, x1 - 1.0F, y1 - 0.5F, x2 + 0.5F, y1 + 1.0F, Color.BLACK);
        RenderUtil.drawQuad(builder, matrix4f, x2 - 0.5F, y1, x2 + 0.5F, y2 + 0.5F, Color.BLACK);
        RenderUtil.drawQuad(builder, matrix4f, x1 - 1.0F, y2 - 0.5F, x2 + 0.5F, y2 + 0.5F, Color.BLACK);
        RenderUtil.drawQuad(builder, matrix4f, x1 - 0.5F, y1, x1, y2, color);
        RenderUtil.drawQuad(builder, matrix4f, x1, y2 - 0.5F, x2, y2, color);
        RenderUtil.drawQuad(builder, matrix4f, x1, y1, x2, y1 + 0.5F, color);
        RenderUtil.drawQuad(builder, matrix4f, x2 - 0.5F, y1, x2, y2, color);
    }

    private void drawHealthBar(class_287 builder, Matrix4f matrix4f, net.minecraft.class_1309 entity, Vector4d v, Color color) {
        float healthFrac;
        if (entity instanceof class_1657 p) {
            healthFrac = Math.max(0.0F, Math.min(Math.min(p.method_6032(), p.method_6063()) / p.method_6063(), 1.0F));
        } else {
            healthFrac = Math.min(entity.method_6032() / entity.method_6063(), 1.0F);
        }
        float x = (float) v.x;
        float y = (float) v.y;
        float right = x + (float) v.z;
        float bottom = y + (float) v.w;
        float barX;
        float barY;
        float barW;
        float barH;
        switch (this.healthBarPosition.getValue()) {
            case 1: {
                barW = (float) v.z;
                barH = 2.0F;
                barX = x;
                barY = y - 4.0F;
                break;
            }
            case 2: {
                barW = 2.0F;
                barH = (float) v.w;
                barX = x - 4.0F;
                barY = y;
                break;
            }
            case 3: {
                barW = 2.0F;
                barH = (float) v.w;
                barX = right + 2.0F;
                barY = y;
                break;
            }
            default: {
                barW = (float) v.z;
                barH = 2.0F;
                barX = x;
                barY = bottom + 2.0F;
                break;
            }
        }
        RenderUtil.drawQuad(builder, matrix4f, barX - 0.6F, barY - 0.6F, barX + barW + 0.6F, barY + barH + 0.6F, Color.BLACK);
        RenderUtil.drawQuad(builder, matrix4f, barX, barY, barX + barW, barY + barH, color.darker().darker());
        Color healthColor = this.getHealthColor(healthFrac);
        if (this.healthBarPosition.getValue() == 2 || this.healthBarPosition.getValue() == 3) {
            RenderUtil.drawQuad(builder, matrix4f, barX, barY + barH * (1.0F - healthFrac), barX + barW, barY + barH, healthColor);
        } else {
            RenderUtil.drawQuad(builder, matrix4f, barX, barY, barX + barW * healthFrac, barY + barH, healthColor);
        }
    }

    private Color getHealthColor(float fraction) {
        return Color.getHSBColor(Math.max(0.0F, fraction) / 3.0F, 1.0F, 1.0F);
    }
}