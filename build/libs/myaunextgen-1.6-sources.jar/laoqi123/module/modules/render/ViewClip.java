package laoqi123.module.modules.render;

import laoqi123.module.Module;
import net.minecraft.class_310;

public class ViewClip extends Module {
    private static final class_310 mc = class_310.method_1551();

    public ViewClip() {
        super("ViewClip", false);
    }

    @Override
    public void onEnabled() {
        if (mc.field_1687 != null) {
            mc.field_1769.method_3279();
        }
    }

    @Override
    public void onDisabled() {
        if (mc.field_1687 != null) {
            mc.field_1769.method_3279();
        }
    }
}
