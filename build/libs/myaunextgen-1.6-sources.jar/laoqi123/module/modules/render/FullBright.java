package laoqi123.module.modules.render;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.TickEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.ModeValue;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_310;

public class FullBright extends Module {
    private static final class_310 mc = class_310.method_1551();
    private float prevGamma = Float.NaN;
    private boolean appliedNightVision = false;
    public final ModeValue mode = new ModeValue("mode", 0, new String[]{"GAMMA", "EFFECT"});

    public FullBright() {
        super("Fullbright", true, true);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.POST) {
            switch (this.mode.getValue()) {
                case 0:
                    mc.field_1690.method_42473().method_41748(1.0);
                    break;
                case 1:
                    mc.field_1724.method_6092(new class_1293(class_1294.field_5925, 25940, 0));
            }
        }
    }

    @Override
    public void onEnabled() {
        switch (this.mode.getValue()) {
            case 0:
                this.prevGamma = mc.field_1690.method_42473().method_41753().floatValue();
                break;
            case 1:
                this.appliedNightVision = true;
        }
    }

    @Override
    public void onDisabled() {
        if (!Float.isNaN(this.prevGamma)) {
            mc.field_1690.method_42473().method_41748((double) this.prevGamma);
            this.prevGamma = Float.NaN;
        }
        if (this.appliedNightVision) {
            if (mc.field_1724 != null) {
                mc.field_1724.method_6016(class_1294.field_5925);
            }
            this.appliedNightVision = false;
        }
    }

    @Override
    public void verifyValue(String mode) {
        if (this.isEnabled()) {
            this.onDisabled();
            this.onEnabled();
        }
    }
}
