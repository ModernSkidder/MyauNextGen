package laoqi123.module.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.Myau;
import laoqi123.enums.ChatColors;
import laoqi123.event.EventTarget;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.*;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1420;
import net.minecraft.class_1429;
import net.minecraft.class_1477;
import net.minecraft.class_1510;
import net.minecraft.class_1528;
import net.minecraft.class_1545;
import net.minecraft.class_1548;
import net.minecraft.class_1560;
import net.minecraft.class_1621;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_8646;
import net.minecraft.class_9013;
import net.minecraft.class_9799;
import laoqi123.util.ColorUtil;
import laoqi123.util.RenderUtil;
import laoqi123.util.TeamUtil;
import org.joml.Matrix4fStack;

import java.awt.Color;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class NameTags extends Module {
    private static final class_310 mc = class_310.method_1551();
    private static final DecimalFormat healthFormatter = new DecimalFormat("0.0", new DecimalFormatSymbols(Locale.US));
    public final FloatValue scale = new FloatValue("scale", 1.0F, 0.5F, 2.0F);
    public final BooleanValue autoScale = new BooleanValue("auto-scale", true);
    public final PercentValue backgroundOpacity = new PercentValue("background", 25);
    public final BooleanValue shadow = new BooleanValue("shadow", true);
    public final ModeValue distanceMode = new ModeValue("distance", 0, new String[]{"NONE", "DEFAULT", "VAPE"});
    public final ModeValue healthMode = new ModeValue("health", 2, new String[]{"NONE", "HP", "HEARTS", "TAB"});
    public final BooleanValue armor = new BooleanValue("armor", true);
    public final BooleanValue effects = new BooleanValue("effects", true);
    public final BooleanValue players = new BooleanValue("players", true);
    public final BooleanValue friends = new BooleanValue("friends", true);
    public final BooleanValue enemies = new BooleanValue("enemies", true);
    public final BooleanValue bossees = new BooleanValue("bosses", false);
    public final BooleanValue mobs = new BooleanValue("mobs", false);
    public final BooleanValue creepers = new BooleanValue("creepers", false);
    public final BooleanValue endermans = new BooleanValue("endermen", false);
    public final BooleanValue blazes = new BooleanValue("blazes", false);
    public final BooleanValue animals = new BooleanValue("animals", false);
    public final BooleanValue self = new BooleanValue("self", false);
    public final BooleanValue bots = new BooleanValue("bots", false);

    public NameTags() {
        super("NameTags", false);
    }

    public boolean shouldRenderTags(class_1309 entityLivingBase) {
        if (entityLivingBase.field_6213 > 0) {
            return false;
        } else if (mc.method_1560().method_5739(entityLivingBase) > 512.0F) {
            return false;
        } else if (entityLivingBase instanceof class_1657) {
            if (entityLivingBase != mc.field_1724 && entityLivingBase != mc.method_1560()) {
                if (TeamUtil.isBot((class_1657) entityLivingBase)) {
                    return this.bots.getValue();
                } else if (TeamUtil.isFriend((class_1657) entityLivingBase)) {
                    return this.friends.getValue();
                } else {
                    return TeamUtil.isTarget((class_1657) entityLivingBase) ? this.enemies.getValue() : this.players.getValue();
                }
            } else {
                return this.self.getValue() && !mc.field_1690.method_31044().method_31034();
            }
        } else if (entityLivingBase instanceof class_1510 || entityLivingBase instanceof class_1528) {
            return !entityLivingBase.method_5767() && this.bossees.getValue();
        } else if (!(entityLivingBase instanceof class_1308) && !(entityLivingBase instanceof class_1621)) {
            return (entityLivingBase instanceof class_1429
                    || entityLivingBase instanceof class_1420
                    || entityLivingBase instanceof class_1477
                    || entityLivingBase instanceof class_1646) && this.animals.getValue();
        } else if (entityLivingBase instanceof class_1548) {
            return this.creepers.getValue();
        } else if (entityLivingBase instanceof class_1560) {
            return this.endermans.getValue();
        } else {
            return entityLivingBase instanceof class_1545 ? this.blazes.getValue() : this.mobs.getValue();
        }
    }

    @EventTarget
    public void onRender(Render3DEvent event) {
        if (this.isEnabled()) {
            for (class_1297 entity : TeamUtil.getLoadedEntitiesSorted()) {
                if (entity instanceof class_1309
                        && this.shouldRenderTags((class_1309) entity)
                        && RenderUtil.isInViewFrustum(entity.method_5829(), 10.0)) {
                    String teamName = TeamUtil.stripName(entity);
                    String strippedName = class_124.method_539(teamName);
                    if (strippedName != null && !strippedName.isBlank()) {
                        double x = RenderUtil.lerpDouble(entity.method_23317(), entity.field_6014, event.getPartialTicks()) - mc.field_1773.method_19418().method_19326().field_1352;
                        double y = RenderUtil.lerpDouble(entity.method_23318(), entity.field_6036, event.getPartialTicks()) - mc.field_1773.method_19418().method_19326().field_1351 + entity.method_5751();
                        double z = RenderUtil.lerpDouble(entity.method_23321(), entity.field_5969, event.getPartialTicks()) - mc.field_1773.method_19418().method_19326().field_1350;
                        double distance = mc.method_1560().method_5739(entity);
                        Matrix4fStack matrixStack = RenderSystem.getModelViewStack();
                        matrixStack.pushMatrix();
                        matrixStack.translate((float) x, (float) (y + (entity.method_18276() ? 0.225 : 0.4)), (float) z);
                        matrixStack.rotate(class_7833.field_40716.rotationDegrees(-mc.field_1773.method_19418().method_19330()));
                        float view = mc.field_1690.method_31044().method_31035() ? -1.0F : 1.0F;
                        matrixStack.rotate(class_7833.field_40714.rotationDegrees(mc.field_1773.method_19418().method_19329() * view));
                        double scale = Math.pow(Math.min(Math.max(this.autoScale.getValue() ? distance : 0.0, 6.0), 128.0), 0.75) * 0.0075;
                        matrixStack.scale((float) (-scale * this.scale.getValue()), (float) (-scale * this.scale.getValue()), 1.0F);
                        String distanceText = "";
                        switch (this.distanceMode.getValue()) {
                            case 1:
                                distanceText = String.format("&7%dm&r ", (int) distance);
                                break;
                            case 2:
                                distanceText = String.format("&a[&f%d&a]&r ", (int) distance);
                        }
                        float health = ((class_1309) entity).method_6032();
                        float absorption = ((class_1309) entity).method_6067();
                        float max = ((class_1309) entity).method_6063();
                        float percent = Math.min(Math.max((health + absorption) / max, 0.0F), 1.0F);
                        String healText = "";
                        switch (this.healthMode.getValue()) {
                            case 1:
                                healText = String.format(" %d%s", (int) health, absorption > 0.0F ? String.format(" &6%d&r", (int) absorption) : "&r");
                                break;
                            case 2:
                                healText = String.format(
                                        " %s%s",
                                        healthFormatter.format((double) health / 2.0),
                                        absorption > 0.0F ? String.format(" &6%s&r", healthFormatter.format((double) absorption / 2.0)) : "&r"
                                );
                                break;
                            case 3:
                                if (entity instanceof class_1657) {
                                    class_269 scoreboard = mc.field_1687.method_8428();
                                    if (scoreboard != null) {
                                        class_266 objective = scoreboard.method_1189(class_8646.field_45156);
                                        if (objective != null) {
                                            class_9013 score = scoreboard.method_55430((class_1657) entity, objective);
                                            if (score != null) {
                                                healText = String.format(" &e%d&r", score.method_55397());
                                            }
                                        }
                                    }
                                }
                        }
                        String color = ChatColors.formatColor(String.format("%s&f%s&r%s", distanceText, teamName, healText));
                        int width = mc.field_1772.method_1727(color);
                        if (this.backgroundOpacity.getValue() > 0) {
                            Color textColor = !entity.method_18276() && !entity.method_5767()
                                    ? new Color(0.0F, 0.0F, 0.0F, (float) this.backgroundOpacity.getValue() / 100.0F)
                                    : new Color(0.33F, 0.0F, 0.33F, (float) this.backgroundOpacity.getValue() / 100.0F);
                            RenderUtil.enableRenderState();
                            RenderUtil.drawRect(
                                    (float) (-width) / 2.0F - 1.0F,
                                    (float) (-mc.field_1772.field_2000) - 1.0F,
                                    (float) width / 2.0F + (this.shadow.getValue() ? 1.0F : 0.0F),
                                    this.shadow.getValue() ? 0.0F : -1.0F,
                                    textColor.getRGB()
                            );
                            RenderUtil.disableRenderState();
                        }
                        class_9799 allocator = new class_9799(256);
                        class_4597.class_4598 immediate = class_4597.method_22991(allocator);
                        mc.field_1772.method_27521(
                                color,
                                (float) (-width) / 2.0F,
                                (float) (-mc.field_1772.field_2000),
                                ColorUtil.getHealthBlend(percent).getRGB(),
                                this.shadow.getValue(),
                                RenderSystem.getModelViewMatrix(),
                                immediate,
                                class_327.class_6415.field_33994,
                                0,
                                0xF000F0
                        );
                        immediate.method_22993();
                        if (entity instanceof class_1657) {
                            int height = mc.field_1772.field_2000 + 2;
                            if (this.armor.getValue()) {
                                ArrayList<class_1799> renderingItems = new ArrayList<>();
                                for (int i = 4; i >= 0; i--) {
                                    class_1799 itemStack;
                                    if (i == 0) {
                                        itemStack = ((class_1657) entity).method_31548().method_7391();
                                    } else {
                                        itemStack = ((class_1657) entity).method_31548().field_7548.get(i - 1);
                                    }
                                    if (!itemStack.method_7960()) {
                                        renderingItems.add(itemStack);
                                    }
                                }
                                if (!renderingItems.isEmpty()) {
                                    int offset = renderingItems.size() * -8;
                                    for (int i = 0; i < renderingItems.size(); i++) {
                                        RenderUtil.renderItemInGUI(renderingItems.get(i), offset + i * 16, -height - 16);
                                    }
                                    height += 16;
                                }
                            }
                            if (this.effects.getValue()) {
                                List<class_1293> effects = ((class_1657) entity)
                                        .method_6026()
                                        .stream()
                                        .filter(class_1293::method_5592)
                                        .collect(Collectors.toList());
                                if (!effects.isEmpty()) {
                                    matrixStack.pushMatrix();
                                    matrixStack.scale(0.5F, 0.5F, 1.0F);
                                    int offset = effects.size() * -9;
                                    for (int i = 0; i < effects.size(); i++) {
                                        RenderUtil.renderPotionEffect(effects.get(i), offset + i * 18, -(height * 2) - 18);
                                    }
                                    matrixStack.popMatrix();
                                }
                            }
                            if (TeamUtil.isFriend((class_1657) entity)) {
                                RenderUtil.enableRenderState();
                                float x1 = (float) (-width) / 2.0F - 1.0F;
                                float y1 = (float) (-mc.field_1772.field_2000) - 1.0F;
                                float x2 = (float) width / 2.0F + 1.0F;
                                float y2 = this.shadow.getValue() ? 0.0F : -1.0F;
                                int friendColor = Myau.friendManager.getColor().getRGB();
                                RenderUtil.drawOutlineRect(x1, y1, x2, y2, 1.5F, 0, friendColor);
                                RenderUtil.disableRenderState();
                            } else if (TeamUtil.isTarget((class_1657) entity)) {
                                RenderUtil.enableRenderState();
                                float x1 = (float) (-width) / 2.0F - 1.0F;
                                float y1 = (float) (-mc.field_1772.field_2000) - 1.0F;
                                float x2 = (float) width / 2.0F + 1.0F;
                                float y2 = this.shadow.getValue() ? 0.0F : -1.0F;
                                int targetColor = Myau.targetManager.getColor().getRGB();
                                RenderUtil.drawOutlineRect(x1, y1, x2, y2, 1.5F, 0, targetColor);
                                RenderUtil.disableRenderState();
                            }
                        }
                        matrixStack.popMatrix();
                    }
                }
            }
        }
    }
}
