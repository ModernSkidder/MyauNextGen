package laoqi123.module.modules.render.esp;

import java.awt.Color;
import net.minecraft.class_1297;

public interface EspColorProvider {
    Color getColor(Object var1);

    default float getFillAlpha() {
        return 0.125f;
    }

    boolean shouldHighlight(class_1297 var1);

    default float getOutlineAlpha() {
        return 0.25f;
    }

    default float getLineWidth() {
        return 0.03f;
    }
}