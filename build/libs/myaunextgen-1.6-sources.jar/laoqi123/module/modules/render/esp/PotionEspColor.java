package laoqi123.module.modules.render.esp;

import java.awt.Color;
import java.util.Collections;
import java.util.HashSet;
import net.minecraft.class_1686;

public class PotionEspColor extends ClassEspColor {
    public PotionEspColor() {
        super(new HashSet<>(Collections.singleton(class_1686.class)), new Color(255, 66, 249));
    }

    @Override
    public float getLineWidth() {
        return 0.05f;
    }
}