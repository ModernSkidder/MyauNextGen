package laoqi123.module.modules.render;

import laoqi123.enums.ChatColors;
import laoqi123.event.EventTarget;
import laoqi123.event.impl.Render2DEvent;
import laoqi123.module.Module;
import laoqi123.util.RenderUtil;
import laoqi123.util.RotationUtil;
import laoqi123.util.TeamUtil;
import laoqi123.value.properties.BooleanValue;
import laoqi123.value.properties.FloatValue;
import net.minecraft.class_1297;
import net.minecraft.class_1667;
import net.minecraft.class_1674;
import net.minecraft.class_1680;
import net.minecraft.class_1681;
import net.minecraft.class_1684;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_5498;
import java.awt.*;
import java.util.stream.Collectors;

public class Indicators extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final FloatValue scale = new FloatValue("scale", 1.0f, 0.5f, 1.5f);
    public final FloatValue offset = new FloatValue("offset", 50.0f, 0.0f, 255.0f);
    public final BooleanValue directionCheck = new BooleanValue("direction-check", true);
    public final BooleanValue fireballs = new BooleanValue("fireballs", true);
    public final BooleanValue pearls = new BooleanValue("pearls", true);
    public final BooleanValue arrows = new BooleanValue("arrows", true);
    public final BooleanValue egg = new BooleanValue("egg", true);
    public final BooleanValue snowball = new BooleanValue("snowball", true);

    private boolean shouldRender(class_1297 entity) {
        double d = (entity.method_23317() - entity.field_6014) * (mc.field_1724.method_23317() - entity.method_23317()) + (entity.method_23318() - entity.field_6036) * (mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()) - entity.method_23318() - entity.method_17682() / 2.0) + (entity.method_23321() - entity.field_5969) * (mc.field_1724.method_23321() - entity.method_23321());
        if (d == 0.0) {
            return false;
        }
        if (d < 0.0) {
            if (this.directionCheck.getValue()) {
                return false;
            }
        }
        if (this.fireballs.getValue() && entity instanceof class_1674) return true;
        if (this.pearls.getValue() && entity instanceof class_1684) return true;
        if (this.arrows.getValue() && entity instanceof class_1667) return true;
        if (this.egg.getValue() && entity instanceof class_1681) return true;
        if (this.snowball.getValue() && entity instanceof class_1680) return true;
        return false;
    }

    private class_1792 getIndicatorItem(class_1297 entity) {
        if (entity instanceof class_1674) {
            return class_1802.field_8814;
        }
        if (entity instanceof class_1684) {
            return class_1802.field_8634;
        }
        if (entity instanceof class_1667) {
            return class_1802.field_8107;
        }
        if (entity instanceof class_1681) {
            return class_1802.field_8803;
        }
        if (entity instanceof class_1680) {
            return class_1802.field_8543;
        }
        return class_1802.field_8162;
    }

    private Color getIndicatorColor(class_1297 entity) {
        if (entity instanceof class_1674) {
            return new Color(12676363);
        }
        if (entity instanceof class_1684) {
            return new Color(2458740);
        }
        if (entity instanceof class_1667) {
            return new Color(0x969696);
        }
        return new Color(-1);
    }

    public Indicators() {
        super("Indicators", false, true);
    }

    @EventTarget
    public void onRender(Render2DEvent render2DEvent) {
        if (!this.isEnabled()) {
            return;
        }
        for (class_1297 entity : TeamUtil.getLoadedEntitiesSorted().stream().filter(this::shouldRender).collect(Collectors.toList())) {
            float offset = 10.0f + this.offset.getValue();
            float yawBetween = RotationUtil.getYawBetween(RenderUtil.lerpDouble(mc.field_1724.method_23317(), mc.field_1724.field_6014, render2DEvent.getPartialTicks()), RenderUtil.lerpDouble(mc.field_1724.method_23321(), mc.field_1724.field_5969, render2DEvent.getPartialTicks()), RenderUtil.lerpDouble(entity.method_23317(), entity.field_6014, render2DEvent.getPartialTicks()), RenderUtil.lerpDouble(entity.method_23321(), entity.field_5969, render2DEvent.getPartialTicks()));
            if (mc.field_1690.method_31044() == class_5498.field_26666) {
                yawBetween += 180.0f;
            }
            float x = (float) Math.sin(Math.toRadians(yawBetween));
            float z = (float) Math.cos(Math.toRadians(yawBetween)) * -1.0f;
            float scaleValue = this.scale.getValue();
            float centerX = (float) mc.method_22683().method_4486() / 2.0f;
            float centerY = (float) mc.method_22683().method_4502() / 2.0f;
            RenderUtil.renderItemInGUI(new class_1799(this.getIndicatorItem(entity)), (int) (centerX + (offset + 0.0f) * x * scaleValue - 8.0f * scaleValue), (int) (centerY + (offset + 0.0f) * z * scaleValue - 8.0f * scaleValue));
            String string = String.format("%dm", (int) mc.field_1724.method_5739(entity));
            int textColor = ChatColors.GRAY.toAwtColor() & 0xFFFFFF | 0xBF000000;
            render2DEvent.getContext().method_51433(mc.field_1772, string, (int) (centerX + (offset + 0.0f) * x * scaleValue - mc.field_1772.method_1727(string) / 2.0f * scaleValue + 1.0f), (int) (centerY + (offset + 0.0f) * z * scaleValue + 1.0f), textColor, true);
            RenderUtil.enableRenderState();
            RenderUtil.drawArrow(centerX + (offset + 15.0f) * x * scaleValue + 1.0f, centerY + (offset + 15.0f) * z * scaleValue + 1.0f, (float) (Math.atan2(z, x) + Math.PI), 7.5f * scaleValue, 1.5f, this.getIndicatorColor(entity).getRGB());
            RenderUtil.disableRenderState();
        }
    }
}
