package laoqi123.module.modules.render;

import laoqi123.module.Module;
import laoqi123.ui.ClickGui;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public class GuiModule extends Module {
    private static final class_310 mc = class_310.method_1551();

    public GuiModule() {
        super("ClickGui", false);
        setKey(GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    @Override
    public void onEnabled() {
        setEnabled(false);
        mc.method_1507(new ClickGui());
    }
}
