package laoqi123.module.modules.render.chestesp.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.LoadWorldEvent;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.module.modules.render.chestesp.ChestESPMode;
import laoqi123.util.BlockUtil;
import laoqi123.util.RenderUtil;
import net.minecraft.class_10142;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2623;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_9974;
import java.awt.Color;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class SimpleChestESP extends ChestESPMode {
    private static final class_310 mc = class_310.method_1551();
    private static final Color CHEST_COLOR = new Color(0, 255, 0);
    private static final Color OPENED_CHEST_COLOR = new Color(255, 0, 0);

    private final List<class_2338> openedChestPositions = new CopyOnWriteArrayList<>();
    private final List<class_238> renderBoundingBoxes = new CopyOnWriteArrayList<>();

    @Override
    public void onLoadWorld(LoadWorldEvent event) {
        this.openedChestPositions.clear();
    }

    @Override
    public void onPacket(PacketEvent event) {
        if (event.getType() != EventType.RECEIVE) return;
        if (!(event.getPacket() instanceof class_2623 packet)) return;
        if (packet.method_11294() != 1 || packet.method_11296() != 1) return;
        if (mc.field_1687 == null) return;
        class_2248 block = packet.method_11295();
        if (block != class_2246.field_10034 && block != class_2246.field_10380) return;
        this.addOpenedChest(packet.method_11298());
    }

    private void addOpenedChest(class_2338 pos) {
        if (this.openedChestPositions.contains(pos)) return;
        this.openedChestPositions.add(pos);
        if (mc.field_1687 == null) return;
        class_2248 block = mc.field_1687.method_8320(pos).method_26204();
        if (block instanceof class_2281) {
            for (class_2350 facing : class_2350.class_2353.field_11062) {
                class_2338 neighbor = pos.method_10093(facing);
                if (mc.field_1687.method_8320(neighbor).method_26204() == block && !this.openedChestPositions.contains(neighbor)) {
                    this.openedChestPositions.add(neighbor);
                }
            }
        }
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (!this.parent.isEnabled() || mc.field_1687 == null) return;

        this.renderBoundingBoxes.clear();
        for (class_2586 blockEntity : BlockUtil.getBlockEntities()) {
            if (!(blockEntity instanceof class_2595 chestBlockEntity)) continue;
            class_238 aabb = this.getChestAabb(chestBlockEntity);
            if (aabb != null) {
                this.renderBoundingBoxes.add(aabb);
            }
        }

        RenderUtil.enableRenderState();
        for (class_238 aabb : this.renderBoundingBoxes) {
            class_2338 blockPos = class_2338.method_49637(aabb.field_1323, aabb.field_1322, aabb.field_1321);
            Color color = this.openedChestPositions.contains(blockPos) ? OPENED_CHEST_COLOR : CHEST_COLOR;
            this.drawFilledBoxAlpha(aabb, color.getRed(), color.getGreen(), color.getBlue(), 64);
        }
        RenderUtil.disableRenderState();
    }

    private class_238 getChestAabb(class_2595 chestBlockEntity) {
        if (mc.field_1687 == null) return null;
        class_2338 pos = chestBlockEntity.method_11016();
        class_2680 state = null;
        if (mc.field_1687.method_8320(pos).method_26204() instanceof class_2281) {
            state = mc.field_1687.method_8320(pos);
        }
        if (state == null || !state.method_28498(class_2281.field_10770)) {
            return null;
        }
        class_2745 chestType = state.method_11654(class_2281.field_10770);
        if (chestType == class_2745.field_12574) {
            return null;
        }
        class_238 aabb = new class_238(pos);
        if (chestType != class_2745.field_12569) {
            class_2248 block = state.method_26204();
            for (class_2350 facing : class_2350.class_2353.field_11062) {
                class_2338 neighbor = pos.method_10093(facing);
                if (mc.field_1687.method_8320(neighbor).method_26204() == block) {
                    aabb = aabb.method_991(new class_238(neighbor));
                }
            }
        }
        return aabb;
    }

    private void drawFilledBoxAlpha(class_238 bb, int red, int green, int blue, int alpha) {
        RenderSystem.setShader(class_10142.field_53876);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        class_9974.method_62300(new class_4587(), bufferBuilder, bb.field_1323, bb.field_1322, bb.field_1321, bb.field_1320, bb.field_1325, bb.field_1324, red, green, blue, alpha);
        class_286.method_43433(bufferBuilder.method_60800());
    }
}