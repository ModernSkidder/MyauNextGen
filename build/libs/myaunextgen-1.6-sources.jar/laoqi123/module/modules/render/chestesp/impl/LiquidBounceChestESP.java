package laoqi123.module.modules.render.chestesp.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.Myau;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.module.modules.player.ChestStealer;
import laoqi123.module.modules.render.chestesp.ChestESPMode;
import laoqi123.value.properties.*;
import net.minecraft.class_10142;
import net.minecraft.class_10256;
import net.minecraft.class_1297;
import net.minecraft.class_1492;
import net.minecraft.class_1501;
import net.minecraft.class_1694;
import net.minecraft.class_1700;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2589;
import net.minecraft.class_2595;
import net.minecraft.class_2601;
import net.minecraft.class_2609;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_2680;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3719;
import net.minecraft.class_4587;
import net.minecraft.class_5498;
import net.minecraft.class_8172;
import net.minecraft.class_8887;
import net.minecraft.class_9974;
import laoqi123.util.BlockUtil;
import laoqi123.util.RenderUtil;

public class LiquidBounceChestESP extends ChestESPMode {
    private static final class_310 mc = class_310.method_1551();

    public final ModeValue mode = new ModeValue("Mode", 0, new String[]{"Box", "Glow"});
    public final BooleanValue requiresChestStealer = new BooleanValue("Requires Chest Stealer", false);
    public final FloatValue maximumDistance = new FloatValue("Maximum Distance", 128.0F, 1.0F, 512.0F);
    public final BooleanValue outline = new BooleanValue("Outline", true);

    public final BooleanValue chest = new BooleanValue("Chest", true);
    public final ColorValue chestColor = new ColorValue("Chest Color", 0xFF0064FF);
    public final BooleanValue chestTracers = new BooleanValue("Chest Tracers", false);

    public final BooleanValue enderChest = new BooleanValue("EnderChest", true);
    public final ColorValue enderChestColor = new ColorValue("EnderChest Color", 0xFFFF00FF);
    public final BooleanValue enderChestTracers = new BooleanValue("EnderChest Tracers", false);

    public final BooleanValue furnace = new BooleanValue("Furnace", true);
    public final ColorValue furnaceColor = new ColorValue("Furnace Color", 0xFF4F4F4F);
    public final BooleanValue furnaceTracers = new BooleanValue("Furnace Tracers", false);

    public final BooleanValue brewingStand = new BooleanValue("BrewingStand", true);
    public final ColorValue brewingStandColor = new ColorValue("BrewingStand Color", 0xFF8B4513);
    public final BooleanValue brewingStandTracers = new BooleanValue("BrewingStand Tracers", false);

    public final BooleanValue dispenser = new BooleanValue("Dispenser", true);
    public final ColorValue dispenserColor = new ColorValue("Dispenser Color", 0xFFD3D3D3);
    public final BooleanValue dispenserTracers = new BooleanValue("Dispenser Tracers", false);

    public final BooleanValue hopper = new BooleanValue("Hopper", true);
    public final ColorValue hopperColor = new ColorValue("Hopper Color", 0xFF808080);
    public final BooleanValue hopperTracers = new BooleanValue("Hopper Tracers", false);

    public final BooleanValue shulkerBox = new BooleanValue("ShulkerBox", true);
    public final ColorValue shulkerBoxColor = new ColorValue("ShulkerBox Color", 0xFF9D6E9D);
    public final BooleanValue shulkerBoxTracers = new BooleanValue("ShulkerBox Tracers", false);

    public final BooleanValue pot = new BooleanValue("Pot", true);
    public final ColorValue potColor = new ColorValue("Pot Color", 0xFFD18600);
    public final BooleanValue potTracers = new BooleanValue("Pot Tracers", false);

    private enum StorageType {
        CHEST,
        ENDER_CHEST,
        FURNACE,
        BREWING_STAND,
        DISPENSER,
        HOPPER,
        SHULKER_BOX,
        POT
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (!this.parent.isEnabled() || mc.field_1687 == null) return;
        if (this.requiresChestStealer.getValue()) {
            ChestStealer chestStealer = (ChestStealer) Myau.moduleManager.modules.get(ChestStealer.class);
            if (chestStealer == null || !chestStealer.isEnabled()) {
                return;
            }
        }

        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        double maxDistanceSquared = this.maximumDistance.getValue() * this.maximumDistance.getValue();

        if (this.mode.getValue() == 0) {
            this.renderBoxes(event, cameraPos, maxDistanceSquared);
        } else {
            this.renderGlow(cameraPos, maxDistanceSquared);
        }
        this.renderTracers(cameraPos, maxDistanceSquared);
    }

    private void renderBoxes(Render3DEvent event, class_243 cameraPos, double maxDistanceSquared) {
        RenderUtil.enableRenderState();

        for (class_2586 blockEntity : BlockUtil.getBlockEntities()) {
            StorageType type = categorize(blockEntity);
            if (type == null) continue;
            int color = this.getTypeColor(type);
            if ((color >>> 24) == 0 || !this.isTypeEnabled(type)) continue;
            class_2338 pos = blockEntity.method_11016();
            if (!this.withinDistance(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, cameraPos, maxDistanceSquared)) continue;
            class_2680 state = mc.field_1687.method_8320(pos);
            if (state.method_26215()) continue;
            class_238 box = state.method_26218(mc.field_1687, pos).method_1107()
                    .method_989(pos.method_10263(), pos.method_10264(), pos.method_10260())
                    .method_989(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
            this.drawBox(box, color);
        }

        for (class_1297 entity : mc.field_1687.method_18112()) {
            StorageType type = categorize(entity);
            if (type == null) continue;
            int color = this.getTypeColor(type);
            if ((color >>> 24) == 0 || !this.isTypeEnabled(type)) continue;
            if (!this.withinDistance(entity.method_23317(), entity.method_23318(), entity.method_23321(), cameraPos, maxDistanceSquared)) continue;

            double halfWidth = entity.method_17681() / 2.0;
            class_238 box = new class_238(-halfWidth, 0.0, -halfWidth, halfWidth, entity.method_17682(), halfWidth).method_1014(0.05);
            double x = RenderUtil.lerpDouble(entity.method_23317(), entity.field_6014, event.getPartialTicks()) - cameraPos.field_1352;
            double y = RenderUtil.lerpDouble(entity.method_23318(), entity.field_6036, event.getPartialTicks()) - cameraPos.field_1351;
            double z = RenderUtil.lerpDouble(entity.method_23321(), entity.field_5969, event.getPartialTicks()) - cameraPos.field_1350;
            this.drawBox(box.method_989(x, y, z), color);
        }

        RenderUtil.disableRenderState();
    }

    private void renderGlow(class_243 cameraPos, double maxDistanceSquared) {
        RenderUtil.enableRenderState();

        for (class_2586 blockEntity : BlockUtil.getBlockEntities()) {
            StorageType type = categorize(blockEntity);
            if (type == null) continue;
            int color = this.getTypeColor(type);
            if ((color >>> 24) == 0 || !this.isTypeEnabled(type)) continue;
            class_2338 pos = blockEntity.method_11016();
            if (!this.withinDistance(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, cameraPos, maxDistanceSquared)) continue;
            class_2680 state = mc.field_1687.method_8320(pos);
            if (state.method_26215() || state.method_26217() != class_2464.field_11458) continue;
            class_238 box = state.method_26218(mc.field_1687, pos).method_1107()
                    .method_989(pos.method_10263(), pos.method_10264(), pos.method_10260())
                    .method_989(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
            RenderUtil.drawBoundingBox(box, getRed(color), getGreen(color), getBlue(color), 255, 2.0F);
        }

        RenderUtil.disableRenderState();
    }

    private void renderTracers(class_243 cameraPos, double maxDistanceSquared) {
        float partialTicks = mc.method_61966().method_60637(true);
        class_243 eyeVector;
        if (mc.field_1690.method_31044() == class_5498.field_26664) {
            eyeVector = new class_243(0.0, 0.0, 1.0)
                    .method_1037((float) (-Math.toRadians(RenderUtil.lerpFloat(mc.method_1560().method_36455(), mc.method_1560().field_6004, partialTicks))))
                    .method_1024((float) (-Math.toRadians(RenderUtil.lerpFloat(mc.method_1560().method_36454(), mc.method_1560().field_5982, partialTicks))));
        } else {
            eyeVector = new class_243(0.0, 0.0, 0.0)
                    .method_1037((float) (-Math.toRadians(mc.field_1773.method_19418().method_19329())))
                    .method_1024((float) (-Math.toRadians(mc.field_1773.method_19418().method_19330())));
        }
        eyeVector = new class_243(eyeVector.field_1352, eyeVector.field_1351 + (double) mc.method_1560().method_5751(), eyeVector.field_1350);

        RenderUtil.enableRenderState();
        for (class_2586 blockEntity : BlockUtil.getBlockEntities()) {
            StorageType type = categorize(blockEntity);
            if (type == null) continue;
            if (!this.isTypeEnabled(type) || !this.isTypeTracers(type)) continue;
            int color = this.getTypeColor(type);
            if ((color >>> 24) == 0) continue;
            class_2338 pos = blockEntity.method_11016();
            double x = pos.method_10263() + 0.5 - cameraPos.field_1352;
            double y = pos.method_10264() + 0.5 - cameraPos.field_1351;
            double z = pos.method_10260() + 0.5 - cameraPos.field_1350;
            if (!this.withinDistance(x, y, z, cameraPos, maxDistanceSquared)) continue;
            RenderUtil.drawLine3D(eyeVector, x, y, z, getRed(color), getGreen(color), getBlue(color), 255.0F, 1.5F);
        }
        RenderUtil.disableRenderState();
    }

    private void drawBox(class_238 box, int color) {
        this.drawFilledBoxAlpha(box, getRed(color), getGreen(color), getBlue(color), 50);
        if (this.outline.getValue()) {
            RenderUtil.drawBoundingBox(box, getRed(color), getGreen(color), getBlue(color), 100, 2.0F);
        }
    }

    private boolean withinDistance(double x, double y, double z, class_243 cameraPos, double maxDistanceSquared) {
        double dx = x - cameraPos.field_1352;
        double dy = y - cameraPos.field_1351;
        double dz = z - cameraPos.field_1350;
        return dx * dx + dy * dy + dz * dz < maxDistanceSquared;
    }

    private boolean isTypeEnabled(StorageType type) {
        switch (type) {
            case CHEST: return this.chest.getValue();
            case ENDER_CHEST: return this.enderChest.getValue();
            case FURNACE: return this.furnace.getValue();
            case BREWING_STAND: return this.brewingStand.getValue();
            case DISPENSER: return this.dispenser.getValue();
            case HOPPER: return this.hopper.getValue();
            case SHULKER_BOX: return this.shulkerBox.getValue();
            case POT: return this.pot.getValue();
            default: return false;
        }
    }

    private boolean isTypeTracers(StorageType type) {
        switch (type) {
            case CHEST: return this.chestTracers.getValue();
            case ENDER_CHEST: return this.enderChestTracers.getValue();
            case FURNACE: return this.furnaceTracers.getValue();
            case BREWING_STAND: return this.brewingStandTracers.getValue();
            case DISPENSER: return this.dispenserTracers.getValue();
            case HOPPER: return this.hopperTracers.getValue();
            case SHULKER_BOX: return this.shulkerBoxTracers.getValue();
            case POT: return this.potTracers.getValue();
            default: return false;
        }
    }

    private int getTypeColor(StorageType type) {
        switch (type) {
            case CHEST: return this.chestColor.getValue();
            case ENDER_CHEST: return this.enderChestColor.getValue();
            case FURNACE: return this.furnaceColor.getValue();
            case BREWING_STAND: return this.brewingStandColor.getValue();
            case DISPENSER: return this.dispenserColor.getValue();
            case HOPPER: return this.hopperColor.getValue();
            case SHULKER_BOX: return this.shulkerBoxColor.getValue();
            case POT: return this.potColor.getValue();
            default: return 0xFFFFFFFF;
        }
    }

    private static int getRed(int color) {
        return (color >> 16) & 0xFF;
    }

    private static int getGreen(int color) {
        return (color >> 8) & 0xFF;
    }

    private static int getBlue(int color) {
        return color & 0xFF;
    }

    private static StorageType categorize(class_2586 blockEntity) {
        if (blockEntity instanceof class_2595 || blockEntity instanceof class_3719) return StorageType.CHEST;
        if (blockEntity instanceof class_2611) return StorageType.ENDER_CHEST;
        if (blockEntity instanceof class_2609) return StorageType.FURNACE;
        if (blockEntity instanceof class_2589) return StorageType.BREWING_STAND;
        if (blockEntity instanceof class_2601 || blockEntity instanceof class_8887) return StorageType.DISPENSER;
        if (blockEntity instanceof class_2614) return StorageType.HOPPER;
        if (blockEntity instanceof class_2627) return StorageType.SHULKER_BOX;
        if (blockEntity instanceof class_8172) return StorageType.POT;
        return null;
    }

    private static StorageType categorize(class_1297 entity) {
        if (entity instanceof class_1700) return StorageType.HOPPER;
        if (entity instanceof class_1694 || entity instanceof class_10256) return StorageType.CHEST;
        if (entity instanceof class_1492 donkey && donkey.method_6703()) return StorageType.CHEST;
        if (entity instanceof class_1501) return StorageType.CHEST;
        return null;
    }

    private void drawFilledBoxAlpha(class_238 bb, int red, int green, int blue, int alpha) {
        RenderSystem.setShader(class_10142.field_53876);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        class_9974.method_62300(new class_4587(), bufferBuilder, bb.field_1323, bb.field_1322, bb.field_1321, bb.field_1320, bb.field_1325, bb.field_1324, red, green, blue, alpha);
        class_286.method_43433(bufferBuilder.method_60800());
    }
}