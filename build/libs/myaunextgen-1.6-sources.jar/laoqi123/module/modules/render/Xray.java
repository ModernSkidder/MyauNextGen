package laoqi123.module.modules.render;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.LoadWorldEvent;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.mixin.MinecraftClientAccessor;
import laoqi123.module.Module;
import laoqi123.value.properties.*;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2496;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5498;
import laoqi123.util.RenderUtil;
import java.awt.*;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.concurrent.CopyOnWriteArraySet;

public class Xray extends Module {
    private static final class_310 mc = class_310.method_1551();
    private static final LinkedHashSet<class_2248> xrayBlocks;
    private static final LinkedHashSet<class_2382> caveOffsetsSmall;
    private static final LinkedHashSet<class_2382> caveOffsetsLarge;
    public final CopyOnWriteArraySet<class_2338> trackedBlocks = new CopyOnWriteArraySet<>();
    public final CopyOnWriteArraySet<class_2338> pendingBlocks = new CopyOnWriteArraySet<>();
    public final ModeValue mode = new ModeValue("mode", 0, new String[]{"SOFT", "FULL"});
    public final PercentValue opacity = new PercentValue("opacity", 50);
    public final IntValue range = new IntValue("range", 64, 16, 512);
    public final BooleanValue cavesOnly = new BooleanValue("caves-only", true);
    public final IntValue caveRadius = new IntValue("caves-radius", 2, 1, 2);
    public final BooleanValue diamonds = new BooleanValue("diamonds", true);
    public final BooleanValue diamondTracers = new BooleanValue("diamonds-tracers", true);
    public final BooleanValue gold = new BooleanValue("gold", true);
    public final BooleanValue goldTracers = new BooleanValue("gold-tracers", true);
    public final BooleanValue iron = new BooleanValue("iron", false);
    public final BooleanValue ironTracers = new BooleanValue("iron-tracers", false);
    public final BooleanValue coal = new BooleanValue("coal", false);
    public final BooleanValue coalTracers = new BooleanValue("coal-tracers", false);
    public final BooleanValue redstone = new BooleanValue("redstone", false);
    public final BooleanValue redStoneTracers = new BooleanValue("redstone-tracers", false);
    public final BooleanValue lapis = new BooleanValue("lapis", false);
    public final BooleanValue lapisTracers = new BooleanValue("lapis-tracers", false);
    public final BooleanValue emeralds = new BooleanValue("emeralds", false);
    public final BooleanValue emeraldsTracers = new BooleanValue("emeralds-tracers", false);
    public final BooleanValue spawners = new BooleanValue("spawners", false);
    public final BooleanValue spawnerTracers = new BooleanValue("spawners-tracers", false);
    public final BooleanValue canes = new BooleanValue("canes", false);
    public final BooleanValue canesTracers = new BooleanValue("canes-tracers", false);
    public final BooleanValue warts = new BooleanValue("warts", false);
    public final BooleanValue wartsTracers = new BooleanValue("warts-tracers", false);

    private void renderOreHighlight(class_2338 blockPos, class_2680 state, class_243 viewVector) {
        if (mc.field_1724 != null
                && mc.field_1724.method_5649((double) blockPos.method_10263() + 0.5, (double) blockPos.method_10264() + 0.5, (double) blockPos.method_10260() + 0.5)
                        <= (double) this.range.getValue() * (double) this.range.getValue()) {
            Color color = this.getOreColor(state);
            RenderUtil.drawBlockBoundingBox(blockPos, 1.0, color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha(), 1.5F);
            if (this.shouldDrawTracer(state)) {
                RenderUtil.drawLine3D(
                        viewVector,
                        (double) blockPos.method_10263() + 0.5,
                        (double) blockPos.method_10264() + 0.5,
                        (double) blockPos.method_10260() + 0.5,
                        (float) color.getRed() / 255.0F,
                        (float) color.getGreen() / 255.0F,
                        (float) color.getBlue() / 255.0F,
                        1.0F,
                        1.5F
                );
            }
        }
    }

    private Color getOreColor(class_2680 state) {
        if (state.method_27852(class_2246.field_10571)) {
            return new Color(16777045);
        }
        if (state.method_27852(class_2246.field_10212)) {
            return new Color(16777215);
        }
        if (state.method_27852(class_2246.field_10418)) {
            return new Color(0);
        }
        if (state.method_27852(class_2246.field_10090)) {
            return new Color(5592575);
        }
        if (state.method_27852(class_2246.field_10260)) {
            return new Color(16733695);
        }
        if (state.method_27852(class_2246.field_10442)) {
            return new Color(5636095);
        }
        if (state.method_27852(class_2246.field_10080) || state.method_27852(class_2246.field_29030)) {
            return new Color(16733525);
        }
        if (state.method_27852(class_2246.field_10424)) {
            return new Color(11206570);
        }
        if (state.method_27852(class_2246.field_9974)) {
            return new Color(11141120);
        }
        if (state.method_27852(class_2246.field_10013)) {
            return new Color(5635925);
        }
        return new Color(-1);
    }

    private boolean shouldDrawTracer(class_2680 state) {
        if (state.method_27852(class_2246.field_10571)) {
            return this.goldTracers.getValue();
        }
        if (state.method_27852(class_2246.field_10212)) {
            return this.ironTracers.getValue();
        }
        if (state.method_27852(class_2246.field_10418)) {
            return this.coalTracers.getValue();
        }
        if (state.method_27852(class_2246.field_10090)) {
            return this.lapisTracers.getValue();
        }
        if (state.method_27852(class_2246.field_10260)) {
            return this.spawnerTracers.getValue();
        }
        if (state.method_27852(class_2246.field_10442)) {
            return this.diamondTracers.getValue();
        }
        if (state.method_27852(class_2246.field_10080) || state.method_27852(class_2246.field_29030)) {
            return this.redStoneTracers.getValue();
        }
        if (state.method_27852(class_2246.field_10424)) {
            return this.canesTracers.getValue();
        }
        if (state.method_27852(class_2246.field_9974)) {
            return this.wartsTracers.getValue();
        }
        if (state.method_27852(class_2246.field_10013)) {
            return this.emeraldsTracers.getValue();
        }
        return false;
    }

    private boolean isValidCaveBlock(class_2680 state) {
        return state.method_26204() instanceof class_2496 || !state.method_26225() || state.method_26219();
    }

    private boolean isValidCaveBlock(class_2338 pos) {
        if (mc.field_1687 == null || !mc.field_1687.method_22340(pos)) {
            return false;
        }
        class_2680 state = mc.field_1687.method_8320(pos);
        return state.method_26204() instanceof class_2496 || !state.method_26234(mc.field_1687, pos) || !state.method_26225() || state.method_26219();
    }

    public Xray() {
        super("Xray", false);
    }

    public boolean shouldRenderSide(class_2248 block) {
        return xrayBlocks.contains(block);
    }

    public boolean isXrayBlock(class_2680 state) {
        if (state.method_27852(class_2246.field_10571)) {
            return this.gold.getValue();
        }
        if (state.method_27852(class_2246.field_10212)) {
            return this.iron.getValue();
        }
        if (state.method_27852(class_2246.field_10418)) {
            return this.coal.getValue();
        }
        if (state.method_27852(class_2246.field_10090)) {
            return this.lapis.getValue();
        }
        if (state.method_27852(class_2246.field_10260)) {
            return this.spawners.getValue();
        }
        if (state.method_27852(class_2246.field_10442)) {
            return this.diamonds.getValue();
        }
        if (state.method_27852(class_2246.field_10080) || state.method_27852(class_2246.field_29030)) {
            return this.redstone.getValue();
        }
        if (state.method_27852(class_2246.field_10424)) {
            return this.canes.getValue();
        }
        if (state.method_27852(class_2246.field_9974)) {
            return this.warts.getValue();
        }
        if (state.method_27852(class_2246.field_10013)) {
            return this.emeralds.getValue();
        }
        return false;
    }

    public boolean checkBlock(class_2680 state) {
        return !this.cavesOnly.getValue() || this.isValidCaveBlock(state);
    }

    public boolean checkBlock(class_2338 blockPos) {
        if (!this.cavesOnly.getValue()) {
            return true;
        } else {
            if (this.caveRadius.getValue() >= 2) {
                for (class_2382 vec3i : caveOffsetsLarge) {
                    if (this.isValidCaveBlock(blockPos.method_10081(vec3i))) {
                        return true;
                    }
                }
            } else {
                for (class_2382 vec3i : caveOffsetsSmall) {
                    if (this.isValidCaveBlock(blockPos.method_10081(vec3i))) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (this.isEnabled()) {
            if (mc.field_1724 == null || mc.field_1687 == null) {
                return;
            }
            class_1297 entity = mc.method_1560() != null ? mc.method_1560() : mc.field_1724;
            float tickDelta = ((MinecraftClientAccessor) mc).getTimer().method_60637(false);
            class_243 vec3;
            if (mc.field_1690.method_31044() == class_5498.field_26664) {
                vec3 = new class_243(0.0, 0.0, 1.0)
                        .method_1037((float) (-Math.toRadians(RenderUtil.lerpFloat(entity.method_36455(), entity.field_6004, tickDelta))))
                        .method_1024((float) (-Math.toRadians(RenderUtil.lerpFloat(entity.method_36454(), entity.field_5982, tickDelta))));
            } else {
                vec3 = new class_243(0.0, 0.0, 0.0)
                        .method_1037((float) (-Math.toRadians(RenderUtil.lerpFloat(entity.method_36455(), entity.field_6004, tickDelta))))
                        .method_1024((float) (-Math.toRadians(RenderUtil.lerpFloat(entity.method_36454(), entity.field_5982, tickDelta))));
            }
            vec3 = new class_243(vec3.field_1352, vec3.field_1351 + (double) entity.method_18381(entity.method_18376()), vec3.field_1350);
            RenderUtil.enableRenderState();
            for (class_2338 blockPos : this.trackedBlocks) {
                if (this.pendingBlocks.contains(blockPos)) {
                    this.trackedBlocks.remove(blockPos);
                } else {
                    class_2680 state = mc.field_1687.method_8320(blockPos);
                    if (this.isXrayBlock(state)) {
                        this.renderOreHighlight(blockPos, state, vec3);
                    } else {
                        this.trackedBlocks.remove(blockPos);
                    }
                }
            }
            for (class_2338 blockPos : this.pendingBlocks) {
                class_2680 state = mc.field_1687.method_8320(blockPos);
                if (this.isXrayBlock(state)) {
                    this.renderOreHighlight(blockPos, state, vec3);
                } else {
                    this.pendingBlocks.remove(blockPos);
                }
            }
            RenderUtil.disableRenderState();
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getType() == EventType.RECEIVE) {
            if (event.getPacket() instanceof class_2637) {
                class_2637 packet = (class_2637) event.getPacket();
                packet.method_30621((blockPos, blockState) -> {
                    if (this.isXrayBlock(blockState)) {
                        this.pendingBlocks.add(blockPos.method_10062());
                    }
                });
            } else if (event.getPacket() instanceof class_2626) {
                class_2626 packet = (class_2626) event.getPacket();
                if (this.isXrayBlock(packet.method_11308())) {
                    this.pendingBlocks.add(packet.method_11309());
                }
            }
        }
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        this.trackedBlocks.clear();
        this.pendingBlocks.clear();
    }

    @Override
    public void onEnabled() {
        if (mc.field_1769 != null) {
            mc.field_1769.method_3279();
        }
    }

    @Override
    public void onDisabled() {
        if (mc.field_1769 != null) {
            mc.field_1769.method_3279();
        }
    }

    @Override
    public void verifyValue(String mode) {
        this.trackedBlocks.clear();
        this.pendingBlocks.clear();
        if (this.isEnabled() && mc.field_1769 != null) {
            mc.field_1769.method_3279();
        }
    }

    static {
        xrayBlocks = new LinkedHashSet<>(
                Arrays.asList(
                        class_2246.field_10442,
                        class_2246.field_10571,
                        class_2246.field_10212,
                        class_2246.field_10418,
                        class_2246.field_10080,
                        class_2246.field_29030,
                        class_2246.field_10090,
                        class_2246.field_10013,
                        class_2246.field_10260,
                        class_2246.field_10424,
                        class_2246.field_9974
                )
        );
        caveOffsetsSmall = new LinkedHashSet<>(
                Arrays.asList(new class_2382(0, -1, 0), new class_2382(1, 0, 0), new class_2382(0, 0, -1), new class_2382(0, 0, 1), new class_2382(-1, 0, 0), new class_2382(0, 1, 0))
        );
        caveOffsetsLarge = new LinkedHashSet<>(
                Arrays.asList(
                        new class_2382(0, -2, 0),
                        new class_2382(1, -1, 0),
                        new class_2382(0, -1, -1),
                        new class_2382(0, -1, 0),
                        new class_2382(0, -1, 1),
                        new class_2382(-1, -1, 0),
                        new class_2382(2, 0, 0),
                        new class_2382(0, 0, 2),
                        new class_2382(0, 0, -2),
                        new class_2382(-2, 0, 0),
                        new class_2382(1, 0, -1),
                        new class_2382(1, 0, 0),
                        new class_2382(1, 0, 1),
                        new class_2382(0, 0, -1),
                        new class_2382(0, 0, 1),
                        new class_2382(-1, 0, -1),
                        new class_2382(-1, 0, 0),
                        new class_2382(-1, 0, 1),
                        new class_2382(1, 1, 0),
                        new class_2382(0, 1, -1),
                        new class_2382(0, 1, 0),
                        new class_2382(0, 1, 1),
                        new class_2382(-1, 1, 0),
                        new class_2382(0, 2, 0)
                )
        );
    }
}
