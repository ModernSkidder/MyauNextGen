package laoqi123.module.modules.render;

import laoqi123.Myau;
import laoqi123.event.EventTarget;
import laoqi123.event.impl.Render3DEvent;
import laoqi123.mixin.EntityRenderDispatcherAccessor;
import laoqi123.module.Module;
import laoqi123.value.properties.*;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2742;
import net.minecraft.class_310;
import laoqi123.util.RenderUtil;
import java.awt.*;
import java.util.Arrays;
import java.util.concurrent.CopyOnWriteArraySet;

public class BedESP extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final CopyOnWriteArraySet<class_2338> beds = new CopyOnWriteArraySet<>();
    public final ModeValue mode = new ModeValue("mode", 0, new String[]{"DEFAULT", "FULL"});
    public final ModeValue color = new ModeValue("color", 0, new String[]{"CUSTOM", "HUD"});
    public final ColorValue customColor;
    public final PercentValue opacity;
    public final BooleanValue outline;
    public final BooleanValue obsidian;

    private Color getColor() {
        switch (this.color.getValue()) {
            case 0:
                return new Color(this.customColor.getValue());
            case 1:
                return ((HUD) Myau.moduleManager.modules.get(HUD.class)).getColor(System.currentTimeMillis());
            default:
                return new Color(-1);
        }
    }

    private void drawObsidianBox(class_238 box) {
        if (this.outline.getValue()) {
            RenderUtil.drawBoundingBox(box, 170, 0, 170, 255, 1.5F);
        }
        RenderUtil.drawFilledBox(box, 170, 0, 170);
    }

    private void drawObsidian(class_2338 blockPos) {
        if (this.outline.getValue()) {
            RenderUtil.drawBlockBoundingBox(blockPos, 1.0, 170, 0, 170, 255, 1.5F);
        }
        RenderUtil.drawBlockBox(
                blockPos, 1.0, 170, 0, 170
        );
    }

    public BedESP() {
        super("BedESP", false);
        this.customColor = new ColorValue("custom-color", (int) 8085714755840333141L, () -> this.color.getValue() == 0);
        this.opacity = new PercentValue("opacity", 25);
        this.outline = new BooleanValue("outline", false);
        this.obsidian = new BooleanValue("obsidian", true);
    }

    public double getHeight() {
        return this.mode.getValue() == 1 ? 1.0 : 0.5625;
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (this.isEnabled()) {
            RenderUtil.enableRenderState();
            EntityRenderDispatcherAccessor renderManager = (EntityRenderDispatcherAccessor) mc.method_1561();
            for (class_2338 blockPos : this.beds) {
                class_2680 state = mc.field_1687.method_8320(blockPos);
                if (state.method_26204() instanceof class_2244 && state.method_11654(class_2244.field_9967) == class_2742.field_12560) {
                    class_2338 opposite = blockPos.method_10093(state.method_11654(class_2244.field_11177).method_10153());
                    class_2680 oppositeState = mc.field_1687.method_8320(opposite);
                    if (oppositeState.method_26204() instanceof class_2244 && oppositeState.method_11654(class_2244.field_9967) == class_2742.field_12557) {
                        if (this.obsidian.getValue()) {
                            for (class_2350 facing : Arrays.asList(class_2350.field_11036, class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039)) {
                                class_2338 offsetX = blockPos.method_10093(facing);
                                class_2338 offsetZ = opposite.method_10093(facing);
                                boolean xObsidian = mc.field_1687.method_8320(offsetX).method_27852(class_2246.field_10540);
                                boolean zObsidian = mc.field_1687.method_8320(offsetZ).method_27852(class_2246.field_10540);
                                if (xObsidian && zObsidian) {
                                    this.drawObsidianBox(
                                            new class_238(
                                                    Math.min(offsetX.method_10263(), offsetZ.method_10263()),
                                                    offsetX.method_10264(),
                                                    Math.min(offsetX.method_10260(), offsetZ.method_10260()),
                                                    Math.max((double) offsetX.method_10263() + 1.0, (double) offsetZ.method_10263() + 1.0),
                                                    (double) offsetX.method_10264() + 1.0,
                                                    Math.max((double) offsetX.method_10260() + 1.0, (double) offsetZ.method_10260() + 1.0)
                                            )
                                                    .method_989(
                                                            -renderManager.getCamera().method_19326().field_1352,
                                                            -renderManager.getCamera().method_19326().field_1351,
                                                            -renderManager.getCamera().method_19326().field_1350
                                                    )
                                    );
                                } else if (xObsidian) {
                                    this.drawObsidian(offsetX);
                                } else if (zObsidian) {
                                    this.drawObsidian(offsetZ);
                                }
                            }
                        }
                        class_238 box = new class_238(
                                Math.min(blockPos.method_10263(), opposite.method_10263()),
                                blockPos.method_10264(),
                                Math.min(blockPos.method_10260(), opposite.method_10260()),
                                Math.max((double) blockPos.method_10263() + 1.0, (double) opposite.method_10263() + 1.0),
                                (double) blockPos.method_10264() + this.getHeight(),
                                Math.max((double) blockPos.method_10260() + 1.0, (double) opposite.method_10260() + 1.0)
                        )
                                .method_989(
                                        -renderManager.getCamera().method_19326().field_1352,
                                        -renderManager.getCamera().method_19326().field_1351,
                                        -renderManager.getCamera().method_19326().field_1350
                                );
                        Color color = this.getColor();
                        if (this.outline.getValue()) {
                            RenderUtil.drawBoundingBox(box, color.getRed(), color.getGreen(), color.getBlue(), 255, 1.5F);
                        }
                        RenderUtil.drawFilledBox(
                                box,
                                color.getRed(),
                                color.getGreen(),
                                color.getBlue()
                        );
                    }
                } else {
                    this.beds.remove(blockPos);
                }
            }
            RenderUtil.disableRenderState();
        }
    }

    @Override
    public void onEnabled() {
        if (mc.field_1769 != null) {
            mc.field_1769.method_3279();
        }
    }
}
