package laoqi123.module.modules.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.Myau;
import laoqi123.enums.BlinkModules;
import laoqi123.enums.ChatColors;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.Render2DEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.font.UFontRenderer;
import laoqi123.mixin.ChatScreenAccessor;
import laoqi123.module.Module;
import laoqi123.value.properties.*;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_8646;
import net.minecraft.class_9011;
import laoqi123.util.ColorUtil;
import laoqi123.util.RenderUtil;
import java.awt.*;
import java.util.*;
import java.util.stream.Collectors;

public class HUD extends Module {
    private static final class_310 mc = class_310.method_1551();
    private List<Module> activeModules = new ArrayList<>();
    private final Map<Module, Float> animationMap = new HashMap<>();

    public final ModeValue colorMode = new ModeValue(
            "color", 3, new String[]{"RAINBOW", "CHROMA", "ASTOLFO", "CUSTOM1", "CUSTOM12", "CUSTOM123"}
    );
    public final FloatValue colorSpeed = new FloatValue("color-speed", 1.0F, 0.5F, 1.5F);
    public final PercentValue colorSaturation = new PercentValue("color-saturation", 50);
    public final PercentValue colorBrightness = new PercentValue("color-brightness", 100);
    public final ColorValue custom1 = new ColorValue("custom-color-1", Color.WHITE.getRGB(), () -> this.colorMode.getValue() == 3 || this.colorMode.getValue() == 4 || this.colorMode.getValue() == 5);
    public final ColorValue custom2 = new ColorValue("custom-color-2", Color.WHITE.getRGB(), () -> this.colorMode.getValue() == 4 || this.colorMode.getValue() == 5);
    public final ColorValue custom3 = new ColorValue("custom-color-3", Color.WHITE.getRGB(), () -> this.colorMode.getValue() == 5);
    public final ModeValue fontMode = new ModeValue("font-mode", 0, new String[]{"Minecraft", "Modern"});
    public final ModeValue posX = new ModeValue("position-x", 0, new String[]{"LEFT", "RIGHT"});
    public final ModeValue posY = new ModeValue("position-y", 0, new String[]{"TOP", "BOTTOM"});

    public final BooleanValue showBar = new BooleanValue("bar", true);
    public final ModeValue sidebarMode = new ModeValue("sidebar-mode", 0, new String[]{"RIGHT", "LEFT", "TOP", "OUTLINE", "NONE"}, this.showBar::getValue);
    public final FloatValue barWidth = new FloatValue("bar-width", 1.0F, 0.1F, 1.5F,
            () -> this.showBar.getValue() && this.sidebarMode.getValue() != 4 && this.sidebarMode.getValue() != 3);
    public final BooleanValue animation = new BooleanValue("animation", false);

    public final IntValue offsetX = new IntValue("offset-x", 2, -3, 255,
            () -> !(showBar.getValue() && sidebarMode.getValue() == 3 && animation.getValue()));
    public final IntValue offsetY = new IntValue("offset-y", 2, -3, 255,
            () -> !(showBar.getValue() && sidebarMode.getValue() == 3 && animation.getValue()));

    public final FloatValue scale = new FloatValue("scale", 1.0F, 0.5F, 1.5F);
    public final PercentValue background = new PercentValue("background", 25);
    public final BooleanValue shadow = new BooleanValue("shadow", true);
    public final BooleanValue suffixes = new BooleanValue("suffixes", true);
    public final BooleanValue interval = new BooleanValue("interval", false);
    public final BooleanValue lowerCase = new BooleanValue("lower-case", false);
    public final BooleanValue chatOutline = new BooleanValue("chat-outline", true);
    public final BooleanValue scoreboardAvoid = new BooleanValue("scoreboard-avoid", true);
    public final BooleanValue blinkTimer = new BooleanValue("blink-timer", true);
    public final BooleanValue toggleSound = new BooleanValue("toggle-sounds", true);
    public final BooleanValue toggleAlerts = new BooleanValue("toggle-alerts", false);

    private UFontRenderer modernFontRenderer;
    private int savedOffsetX = 2;
    private int savedOffsetY = 2;
    private boolean wasOutlineAnimation = false;

    public UFontRenderer getModernFontRenderer() {
        if (fontMode.getValue() == 1) {
            if (modernFontRenderer == null) {
                try {
                    modernFontRenderer = new UFontRenderer("GoogleSans-Regular", 20);
                } catch (Exception e) {
                    modernFontRenderer = null;
                }
            }
            return modernFontRenderer;
        }
        return null;
    }

    private boolean isModernFont() {
        return fontMode.getValue() == 1 && getModernFontRenderer() != null;
    }

    private float getFontHeight() {
        if (isModernFont()) {
            return getModernFontRenderer().getHeight() + 1.0F;
        }
        return mc.field_1772.field_2000;
    }

    private int getStringWidth(String text) {
        if (isModernFont()) {
            return getModernFontRenderer().getStringWidth(text);
        }
        return mc.field_1772.method_1727(text);
    }

    private void drawStringWithShadow(class_332 context, String text, float x, float y, int color) {
        if (isModernFont()) {
            getModernFontRenderer().drawStringWithShadow(text, x, y, color);
        } else {
            context.method_51433(mc.field_1772, text, (int) x, (int) y, color, true);
        }
    }

    private void drawString(class_332 context, String text, float x, float y, int color, boolean shadow) {
        if (isModernFont()) {
            getModernFontRenderer().drawString(text, x, y, color, shadow);
        } else {
            context.method_51433(mc.field_1772, text, (int) x, (int) y, color, shadow);
        }
    }

    private String getModuleName(Module module) {
        String moduleName = module.getName();
        if (this.interval.getValue()) {
            moduleName = moduleName.replaceAll("(?<=[a-z])(?=[A-Z])", " ");
        }
        if (this.lowerCase.getValue()) {
            moduleName = moduleName.toLowerCase(Locale.ROOT);
        }
        return moduleName;
    }

    private String[] getModuleSuffix(Module module) {
        String[] moduleSuffix = module.getSuffix();
        if (this.lowerCase.getValue()) {
            for (int i = 0; i < moduleSuffix.length; i++) {
                moduleSuffix[i] = moduleSuffix[i].toLowerCase();
            }
        }
        return moduleSuffix;
    }

    private int getModuleWidth(Module module) {
        return this.calculateStringWidth(
                this.getModuleName(module), this.getModuleSuffix(module)
        );
    }

    private int calculateStringWidth(String string, String[] arr) {
        int width = getStringWidth(string);
        if (this.suffixes.getValue()) {
            for (String str : arr) {
                width += 3 + getStringWidth(str);
            }
        }
        return width;
    }

    private float getColorCycle(long long3, long long4) {
        long speed = (long) (3000.0 / Math.pow(Math.min(Math.max(0.5F, this.colorSpeed.getValue()), 1.5F), 3.0));
        return 1.0F - (float) (Math.abs(long3 - long4 * 300L) % speed) / (float) speed;
    }

    public HUD() {
        super("HUD", true, true);
    }

    public Color getColor(long time) {
        return this.getColor(time, 0L);
    }

    public Color getColor(long time, long offset) {
        Color color = Color.white;
        switch (this.colorMode.getValue()) {
            case 0:
                color = ColorUtil.fromHSB(this.getColorCycle(time, offset), 1.0F, 1.0F);
                break;
            case 1:
                color = ColorUtil.fromHSB(this.getColorCycle(time / 3L, 0L), 1.0F, 1.0F);
                break;
            case 2:
                float cycle = this.getColorCycle(time, offset);
                if (cycle % 1.0F < 0.5F) {
                    cycle = 1.0F - cycle % 1.0F;
                }
                color = ColorUtil.fromHSB(cycle, 1.0F, 1.0F);
                break;
            case 3:
                color = new Color(this.custom1.getValue());
                break;
            case 4:
                double cycle1 = this.getColorCycle(time, offset);
                color = ColorUtil.interpolate(
                        (float) (2.0 * Math.abs(cycle1 - Math.floor(cycle1 + 0.5))),
                        new Color(this.custom1.getValue()),
                        new Color(this.custom2.getValue())
                );
                break;
            case 5:
                double cycle2 = this.getColorCycle(time, offset);
                float floor = (float) (2.0 * Math.abs(cycle2 - Math.floor(cycle2 + 0.5)));
                if (floor <= 0.5F) {
                    color = ColorUtil.interpolate(floor * 2.0F, new Color(this.custom1.getValue()), new Color(this.custom2.getValue()));
                } else {
                    color = ColorUtil.interpolate((floor - 0.5F) * 2.0F, new Color(this.custom2.getValue()), new Color(this.custom3.getValue()));
                }
        }
        float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
        return Color.getHSBColor(
                hsb[0],
                hsb[1] * (this.colorSaturation.getValue().floatValue() / 100.0F),
                hsb[2] * (this.colorBrightness.getValue().floatValue() / 100.0F)
        );
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (this.isEnabled() && event.getType() == EventType.POST) {
            boolean isOutlineAnimation = this.showBar.getValue() && this.sidebarMode.getValue() == 3 && this.animation.getValue();
            if (isOutlineAnimation) {
                if (!wasOutlineAnimation) {
                    savedOffsetX = this.offsetX.getValue();
                    savedOffsetY = this.offsetY.getValue();
                    this.offsetX.setValue(-2);
                    this.offsetY.setValue(-1);
                    wasOutlineAnimation = true;
                }
            } else {
                if (wasOutlineAnimation) {
                    this.offsetX.setValue(savedOffsetX);
                    this.offsetY.setValue(savedOffsetY);
                    wasOutlineAnimation = false;
                }
            }

            List<Module> newActive;
            if (this.animation.getValue()) {
                newActive = Myau.moduleManager.modules.values().stream()
                        .filter(module -> !module.isHidden() && (module.isEnabled() || this.animationMap.getOrDefault(module, 0.0F) > 0.01F))
                        .collect(Collectors.toList());
            } else {
                newActive = Myau.moduleManager.modules.values().stream()
                        .filter(module -> module.isEnabled() && !module.isHidden())
                        .collect(Collectors.toList());
            }
            newActive.sort(Comparator.comparingInt(this::getModuleWidth).reversed());
            this.activeModules = newActive;
        }
    }

    @Override
    public void onEnabled() {
        wasOutlineAnimation = false;
        savedOffsetX = 2;
        savedOffsetY = 2;
        if (!(showBar.getValue() && sidebarMode.getValue() == 3 && animation.getValue())) {
            this.offsetX.setValue(2);
            this.offsetY.setValue(2);
        }
    }

    private static float animateSmooth(float target, float current, float speed, float deltaTime) {
        float diff = target - current;
        float change = diff * Math.min(1.0f, speed * deltaTime);
        if (Math.abs(change) < 0.01f && Math.abs(diff) < 0.01f) return target;
        return current + change;
    }

    private boolean hasSidebar() {
        return this.showBar.getValue() && this.sidebarMode.getValue() != 4;
    }

    private int getScoreboardWidth() {
        if (mc.field_1687 == null || !this.scoreboardAvoid.getValue()) {
            return 0;
        }
        class_269 scoreboard = mc.field_1687.method_8428();
        if (scoreboard == null) {
            return 0;
        }
        class_266 objective = scoreboard.method_1189(class_8646.field_45157);
        if (objective == null) {
            return 0;
        }
        int width = mc.field_1772.method_27525(objective.method_1114());
        for (class_9011 entry : scoreboard.method_1184(objective)) {
            String line = class_268.method_1142(scoreboard.method_1153(entry.comp_2127()), class_2561.method_43470(entry.comp_2127())).getString();
            width = Math.max(width, mc.field_1772.method_1727(line));
        }
        return width + 6;
    }

    private float getModuleRenderWidth(Module module) {
        return (float) this.calculateStringWidth(this.getModuleName(module), this.getModuleSuffix(module));
    }

    private void renderSidebar(Module module, int index, float bgX1, float bgY1, float bgX2, float bgY2, int color) {
        if (!this.hasSidebar()) {
            return;
        }

        float thickness;
        if (this.sidebarMode.getValue() == 3) {
            thickness = 1.0F;
        } else {
            thickness = this.barWidth.getValue();
        }

        boolean first = index == 0;
        boolean last = index == this.activeModules.size() - 1;
        boolean topList = this.posY.getValue() == 0;
        boolean visualFirst = topList ? first : last;
        boolean visualLast = topList ? last : first;

        switch (this.sidebarMode.getValue()) {
            case 1:
                this.drawVerticalSidebar(bgX1 - thickness, bgY1, bgY2, thickness, color);
                break;
            case 2:
                if (visualFirst) {
                    RenderUtil.drawRect(bgX1, bgY1 - thickness, bgX2, bgY1, color);
                }
                break;
            case 3:
                this.drawVerticalSidebar(bgX2, bgY1, bgY2, thickness, color);
                this.drawVerticalSidebar(bgX1 - thickness, bgY1, bgY2, thickness, color);
                if (visualFirst) {
                    RenderUtil.drawRect(bgX1 - thickness, bgY1 - thickness, bgX2 + thickness, bgY1, color);
                } else {
                    this.renderOutlineConnector(module, index, bgX1, bgY1, bgX2, bgY2, thickness, color);
                }
                if (visualLast) {
                    RenderUtil.drawRect(bgX1 - thickness, bgY2, bgX2 + thickness, bgY2 + thickness, color);
                }
                break;
            default:
                this.drawVerticalSidebar(bgX2, bgY1, bgY2, thickness, color);
                break;
        }
    }

    private void renderOutlineConnector(Module module, int index, float bgX1, float bgY1, float bgX2, float bgY2, float thickness, int color) {
        if (index <= 0) {
            return;
        }

        Module previous = this.activeModules.get(index - 1);
        float previousWidth = this.getModuleRenderWidth(previous);
        float rectExtraWidth = 2.0F;
        float boundaryY1 = this.posY.getValue() == 0 ? bgY1 - thickness : bgY2;
        float boundaryY2 = this.posY.getValue() == 0 ? bgY1 : bgY2 + thickness;

        if (this.posX.getValue() == 0) {
            float previousRight = bgX1 + previousWidth + rectExtraWidth;
            float start = Math.min(previousRight, bgX2);
            float end = Math.max(previousRight, bgX2) + thickness;
            RenderUtil.drawRect(start, boundaryY1, end, boundaryY2, color);
        } else {
            float previousLeft = bgX2 - previousWidth - rectExtraWidth;
            float start = Math.min(previousLeft, bgX1) - thickness;
            float end = Math.max(previousLeft, bgX1);
            RenderUtil.drawRect(start, boundaryY1, end, boundaryY2, color);
        }
    }

    private void drawVerticalSidebar(float x, float y1, float y2, float width, int color) {
        RenderUtil.drawRect(x, y1, x + width, y2, color);
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        class_332 context = event.getContext();
        if (this.chatOutline.getValue() && mc.field_1755 instanceof class_408) {
            String text = ((ChatScreenAccessor) mc.field_1755).getInputField().method_1882().trim();
            if (Myau.commandManager != null && Myau.commandManager.isTypingCommand(text)) {
                RenderUtil.enableRenderState();
                RenderUtil.drawOutlineRect(
                        2.0F,
                        (float) (mc.field_1755.field_22790 - 14),
                        (float) (mc.field_1755.field_22789 - 2),
                        (float) (mc.field_1755.field_22790 - 2),
                        1.5F,
                        0,
                        this.getColor(System.currentTimeMillis()).getRGB()
                );
                RenderUtil.disableRenderState();
            }
        }
        if (!this.isEnabled() || mc.method_53526().method_53536()) return;

        if (this.animation.getValue()) {
            this.renderAnimated(context);
        } else {
            this.renderStatic(context);
        }
    }

    private void renderStatic(class_332 context) {
        float height = getFontHeight();
        if (!isModernFont()) {
            height -= 1.0F;
        }
        float x = (float) this.offsetX.getValue()
                + (1.0F + (this.hasSidebar() ? 1.0F : 0.0F)) * this.scale.getValue();
        float y = (float) this.offsetY.getValue() + 1.0F * this.scale.getValue();
        if (this.posX.getValue() == 1) {
            x = (float) mc.method_22683().method_4486() - x;
            int scoreboardWidth = this.getScoreboardWidth();
            if (scoreboardWidth > 0) {
                x -= scoreboardWidth;
            }
        }
        if (this.posY.getValue() == 1) {
            y = (float) mc.method_22683().method_4502() - y - height * this.scale.getValue();
        }
        RenderSystem.getModelViewStack().pushMatrix();
        RenderSystem.getModelViewStack().scale(this.scale.getValue(), this.scale.getValue(), 1.0F);
        long l = System.currentTimeMillis();
        long offset = 0L;
        for (Module module : this.activeModules) {
            String moduleName = this.getModuleName(module);
            String[] moduleSuffix = this.getModuleSuffix(module);
            float totalWidth = this.getModuleRenderWidth(module);
            int color = this.getColor(l, offset).getRGB();
            float pad = 0.0F;
            float bgX1 = x / this.scale.getValue() - 1.0F - pad - (this.posX.getValue() == 0 ? 0.0F : totalWidth);
            float bgY1 = y / this.scale.getValue() - pad - (this.posY.getValue() == 0 ? (offset == 0L ? 1.0F : 0.0F) : (this.shadow.getValue() ? 1.0F : 0.0F));
            float bgX2 = x / this.scale.getValue() + 1.0F + pad + (this.posX.getValue() == 0 ? totalWidth : 0.0F);
            float bgY2 = y / this.scale.getValue() + height + pad + (this.posY.getValue() == 0 ? (this.shadow.getValue() ? 1.0F : 0.0F) : (offset == 0L ? 1.0F : 0.0F));
            RenderUtil.enableRenderState();
            if (this.background.getValue() > 0) {
                RenderUtil.drawRect(
                        bgX1, bgY1, bgX2, bgY2,
                        new Color(0.0F, 0.0F, 0.0F, this.background.getValue().floatValue() / 100.0F).getRGB()
                );
            }
            this.renderSidebar(module, (int) offset, bgX1, bgY1, bgX2, bgY2, color);
            RenderUtil.disableRenderState();
            RenderSystem.disableDepthTest();
            float textX = x / this.scale.getValue() - (this.posX.getValue() == 1 ? totalWidth : 0.0F);
            float textY = y / this.scale.getValue();
            if (isModernFont()) {
                textY -= 1.0F;
            }
            if (this.shadow.getValue()) {
                drawStringWithShadow(context, moduleName, textX, textY, color);
            } else {
                drawString(context, moduleName, textX, textY + (this.posY.getValue() == 1 ? 1.0F : 0.0F), color, false);
            }
            if (this.suffixes.getValue() && moduleSuffix.length > 0) {
                float width = getStringWidth(moduleName) + 3.0F;
                for (String string : moduleSuffix) {
                    float suffixX = textX + width;
                    if (this.shadow.getValue()) {
                        drawStringWithShadow(context, string, suffixX, textY, ChatColors.GRAY.toAwtColor());
                    } else {
                        drawString(context, string, suffixX, textY + (this.posY.getValue() == 1 ? 1.0F : 0.0F), ChatColors.GRAY.toAwtColor(), false);
                    }
                    width += getStringWidth(string) + (this.shadow.getValue() ? 3.0F : 2.0F);
                }
            }
            y += (height + (this.shadow.getValue() ? 1.0F : 0.0F)) * this.scale.getValue() * (this.posY.getValue() == 0 ? 1.0F : -1.0F);
            offset++;
        }
        if (this.blinkTimer.getValue()) {
            BlinkModules blinkingModule = Myau.blinkManager.getBlinkingModule();
            if (blinkingModule != BlinkModules.NONE && blinkingModule != BlinkModules.AUTO_BLOCK) {
                long movementPacketSize = Myau.blinkManager.countMovement();
                if (movementPacketSize > 0L) {
                    RenderSystem.enableBlend();
                    RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
                    String blinkText = String.valueOf(movementPacketSize);
                    float blinkX = (float) mc.method_22683().method_4486() / 2.0F / this.scale.getValue()
                            - (float) getStringWidth(blinkText) / 2.0F;
                    float blinkY = (float) mc.method_22683().method_4502() / 5.0F * 3.0F / this.scale.getValue();
                    if (this.shadow.getValue()) {
                        drawStringWithShadow(context, blinkText, blinkX, blinkY,
                                this.getColor(System.currentTimeMillis(), offset).getRGB() & 16777215 | -1090519040);
                    } else {
                        drawString(context, blinkText, blinkX, blinkY,
                                this.getColor(System.currentTimeMillis(), offset).getRGB() & 16777215 | -1090519040, false);
                    }
                    RenderSystem.disableBlend();
                }
            }
        }
        RenderSystem.enableDepthTest();
        RenderSystem.getModelViewStack().popMatrix();
    }

    private void renderAnimated(class_332 context) {
        float scaleVal = this.scale.getValue();
        float scaledWidth = (float) mc.method_22683().method_4486() / scaleVal;
        float scaledHeight = (float) mc.method_22683().method_4502() / scaleVal;

        boolean alignLeft = this.posX.getValue() == 0;
        boolean alignTop = this.posY.getValue() == 0;

        float baseOffsetX = (1.0F + (this.hasSidebar() ? 1.0F : 0.0F));
        float baseOffsetY = 1.0F;

        float startX = alignLeft ? this.offsetX.getValue() + baseOffsetX : scaledWidth - this.offsetX.getValue() - baseOffsetX;
        if (!alignLeft) {
            float scoreboardWidth = this.getScoreboardWidth() / scaleVal;
            if (scoreboardWidth > 0) {
                startX -= scoreboardWidth;
            }
        }
        float startY = alignTop ? this.offsetY.getValue() + baseOffsetY : scaledHeight - this.offsetY.getValue() - baseOffsetY;

        RenderSystem.getModelViewStack().pushMatrix();
        RenderSystem.getModelViewStack().scale(scaleVal, scaleVal, 1.0F);

        long l = System.currentTimeMillis();
        long offset = 0L;
        float deltaTime = 1.0F / Math.max(mc.method_47599(), 5);

        float currentY = startY;

        float height = getFontHeight();
        if (!isModernFont()) {
            height -= 1.0F;
        }
        float fullHeight = height + 1.0F + (this.shadow.getValue() ? 1.0F : 0.0F);

        for (Module module : this.activeModules) {
            String moduleName = this.getModuleName(module);
            String[] moduleSuffix = this.getModuleSuffix(module);

            float textWidth = getStringWidth(moduleName);
            float totalWidth = textWidth;
            if (this.suffixes.getValue() && moduleSuffix.length > 0) {
                for (String s : moduleSuffix) {
                    totalWidth += 3.0F + getStringWidth(s);
                }
            }

            float targetSlide = module.isEnabled() ? totalWidth : 0.0F;
            float currentSlide = this.animationMap.getOrDefault(module, 0.0F);
            currentSlide = animateSmooth(targetSlide, currentSlide, 12.0F, deltaTime);
            currentSlide = Math.max(0.0F, Math.min(totalWidth, currentSlide));
            this.animationMap.put(module, currentSlide);

            float heightFactor = (totalWidth > 0.0F) ? (currentSlide / totalWidth) : 0.0F;
            float currentHeight = fullHeight * heightFactor;
            if (currentSlide <= 0.1F) {
                offset++;
                currentY += alignTop ? currentHeight : -currentHeight;
                continue;
            }

            float bgWidth = totalWidth + 2.0F;
            float totalModuleWidth = bgWidth + (this.hasSidebar() ? 1.0F : 0.0F);
            float xSlideAmount = (1.0F - heightFactor) * (totalModuleWidth + 5.0F);
            float currentX = startX + (alignLeft ? -xSlideAmount : xSlideAmount);

            float bgLeft, bgRight, textStartX;
            if (alignLeft) {
                bgLeft = currentX;
                bgRight = currentX + bgWidth;
                textStartX = bgLeft + 1.0F;
            } else {
                bgRight = currentX;
                bgLeft = currentX - bgWidth;
                textStartX = bgRight - 1.0F - totalWidth;
            }

            float fullTop = alignTop ? currentY : currentY - fullHeight;
            float fullBottom = fullTop + fullHeight;
            float drawTop, drawBottom;
            if (alignTop) {
                drawTop = fullTop;
                drawBottom = drawTop + currentHeight;
            } else {
                drawBottom = fullBottom;
                drawTop = drawBottom - currentHeight;
            }

            int color = this.getColor(l, offset).getRGB();
            int animatedColor = color;
            if (heightFactor < 1.0F) {
                int alpha = Math.max(0, Math.min(255, (int) (heightFactor * 255.0F)));
                animatedColor = (color & 0x00FFFFFF) | (alpha << 24);
            }

            RenderUtil.enableRenderState();

            if (this.background.getValue() > 0 && heightFactor > 0.02F) {
                int alpha = (int) (heightFactor * this.background.getValue().floatValue() / 100.0F * 255.0F);
                alpha = Math.min(255, Math.max(0, alpha));
                int bgColor = new Color(0, 0, 0, alpha).getRGB();
                RenderUtil.drawRect(bgLeft, drawTop, bgRight, drawBottom, bgColor);
            }

            this.renderSidebar(module, (int) offset, bgLeft, drawTop, bgRight, drawBottom, animatedColor);

            RenderUtil.disableRenderState();

            RenderSystem.disableDepthTest();
            if (heightFactor > 0.05F) {
                RenderSystem.enableBlend();
                RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);

                float textY = drawTop + 1.0F + (isModernFont() ? -1.0F : 0.0F) + (this.posY.getValue() == 1 ? 1.0F : 0.0F);
                float currentTextX = textStartX;

                if (this.shadow.getValue()) {
                    drawStringWithShadow(context, moduleName, currentTextX, textY, animatedColor);
                } else {
                    drawString(context, moduleName, currentTextX, textY, animatedColor, false);
                }
                currentTextX += textWidth;

                if (this.suffixes.getValue() && moduleSuffix.length > 0 && heightFactor > 0.5F) {
                    int suffixAlpha = Math.min(255, (int) (((heightFactor - 0.5F) / 0.5F) * 255.0F));
                    int suffixColor = (ChatColors.GRAY.toAwtColor() & 0x00FFFFFF) | (suffixAlpha << 24);
                    for (String suffix : moduleSuffix) {
                        currentTextX += 3.0F;
                        if (this.shadow.getValue()) {
                            drawStringWithShadow(context, suffix, currentTextX, textY, suffixColor);
                        } else {
                            drawString(context, suffix, currentTextX, textY, suffixColor, false);
                        }
                        currentTextX += getStringWidth(suffix);
                    }
                }

                RenderSystem.disableBlend();
            }

            currentY += alignTop ? currentHeight : -currentHeight;
            offset++;
        }

        if (this.blinkTimer.getValue()) {
            BlinkModules blinkingModule = Myau.blinkManager.getBlinkingModule();
            if (blinkingModule != BlinkModules.NONE && blinkingModule != BlinkModules.AUTO_BLOCK) {
                long movementPacketSize = Myau.blinkManager.countMovement();
                if (movementPacketSize > 0L) {
                    RenderSystem.enableBlend();
                    RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
                    String bText = String.valueOf(movementPacketSize);
                    int blinkColor = this.getColor(System.currentTimeMillis(), offset).getRGB() & 0x00FFFFFF | 0xBF000000;
                    float blinkX = scaledWidth / 2.0F - (float) getStringWidth(bText) / 2.0F;
                    float blinkY = scaledHeight * 0.6F;
                    if (this.shadow.getValue()) {
                        drawStringWithShadow(context, bText, blinkX, blinkY, blinkColor);
                    } else {
                        drawString(context, bText, blinkX, blinkY, blinkColor, false);
                    }
                    RenderSystem.disableBlend();
                }
            }
        }

        RenderSystem.enableDepthTest();
        RenderSystem.getModelViewStack().popMatrix();
    }

    @Override
    public void verifyValue(String mode) {
    }
}
