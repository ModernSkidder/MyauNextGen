package laoqi123.module.modules.render;

import laoqi123.Myau;
import laoqi123.module.Module;
import laoqi123.module.modules.combat.KillAura;
import laoqi123.value.properties.FloatValue;
import laoqi123.value.properties.ModeValue;
import net.minecraft.class_1306;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Vector3f;

public class OldHitting extends Module {
    public final ModeValue animation = new ModeValue("Animation", 1, new String[]{"Vanilla", "Leaked", "Slide"});
    public final FloatValue size = new FloatValue("Size", 1.0F, 0.1F, 3.0F);
    public final FloatValue speed = new FloatValue("Speed", 1.0F, 0.1F, 5.0F);
    public final FloatValue yOffset = new FloatValue("Y-Offset", 0.0F, -1.0F, 1.0F);

    public OldHitting() {
        super("OldHitting", true);
    }

    public boolean isKillAuraAttacking() {
        KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
        return killAura != null
                && killAura.isEnabled()
                && killAura.autoBlock.mode.getValue() == 4
                && killAura.getTarget() != null;
    }

    public void applyHitAnimation(class_4587 matrices, float progress, class_1306 arm, float equipProgress) {
        float scaledProgress = progress * this.speed.getValue();
        float size = this.size.getValue();
        matrices.method_46416(0.0F, this.yOffset.getValue(), 0.0F);
        if (this.animation.getValue() == 0) {
            int side = arm == class_1306.field_6183 ? 1 : -1;
            translate((float) side * 0.56F, -0.52F + equipProgress * -0.6F, -0.72, matrices);
            translate((float) side * -0.1414214F, 0.08F, 0.1414213925600052, matrices);
            rotate(-102.25F, 1.0F, 0.0F, 0.0F, matrices);
            rotate((float) side * 13.365F, 0.0F, 1.0F, 0.0F, matrices);
            rotate((float) side * 78.05F, 0.0F, 0.0F, 1.0F, matrices);
            double sinSquared = Math.sin((double) (scaledProgress * scaledProgress) * Math.PI);
            double sinSqrt = Math.sin(Math.sqrt(scaledProgress) * Math.PI);
            rotate((float) (sinSquared * -20.0), 0.0F, 1.0F, 0.0F, matrices);
            rotate((float) (sinSqrt * -20.0), 0.0F, 0.0F, 1.0F, matrices);
            rotate((float) (sinSqrt * -80.0), 1.0F, 0.0F, 0.0F, matrices);
            scale(size, size, size, matrices);
        } else if (this.animation.getValue() == 1) {
            setupLeakedAnim(matrices, equipProgress, scaledProgress, size);
            setupLeakedArmPos(matrices);
            float pulse = class_3532.method_15374(class_3532.method_15355(scaledProgress) * (float) Math.PI) / 8.0F;
            matrices.method_46416(0.008F, 0.24F, 0.03F);
            matrices.method_46416(-0.16F, -0.25F, 0.0F);
            matrices.method_22905((0.8F + pulse) * size, (0.8F + pulse) * size, (0.8F + pulse) * size);
            rotate(-class_3532.method_15374(class_3532.method_15355(scaledProgress) * (float) Math.PI) * 20.0F, 0.0F, 1.2F, -0.8F, matrices);
            rotate(-class_3532.method_15374(class_3532.method_15355(scaledProgress) * (float) Math.PI) * 30.0F, 1.0F, 0.0F, 0.0F, matrices);
            matrices.method_22905(2.4F * size, 2.4F * size, 2.4F * size);
            rotate(-38.4F, 0.0F, 1.0F, 0.0F, matrices);
            scale(size, size, size, matrices);
        } else if (this.animation.getValue() == 2) {
            float slideSwing = class_3532.method_15374(class_3532.method_15355(scaledProgress) * (float) Math.PI);
            translate(0.648F, -0.55F, -0.7199999690055847, matrices);
            rotate(77.0F, 0.0F, 1.0F, 0.0F, matrices);
            rotate(-10.0F, 0.0F, 0.0F, 1.0F, matrices);
            rotate(-80.0F, 1.0F, 0.0F, 0.0F, matrices);
            rotate(-slideSwing * 20.0F, 1.0F, 0.0F, 0.0F, matrices);
            scale(1.2F * size, 1.2F * size, 1.2F * size, matrices);
            scale(size, size, size, matrices);
        }
    }

    private void setupLeakedAnim(class_4587 matrices, float equipProgress, float scaledProgress, float size) {
        matrices.method_46416(0.56F, -0.52F, -0.71999997F);
        rotate(45.0F, 0.0F, 1.0F, 0.0F, matrices);
        float sinSquared = class_3532.method_15374(scaledProgress * scaledProgress * (float) Math.PI);
        float sinSqrt = class_3532.method_15374(class_3532.method_15355(scaledProgress) * (float) Math.PI);
        rotate(sinSquared * -20.0F, 0.0F, 1.0F, 0.0F, matrices);
        rotate(sinSqrt * -20.0F, 0.0F, 0.0F, 1.0F, matrices);
        rotate(sinSqrt * -80.0F, 1.0F, 0.0F, 0.0F, matrices);
        matrices.method_22905(0.4F * size, 0.4F * size, 0.4F * size);
    }

    private void setupLeakedArmPos(class_4587 matrices) {
        matrices.method_46416(-0.5F, 0.2F, 0.0F);
        rotate(30.0F, 0.0F, 1.0F, 0.0F, matrices);
        rotate(-80.0F, 1.0F, 0.0F, 0.0F, matrices);
        rotate(60.0F, 0.0F, 1.0F, 0.0F, matrices);
    }

    private static void translate(double tx, double ty, double tz, class_4587 matrices) {
        matrices.method_22904(tx, ty, tz);
    }

    private static void rotate(float angle, float ax, float ay, float az, class_4587 matrices) {
        matrices.method_22907(class_7833.method_46356(new Vector3f(ax, ay, az)).rotationDegrees(angle));
    }

    private static void scale(float sx, float sy, float sz, class_4587 matrices) {
        matrices.method_22905(sx, sy, sz);
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.animation.getModeString()};
    }
}