package laoqi123.module.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.event.EventTarget;
import laoqi123.events.Render3DEvent;
import laoqi123.mixin.EntityRenderDispatcherAccessor;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.PercentProperty;
import laoqi123.util.RenderUtil;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1753;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1823;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5498;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Trajectories extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final PercentProperty opacity = new PercentProperty("opacity", 100);
    public final BooleanProperty bow = new BooleanProperty("bow", true);
    public final BooleanProperty projectiles = new BooleanProperty("projectiles", false);
    public final BooleanProperty pearls = new BooleanProperty("pearls", true);

    public Trajectories() {
        super("Trajectories", false, true);
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (this.isEnabled() && mc.field_1724.method_6047() != null && mc.field_1690.method_31044() == class_5498.field_26664) {
            class_1792 item = mc.field_1724.method_6047().method_7909();
            boolean isBow = false;
            float velocityMultiplier = 1.5F;
            float drag = 0.99F;
            float gravity;
            float hitboxExpand;
            if (item instanceof class_1753 && this.bow.getValue()) {
                if (!mc.field_1724.method_6115()) {
                    return;
                }
                isBow = true;
                gravity = 0.05F;
                hitboxExpand = 0.3F;
                float charge = (float) mc.field_1724.method_6048() / 20.0F;
                charge = (charge * charge + charge * 2.0F) / 3.0F;
                if (charge < 0.1F) {
                    return;
                }
                if (charge > 1.0F) {
                    charge = 1.0F;
                }
                velocityMultiplier = charge * 3.0F;
            } else if (item instanceof class_1787 && this.projectiles.getValue()) {
                gravity = 0.04F;
                hitboxExpand = 0.25F;
                drag = 0.92F;
            } else if ((item instanceof class_1823 || item instanceof class_1771) && this.projectiles.getValue()) {
                gravity = 0.03F;
                hitboxExpand = 0.25F;
            } else {
                if (!(item instanceof class_1776) || !this.pearls.getValue()) {
                    return;
                }
                gravity = 0.03F;
                hitboxExpand = 0.25F;
            }
            float yaw = mc.field_1724.method_36454();
            float pitch = mc.field_1724.method_36455();
            double x = ((EntityRenderDispatcherAccessor) mc.method_1561()).getCamera().method_19326().field_1352 - (double) class_3532.method_15362(yaw / 180.0F * (float) Math.PI) * 0.16;
            double y = ((EntityRenderDispatcherAccessor) mc.method_1561()).getCamera().method_19326().field_1351 + (double) mc.field_1724.method_5751() - 0.1F;
            double z = ((EntityRenderDispatcherAccessor) mc.method_1561()).getCamera().method_19326().field_1350 - (double) class_3532.method_15374(yaw / 180.0F * (float) Math.PI) * 0.16;
            double mx = (double) (class_3532.method_15374(yaw / 180.0F * (float) Math.PI) * class_3532.method_15362(pitch / 180.0F * (float) Math.PI))
                    * (isBow ? 1.0 : 0.4)
                    * -1.0;
            double my = (double) class_3532.method_15374(pitch / 180.0F * (float) Math.PI) * (isBow ? 1.0 : 0.4) * -1.0;
            double mz = (double) (class_3532.method_15362(yaw / 180.0F * (float) Math.PI) * class_3532.method_15362(pitch / 180.0F * (float) Math.PI)) * (isBow ? 1.0 : 0.4);
            float mag = class_3532.method_15355((float) (mx * mx + my * my + mz * mz));
            mx /= mag;
            my /= mag;
            mz /= mag;
            mx *= velocityMultiplier;
            my *= velocityMultiplier;
            mz *= velocityMultiplier;
            class_239 mop = null;
            boolean hasHitBlock = false;
            boolean hasHitEntity = false;
            ArrayList<class_243> trajectoryPoints = new ArrayList<>();
            while (!hasHitBlock && y > 0.0) {
                class_243 start = new class_243(x, y, z);
                class_243 end = new class_243(x + mx, y + my, z + mz);
                mop = mc.field_1687.method_17742(new class_3959(start, end, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, mc.field_1724));
                start = new class_243(x, y, z);
                end = new class_243(x + mx, y + my, z + mz);
                if (mop != null) {
                    hasHitBlock = true;
                    end = new class_243(mop.method_17784().field_1352, mop.method_17784().field_1351, mop.method_17784().field_1350);
                }
                class_238 aabb = new class_238(
                        x - (double) hitboxExpand,
                        y - (double) hitboxExpand,
                        z - (double) hitboxExpand,
                        x + (double) hitboxExpand,
                        y + (double) hitboxExpand,
                        z + (double) hitboxExpand
                )
                        .method_989(mx, my, mz)
                        .method_1009(1.0, 1.0, 1.0);
                List<class_1297> possibleEntities = mc.field_1687.method_8333(mc.field_1724, aabb, entity -> true);
                for (class_1297 entity : possibleEntities) {
                    if (entity.method_30948() && entity != mc.field_1724) {
                        class_238 entityBox = entity.method_5829().method_1009(hitboxExpand, hitboxExpand, hitboxExpand);
                        Optional<class_243> intercept = entityBox.method_992(start, end);
                        if (intercept.isPresent()) {
                            hasHitEntity = true;
                            hasHitBlock = true;
                            mop = new class_3965(intercept.get(), class_2350.field_11036, class_2338.field_10980, false);
                        }
                    }
                }
                x += mx;
                y += my;
                z += mz;
                if (mc.field_1687.method_8320(class_2338.method_49637(x, y, z)).method_26227().method_15767(class_3486.field_15517)) {
                    mx *= 0.6;
                    my *= 0.6;
                    mz *= 0.6;
                } else {
                    mx *= drag;
                    my *= drag;
                    mz *= drag;
                }
                my -= gravity;
                trajectoryPoints.add(
                        new class_243(
                                x - ((EntityRenderDispatcherAccessor) mc.method_1561()).getCamera().method_19326().field_1352,
                                y - ((EntityRenderDispatcherAccessor) mc.method_1561()).getCamera().method_19326().field_1351,
                                z - ((EntityRenderDispatcherAccessor) mc.method_1561()).getCamera().method_19326().field_1350
                        )
                );
            }
            if (trajectoryPoints.size() > 1) {
                int trajectoryColor = new Color(hasHitEntity ? 85 : 255, 255, hasHitEntity ? 85 : 255, (int) (this.opacity.getValue().floatValue() / 100.0F * 255.0F)).getRGB();
                RenderUtil.enableRenderState();
                RenderUtil.setColor(trajectoryColor);
                RenderSystem.lineWidth(1.5F);
                RenderSystem.setShader(class_10142.field_53875);
                class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_29345, class_290.field_1592);
                for (class_243 vec3 : trajectoryPoints) {
                    bufferBuilder.method_22912((float) vec3.field_1352, (float) vec3.field_1351, (float) vec3.field_1350);
                }
                class_286.method_43433(bufferBuilder.method_60800());
                if (mop != null) {
                    class_243 impact = trajectoryPoints.get(trajectoryPoints.size() - 1);
                    this.draw3DLine(new class_243(impact.field_1352 - 0.25, impact.field_1351 - 0.25, impact.field_1350), new class_243(impact.field_1352 + 0.25, impact.field_1351 + 0.25, impact.field_1350), trajectoryColor, 1.5F);
                    this.draw3DLine(new class_243(impact.field_1352 - 0.25, impact.field_1351 + 0.25, impact.field_1350), new class_243(impact.field_1352 + 0.25, impact.field_1351 - 0.25, impact.field_1350), trajectoryColor, 1.5F);
                }
                RenderSystem.lineWidth(2.0F);
                RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
                RenderUtil.disableRenderState();
            }
        }
    }

    private void draw3DLine(class_243 start, class_243 end, int color, float width) {
        RenderUtil.setColor(color);
        RenderSystem.lineWidth(width);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27377, class_290.field_1592);
        bufferBuilder.method_22912((float) start.field_1352, (float) start.field_1351, (float) start.field_1350);
        bufferBuilder.method_22912((float) end.field_1352, (float) end.field_1351, (float) end.field_1350);
        class_286.method_43433(bufferBuilder.method_60800());
    }
}
