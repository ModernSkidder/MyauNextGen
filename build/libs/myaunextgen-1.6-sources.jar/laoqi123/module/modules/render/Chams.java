package laoqi123.module.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.RenderLivingEvent;
import laoqi123.module.Module;
import laoqi123.value.properties.BooleanValue;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1420;
import net.minecraft.class_1429;
import net.minecraft.class_1477;
import net.minecraft.class_1510;
import net.minecraft.class_1528;
import net.minecraft.class_1545;
import net.minecraft.class_1548;
import net.minecraft.class_1560;
import net.minecraft.class_1621;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import laoqi123.util.TeamUtil;

public class Chams extends Module {
    private static final class_310 mc = class_310.method_1551();
    public final BooleanValue players = new BooleanValue("players", true);
    public final BooleanValue friends = new BooleanValue("friends", true);
    public final BooleanValue enemiess = new BooleanValue("enemies", true);
    public final BooleanValue bosses = new BooleanValue("bosses", false);
    public final BooleanValue mobs = new BooleanValue("mobs", false);
    public final BooleanValue creepers = new BooleanValue("creepers", false);
    public final BooleanValue enderman = new BooleanValue("endermen", false);
    public final BooleanValue blaze = new BooleanValue("blazes", false);
    public final BooleanValue animals = new BooleanValue("animals", false);
    public final BooleanValue self = new BooleanValue("self", false);
    public final BooleanValue bots = new BooleanValue("bots", false);

    private boolean shouldRenderChams(class_1309 entityLivingBase) {
        if (entityLivingBase.field_6213 > 0) {
            return false;
        } else if (mc.method_1560().method_5739(entityLivingBase) > 512.0F) {
            return false;
        } else if (entityLivingBase instanceof class_1657) {
            if (entityLivingBase != mc.field_1724 && entityLivingBase != mc.method_1560()) {
                if (TeamUtil.isBot((class_1657) entityLivingBase)) {
                    return this.bots.getValue();
                } else if (TeamUtil.isFriend((class_1657) entityLivingBase)) {
                    return this.friends.getValue();
                } else {
                    return TeamUtil.isTarget((class_1657) entityLivingBase) ? this.enemiess.getValue() : this.players.getValue();
                }
            } else {
                return this.self.getValue() && !mc.field_1690.method_31044().method_31034();
            }
        } else if (entityLivingBase instanceof class_1510 || entityLivingBase instanceof class_1528) {
            return !entityLivingBase.method_5767() && this.bosses.getValue();
        } else if (!(entityLivingBase instanceof class_1308) && !(entityLivingBase instanceof class_1621)) {
            return (entityLivingBase instanceof class_1429
                    || entityLivingBase instanceof class_1420
                    || entityLivingBase instanceof class_1477
                    || entityLivingBase instanceof class_1646) && this.animals.getValue();
        } else if (entityLivingBase instanceof class_1548) {
            return this.creepers.getValue();
        } else if (entityLivingBase instanceof class_1560) {
            return this.enderman.getValue();
        } else {
            return entityLivingBase instanceof class_1545 ? this.blaze.getValue() : this.mobs.getValue();
        }
    }

    public Chams() {
        super("Chams", false);
    }

    @EventTarget
    public void onRenderLiving(RenderLivingEvent event) {
        if (this.isEnabled() && this.shouldRenderChams(event.getEntity())) {
            if (event.getType() == EventType.PRE) {
                RenderSystem.enablePolygonOffset();
                RenderSystem.polygonOffset(1.0F, -2500000.0F);
            } else {
                RenderSystem.polygonOffset(1.0F, 2500000.0F);
                RenderSystem.disablePolygonOffset();
            }
        }
    }
}
