package laoqi123.module.modules;

import laoqi123.module.Module;
import laoqi123.util.ItemUtil;
import laoqi123.util.TeamUtil;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import laoqi123.property.properties.BooleanProperty;

public class GhostHand extends Module {
    public final BooleanProperty teamsOnly = new BooleanProperty("team-only", true);
    public final BooleanProperty ignoreWeapons = new BooleanProperty("ignore-weapons", false);

    public GhostHand() {
        super("GhostHand", false);
    }

    public boolean shouldSkip(class_1297 entity) {
        return entity instanceof class_1657
                && !TeamUtil.isBot((class_1657) entity)
                && (!this.teamsOnly.getValue() || TeamUtil.isSameTeam((class_1657) entity))
                && (!this.ignoreWeapons.getValue() || !ItemUtil.hasRawUnbreakingEnchant());
    }
}
