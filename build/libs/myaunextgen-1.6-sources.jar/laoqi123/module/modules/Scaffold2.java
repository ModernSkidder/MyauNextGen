package laoqi123.module.modules;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.types.Priority;
import laoqi123.events.HitBlockEvent;
import laoqi123.events.LeftClickMouseEvent;
import laoqi123.events.MoveInputEvent;
import laoqi123.events.Render2DEvent;
import laoqi123.events.Render3DEvent;
import laoqi123.events.RightClickMouseEvent;
import laoqi123.events.StrafeEvent;
import laoqi123.events.SwapItemEvent;
import laoqi123.events.TickEvent;
import laoqi123.events.UpdateEvent;
import laoqi123.management.RotationState;
import laoqi123.module.Module;
import laoqi123.property.properties.BooleanProperty;
import laoqi123.property.properties.FloatProperty;
import laoqi123.property.properties.IntProperty;
import laoqi123.property.properties.ModeProperty;
import laoqi123.util.BlockUtil;
import laoqi123.util.ChatUtil;
import laoqi123.util.ItemUtil;
import laoqi123.util.MoveUtil;
import laoqi123.util.PacketUtil;
import laoqi123.util.RandomUtil;
import laoqi123.util.RenderUtil;
import laoqi123.util.RotationUtil;
import laoqi123.util.player.FallingPlayer;
import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2879;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Southside (Naven) Scaffold ported from 1.8.9 to 1.21.4.
 * Added alongside the existing SSNG Scaffold as a separate module.
 */
public class Scaffold2 extends Module {
    private static final class_310 mc = class_310.method_1551();

    // ===== Southside configuration =====
    public final ModeProperty mode = new ModeProperty("Mode", 0, new String[]{"Telly", "Snap", "Normal"});
    public final BooleanProperty alwaysUpdateRot = new BooleanProperty("Always Update Rotation", false);
    public final IntProperty placeTick = new IntProperty("Place Tick", 1, 1, 5, () -> this.mode.getValue() == 0);
    public final IntProperty rotTick = new IntProperty("Rotation Tick", 1, 1, 5, () -> this.mode.getValue() == 0);
    public final BooleanProperty itemSpoof = new BooleanProperty("Spoof Item", true);
    public final BooleanProperty noSwing = new BooleanProperty("No Swing", false);
    public final BooleanProperty eagle = new BooleanProperty("Eagle", false, () -> this.mode.getValue() == 0);
    public final BooleanProperty snap = new BooleanProperty("Snap", false, () -> this.mode.getValue() == 0);
    public final BooleanProperty noUptelly = new BooleanProperty("No Up Telly", true, () -> this.mode.getValue() == 0);
    public final BooleanProperty godBridge = new BooleanProperty("God Bridge", false, () -> this.mode.getValue() == 2);
    public final BooleanProperty smoothed = new BooleanProperty("Smoothed", true, () -> this.mode.getValue() == 0);
    public final BooleanProperty safeMode = new BooleanProperty("Safe Mode", false, () -> this.mode.getValue() == 0 && this.smoothed.getValue());
    public final BooleanProperty testOnGround = new BooleanProperty("Test On Ground", false, () -> this.mode.getValue() == 0 && this.smoothed.getValue());
    public final BooleanProperty fixRotation = new BooleanProperty("Fix Rotation", true);
    public final BooleanProperty randomSlow = new BooleanProperty("Slow Up Telly", false, () -> this.mode.getValue() == 0);
    public final BooleanProperty blockFly = new BooleanProperty("Block Fly", false);
    public final BooleanProperty abuseRotation = new BooleanProperty("Abuse Rotation", true);
    public final ModeProperty blockSlotMode = new ModeProperty("Block Slot Mode", 0, new String[]{"Farthest", "Most Blocks"});
    public final ModeProperty jumpMode = new ModeProperty("Jump Mode", 1, new String[]{"Parkour", "Normal", "None"}, () -> this.mode.getValue() == 0);
    public final FloatProperty safeDistance = new FloatProperty("Clutch Safe Distance", 4.5F, 1.0F, 5.0F);
    public final IntProperty tellyEagleTick = new IntProperty("Eagle Tick", 1, 1, 5, () -> this.mode.getValue() == 0 && this.eagle.getValue());
    public final IntProperty keepEagleSneakTick = new IntProperty("Keep Eagle Tick", 1, 1, 5, () -> this.mode.getValue() == 0 && this.eagle.getValue());
    public final BooleanProperty dbgV = new BooleanProperty("Debug", false);
    public final BooleanProperty keepFoV = new BooleanProperty("Keep FoV", true);
    public final FloatProperty fovValue = new FloatProperty("Fov", 1.1F, 1.0F, 2.1F);
    public final BooleanProperty mark = new BooleanProperty("Mark", true);
    private final BooleanProperty duplicateRotPlace = new BooleanProperty("Duplicate Rot Place", true);
    private final BooleanProperty interactItem = new BooleanProperty("Interact Item Before Place", false);
    public final BooleanProperty blockCount = new BooleanProperty("Block Count", true);
    public final ModeProperty blockCountStyle = new ModeProperty("Block Count Style", 0, new String[]{"Retro", "Old"});
    public final IntProperty blockCountOffset = new IntProperty("Block Count Y Offset", 0, 0, 200);

    private static final List<class_2248> invalidBlocks = Arrays.asList(
            class_2246.field_10485, class_2246.field_10034, class_2246.field_10443,
            class_2246.field_10380, class_2246.field_10535, class_2246.field_10102,
            class_2246.field_10343, class_2246.field_10336, class_2246.field_9980,
            class_2246.field_10181, class_2246.field_10200, class_2246.field_10158,
            class_2246.field_10179, class_2246.field_10228, class_2246.field_10375,
            class_2246.field_10523, class_2246.field_10429
    );

    // ===== Southside state =====
    private SlotData slot;
    private SlotData blockSlot;
    private int oldSlot;
    private int count;
    private int lastCount = 0;
    private int startHotbarCount = 1;
    private boolean canPlace;
    private BlockData blockData;
    private BlockData lastBlockData;
    private int rotateCount = 0;
    private double posY;
    private class_2338 lastPlacePosition = null;
    private int tellyJumpTicks;
    private boolean waitingForEagleSneak;
    private Rotation lastRotation;
    private Rotation rot;
    private int placeCount = 0;
    private int ups = 0;
    private int onGroundTicks = 0;
    private int offGroundTicks = 0;
    private boolean cancelMove = false;

    public Scaffold2() {
        super("Scaffold2", false);
    }

    @Override
    public void onEnabled() {
        placeCount = 0;
        ups = 0;
        if (mc.field_1724 == null) {
            return;
        }
        lastRotation = new Rotation(mc.field_1724.method_36454(), mc.field_1724.method_36455());
        this.slot = new SlotData(mc.field_1724.method_31548().field_7545, false);
        this.oldSlot = mc.field_1724.method_31548().field_7545;
        this.blockSlot = null;
        startHotbarCount = Math.max(1, getBlockCountHotbar());
        blockData = null;
        lastBlockData = null;
        canPlace = true;
        lastPlacePosition = null;
        tellyJumpTicks = 0;
        waitingForEagleSneak = false;
        rot = null;
        onGroundTicks = 0;
        offGroundTicks = 0;
        cancelMove = false;
    }

    @Override
    public void onDisabled() {
        if (mc.field_1724 == null) {
            return;
        }
        mc.field_1724.method_31548().field_7545 = slot != null ? slot.slot() : oldSlot;
        mc.field_1690.field_1832.method_23481(false);
        cancelMove = false;
    }

    // ===== Southside helpers =====

    private static boolean isValid(class_1792 item) {
        return item instanceof class_1747
                && !invalidBlocks.contains(((class_1747) item).method_7711())
                && BlockUtil.isSolid(((class_1747) item).method_7711())
                && !BlockUtil.isInteractable(((class_1747) item).method_7711());
    }

    private static boolean isFullBlock(class_1799 stack) {
        return stack != null && stack.method_7947() > 0 && isValid(stack.method_7909());
    }

    private int getHotbarBlockSlot() {
        if (blockSlotMode.getValue() == 1) {
            return getMostBlocksHotbarSlot();
        }
        int slot = -1;
        for (int i = 0; i <= 8; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (isFullBlock(stack)) {
                slot = i;
            }
        }
        return slot;
    }

    private int getMostBlocksHotbarSlot() {
        int selectedSlot = mc.field_1724.method_31548().field_7545;
        int bestSlot = -1;
        int bestCount = -1;
        class_1799 selectedStack = mc.field_1724.method_31548().method_5438(selectedSlot);
        if (isFullBlock(selectedStack)) {
            bestSlot = selectedSlot;
            bestCount = selectedStack.method_7947();
        }
        for (int i = 0; i <= 8; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (isFullBlock(stack) && stack.method_7947() > bestCount) {
                bestSlot = i;
                bestCount = stack.method_7947();
            }
        }
        return bestSlot;
    }

    private int getBlockCountHotbar() {
        if (mc.field_1724 == null) {
            return 0;
        }
        int count = 0;
        for (int i = 0; i <= 8; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (isFullBlock(stack)) {
                count += stack.method_7947();
            }
        }
        class_1799 offhand = mc.field_1724.method_6079();
        if (isFullBlock(offhand)) {
            count += offhand.method_7947();
        }
        return count;
    }

    private int getBlockCountColor(int count) {
        if (count < 16) {
            return new Color(255, 80, 80).getRGB();
        }
        if (count < 32) {
            return new Color(255, 220, 80).getRGB();
        }
        return Color.WHITE.getRGB();
    }

    private BlockData getBlockData(class_2338 pos) {
        BlockData data = getPos(pos);
        if (data == null) {
            class_2338 blockPos = getBlockPos();
            if (blockPos == null) {
                return null;
            }
            class_2350 direction = getPlaceSide(blockPos);
            if (direction == null) {
                return null;
            }
            data = new BlockData(blockPos, direction);
        }
        if (BlockUtil.isReplaceable(data.blockPos().method_10093(data.facing()))) {
            return data;
        }
        return null;
    }

    private BlockData getPos(class_2338 pos) {
        if (isPosSolid(pos.method_10069(-1, 0, 0))) {
            return new BlockData(pos.method_10069(-1, 0, 0), class_2350.field_11034);
        } else if (isPosSolid(pos.method_10069(1, 0, 0))) {
            return new BlockData(pos.method_10069(1, 0, 0), class_2350.field_11039);
        } else if (isPosSolid(pos.method_10069(0, 0, 1))) {
            return new BlockData(pos.method_10069(0, 0, 1), class_2350.field_11043);
        } else if (isPosSolid(pos.method_10069(0, 0, -1))) {
            return new BlockData(pos.method_10069(0, 0, -1), class_2350.field_11035);
        } else if (isPosSolid(pos.method_10069(0, -1, 0))) {
            return new BlockData(pos.method_10069(0, -1, 0), class_2350.field_11036);
        }
        return null;
    }

    private class_2338 getBlockPos() {
        class_2338 playerPos = new class_2338(
                class_3532.method_15357(mc.field_1724.method_23317()),
                class_3532.method_15357(mc.field_1724.method_23318()),
                class_3532.method_15357(mc.field_1724.method_23321())
        );
        ArrayList<class_2338> positions = new ArrayList<>();
        for (Map.Entry<class_2338, class_2248> block : searchBlocks(5).entrySet()) {
            if (isPosSolid(block.getKey())) {
                positions.add(block.getKey());
            }
        }
        positions.removeIf(pos -> pos.method_10264() >= playerPos.method_10264());
        if (positions.isEmpty()) {
            return null;
        }
        positions.sort(Comparator.comparingDouble(vec3 -> vec3.method_10262(playerPos)));
        return positions.get(0);
    }

    private class_2350 getPlaceSide(class_2338 blockPos) {
        List<BlockData> blockData = new ArrayList<>();
        class_2338 pos = new class_2338(
                class_3532.method_15357(mc.field_1724.method_23317()),
                class_3532.method_15357(mc.field_1724.method_23318()),
                class_3532.method_15357(mc.field_1724.method_23321())
        );
        if (isAirBlock(blockPos.method_10078()) && !blockPos.method_10078().equals(pos)) {
            blockData.add(new BlockData(blockPos.method_10078(), class_2350.field_11034));
        }
        if (isAirBlock(blockPos.method_10095()) && !blockPos.method_10095().equals(pos)) {
            blockData.add(new BlockData(blockPos.method_10095(), class_2350.field_11043));
        }
        if (isAirBlock(blockPos.method_10072()) && !blockPos.method_10072().equals(pos)) {
            blockData.add(new BlockData(blockPos.method_10072(), class_2350.field_11035));
        }
        if (isAirBlock(blockPos.method_10067()) && !blockPos.method_10067().equals(pos)) {
            blockData.add(new BlockData(blockPos.method_10067(), class_2350.field_11039));
        }
        if (blockData.isEmpty()) {
            return null;
        }
        blockData.sort(Comparator.comparingDouble(vec3 -> vec3.blockPos().method_10262(pos)));
        blockData.removeIf(bd -> !BlockUtil.isReplaceable(bd.blockPos().method_10093(bd.facing())));
        return blockData.get(0).facing();
    }

    private boolean isAirBlock(class_2338 blockPos) {
        return BlockUtil.isReplaceable(blockPos);
    }

    private Map<class_2338, class_2248> searchBlocks(int radius) {
        Map<class_2338, class_2248> blocks = new HashMap<>();
        if (mc.field_1724 == null) {
            return blocks;
        }
        for (int x = radius; x >= -radius + 1; x--) {
            for (int y = radius; y >= -radius + 1; y--) {
                for (int z = radius; z >= -radius + 1; z--) {
                    class_2338 blockPos = new class_2338(
                            mc.field_1724.method_24515().method_10263() + x,
                            mc.field_1724.method_24515().method_10264() + y,
                            mc.field_1724.method_24515().method_10260() + z
                    );
                    class_2248 block = mc.field_1687.method_8320(blockPos).method_26204();
                    if (block != null) {
                        blocks.put(blockPos, block);
                    }
                }
            }
        }
        return blocks;
    }

    private boolean isPosSolid(class_2338 pos) {
        class_2248 block = mc.field_1687.method_8320(pos).method_26204();
        if (block instanceof class_2533
                || block instanceof class_2323
                || block instanceof class_2349) {
            return false;
        }
        return !BlockUtil.isReplaceable(pos) && BlockUtil.isSolid(block) && !BlockUtil.isInteractable(pos);
    }

    // ===== Rotation =====

    private static float smooth(float angle, float factor) {
        return angle * class_3532.method_15363(factor / 100.0F, 0.0F, 1.0F);
    }

    private Rotation getClosestToBlockFace(BlockData data, float yaw, float pitch) {
        if (data == null) {
            return null;
        }
        class_243 face = getVec3(data);
        float[] rots = RotationUtil.getRotationsTo(
                face.field_1352 - mc.field_1724.method_23317(),
                face.field_1351 - mc.field_1724.method_23318() - mc.field_1724.method_5751(),
                face.field_1350 - mc.field_1724.method_23321(),
                yaw,
                pitch
        );
        return new Rotation(rots[0], rots[1]);
    }

    private class_243 getVec3(BlockData data) {
        class_2338 pos = data.blockPos();
        class_2350 face = data.facing();
        double x = pos.method_10263() + 0.5D + face.method_10148() * 0.5D;
        double y = pos.method_10264() + 0.5D + face.method_10164() * 0.5D;
        double z = pos.method_10260() + 0.5D + face.method_10165() * 0.5D;
        return new class_243(x, y, z);
    }

    private static float yawDiffDirectly(float a, float b) {
        return class_3532.method_15393(a - b);
    }

    private static float normalizeYawDiff(float a, float b) {
        return Math.abs(class_3532.method_15393(a - b));
    }

    private float getServerYaw() {
        return RotationState.isActived() && RotationState.getPriority() == 3.0F
                ? RotationState.getSmoothedYaw()
                : mc.field_1724.method_36454();
    }

    private float getServerPitch() {
        return mc.field_1724.method_36455();
    }

    private Rotation getBRot(boolean forceRotation) {
        Rotation rotation = blockData != null
                ? getClosestToBlockFace(blockData, getServerYaw(), getServerPitch())
                : null;
        if (rotation == null) {
            if (normalizeYawDiff(mc.field_1724.method_36454() + 100f, getServerYaw()) < normalizeYawDiff(mc.field_1724.method_36454() - 100f, getServerYaw())) {
                rotation = new Rotation(mc.field_1724.method_36454() + 100f, getServerPitch());
            } else {
                rotation = new Rotation(mc.field_1724.method_36454() - 100f, getServerPitch());
            }
        }
        if (cancelMove) {
            return getClosestToBlockFace(blockData, getServerYaw(), getServerPitch());
        }
        double diff = yawDiffDirectly(rotation.yaw, getServerYaw());
        if (mode.getValue() == 0) {
            if (mc.field_1690.field_1903.method_1434() && noUptelly.getValue()) {
                return rotation;
            }
            if (mc.field_1690.field_1903.method_1434() && randomSlow.getValue()) {
                ups++;
                if (ups % 2 == 0) {
                    return rotation;
                }
            }
            if (smoothed.getValue() && (offGroundTicks < rotTick.getValue() || safeMode.getValue())) {
                if (onGroundTicks > 0) {
                    if (safeMode.getValue() && (!testOnGround.getValue() || mc.field_1690.field_1903.method_1434())) {
                        switch (onGroundTicks) {
                            case 1: {
                                if (!forceRotation) {
                                    rotation.yaw = getServerYaw() + smooth((float) diff, 50.0F);
                                    rotation.pitch = 75.5f;
                                } else {
                                    rotation = getClosestToBlockFace(blockData, mc.field_1724.method_36454(), getServerPitch());
                                }
                                break;
                            }
                            case 2: {
                                return new Rotation(mc.field_1724.method_36454(), 75.5f);
                            }
                        }
                    } else {
                        return new Rotation(mc.field_1724.method_36454(), 75.5f);
                    }
                } else {
                    float smoothFactor = offGroundTicks == 1 ? 80f : 50.0f;
                    smoothFactor -= (float) RandomUtil.nextDouble(0.001, 0.005);
                    rotation.yaw = getServerYaw() + smooth((float) diff, smoothFactor);
                }
            } else {
                if (snap.getValue() && mc.field_1690.field_1903.method_1434()) {
                    if (lastBlockData == null || offGroundTicks < rotTick.getValue()) {
                        return new Rotation(mc.field_1724.method_36454(), 85.0F + (float) Math.random());
                    }
                } else if (offGroundTicks < rotTick.getValue()) {
                    return new Rotation(mc.field_1724.method_36454(), 85.0F + (float) Math.random());
                }
            }
        }
        if (lastRotation != null && blockData != null && didHitBlockFace(mc.field_1724, lastRotation.yaw, lastRotation.pitch, blockData.blockPos(), blockData.facing(), true)) {
            return lastRotation;
        }
        if (blockData != null && !alwaysUpdateRot.getValue() && offGroundTicks >= rotTick.getValue()) {
            if (!didHitBlockFace(mc.field_1724, rotation.yaw, rotation.pitch, blockData.blockPos(), blockData.facing(), true) && offGroundTicks >= rotTick.getValue()) {
                lastRotation.yaw += (float) Math.random();
                return lastRotation;
            }
        }
        lastRotation = rotation;
        return rotation;
    }

    private static boolean didHitBlockFace(class_1297 player, float yaw, float pitch, class_2338 targetPos, class_2350 expectedFace, boolean strict) {
        if (player == null || expectedFace == null) {
            return false;
        }
        class_239 result = RotationUtil.rayTrace(yaw, pitch, mc.field_1724.method_55754(), 1.0F);
        if (result == null || result.method_17783() != class_239.class_240.field_1332) {
            return false;
        }
        class_3965 blockHit = (class_3965) result;
        return blockHit.method_17777().equals(targetPos) && (!strict || blockHit.method_17780() == expectedFace);
    }

    private static boolean didHitBlockFace(Rotation rotation, class_2338 targetPos, class_2350 expectedFace, boolean strict) {
        return didHitBlockFace(mc.field_1724, rotation.yaw, rotation.pitch, targetPos, expectedFace, strict);
    }

    private static boolean didHitBlockFace(BlockData blockData, Rotation rot) {
        return blockData == null || !didHitBlockFace(rot, blockData.blockPos(), blockData.facing(), true);
    }

    private boolean doesNotContainBlock(int down) {
        return BlockUtil.isReplaceable(mc.field_1724.method_24515().method_10087(down));
    }

    private void place() {
        if (blockData == null) {
            return;
        }
        if (rot == null) {
            return;
        }
        if (mc.field_1761 == null) {
            return;
        }
        if (!canPlace) {
            return;
        }
        if (!didHitBlockFace(mc.field_1724, rot.yaw, rot.pitch, blockData.blockPos(), blockData.facing(), true)) {
            return;
        }
        if (!this.blockSlot.offhand()) {
            mc.field_1724.method_31548().field_7545 = this.blockSlot.slot();
        }
        if (interactItem.getValue()) {
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        }
        class_243 hitVec = BlockUtil.getHitVec(blockData.blockPos(), blockData.facing(), rot.yaw, rot.pitch);
        class_3965 hitResult = new class_3965(hitVec, blockData.facing(), blockData.blockPos(), false);
        class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hitResult);
        if (result != null && result != class_1269.field_5811) {
            placeCount++;
            lastPlacePosition = blockData.blockPos().method_10093(blockData.facing());
            if (noSwing.getValue()) {
                PacketUtil.sendPacket(new class_2879(class_1268.field_5808));
            } else {
                mc.field_1724.method_6104(class_1268.field_5808);
            }
        }
    }

    private void rotationAbuse(float step, float targetYaw) {
        if (rot == null) {
            return;
        }
        double change = yawDiffDirectly(rot.yaw, targetYaw);
        int times = (int) (Math.abs(change) / step);
        float currentYaw = rot.yaw;
        for (int i = 0; i < times; i++) {
            currentYaw += smooth((float) change, step);
            rot = new Rotation(currentYaw, rot.pitch);
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        }
        rot = new Rotation(targetYaw, rot.pitch);
    }

    // ===== Events =====

    @EventTarget(Priority.LOWEST)
    public void onTick(TickEvent event) {
        if (event.getType() != EventType.POST) {
            return;
        }
        if (!this.isEnabled()) {
            return;
        }
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        if (blockFly.getValue()) {
            // BlockFly de-sync release placeholder.
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) {
            return;
        }
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }

        if (mc.field_1724.method_24828()) {
            onGroundTicks++;
            offGroundTicks = 0;
        } else {
            onGroundTicks = 0;
            offGroundTicks++;
        }

        this.blockSlot = null;

        class_1799 offhand = mc.field_1724.method_6079();
        if (isFullBlock(offhand)) {
            this.blockSlot = new SlotData(-1, true);
        }
        if (this.blockSlot == null && blockSlotMode.getValue() != 1) {
            if (isFullBlock(mc.field_1724.method_6047())) {
                this.blockSlot = new SlotData(mc.field_1724.method_31548().field_7545, false);
            }
        }
        if (this.blockSlot == null) {
            int hotbarSlot = getHotbarBlockSlot();
            if (hotbarSlot != -1) {
                this.blockSlot = new SlotData(hotbarSlot, false);
            }
        }
        if (this.blockSlot == null || blockSlot.check()) {
            return;
        }

        if (mc.field_1724.method_24828()) {
            posY = class_3532.method_15357(mc.field_1724.method_23318() - 1);
        }
        if (mc.field_1690.field_1903.method_1434()) {
            posY = mc.field_1724.method_24515().method_10264() - 1;
        }

        class_2338 playerBlock = new class_2338(
                class_3532.method_15357(mc.field_1724.method_23317()),
                class_3532.method_15357(mc.field_1724.method_23318()),
                class_3532.method_15357(mc.field_1724.method_23321())
        );
        BlockData possible = BlockUtil.isReplaceable(playerBlock)
                ? getBlockData(new class_2338(playerBlock.method_10263(), (int) posY, playerBlock.method_10260()))
                : null;
        if (possible != null) {
            blockData = possible;
        }
        lastBlockData = possible;

        if (mode.getValue() == 2) {
            canPlace = true;
        } else if (mode.getValue() == 1) {
            canPlace = doesNotContainBlock(1);
        } else {
            canPlace = offGroundTicks >= placeTick.getValue();
            if (safeMode.getValue() && testOnGround.getValue() && !canPlace && mc.field_1690.field_1903.method_1434()) {
                canPlace = onGroundTicks == 1;
            }
        }

        if (!this.blockSlot.offhand()) {
            mc.field_1724.method_31548().field_7545 = this.blockSlot.slot();
        }

        FallingPlayer fallingPlayer = new FallingPlayer(mc.field_1724);
        boolean reachable = true;
        fallingPlayer.calculate(1);
        class_243 nextEyePos = fallingPlayer.getEyePos();
        fallingPlayer.calculate(1);
        BlockData placement = getBlockData(new class_2338(
                class_3532.method_15357(mc.field_1724.method_23317()),
                mc.field_1724.method_24515().method_10264() - 1,
                class_3532.method_15357(mc.field_1724.method_23321())
        ));
        boolean forceRotation = false;
        if (placement != null) {
            if (safeMode.getValue() && testOnGround.getValue() && onGroundTicks == 1 && mc.field_1690.field_1903.method_1434()) {
                forceRotation = true;
            }
            double distance = nextEyePos.method_1022(new class_243(
                    placement.blockPos().method_10263() + 0.5D,
                    placement.blockPos().method_10264() + 0.5D,
                    placement.blockPos().method_10260() + 0.5D
            ));
            if (distance >= safeDistance.getValue() || placement.blockPos().method_10264() > fallingPlayer.getY()) {
                canPlace = true;
                reachable = false;
                blockData = lastBlockData = placement;
            }
        }
        if (blockData != null) {
            class_238 box = new class_238(
                    blockData.blockPos().method_10263(),
                    blockData.blockPos().method_10264() - 1,
                    blockData.blockPos().method_10260(),
                    blockData.blockPos().method_10263() + 1,
                    blockData.blockPos().method_10264() + 1,
                    blockData.blockPos().method_10260() + 1
            );
            if (blockData.blockPos().method_10264() > fallingPlayer.getY() && !box.method_1006(new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()))) {
                canPlace = true;
                reachable = false;
                posY = mc.field_1724.method_24515().method_10264() - 1;
                blockData = lastBlockData = getBlockData(new class_2338(
                        class_3532.method_15357(mc.field_1724.method_23317()),
                        (int) class_3532.method_15357(posY),
                        class_3532.method_15357(mc.field_1724.method_23321())
                ));
            }
        }

        if (!reachable && rotateCount < 8) {
            if (dbgV.getValue() && rotateCount == 1) {
                ChatUtil.sendFormatted("working");
            }
            cancelMove = true;
            rotateCount++;
        } else {
            rotateCount = 0;
        }

        rot = getBRot(forceRotation);
        if (rot == null) {
            return;
        }
        if (duplicateRotPlace.getValue()) {
            rot.pitch -= (float) RandomUtil.nextDouble(0.001, 0.003);
            rot.yaw -= (float) RandomUtil.nextDouble(0.0001, 0.0003);
            do {
                rot.pitch -= (float) RandomUtil.nextDouble(0.001, 0.003);
            } while (rot.pitch > 90.0F);
            if (rot.pitch < -90.0F) {
                rot.pitch = -90.0F;
            }
        }
        if (didHitBlockFace(blockData, rot)) {
            this.cancelMove = false;
            this.rotateCount = 0;
        }
        if (fixRotation.getValue()) {
            rot = new Rotation(rot.yaw, rot.pitch);
        }
        event.setRotation(rot.yaw, rot.pitch, 3);
        event.setPervRotation(rot.yaw, 3);

        if (abuseRotation.getValue()) {
            rotationAbuse(30f, rot.yaw);
        }
        place();

        if (waitingForEagleSneak) {
            tellyJumpTicks++;
            if (tellyJumpTicks == tellyEagleTick.getValue() && !mc.field_1690.field_1832.method_1434()) {
                mc.field_1690.field_1832.method_23481(true);
            }
            if (tellyJumpTicks == tellyEagleTick.getValue() + keepEagleSneakTick.getValue()) {
                mc.field_1690.field_1832.method_23481(false);
                waitingForEagleSneak = false;
                tellyJumpTicks = 0;
            }
        }
    }

    @EventTarget
    public void onStrafe(StrafeEvent event) {
        if (!this.isEnabled() || mc.field_1724 == null) {
            return;
        }
        if (this.blockSlot == null || blockSlot.check()) {
            return;
        }
        if (onGroundTicks > (smoothed.getValue() && safeMode.getValue() && !testOnGround.getValue() ? 1 : 0)
                && !mc.field_1690.field_1903.method_1434()
                && MoveUtil.isForwardPressed()
                && mode.getValue() == 0) {
            switch (jumpMode.getValue()) {
                case 0:
                    double yaw = Math.toRadians(mc.field_1724.method_36454());
                    double forwardX = -Math.sin(yaw);
                    double forwardZ = Math.cos(yaw);
                    class_2338 front1 = new class_2338(
                            (int) (mc.field_1724.method_23317() + forwardX),
                            (int) (mc.field_1724.method_23318() - 0.1),
                            (int) (mc.field_1724.method_23321() + forwardZ)
                    );
                    class_2338 front2 = new class_2338(
                            (int) (mc.field_1724.method_23317() + forwardX * 2),
                            (int) (mc.field_1724.method_23318() - 0.1),
                            (int) (mc.field_1724.method_23321() + forwardZ * 2)
                    );
                    if (BlockUtil.isReplaceable(front1) || BlockUtil.isReplaceable(front2)) {
                        mc.field_1724.method_6043();
                    }
                    break;
                case 1:
                    mc.field_1724.method_6043();
                    break;
                case 2:
                    break;
            }
            if (eagle.getValue() && mode.getValue() == 0) {
                waitingForEagleSneak = true;
                tellyJumpTicks = 0;
            }
        }
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (!this.isEnabled() || mc.field_1724 == null) {
            return;
        }
        if (this.cancelMove) {
            mc.field_1724.field_3913.field_3905 = 0.0F;
            mc.field_1724.field_3913.field_3907 = 0.0F;
            mc.field_1724.method_18800(0.0, 0.0, 0.0);
        } else if (RotationState.isActived() && RotationState.getPriority() == 3.0F && MoveUtil.isForwardPressed()) {
            MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
        }
        if (mode.getValue() == 0 && eagle.getValue()) {
            class_10185 pi = mc.field_1724.field_3913.field_54155;
            mc.field_1724.field_3913.field_54155 = new class_10185(pi.comp_3159(), pi.comp_3160(), pi.comp_3161(), pi.comp_3162(), pi.comp_3163(), placeCount % 4 == 0, pi.comp_3165());
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (lastPlacePosition != null && mark.getValue() && this.isEnabled()) {
            class_243 cameraPos = mc.field_1773.method_19418().method_19326();
            class_238 box = new class_238(
                    lastPlacePosition.method_10263() - cameraPos.field_1352,
                    lastPlacePosition.method_10264() - cameraPos.field_1351,
                    lastPlacePosition.method_10260() - cameraPos.field_1350,
                    lastPlacePosition.method_10263() + 1 - cameraPos.field_1352,
                    lastPlacePosition.method_10264() + 1 - cameraPos.field_1351,
                    lastPlacePosition.method_10260() + 1 - cameraPos.field_1350
            );
            RenderUtil.enableRenderState();
            RenderUtil.drawBoundingBox(box, 255, 255, 255, 150, 1.0F);
            RenderUtil.disableRenderState();
        }
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!this.isEnabled() || mc.field_1724 == null || !blockCount.getValue()) {
            return;
        }
        int newCount = Math.max(0, getBlockCountHotbar());
        if (newCount > startHotbarCount) {
            startHotbarCount = newCount;
        }
        float centerX = mc.method_22683().method_4486() / 2f;
        float centerY = mc.method_22683().method_4502() / 2f;
        float y = centerY + 15f + blockCountOffset.getValue();
        String text = newCount + " Blocks";
        int x = Math.round(centerX - (mc.field_1772.method_1727(text) / 2f));
        event.getContext().method_51433(mc.field_1772, text, x, (int) y, getBlockCountColor(newCount), true);
        lastCount = newCount;
        count = newCount;
    }

    @EventTarget
    public void onLeftClick(LeftClickMouseEvent event) {
        if (this.isEnabled() && !(mc.field_1755 instanceof class_465)) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onRightClick(RightClickMouseEvent event) {
        if (this.isEnabled() && !(mc.field_1755 instanceof class_465)) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onHitBlock(HitBlockEvent event) {
        if (this.isEnabled() && !(mc.field_1755 instanceof class_465)) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onSwap(SwapItemEvent event) {
        if (this.isEnabled()) {
            this.oldSlot = event.setSlot(this.oldSlot);
            event.setCancelled(true);
        }
    }

    public int getSlot() {
        return this.oldSlot;
    }

    @Override
    public String[] getSuffix() {
        return new String[]{mode.getModeString()};
    }

    public record BlockData(class_2338 blockPos, class_2350 facing) {
    }

    private record SlotData(int slot, boolean offhand) {
        public boolean check() {
            if (mc.field_1724 == null) {
                return true;
            }
            if (offhand) {
                return !isFullBlock(mc.field_1724.method_6079());
            }
            return !isFullBlock(mc.field_1724.method_31548().method_5438(slot));
        }
    }

    private static final class Rotation {
        float yaw;
        float pitch;

        Rotation(float yaw, float pitch) {
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }
}

