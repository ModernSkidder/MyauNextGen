package laoqi123.event.impl;

import laoqi123.event.impl.callables.EventCancellable;
import laoqi123.event.types.EventType;
import net.minecraft.class_2596;

public class PacketEvent extends EventCancellable {
    private final EventType type;
    private final class_2596<?> packet;

    public PacketEvent(EventType type, class_2596<?> packet) {
        this.type = type;
        this.packet = packet;
    }

    public EventType getType() {
        return this.type;
    }

    public class_2596<?> getPacket() {
        return this.packet;
    }
}
