package laoqi123.event.impl;

import net.minecraft.class_1297;

public class AttackEvent implements Event {
    private final class_1297 target;
    private boolean cancelled;

    public AttackEvent(class_1297 target) {
        this.target = target;
        this.cancelled = false;
    }

    public class_1297 getTarget() {
        return this.target;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }
}