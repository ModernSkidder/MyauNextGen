package laoqi123.event.impl;

import net.minecraft.class_4587;
import net.minecraft.class_4597;

public class Render3DEvent implements Event {
    private final class_4587 matrices;
    private final class_4597 consumers;
    private final float partialTicks;

    public Render3DEvent(class_4587 matrices, class_4597 consumers, float partialTicks) {
        this.matrices = matrices;
        this.consumers = consumers;
        this.partialTicks = partialTicks;
    }

    public class_4587 getMatrices() {
        return this.matrices;
    }

    public class_4597 getConsumers() {
        return this.consumers;
    }

    public float getPartialTicks() {
        return this.partialTicks;
    }
}
