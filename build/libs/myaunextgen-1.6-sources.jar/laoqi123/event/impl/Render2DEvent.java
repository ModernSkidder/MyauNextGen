package laoqi123.event.impl;

import net.minecraft.class_332;

public class Render2DEvent implements Event {
    private final class_332 context;
    private final float partialTicks;

    public Render2DEvent(class_332 context, float partialTicks) {
        this.context = context;
        this.partialTicks = partialTicks;
    }

    public class_332 getContext() {
        return this.context;
    }

    public float getPartialTicks() {
        return this.partialTicks;
    }
}
