package laoqi123.management;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.PacketEvent;
import laoqi123.events.TickEvent;
import laoqi123.util.PacketUtil;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2797;
import net.minecraft.class_2827;
import net.minecraft.class_2828;
import net.minecraft.class_2889;
import net.minecraft.class_2915;
import net.minecraft.class_2917;
import net.minecraft.class_2935;
import net.minecraft.class_2937;
import net.minecraft.class_310;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;

public class LagManager {
    private static final class_310 mc = class_310.method_1551();
    public final Deque<LagPacket> packetQueue;
    private int tickDelay;
    private boolean flushing;
    private class_243 lastPosition;

    public LagManager() {
        this.packetQueue = new ConcurrentLinkedDeque<>();
        this.tickDelay = 0;
        this.flushing = false;
        this.lastPosition = new class_243(0.0, 0.0, 0.0);
    }

    private void flushQueue() {
        if (mc.method_1562() == null) {
            this.packetQueue.clear();
        } else {
            for (this.flushing = true; !this.packetQueue.isEmpty(); this.packetQueue.poll()) {
                LagPacket lagPacket = this.packetQueue.peek();
                if (this.tickDelay > 0 && lagPacket.delay <= this.tickDelay) {
                    break;
                }
                PacketUtil.sendPacketNoEvent(lagPacket.packet);
                if (lagPacket.packet instanceof class_2828) {
                    class_2828 c03 = (class_2828) lagPacket.packet;
                    if (c03.method_36171()) {
                        this.lastPosition = new class_243(c03.method_12269(0.0), c03.method_12268(0.0), c03.method_12274(0.0));
                    }
                }
            }
            this.flushing = false;
        }
    }

    private void incrementDelays() {
        this.packetQueue.forEach(z -> z.delay++);
    }

    public boolean handlePacket(class_2596<?> packet) {
        this.flushQueue();
        if (packet instanceof class_2827 || packet instanceof class_2797) {
            return false;
        } else if ((long) this.tickDelay > 0L) {
            this.packetQueue.offer(new LagPacket(packet));
            return true;
        } else {
            if (packet instanceof class_2828) {
                class_2828 c03 = (class_2828) packet;
                if (c03.method_36171()) {
                    this.lastPosition = new class_243(c03.method_12269(0.0), c03.method_12268(0.0), c03.method_12274(0.0));
                }
            }
            return false;
        }
    }

    public void setDelay(int delay) {
        this.tickDelay = delay;
    }

    public class_243 getLastPosition() {
        return this.lastPosition;
    }

    public boolean isFlushing() {
        return this.flushing;
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (event.getType() == EventType.POST) {
            if (mc.field_1724 != null && mc.field_1724.method_31481()) {
                this.setDelay(0);
            }
            this.incrementDelays();
            this.flushQueue();
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getPacket() instanceof class_2889
                || event.getPacket() instanceof class_2915
                || event.getPacket() instanceof class_2937
                || event.getPacket() instanceof class_2935
                || event.getPacket() instanceof class_2917) {
            this.setDelay(0);
        }
    }

    public static class LagPacket {
        public final class_2596<?> packet;
        public int delay;

        public LagPacket(class_2596<?> packet) {
            this.packet = packet;
            this.delay = 0;
        }
    }
}
