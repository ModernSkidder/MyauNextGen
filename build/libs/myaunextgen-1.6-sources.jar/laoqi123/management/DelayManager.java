package laoqi123.management;

import laoqi123.enums.DelayModules;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import net.minecraft.class_1297;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2663;
import net.minecraft.class_2670;
import net.minecraft.class_2678;
import net.minecraft.class_2724;
import net.minecraft.class_2889;
import net.minecraft.class_2915;
import net.minecraft.class_2917;
import net.minecraft.class_2935;
import net.minecraft.class_2937;
import net.minecraft.class_310;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.TickEvent;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;

public class DelayManager {
    public static class_310 mc = class_310.method_1551();
    public DelayModules delayModule = DelayModules.NONE;
    public long delay = 0L;
    public Deque<class_2596<class_2602>> delayedPacket = new ConcurrentLinkedDeque<>();

    public boolean shouldDelay(class_2596<?> packet) {
        if (this.delayModule == DelayModules.NONE) {
            return false;
        } else if (packet instanceof class_2670) {
            return false;
        } else if (!(packet instanceof class_2678) && !(packet instanceof class_2724)) {
            if (packet instanceof class_2663) {
                class_2663 s19 = (class_2663) packet;
                if (mc.field_1687 != null) {
                    class_1297 entity = s19.method_11469(mc.field_1687);
                    if (entity != null && (!entity.equals(mc.field_1724) || s19.method_11470() != 2)) {
                        return false;
                    }
                }
            }
            this.delayedPacket.offer((class_2596<class_2602>) packet);
            return true;
        } else {
            this.setDelayState(false, this.delayModule);
            return false;
        }
    }

    public boolean setDelayState(boolean state, DelayModules delayModule) {
        if (state) {
            this.delay = 0;
            this.delayModule = delayModule;
        } else {
            this.delayModule = DelayModules.NONE;
            if (class_310.method_1551().method_1562() != null && this.delayedPacket.isEmpty()) {
                return true;
            }
            while (true) {
                class_2596<class_2602> packet = this.delayedPacket.poll();
                if (packet == null) {
                    this.delayedPacket.clear();
                    break;
                }
                laoqi123.util.PacketUtil.receivePacket(packet);
            }
        }
        return this.delayModule != DelayModules.NONE;
    }

    public DelayModules getDelayModule() {
        return this.delayModule;
    }

    public void delay(DelayModules modules) {
        this.delayModule = modules;
    }

    public long getDelay() {
        return this.delay;
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getPacket() instanceof class_2889
                || event.getPacket() instanceof class_2915
                || event.getPacket() instanceof class_2937
                || event.getPacket() instanceof class_2935
                || event.getPacket() instanceof class_2917) {
            this.setDelayState(false, this.delayModule);
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (event.getType() == EventType.POST) {
            if (mc.field_1724 != null && mc.field_1724.method_31481()) {
                this.setDelayState(false, this.delayModule);
            }
            if (this.delayModule != DelayModules.NONE) {
                this.delay++;
            }
        }
    }
}
