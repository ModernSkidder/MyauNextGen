package laoqi123.management;

import laoqi123.enums.BlinkModules;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.events.PacketEvent;
import laoqi123.events.TickEvent;
import laoqi123.util.PacketUtil;
import net.minecraft.class_2596;
import net.minecraft.class_2797;
import net.minecraft.class_2813;
import net.minecraft.class_2827;
import net.minecraft.class_2828;
import net.minecraft.class_2889;
import net.minecraft.class_2915;
import net.minecraft.class_2917;
import net.minecraft.class_2935;
import net.minecraft.class_2937;
import net.minecraft.class_310;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;

public class BlinkManager {
    public static class_310 mc = class_310.method_1551();
    public BlinkModules blinkModule = BlinkModules.NONE;
    public boolean blinking = false;
    public Deque<class_2596<?>> blinkedPackets = new ConcurrentLinkedDeque<>();

    public boolean offerPacket(class_2596<?> packet) {
        if (this.blinkModule == BlinkModules.NONE || packet instanceof class_2827 || packet instanceof class_2797) {
            return false;
        } else if (this.blinkedPackets.isEmpty() && packet instanceof class_2813) {
            return false;
        } else {
            this.blinkedPackets.offer(packet);
            return true;
        }
    }

    public boolean setBlinkState(boolean state, BlinkModules module) {
        if (module == BlinkModules.NONE) {
            return false;
        }
        if (state) {
            this.blinkModule = module;
            this.blinking = true;
        } else {
            if(blinkModule != module){
                return false;
            }
            this.blinking = false;
            if (class_310.method_1551().method_1562() != null && this.blinkedPackets.isEmpty()) {
                return true;
            }
            for (class_2596<?> blinkedPacket : blinkedPackets) {
                PacketUtil.sendPacketNoEvent(blinkedPacket);
            }
            this.blinkedPackets.clear();
            this.blinkModule = BlinkModules.NONE;
        }
        return true;
    }

    public BlinkModules getBlinkingModule() {
        return this.blinkModule;
    }

    public long countMovement() {
        return this.blinkedPackets.stream().filter(packet -> packet instanceof class_2828).count();
    }

    public boolean isBlinking() {
        return blinking;
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getPacket() instanceof class_2889
                || event.getPacket() instanceof class_2915
                || event.getPacket() instanceof class_2937
                || event.getPacket() instanceof class_2935
                || event.getPacket() instanceof class_2917) {
            this.setBlinkState(false, this.blinkModule);
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (event.getType() == EventType.POST) {
            if (mc.field_1724.method_31481()) {
                this.setBlinkState(false, this.blinkModule);
            }
        }
    }
}
