package laoqi123.management;

import laoqi123.enums.FloatModules;
import laoqi123.event.EventTarget;
import laoqi123.event.impl.PlayerUpdateEvent;
import net.minecraft.class_310;
import java.util.LinkedHashMap;

public class FloatManager {
    private static final class_310 mc = class_310.method_1551();
    private final LinkedHashMap<FloatModules, Boolean> activeMap;
    private boolean floating;

    public FloatManager() {
        this.activeMap = new LinkedHashMap<>();
        this.floating = false;
    }

    public boolean isPredicted() {
        return this.floating;
    }

    public boolean isFalling() {
        return mc.field_1724.method_24828() && mc.field_1724.method_23318() - mc.field_1724.field_6036 < 0.0 && mc.field_1724.method_18798().field_1351 < 0.0;
    }

    public boolean hasActiveModule() {
        return this.activeMap.containsValue(true);
    }

    public void setFloatState(boolean state, FloatModules floatModules) {
        this.activeMap.put(floatModules, state);
    }

    @EventTarget
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if ((this.hasActiveModule() || this.isPredicted()) && this.isFalling()) {
            mc.field_1724.method_5814(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 0.001, mc.field_1724.method_23321());
            this.floating = true;
        } else {
            this.floating = false;
        }
    }
}
