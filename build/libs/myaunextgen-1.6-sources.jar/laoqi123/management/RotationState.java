package laoqi123.management;

import net.minecraft.class_310;
import net.minecraft.class_3532;

public class RotationState {
    private static final class_310 mc = class_310.method_1551();
    private static int state = -1;
    private static float prevRenderYawOffset;
    private static float renderYawOffset;
    private static float prevRotationYawHead;
    private static float rotationYawHead;
    private static float prevRotationPitch;
    private static float rotationPitch;
    private static float smoothYaw;
    private static int priority;

    private static float calculateRenderYawOffset(float targetYaw, float currentYawOffset) {
        float newYawOffset = currentYawOffset;
        double deltaX = RotationState.mc.field_1724.method_23317() - RotationState.mc.field_1724.field_6014;
        double deltaZ = RotationState.mc.field_1724.method_23321() - RotationState.mc.field_1724.field_5969;
        if ((float) (deltaX * deltaX + deltaZ * deltaZ) > 0.0025000002f) {
            newYawOffset = (float) class_3532.method_15349(deltaZ, deltaX) * 180.0f / (float) Math.PI - 90.0f;
        }
        if (RotationState.mc.field_1724.field_6251 > 0.0f) {
            newYawOffset = targetYaw;
        }
        float f4 = class_3532.method_15393(newYawOffset - currentYawOffset);
        float f5 = class_3532.method_15393(targetYaw - (currentYawOffset += f4 * 0.3f));
        if (f5 < -75.0f) {
            f5 = -75.0f;
        }
        if (f5 >= 75.0f) {
            f5 = 75.0f;
        }
        newYawOffset = targetYaw - f5;
        if (f5 * f5 > 2500.0f) {
            newYawOffset += f5 * 0.2f;
        }
        return newYawOffset;
    }

    public static void applyState(boolean bl, float f, float f2, float f3, int n) {
        state = bl ? 0 : state + 1;
        if (RotationState.mc.field_1724 == null) return;
        prevRenderYawOffset = renderYawOffset;
        renderYawOffset = bl ? RotationState.calculateRenderYawOffset(f, renderYawOffset) : RotationState.mc.field_1724.method_43078();
        prevRotationYawHead = rotationYawHead;
        rotationYawHead = bl ? f : RotationState.mc.field_1724.method_5791();
        prevRotationPitch = rotationPitch;
        rotationPitch = bl ? f2 : RotationState.mc.field_1724.method_36455();
        smoothYaw = f3;
        priority = n;
    }

    public static boolean isActived() {
        return RotationState.isRotated(0);
    }

    public static boolean isRotated(int state) {
        if (RotationState.state < 0) return false;
        return RotationState.state <= state;
    }

    public static float getPrevRenderYawOffset() {
        return prevRenderYawOffset;
    }

    public static float getRenderYawOffset() {
        return renderYawOffset;
    }

    public static float getPrevRotationYawHead() {
        return prevRotationYawHead;
    }

    public static float getRotationYawHead() {
        return rotationYawHead;
    }

    public static float getPrevRotationPitch() {
        return prevRotationPitch;
    }

    public static float getRotationPitch() {
        return rotationPitch;
    }

    public static float getSmoothedYaw() {
        return smoothYaw;
    }

    public static float getPriority() {
        return priority;
    }
}
