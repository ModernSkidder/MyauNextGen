package laoqi123.management;

import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2885;

public class PlayerStateManager {
    public boolean attacking = false;
    public boolean digging = false;
    public boolean placing = false;
    public boolean swapping = false;
    public boolean swinging = false;

    public void handlePacket(class_2596<?> packet) {
        if (packet instanceof class_2824) {
            this.attacking = true;
        }
        if (packet instanceof class_2846) {
            this.digging = true;
        }
        if (packet instanceof class_2885) {
            this.placing = true;
        }
        if (packet instanceof class_2868) {
            this.swapping = true;
        }
        if (packet instanceof class_2879) {
            this.swinging = true;
        }
        if (packet instanceof class_2828) {
            this.attacking = false;
            this.digging = false;
            this.placing = false;
            this.swapping = false;
            this.swinging = false;
        }
    }
}
