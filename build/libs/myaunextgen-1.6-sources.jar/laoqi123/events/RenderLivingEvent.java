package laoqi123.events;

import laoqi123.event.events.Event;
import laoqi123.event.types.EventType;
import net.minecraft.class_1309;

public class RenderLivingEvent implements Event {
    private final EventType type;
    private final class_1309 entity;

    public RenderLivingEvent(EventType type, class_1309 entity) {
        this.type = type;
        this.entity = entity;
    }

    public EventType getType() {
        return this.type;
    }

    public class_1309 getEntity() {
        return this.entity;
    }
}
