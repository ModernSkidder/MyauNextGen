package laoqi123.init;

import laoqi123.event.EventManager;
import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import laoqi123.event.impl.TickEvent;
import laoqi123.ui.ClickGui;
import net.minecraft.class_1011;
import net.minecraft.class_310;
import net.minecraft.class_318;
import java.io.File;

public class DebugGuiHook {
    private int ticks = 0;
    private boolean opened = false;
    private int shots = 0;

    public DebugGuiHook() {
        EventManager.register(this);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (event.getType() != EventType.PRE) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        ticks++;
        if (!opened && ticks > 100) {
            opened = true;
            mc.method_1507(new ClickGui());
        }
        if (opened && ticks > 120 && shots < 3) {
            shots++;
            try {
                class_1011 image = class_318.method_1663(mc.method_1522());
                image.method_4325(new File("C:\\Users\\37672\\AppData\\Local\\Temp\\opencode\\clickgui-" + shots + ".png"));
                laoqi123.font.GlyphCache.debugLast.debugDumpGpuTexture("C:\\Users\\37672\\AppData\\Local\\Temp\\opencode\\gpu-" + shots + ".png");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (opened && ticks > 300) {
            EventManager.unregister(this);
            mc.method_1507(null);
        }
    }
}
