package laoqi123.init;

import laoqi123.Myau;
import laoqi123.event.EventManager;
import laoqi123.event.types.EventType;
import laoqi123.events.KeyEvent;
import laoqi123.events.TickEvent;
import laoqi123.module.Module;
import laoqi123.util.KeyBindUtil;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;
import java.util.HashSet;
import java.util.Set;

public class MyauClient implements ClientModInitializer {
    private final Set<Integer> pressedKeys = new HashSet<>();

    @Override
    public void onInitializeClient() {
        new Myau();

        if (Boolean.getBoolean("laoqi123.debuggui")) {
            new DebugGuiHook();
        }

        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            if (client.field_1687 == null || client.field_1724 == null) return;
            EventManager.call(new TickEvent(EventType.PRE));
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            class_310 mc = class_310.method_1551();
            if (mc.field_1687 == null || mc.field_1724 == null) return;
            EventManager.call(new TickEvent(EventType.POST));
            if (mc.field_1755 != null) return;

            Set<Integer> currentlyPressed = new HashSet<>();
            for (Module module : Myau.moduleManager.modules.values()) {
                int key = module.getKey();
                if (key == 0 || currentlyPressed.contains(key)) continue;
                if (KeyBindUtil.isKeyDown(key)) {
                    currentlyPressed.add(key);
                    if (!pressedKeys.contains(key)) {
                        EventManager.call(new KeyEvent(key));
                    }
                }
            }
            pressedKeys.retainAll(currentlyPressed);
            for (int key : currentlyPressed) pressedKeys.add(key);
        });
    }
}
