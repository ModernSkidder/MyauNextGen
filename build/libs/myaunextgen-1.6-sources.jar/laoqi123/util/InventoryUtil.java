package laoqi123.util;

import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_310;

public class InventoryUtil {
    private static final class_310 mc = class_310.method_1551();

    public static boolean isFullBlock(class_1799 stack) {
        if (stack == null || stack.method_7960() || !(stack.method_7909() instanceof class_1747)) {
            return false;
        }
        class_2248 block = ((class_1747) stack.method_7909()).method_7711();
        if (mc.field_1687 == null || block.method_9564().method_26215()) {
            return false;
        }
        return block.method_9564().method_26234(mc.field_1687, class_2338.field_10980);
    }

    public static void swap(int slot, int switchSlot) {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }
        int hotbarIndex = 36 + switchSlot;
        if (slot == hotbarIndex) {
            return;
        }
        mc.field_1761.method_2906(0, slot, 0, class_1713.field_7790, mc.field_1724);
        mc.field_1761.method_2906(0, hotbarIndex, 0, class_1713.field_7790, mc.field_1724);
    }
}