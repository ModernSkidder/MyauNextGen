package laoqi123.util;

import net.minecraft.class_1747;
import net.minecraft.class_1792;

public class SlotUtils {
    public static final int OFFHAND = 40;

    public static boolean isGoodForBridging(class_1792 item) {
        return item instanceof class_1747;
    }
}