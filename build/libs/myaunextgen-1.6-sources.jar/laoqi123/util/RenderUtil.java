package laoqi123.util;

import com.mojang.blaze3d.platform.GlConst;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.enums.ChatColors;
import net.minecraft.class_10142;
import net.minecraft.class_1058;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_276;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_6367;
import net.minecraft.class_6880;
import net.minecraft.class_7833;
import net.minecraft.class_9304;
import net.minecraft.class_9799;
import net.minecraft.class_9974;
import org.joml.Matrix4f;
import org.joml.Vector4d;
import org.joml.Vector4f;

import java.awt.Color;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class RenderUtil {
    private static final class_310 mc = class_310.method_1551();
    private static class_4604 cameraFrustum;
    private static IntBuffer viewportBuffer;
    private static FloatBuffer modelViewBuffer;
    private static FloatBuffer projectionBuffer;
    private static FloatBuffer vectorBuffer;
    private static Map<class_2960, EnchantmentData> enchantmentMap;

    static {
        RenderUtil.cameraFrustum = new class_4604(new Matrix4f(), new Matrix4f());
        RenderUtil.viewportBuffer = null;
        RenderUtil.modelViewBuffer = null;
        RenderUtil.projectionBuffer = null;
        RenderUtil.vectorBuffer = null;
        RenderUtil.enchantmentMap = new EnchantmentMap();
    }

    private static ChatColors getColorForLevel(int currentLevel, int maxLevel) {
        if (currentLevel > maxLevel) {
            return ChatColors.LIGHT_PURPLE;
        }
        if (currentLevel == maxLevel) {
            return ChatColors.RED;
        }
        switch (currentLevel) {
            case 1: {
                return ChatColors.AQUA;
            }
            case 2: {
                return ChatColors.GREEN;
            }
            case 3: {
                return ChatColors.YELLOW;
            }
            case 4: {
                return ChatColors.GOLD;
            }
        }
        return ChatColors.GRAY;
    }

    public static void drawOutlinedString(String text, float x, float y) {
        String string2 = text.replaceAll("(?i)§[\\da-f]", "");
        class_9799 allocator = new class_9799(256);
        class_4597.class_4598 immediate = class_4597.method_22991(allocator);
        mc.field_1772.method_37296(class_2561.method_43470(string2).method_30937(), x, y, -1, 0xFF000000, RenderSystem.getModelViewMatrix(), immediate, 0xF000F0);
        immediate.method_22993();
    }

    public static void renderEnchantmentText(class_1799 itemStack, float x, float y, float scale) {
        class_9304 itemEnchantmentsComponent = itemStack.method_58657();
        if (itemEnchantmentsComponent != null && !itemEnchantmentsComponent.method_57543()) {
            int i = 0;
            for (Entry<class_6880<class_1887>, Integer> entry : itemEnchantmentsComponent.method_57539()) {
                EnchantmentData enchantmentData = enchantmentMap.get(entry.getKey().method_40230().get().method_29177());
                if (enchantmentData == null) {
                    continue;
                }
                int level = entry.getValue();
                ChatColors chatColors = RenderUtil.getColorForLevel(level, enchantmentData.maxLevel);
                RenderUtil.drawOutlinedString(ChatColors.formatColor(String.format("&r%s%s%d&r", enchantmentData.shortName, chatColors, level)), x * (1.0f / scale), (y + (float) i * 4.0f) * (1.0f / scale));
                i++;
            }
        }
    }

    public static void renderItemInGUI(class_1799 itemStack, int x, int y) {
        class_9799 allocator = new class_9799(2048);
        class_4597.class_4598 immediate = class_4597.method_22991(allocator);
        class_332 context = new class_332(mc, immediate);
        context.method_51427(itemStack, x, y);
        context.method_51431(mc.field_1772, itemStack, x, y);
        context.method_51452();
        RenderUtil.renderEnchantmentText(itemStack, x, y, 0.5f);
    }

    public static void renderPotionEffect(class_1293 potionEffect, int x, int y) {
        class_1058 sprite = mc.method_18505().method_18663(potionEffect.method_5579());
        class_9799 allocator = new class_9799(256);
        class_4597.class_4598 immediate = class_4597.method_22991(allocator);
        class_332 context = new class_332(mc, immediate);
        context.method_52710(class_1921::method_62277, sprite, x, y, 18, 18, 0xFFFFFFFF);
        context.method_51452();
    }

    public static void drawRect(float x1, float y1, float x2, float y2, int color) {
        if (color == 0) {
            return;
        }
        RenderUtil.setColor(color);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        bufferBuilder.method_22912(x1, y1, 0.0F);
        bufferBuilder.method_22912(x1, y2, 0.0F);
        bufferBuilder.method_22912(x2, y2, 0.0F);
        bufferBuilder.method_22912(x2, y1, 0.0F);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawRect3D(float x1, float y1, float x2, float y2, int color) {
        if (color == 0) {
            return;
        }
        RenderUtil.setColor(color);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        for (int i = 0; i < 2; ++i) {
            bufferBuilder.method_22912(x1, y1, 0.0F);
            bufferBuilder.method_22912(x1, y2, 0.0F);
            bufferBuilder.method_22912(x2, y2, 0.0F);
            bufferBuilder.method_22912(x2, y1, 0.0F);
        }
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawOutlineRect(float x1, float y1, float x2, float y2, float lineWidth, int backgroundColor, int lineColor) {
        RenderUtil.drawRect(0.0f, 0.0f, x2, 27.0f, backgroundColor);
        if (lineColor == 0) {
            return;
        }
        RenderUtil.setColor(lineColor);
        RenderSystem.lineWidth(lineWidth);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27377, class_290.field_1592);
        bufferBuilder.method_22912(x1, y1, 0.0F);
        bufferBuilder.method_22912(x1, y2, 0.0F);
        bufferBuilder.method_22912(x2, y2, 0.0F);
        bufferBuilder.method_22912(x2, y1, 0.0F);
        bufferBuilder.method_22912(x1, y1, 0.0F);
        bufferBuilder.method_22912(x2, y1, 0.0F);
        bufferBuilder.method_22912(x1, y2, 0.0F);
        bufferBuilder.method_22912(x2, y2, 0.0F);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0f);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawLine(float x1, float y1, float x2, float y2, float lineWidth, int color) {
        RenderUtil.setColor(color);
        RenderSystem.lineWidth(lineWidth);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27377, class_290.field_1592);
        bufferBuilder.method_22912(x1, y1, 0.0F);
        bufferBuilder.method_22912(x2, y2, 0.0F);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0f);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawLine3D(class_243 start, double endX, double endY, double endZ, float red, float green, float blue, float alpha, float lineWidth) {
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        RenderSystem.setShaderColor(red, green, blue, alpha);
        RenderSystem.lineWidth(lineWidth);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27377, class_290.field_1592);
        bufferBuilder.method_22912((float) start.field_1352, (float) start.field_1351, (float) start.field_1350);
        bufferBuilder.method_22912((float) (endX - cameraPos.field_1352), (float) (endY - cameraPos.field_1351), (float) (endZ - cameraPos.field_1350));
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0f);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawArrow(float centerX, float centerY, float angle, float length, float lineWidth, int color) {
        float f6 = angle + (float) Math.toRadians(45.0);
        float f7 = angle - (float) Math.toRadians(45.0);
        RenderUtil.setColor(color);
        RenderSystem.lineWidth(lineWidth);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27377, class_290.field_1592);
        bufferBuilder.method_22912(centerX, centerY, 0.0F);
        bufferBuilder.method_22912(centerX + length * (float) Math.cos(f6), centerY + length * (float) Math.sin(f6), 0.0F);
        bufferBuilder.method_22912(centerX, centerY, 0.0F);
        bufferBuilder.method_22912(centerX + length * (float) Math.cos(f7), centerY + length * (float) Math.sin(f7), 0.0F);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0f);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawTriangle(float centerX, float centerY, float angle, float length, int color) {
        float f5 = angle + (float) Math.toRadians(26.25);
        float f6 = angle - (float) Math.toRadians(26.25);
        RenderUtil.setColor(color);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27381, class_290.field_1592);
        bufferBuilder.method_22912(centerX, centerY, 0.0F);
        bufferBuilder.method_22912(centerX + length * (float) Math.cos(f5), centerY + length * (float) Math.sin(f5), 0.0F);
        bufferBuilder.method_22912(centerX + length * (float) Math.cos(f6), centerY + length * (float) Math.sin(f6), 0.0F);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawFramebuffer(class_276 framebuffer) {
        framebuffer.method_1237(mc.method_22683().method_4489(), mc.method_22683().method_4506());
    }

    public static void fillCircle(double x, double y, double radius, int segments, int color) {
        RenderUtil.setColor(color);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27381, class_290.field_1592);
        bufferBuilder.method_22912((float) x, (float) y, 0.0F);
        for (int i = 0; i <= segments; i++) {
            double angle = i * (Math.PI * 2.0 / segments);
            double px = x + Math.cos(angle) * radius;
            double py = y + Math.sin(angle) * radius;
            bufferBuilder.method_22912((float) px, (float) py, 0.0F);
        }
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawCircle(double centerX, double centerY, double centerZ, double radius, int segments, int color) {
        RenderUtil.setColor(color);
        RenderSystem.lineWidth(3.0f);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_29345, class_290.field_1592);
        for (int i = 0; i <= segments; ++i) {
            double d5 = (double) i * (Math.PI * 2 / (double) segments);
            bufferBuilder.method_22912((float) (centerX + Math.cos(d5) * radius), (float) centerY, (float) (centerZ + Math.sin(d5) * radius));
        }
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0f);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawEntityCircle(class_1297 entity, double radius, int segments, int color) {
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        float partialTicks = mc.method_61966().method_60637(true);
        double d2 = RenderUtil.lerpDouble(entity.method_23317(), entity.field_6014, partialTicks) - cameraPos.field_1352;
        double d3 = RenderUtil.lerpDouble(entity.method_23318(), entity.field_6036, partialTicks) - cameraPos.field_1351;
        double d4 = RenderUtil.lerpDouble(entity.method_23321(), entity.field_5969, partialTicks) - cameraPos.field_1350;
        RenderUtil.drawCircle(d2, d3, d4, radius, segments, color);
    }

    public static void drawFilledBox(class_238 axisAlignedBB, int red, int green, int blue) {
        RenderSystem.setShader(class_10142.field_53876);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        class_9974.method_62300(new class_4587(), bufferBuilder, axisAlignedBB.field_1323, axisAlignedBB.field_1322, axisAlignedBB.field_1321, axisAlignedBB.field_1320, axisAlignedBB.field_1325, axisAlignedBB.field_1324, red, green, blue, 63);
        class_286.method_43433(bufferBuilder.method_60800());
    }

    public static void drawBoundingBox(class_238 axisAlignedBB, int red, int green, int blue, int alpha, float lineWidth) {
        RenderSystem.lineWidth(lineWidth);
        RenderSystem.setShader(class_10142.field_53876);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        class_9974.method_62295(new class_4587(), bufferBuilder, axisAlignedBB, red, green, blue, alpha);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0f);
    }

    public static void drawEntityBox(class_1297 entity, int red, int green, int blue) {
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        float partialTicks = mc.method_61966().method_60637(true);
        double d2 = RenderUtil.lerpDouble(entity.method_23317(), entity.field_6014, partialTicks);
        double d3 = RenderUtil.lerpDouble(entity.method_23318(), entity.field_6036, partialTicks);
        double d4 = RenderUtil.lerpDouble(entity.method_23321(), entity.field_5969, partialTicks);
        RenderUtil.drawFilledBox(entity.method_5829().method_1009(0.1, 0.1, 0.1).method_989(d2 - entity.method_23317(), d3 - entity.method_23318(), d4 - entity.method_23321()).method_989(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350), red, green, blue);
    }

    public static void drawEntityBoundingBox(class_1297 entity, int red, int green, int blue, int alpha, float lineWidth, double expand) {
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        float partialTicks = mc.method_61966().method_60637(true);
        double d2 = RenderUtil.lerpDouble(entity.method_23317(), entity.field_6014, partialTicks);
        double d3 = RenderUtil.lerpDouble(entity.method_23318(), entity.field_6036, partialTicks);
        double d4 = RenderUtil.lerpDouble(entity.method_23321(), entity.field_5969, partialTicks);
        RenderUtil.drawBoundingBox(entity.method_5829().method_1009(expand, expand, expand).method_989(d2 - entity.method_23317(), d3 - entity.method_23318(), d4 - entity.method_23321()).method_989(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350), red, green, blue, alpha, lineWidth);
    }

    public static void drawBlockBox(class_2338 blockPos, double height, int red, int green, int blue) {
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        double x = blockPos.method_10263() - cameraPos.field_1352;
        double y = blockPos.method_10264() - cameraPos.field_1351;
        double z = blockPos.method_10260() - cameraPos.field_1350;
        RenderUtil.drawFilledBox(new class_238(x, y, z, x + 1.0, y + height, z + 1.0), red, green, blue);
    }

    public static void drawBlockBoundingBox(class_2338 blockPos, double height, int red, int green, int blue, int alpha, float lineWidth) {
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        double x = blockPos.method_10263() - cameraPos.field_1352;
        double y = blockPos.method_10264() - cameraPos.field_1351;
        double z = blockPos.method_10260() - cameraPos.field_1350;
        RenderUtil.drawBoundingBox(new class_238(x, y, z, x + 1.0, y + height, z + 1.0), red, green, blue, alpha, lineWidth);
    }

    public static void drawCornerESP(class_1657 entity, float red, float green, float blue) {
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        float partialTicks = mc.method_61966().method_60637(true);
        float x = (float) (RenderUtil.lerpDouble(entity.method_23317(), entity.field_6014, partialTicks) - cameraPos.field_1352);
        float y = (float) (RenderUtil.lerpDouble(entity.method_23318(), entity.field_6036, partialTicks) - cameraPos.field_1351);
        float z = (float) (RenderUtil.lerpDouble(entity.method_23321(), entity.field_5969, partialTicks) - cameraPos.field_1350);
        class_4587 matrices = new class_4587();
        matrices.method_46416(x, y + entity.method_17682() / 2.0F, z);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-mc.field_1773.method_19418().method_19330()));
        matrices.method_22905(-0.098F, -0.098F, 0.098F);
        float width = (float) (26.6 * entity.method_17681() / 2.0);
        float height = 12.0F;
        RenderSystem.setShaderColor(red, green, blue, 1.0F);
        RenderUtil.drawRectInMatrix(matrices, width, height - 1.0F, width - 4.0F, height);
        RenderUtil.drawRectInMatrix(matrices, -width, height - 1.0F, -width + 4.0F, height);
        RenderUtil.drawRectInMatrix(matrices, -width, height, -width + 1.0F, height - 4.0F);
        RenderUtil.drawRectInMatrix(matrices, width, height, width - 1.0F, height - 4.0F);
        RenderUtil.drawRectInMatrix(matrices, width, -height, width - 4.0F, -height + 1.0F);
        RenderUtil.drawRectInMatrix(matrices, -width, -height, -width + 4.0F, -height + 1.0F);
        RenderUtil.drawRectInMatrix(matrices, -width, -height + 1.0F, -width + 1.0F, -height + 4.0F);
        RenderUtil.drawRectInMatrix(matrices, width, -height + 1.0F, width - 1.0F, -height + 4.0F);
        RenderSystem.setShaderColor(0.0F, 0.0F, 0.0F, 1.0F);
        RenderUtil.drawRectInMatrix(matrices, width, height, width - 4.0F, height + 0.2F);
        RenderUtil.drawRectInMatrix(matrices, -width, height, -width + 4.0F, height + 0.2F);
        RenderUtil.drawRectInMatrix(matrices, -width - 0.2F, height + 0.2F, -width, height - 4.0F);
        RenderUtil.drawRectInMatrix(matrices, width + 0.2F, height + 0.2F, width, height - 4.0F);
        RenderUtil.drawRectInMatrix(matrices, width + 0.2F, -height, width - 4.0F, -height - 0.2F);
        RenderUtil.drawRectInMatrix(matrices, -width - 0.2F, -height, -width + 4.0F, -height - 0.2F);
        RenderUtil.drawRectInMatrix(matrices, -width - 0.2F, -height, -width, -height + 4.0F);
        RenderUtil.drawRectInMatrix(matrices, width + 0.2F, -height, width, -height + 4.0F);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawFake2DESP(class_1657 entity, float red, float green, float blue) {
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        float partialTicks = mc.method_61966().method_60637(true);
        float x = (float) (RenderUtil.lerpDouble(entity.method_23317(), entity.field_6014, partialTicks) - cameraPos.field_1352);
        float y = (float) (RenderUtil.lerpDouble(entity.method_23318(), entity.field_6036, partialTicks) - cameraPos.field_1351);
        float z = (float) (RenderUtil.lerpDouble(entity.method_23321(), entity.field_5969, partialTicks) - cameraPos.field_1350);
        class_4587 matrices = new class_4587();
        matrices.method_46416(x, y + entity.method_17682() / 2.0F, z);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-mc.field_1773.method_19418().method_19330()));
        matrices.method_22905(-0.1F, -0.1F, 0.1F);
        float width = (float) (23.3 * entity.method_17681() / 2.0);
        float height = 12.0F;
        RenderSystem.setShaderColor(red, green, blue, 1.0F);
        RenderUtil.drawRectInMatrix(matrices, width, height, -width, height + 0.4F);
        RenderUtil.drawRectInMatrix(matrices, width, -height, -width, -height + 0.4F);
        RenderUtil.drawRectInMatrix(matrices, width, -height + 0.4F, width - 0.4F, height + 0.4F);
        RenderUtil.drawRectInMatrix(matrices, -width, -height + 0.4F, -width + 0.4F, height + 0.4F);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void draw3DRect(float x1, float y1, float x2, float y2) {
        RenderUtil.drawRectInMatrix(new class_4587(), x1, y1, x2, y2);
    }

    private static void drawRectInMatrix(class_4587 matrices, float x1, float y1, float x2, float y2) {
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        class_4587.class_4665 entry = matrices.method_23760();
        bufferBuilder.method_56824(entry, x2, y1, 0.0F);
        bufferBuilder.method_56824(entry, x1, y1, 0.0F);
        bufferBuilder.method_56824(entry, x1, y2, 0.0F);
        bufferBuilder.method_56824(entry, x2, y2, 0.0F);
        class_286.method_43433(bufferBuilder.method_60800());
    }

    public static Vector4d projectToScreen(class_1297 entity, double screenScale) {
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        float partialTicks = mc.method_61966().method_60637(true);
        double d3 = RenderUtil.lerpDouble(entity.method_23317(), entity.field_6014, partialTicks);
        double d4 = RenderUtil.lerpDouble(entity.method_23318(), entity.field_6036, partialTicks);
        double d5 = RenderUtil.lerpDouble(entity.method_23321(), entity.field_5969, partialTicks);
        class_238 axisAlignedBB = entity.method_5829().method_1009(0.1, 0.1, 0.1).method_989(d3 - entity.method_23317(), d4 - entity.method_23318(), d5 - entity.method_23321());
        return RenderUtil.projectToScreen(axisAlignedBB, screenScale);
    }

    public static Vector4d projectToScreen(class_238 axisAlignedBB, double screenScale) {
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        Vector4d vector4d = null;
        Matrix4f modelView = RenderSystem.getModelViewMatrix();
        Matrix4f projection = RenderSystem.getProjectionMatrix();
        int viewportWidth = mc.method_22683().method_4489();
        int viewportHeight = mc.method_22683().method_4506();
        double[] xs = {axisAlignedBB.field_1323, axisAlignedBB.field_1323, axisAlignedBB.field_1320, axisAlignedBB.field_1320, axisAlignedBB.field_1323, axisAlignedBB.field_1323, axisAlignedBB.field_1320, axisAlignedBB.field_1320};
        double[] ys = {axisAlignedBB.field_1322, axisAlignedBB.field_1325, axisAlignedBB.field_1322, axisAlignedBB.field_1325, axisAlignedBB.field_1322, axisAlignedBB.field_1325, axisAlignedBB.field_1322, axisAlignedBB.field_1325};
        double[] zs = {axisAlignedBB.field_1321, axisAlignedBB.field_1321, axisAlignedBB.field_1321, axisAlignedBB.field_1321, axisAlignedBB.field_1324, axisAlignedBB.field_1324, axisAlignedBB.field_1324, axisAlignedBB.field_1324};
        for (int i = 0; i < 8; i++) {
            Vector4f vector4f = new Vector4f((float) (xs[i] - cameraPos.field_1352), (float) (ys[i] - cameraPos.field_1351), (float) (zs[i] - cameraPos.field_1350), 1.0F);
            vector4f.mul(modelView);
            vector4f.mulProject(projection);
            if (vector4f.w != 0.0F) {
                vector4f.mul(1.0F / vector4f.w);
            }
            double sx = (vector4f.x * 0.5F + 0.5F) * viewportWidth / screenScale;
            double sy = (0.5F - vector4f.y * 0.5F) * viewportHeight / screenScale;
            double sz = vector4f.z;
            if (sz < 0.0 || sz >= 1.0) {
                continue;
            }
            if (vector4d == null) {
                vector4d = new Vector4d(sx, sy, sz, 0.0);
            }
            vector4d.x = Math.min(sx, vector4d.x);
            vector4d.y = Math.min(sy, vector4d.y);
            vector4d.z = Math.max(sx, vector4d.z);
            vector4d.w = Math.max(sy, vector4d.w);
        }
        return vector4d;
    }

    public static boolean isInViewFrustum(class_238 axisAlignedBB, double expand) {
        cameraFrustum = new class_4604(RenderSystem.getModelViewMatrix(), RenderSystem.getProjectionMatrix());
        return cameraFrustum.method_23093(axisAlignedBB.method_1009(expand, expand, expand));
    }

    public static void enableRenderState() {
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA, GlStateManager.class_4535.ONE, GlStateManager.class_4534.ZERO);
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
    }

    public static void disableRenderState() {
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    public static void setColor(int argb) {
        float f = (float) (argb >> 24 & 0xFF) / 255.0f;
        float f2 = (float) (argb >> 16 & 0xFF) / 255.0f;
        float f3 = (float) (argb >> 8 & 0xFF) / 255.0f;
        float f4 = (float) (argb & 0xFF) / 255.0f;
        RenderSystem.setShaderColor(f2, f3, f4, f);
    }

    public static float lerpFloat(float current, float previous, float t) {
        return previous + (current - previous) * t;
    }

    public static double lerpDouble(double current, double previous, double t) {
        return previous + (current - previous) * t;
    }

    public static final class EnchantmentData {
        public final String shortName;
        public final int maxLevel;

        public EnchantmentData(String shortName, int maxLevel) {
            this.shortName = shortName;
            this.maxLevel = maxLevel;
        }
    }

    static final class EnchantmentMap extends HashMap<class_2960, EnchantmentData> {
        EnchantmentMap() {
            this.put(class_2960.method_60654("protection"), new EnchantmentData("Pr", 4));
            this.put(class_2960.method_60654("fire_protection"), new EnchantmentData("Fp", 4));
            this.put(class_2960.method_60654("fire_aspect"), new EnchantmentData("Ff", 4));
            this.put(class_2960.method_60654("blast_protection"), new EnchantmentData("Bp", 4));
            this.put(class_2960.method_60654("projectile_protection"), new EnchantmentData("Pp", 4));
            this.put(class_2960.method_60654("respiration"), new EnchantmentData("Re", 3));
            this.put(class_2960.method_60654("aqua_affinity"), new EnchantmentData("Aq", 1));
            this.put(class_2960.method_60654("thorns"), new EnchantmentData("Th", 3));
            this.put(class_2960.method_60654("depth_strider"), new EnchantmentData("Ds", 3));
            this.put(class_2960.method_60654("sharpness"), new EnchantmentData("Sh", 5));
            this.put(class_2960.method_60654("smite"), new EnchantmentData("Sm", 5));
            this.put(class_2960.method_60654("bane_of_arthropods"), new EnchantmentData("BoA", 5));
            this.put(class_2960.method_60654("knockback"), new EnchantmentData("Kb", 2));
            this.put(class_2960.method_60654("looting"), new EnchantmentData("Lo", 3));
            this.put(class_2960.method_60654("efficiency"), new EnchantmentData("Ef", 5));
            this.put(class_2960.method_60654("silk_touch"), new EnchantmentData("St", 1));
            this.put(class_2960.method_60654("unbreaking"), new EnchantmentData("Ub", 3));
            this.put(class_2960.method_60654("fortune"), new EnchantmentData("Fo", 3));
            this.put(class_2960.method_60654("power"), new EnchantmentData("Po", 5));
            this.put(class_2960.method_60654("punch"), new EnchantmentData("Pu", 2));
            this.put(class_2960.method_60654("flame"), new EnchantmentData("Fl", 1));
            this.put(class_2960.method_60654("infinity"), new EnchantmentData("Inf", 1));
            this.put(class_2960.method_60654("luck_of_the_sea"), new EnchantmentData("LoS", 3));
            this.put(class_2960.method_60654("lure"), new EnchantmentData("Lu", 3));
        }
    }

    public static class_276 createFrameBuffer(class_276 framebuffer, boolean depth) {
        int width = mc.method_22683().method_4489();
        int height = mc.method_22683().method_4506();
        if (framebuffer == null || framebuffer.field_1482 != width || framebuffer.field_1481 != height) {
            if (framebuffer != null) {
                framebuffer.method_1238();
            }
            framebuffer = new class_6367(width, height, depth);
            framebuffer.method_58226(GlConst.GL_LINEAR);
        }
        return framebuffer;
    }

    public static void setAlphaLimit(float limit) {
    }

    public static void bindTexture(int texture) {
        GlStateManager._bindTexture(texture);
    }

    public static void drawQuads() {
        float width = mc.method_22683().method_4489();
        float height = mc.method_22683().method_4506();
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        bufferBuilder.method_22912(0.0F, 0.0F, 0.0F);
        bufferBuilder.method_22912(0.0F, height, 0.0F);
        bufferBuilder.method_22912(width, height, 0.0F);
        bufferBuilder.method_22912(width, 0.0F, 0.0F);
        class_286.method_43433(bufferBuilder.method_60800());
    }

    public static void drawQuad(class_287 builder, Matrix4f matrix, float x1, float y1, float x2, float y2, Color color) {
        builder.method_22918(matrix, x1, y2, 0.0F).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
        builder.method_22918(matrix, x2, y2, 0.0F).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
        builder.method_22918(matrix, x2, y1, 0.0F).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
        builder.method_22918(matrix, x1, y1, 0.0F).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    public static void drawRect(double left, double top, double right, double bottom, int color) {
        if (left < right) {
            double i = left;
            left = right;
            right = i;
        }
        if (top < bottom) {
            double j = top;
            top = bottom;
            bottom = j;
        }
        RenderUtil.setColor(color);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        bufferBuilder.method_22912((float) left, (float) bottom, 0.0F);
        bufferBuilder.method_22912((float) right, (float) bottom, 0.0F);
        bufferBuilder.method_22912((float) right, (float) top, 0.0F);
        bufferBuilder.method_22912((float) left, (float) top, 0.0F);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawRoundedRect(float x, float y, float width, float height, float radius, int color) {
        if (width <= 0 || height <= 0) {
            return;
        }
        RenderUtil.drawRoundedRect((double) x, (double) y, (double) width, (double) height, (double) radius, color, true, true, true, true);
    }

    public static void drawRoundedRect(double x, double y, double width, double height, double radius, int color, boolean roundTopLeft, boolean roundTopRight, boolean roundBottomLeft, boolean roundBottomRight) {
        if (width <= 0.0D || height <= 0.0D || (color >>> 24) == 0) {
            return;
        }
        radius = Math.max(0.0D, Math.min(radius, Math.min(width, height) / 2.0D));
        if (radius <= 0.0D || !(roundTopLeft || roundTopRight || roundBottomLeft || roundBottomRight)) {
            RenderUtil.drawRect((float) x, (float) y, (float) (x + width), (float) (y + height), color);
            return;
        }
        RenderUtil.enableRenderState();
        RenderUtil.setColor(color);
        RenderUtil.drawQuadNoState(x + radius, y, x + width - radius, y + height);
        RenderUtil.drawQuadNoState(x, y + radius, x + radius, y + height - radius);
        RenderUtil.drawQuadNoState(x + width - radius, y + radius, x + width, y + height - radius);
        if (roundTopLeft) {
            RenderUtil.drawCornerFan(x + radius, y + radius, radius, 180.0D, 270.0D);
        } else {
            RenderUtil.drawQuadNoState(x, y, x + radius, y + radius);
        }
        if (roundTopRight) {
            RenderUtil.drawCornerFan(x + width - radius, y + radius, radius, 270.0D, 360.0D);
        } else {
            RenderUtil.drawQuadNoState(x + width - radius, y, x + width, y + radius);
        }
        if (roundBottomRight) {
            RenderUtil.drawCornerFan(x + width - radius, y + height - radius, radius, 0.0D, 90.0D);
        } else {
            RenderUtil.drawQuadNoState(x + width - radius, y + height - radius, x + width, y + height);
        }
        if (roundBottomLeft) {
            RenderUtil.drawCornerFan(x + radius, y + height - radius, radius, 90.0D, 180.0D);
        } else {
            RenderUtil.drawQuadNoState(x, y + height - radius, x + radius, y + height);
        }
        RenderUtil.disableRenderState();
    }

    public static void drawRoundedRect(float x, float y, float width, float height, float radius, int color, boolean roundTopLeft, boolean roundTopRight, boolean roundBottomLeft, boolean roundBottomRight) {
        RenderUtil.drawRoundedRect((double) x, (double) y, (double) width, (double) height, (double) radius, color, roundTopLeft, roundTopRight, roundBottomLeft, roundBottomRight);
    }

    public static void drawRoundedRectOutline(float x, float y, float width, float height, float radius, float lineWidth, int color, boolean topLeft, boolean topRight, boolean bottomLeft, boolean bottomRight) {
        radius = Math.min(radius, Math.min(width, height) / 2.0f);
        float a = (float) (color >> 24 & 255) / 255.0F;
        float r = (float) (color >> 16 & 255) / 255.0F;
        float g = (float) (color >> 8 & 255) / 255.0F;
        float b = (float) (color & 255) / 255.0F;
        RenderSystem.setShaderColor(r, g, b, a);
        RenderSystem.lineWidth(lineWidth);
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_29345, class_290.field_1592);
        float firstX = 0.0F;
        float firstY = 0.0F;
        boolean first = true;
        if (topLeft) {
            for (int i = 180; i <= 270; i += 3) {
                double rad = Math.toRadians(i);
                float px = (float) (x + radius + Math.cos(rad) * radius);
                float py = (float) (y + radius + Math.sin(rad) * radius);
                if (first) {
                    firstX = px;
                    firstY = py;
                    first = false;
                }
                bufferBuilder.method_22912(px, py, 0.0F);
            }
        } else {
            bufferBuilder.method_22912(x, y, 0.0F);
            if (first) {
                firstX = x;
                firstY = y;
                first = false;
            }
        }
        if (topRight) {
            for (int i = 270; i <= 360; i += 3) {
                double rad = Math.toRadians(i);
                float px = (float) (x + width - radius + Math.cos(rad) * radius);
                float py = (float) (y + radius + Math.sin(rad) * radius);
                if (first) {
                    firstX = px;
                    firstY = py;
                    first = false;
                }
                bufferBuilder.method_22912(px, py, 0.0F);
            }
        } else {
            bufferBuilder.method_22912(x + width, y, 0.0F);
            if (first) {
                firstX = x + width;
                firstY = y;
                first = false;
            }
        }
        if (bottomRight) {
            for (int i = 0; i <= 90; i += 3) {
                double rad = Math.toRadians(i);
                float px = (float) (x + width - radius + Math.cos(rad) * radius);
                float py = (float) (y + height - radius + Math.sin(rad) * radius);
                if (first) {
                    firstX = px;
                    firstY = py;
                    first = false;
                }
                bufferBuilder.method_22912(px, py, 0.0F);
            }
        } else {
            bufferBuilder.method_22912(x + width, y + height, 0.0F);
            if (first) {
                firstX = x + width;
                firstY = y + height;
                first = false;
            }
        }
        if (bottomLeft) {
            for (int i = 90; i <= 180; i += 3) {
                double rad = Math.toRadians(i);
                float px = (float) (x + radius + Math.cos(rad) * radius);
                float py = (float) (y + height - radius + Math.sin(rad) * radius);
                if (first) {
                    firstX = px;
                    firstY = py;
                    first = false;
                }
                bufferBuilder.method_22912(px, py, 0.0F);
            }
        } else {
            bufferBuilder.method_22912(x, y + height, 0.0F);
            if (first) {
                firstX = x;
                firstY = y + height;
                first = false;
            }
        }
        bufferBuilder.method_22912(firstX, firstY, 0.0F);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0f);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    private static void drawQuadNoState(double x1, double y1, double x2, double y2) {
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        bufferBuilder.method_22912((float) x1, (float) y1, 0.0F);
        bufferBuilder.method_22912((float) x2, (float) y1, 0.0F);
        bufferBuilder.method_22912((float) x2, (float) y2, 0.0F);
        bufferBuilder.method_22912((float) x1, (float) y2, 0.0F);
        class_286.method_43433(bufferBuilder.method_60800());
    }

    private static void drawCornerFan(double centerX, double centerY, double radius, double start, double end) {
        int segments = Math.max(12, (int) Math.ceil(radius * 3.0D));
        RenderSystem.setShader(class_10142.field_53875);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27381, class_290.field_1592);
        bufferBuilder.method_22912((float) centerX, (float) centerY, 0.0F);
        for (int i = 0; i <= segments; i++) {
            double angle = Math.toRadians(start + (end - start) * i / segments);
            bufferBuilder.method_22912((float) (centerX + Math.cos(angle) * radius), (float) (centerY + Math.sin(angle) * radius), 0.0F);
        }
        class_286.method_43433(bufferBuilder.method_60800());
    }

    public static int mergeAlpha(int color, int alpha) {
        if (alpha < 0) {
            alpha = 0;
        }
        if (alpha > 255) {
            alpha = 255;
        }
        return color & 0x00FFFFFF | alpha << 24;
    }

    public static int darkenColor(int color, int amount) {
        int r = Math.max(0, (color >> 16 & 255) - amount);
        int g = Math.max(0, (color >> 8 & 255) - amount);
        int b = Math.max(0, (color & 255) - amount);
        return color & 0xFF000000 | r << 16 | g << 8 | b;
    }

    public static int lerpColor(int color1, int color2, float fraction) {
        fraction = Math.min(Math.max(fraction, 0.0F), 1.0F);
        int a1 = color1 >> 24 & 255;
        int a2 = color2 >> 24 & 255;
        int r1 = color1 >> 16 & 255;
        int r2 = color2 >> 16 & 255;
        int g1 = color1 >> 8 & 255;
        int g2 = color2 >> 8 & 255;
        int b1 = color1 & 255;
        int b2 = color2 & 255;
        return (a1 + (int) ((float) (a2 - a1) * fraction)) << 24
                | (r1 + (int) ((float) (r2 - r1) * fraction)) << 16
                | (g1 + (int) ((float) (g2 - g1) * fraction)) << 8
                | b1 + (int) ((float) (b2 - b1) * fraction);
    }

    public static void drawRoundedRectangle(float x1, float y1, float x2, float y2, float radius, int color) {
        float width = Math.max(0.0F, x2 - x1);
        float height = Math.max(0.0F, y2 - y1);
        RenderUtil.drawRoundedRect(x1, y1, width, height, Math.max(0.0F, radius), color);
    }

    public static void drawGradientRect(float x1, float y1, float x2, float y2, int topLeft, int topRight, int bottomLeft, int bottomRight) {
        if (Math.abs(x2 - x1) < 0.5F || Math.abs(y2 - y1) < 0.5F) {
            return;
        }
        RenderUtil.enableRenderState();
        RenderSystem.setShader(class_10142.field_53876);
        class_287 gradient = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        gradient.method_22912(x1, y1, 0.0F).method_1336(topLeft >> 16 & 255, topLeft >> 8 & 255, topLeft & 255, topLeft >> 24 & 255);
        gradient.method_22912(x1, y2, 0.0F).method_1336(bottomLeft >> 16 & 255, bottomLeft >> 8 & 255, bottomLeft & 255, bottomLeft >> 24 & 255);
        gradient.method_22912(x2, y2, 0.0F).method_1336(bottomRight >> 16 & 255, bottomRight >> 8 & 255, bottomRight & 255, bottomRight >> 24 & 255);
        gradient.method_22912(x2, y1, 0.0F).method_1336(topRight >> 16 & 255, topRight >> 8 & 255, topRight & 255, topRight >> 24 & 255);
        class_286.method_43433(gradient.method_60800());
        RenderUtil.disableRenderState();
    }

    public static void drawRoundedGradientRect(float x1, float y1, float x2, float y2, float radius, int topLeft, int topRight, int bottomLeft, int bottomRight) {
        float width = x2 - x1;
        float height = y2 - y1;
        radius = Math.max(0.0F, Math.min(radius, Math.min(width, height) / 2.0F));
        if (radius <= 0.0F) {
            RenderUtil.drawGradientRect(x1, y1, x2, y2, topLeft, topRight, bottomLeft, bottomRight);
            return;
        }
        RenderUtil.enableRenderState();
        float horizontal = height > 0.0F ? radius / height : 0.0F;
        RenderUtil.drawGradientRect(x1 + radius, y1, x2 - radius, y2, RenderUtil.lerpColor(topLeft, bottomLeft, horizontal), RenderUtil.lerpColor(topRight, bottomRight, horizontal), RenderUtil.lerpColor(bottomLeft, topLeft, horizontal), RenderUtil.lerpColor(bottomRight, topRight, horizontal));
        int leftTop = RenderUtil.lerpColor(topLeft, bottomLeft, horizontal);
        int leftBottom = RenderUtil.lerpColor(bottomLeft, topLeft, horizontal);
        RenderUtil.drawGradientRect(x1, y1 + radius, x1 + radius, y2 - radius, topLeft, leftTop, leftBottom, bottomLeft);
        int rightTop = RenderUtil.lerpColor(topRight, bottomRight, horizontal);
        int rightBottom = RenderUtil.lerpColor(bottomRight, topRight, horizontal);
        RenderUtil.drawGradientRect(x2 - radius, y1 + radius, x2, y2 - radius, topRight, rightTop, rightBottom, bottomRight);
        float vertical = width > 0.0F ? radius / width : 0.0F;
        int topLeftCorner = RenderUtil.lerpColor(topLeft, topRight, vertical);
        int topRightCorner = RenderUtil.lerpColor(topRight, topLeft, vertical);
        RenderUtil.drawGradientRect(x1 + radius, y1, x2 - radius, y1 + radius, topLeft, topRight, topRightCorner, topLeftCorner);
        int bottomLeftCorner = RenderUtil.lerpColor(bottomLeft, bottomRight, vertical);
        int bottomRightCorner = RenderUtil.lerpColor(bottomRight, bottomLeft, vertical);
        RenderUtil.drawGradientRect(x1 + radius, y2 - radius, x2 - radius, y2, bottomLeft, bottomRight, bottomRightCorner, bottomLeftCorner);

        RenderSystem.setShader(class_10142.field_53876);
        RenderUtil.drawGradientCornerFan(x1 + radius, y1 + radius, radius, 180.0F, 270.0F, leftTop, topLeft);
        RenderUtil.drawGradientCornerFan(x2 - radius, y1 + radius, radius, 270.0F, 360.0F, topRight, rightTop);
        RenderUtil.drawGradientCornerFan(x2 - radius, y2 - radius, radius, 0.0F, 90.0F, bottomRight, rightBottom);
        RenderUtil.drawGradientCornerFan(x1 + radius, y2 - radius, radius, 90.0F, 180.0F, bottomLeft, leftBottom);
        RenderUtil.disableRenderState();
    }

    private static void drawGradientCornerFan(double centerX, double centerY, double radius, double start, double end, int startColor, int endColor) {
        int segments = Math.max(12, (int) Math.ceil(radius * 3.0D));
        class_287 fan = class_289.method_1348().method_60827(class_293.class_5596.field_27381, class_290.field_1576);
        for (int i = 0; i <= segments; i++) {
            double angle = Math.toRadians(start + (end - start) * i / segments);
            int color = RenderUtil.lerpColor(startColor, endColor, (float) i / (float) segments);
            fan.method_22912((float) (centerX + Math.cos(angle) * radius), (float) (centerY + Math.sin(angle) * radius), 0.0F)
                    .method_1336(color >> 16 & 255, color >> 8 & 255, color & 255, color >> 24 & 255);
        }
        class_286.method_43433(fan.method_60800());
    }

    public static void drawRoundedGradientOutlinedRectangle(float x1, float y1, float x2, float y2, float radius, int background, int gradient1, int gradient2) {
        RenderUtil.drawRoundedGradientRect(x1, y1, x2, y2, radius, gradient1, gradient1, gradient2, gradient2);
        RenderUtil.drawRoundedRectangle(x1 + 1.5F, y1 + 1.5F, x2 - 1.5F, y2 - 1.5F, Math.max(0.0F, radius - 1.5F), background);
    }

    public static void drawSkeetRect(float x, float y, float width, float height) {
        RenderUtil.drawRoundedRect(x, y, width, height, 3.0F, new Color(0, 0, 0, 90).getRGB());
        RenderUtil.drawRoundedRectOutline(x, y, width, height, 3.0F, 1.0F, new Color(200, 200, 200, 110).getRGB(), true, true, true, true);
        RenderUtil.drawLine(x + 3.0F, y + 0.5F, x + width - 3.0F, y + 0.5F, 1.0F, new Color(255, 255, 255, 140).getRGB());
    }

    public static void drawTexturedRect(net.minecraft.class_2960 texture, float x, float y, float width, float height, float u0, float v0, float u1, float v1, int rgba) {
        RenderSystem.enableBlend();
        RenderSystem.setShader(class_10142.field_53880);
        RenderSystem.setShaderTexture(0, texture);
        RenderUtil.setColor(rgba);
        class_287 direct = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        direct.method_22912(x, y + height, 0.0F).method_22913(u0, v1).method_1336(255, 255, 255, 255);
        direct.method_22912(x + width, y + height, 0.0F).method_22913(u1, v1).method_1336(255, 255, 255, 255);
        direct.method_22912(x + width, y, 0.0F).method_22913(u1, v0).method_1336(255, 255, 255, 255);
        direct.method_22912(x, y, 0.0F).method_22913(u0, v0).method_1336(255, 255, 255, 255);
        class_286.method_43433(direct.method_60800());
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    public static void drawGuiText(String text, float x, float y, int color, boolean shadow) {
        RenderSystem.disableScissor();
        RenderSystem.colorMask(true, true, true, true);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(true);
        class_9799 allocator = new class_9799(256);
        class_4597.class_4598 immediate = class_4597.method_22991(allocator);
        mc.field_1772.method_27521(text, x, y, color, shadow, RenderSystem.getModelViewMatrix(), immediate, net.minecraft.class_327.class_6415.field_33993, 0, 0xF000F0);
        immediate.method_22993();
    }
}
