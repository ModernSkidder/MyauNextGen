package laoqi123.util;

import laoqi123.util.raytrace.ClientRayTraceUtil;
import laoqi123.util.rotation.Rotation;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class RotationUtils {
    private static final class_310 mc = class_310.method_1551();

    public static float normalizeYawDiff(float yaw, float target) {
        return Math.abs(class_3532.method_15393(yaw - target));
    }

    public static float yawDiffDirectly(float yaw, float target) {
        return class_3532.method_15393(yaw - target);
    }

    public static float smooth(float diff, float smooth) {
        if (smooth == 0.0f) {
            return 0.0f;
        }
        return Math.signum(diff) * Math.min(Math.abs(diff), Math.abs(smooth));
    }

    public static Rotation getClosestToBlockFace(class_2338 pos, class_2350 face, float yaw, float pitch) {
        if (pos == null || face == null || mc.field_1724 == null) {
            return null;
        }
        class_243 eye = ClientRayTraceUtil.eyePos != null ? ClientRayTraceUtil.eyePos : mc.field_1724.method_33571();

        double[] axis1 = {0.25, 0.5, 0.75};
        double[] axis2 = {0.25, 0.5, 0.75};

        Rotation best = null;
        double bestDiff = Double.MAX_VALUE;
        for (double a : axis1) {
            for (double b : axis2) {
                double px;
                double py;
                double pz;
                switch (face) {
                    case field_11036 -> {
                        px = pos.method_10263() + a;
                        py = pos.method_10264() + 1.0;
                        pz = pos.method_10260() + b;
                    }
                    case field_11033 -> {
                        px = pos.method_10263() + a;
                        py = pos.method_10264();
                        pz = pos.method_10260() + b;
                    }
                    case field_11034 -> {
                        px = pos.method_10263() + 1.0;
                        py = pos.method_10264() + a;
                        pz = pos.method_10260() + b;
                    }
                    case field_11039 -> {
                        px = pos.method_10263();
                        py = pos.method_10264() + a;
                        pz = pos.method_10260() + b;
                    }
                    case field_11035 -> {
                        px = pos.method_10263() + a;
                        py = pos.method_10264() + b;
                        pz = pos.method_10260() + 1.0;
                    }
                    default -> {
                        px = pos.method_10263() + a;
                        py = pos.method_10264() + b;
                        pz = pos.method_10260();
                    }
                }
                Rotation rot = new Rotation(
                        class_3532.method_15393((float) Math.toDegrees(Math.atan2(pz - eye.field_1350, px - eye.field_1352)) - 90.0f),
                        class_3532.method_15393((float) -Math.toDegrees(Math.atan2(py - eye.field_1351, Math.hypot(px - eye.field_1352, pz - eye.field_1350))))
                );
                if (!ClientRayTraceUtil.didHitBlockFace(rot, pos, face, true)) {
                    continue;
                }
                float yawDiff = Math.abs(class_3532.method_15393(rot.getYaw() - yaw));
                float pitchDiff = Math.abs(rot.getPitch() - pitch);
                double diff = yawDiff + pitchDiff;
                if (diff < bestDiff) {
                    bestDiff = diff;
                    best = rot;
                }
            }
        }
        return best;
    }
}