package laoqi123.util;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_3532;
public class PlayerUtil {
    private static final class_310 mc = class_310.method_1551();

    public static boolean isJumping() {
        return mc.field_1755 == null && KeyBindUtil.isKeyDown(mc.field_1690.field_1903);
    }

    public static boolean isSneaking() {
        return mc.field_1755 == null && KeyBindUtil.isKeyDown(mc.field_1690.field_1832);
    }

    public static boolean isMovingLeft() {
        return mc.field_1755 == null && KeyBindUtil.isKeyDown(mc.field_1690.field_1913);
    }

    public static boolean isMovingRight() {
        return mc.field_1755 == null && KeyBindUtil.isKeyDown(mc.field_1690.field_1849);
    }

    public static boolean isAttacking() {
        return mc.field_1755 == null && KeyBindUtil.isKeyDown(mc.field_1690.field_1886);
    }

    public static boolean isUsingItem() {
        return mc.field_1755 == null && KeyBindUtil.isKeyDown(mc.field_1690.field_1904);
    }

    public static boolean canFly(float fallThreshold) {
        if (!mc.field_1724.method_31549().field_7478 && !mc.field_1724.method_31549().field_7480) {
            class_1293 jumpEffect = mc.field_1724.method_6112(class_1294.field_5913);
            float jumpBoost = jumpEffect != null ? (float) (jumpEffect.method_5578() + 1) : 0.0F;
            float fallDistance = mc.field_1724.field_6017;
            if (mc.field_1724.method_18798().field_1351 < -0.67 || !isAirBelow()) {
                fallDistance -= (float) mc.field_1724.method_18798().field_1351;
            }
            return class_3532.method_15386(fallDistance - fallThreshold - jumpBoost) > 0;
        } else {
            return false;
        }
    }

    public static boolean canFly(int checkHeight) {
        if (!mc.field_1724.method_31549().field_7478 && !mc.field_1724.method_31549().field_7480) {
            int playerY = class_3532.method_15357(mc.field_1724.method_23318());
            for (int offset = 0; offset <= checkHeight; ++offset) {
                int currentY = playerY - offset;
                if (currentY < 0) {
                    break;
                }
                class_2248 block = mc.field_1687.method_8320(new class_2338(class_3532.method_15357(mc.field_1724.method_23317()), currentY, class_3532.method_15357(mc.field_1724.method_23321()))).method_26204();
                if (block != class_2246.field_10124) {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }

    public static boolean isInWater() {
        return checkInWater(mc.field_1724.method_5829().method_1009(-1.0E-6, 0.0, -1.0E-6));
    }

    public static boolean checkInWater(class_238 boundingBox) {
        if (!mc.field_1724.method_5799() && !mc.field_1724.method_5771()) {
            int minY = class_3532.method_15357(boundingBox.field_1322);
            if (minY < 0) {
                return true;
            } else {
                int minX = class_3532.method_15357(boundingBox.field_1323);
                int maxX = class_3532.method_15357(boundingBox.field_1320 + 1.0);
                int minZ = class_3532.method_15357(boundingBox.field_1321);
                int maxZ = class_3532.method_15357(boundingBox.field_1324 + 1.0);
                for (int x = minX; x < maxX; ++x) {
                    for (int z = minZ; z < maxZ; ++z) {
                        for (int y = minY; y >= 0; --y) {
                            if (!BlockUtil.isReplaceable(new class_2338(x, y, z))) {
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
        } else {
            return false;
        }
    }

    public static boolean canMove(double x, double z) {
        return PlayerUtil.canMove(x, z, -1.0);
    }

    public static boolean canMove(double x, double z, double y) {
        class_238 boundingBox = PlayerUtil.mc.field_1724.method_5829().method_989(x, y, z);
        return PlayerUtil.mc.field_1687.method_18026(boundingBox);
    }

    public static boolean isAirBelow() {
        class_238 axisAlignedBB = PlayerUtil.mc.field_1724.method_5829().method_989(0.0, -1.0, 0.0);
        return !PlayerUtil.mc.field_1687.method_18026(axisAlignedBB);
    }

    public static boolean isAirAbove() {
        class_238 axisAlignedBB = PlayerUtil.mc.field_1724.method_5829().method_989(0.0, 1.0, 0.0);
        return !PlayerUtil.mc.field_1687.method_18026(axisAlignedBB);
    }

    public static boolean canReach(class_2338 blockPos, double reach) {
        return PlayerUtil.isBlockWithinReach(blockPos, PlayerUtil.mc.field_1724.method_23317(), PlayerUtil.mc.field_1724.method_23318() + (double) PlayerUtil.mc.field_1724.method_18381(PlayerUtil.mc.field_1724.method_18376()), PlayerUtil.mc.field_1724.method_23321(), reach);
    }

    public static boolean isBlockWithinReach(class_2338 blockPos, double x, double y, double z, double reach) {
        return blockPos.method_40081(x, y, z) < Math.pow(reach, 2.0);
    }

    public static void attackEntity(class_1297 target) {
        if (mc.field_1761 != null) {
            mc.field_1761.method_2918(mc.field_1724, target);
            mc.field_1724.method_6104(net.minecraft.class_1268.field_5808);
        }
    }
}
