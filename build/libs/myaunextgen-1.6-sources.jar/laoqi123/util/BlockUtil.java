package laoqi123.util;

import net.minecraft.block.*;
import net.minecraft.class_1937;
import net.minecraft.class_2199;
import net.minecraft.class_2231;
import net.minecraft.class_2237;
import net.minecraft.class_2241;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2266;
import net.minecraft.class_2269;
import net.minecraft.class_2304;
import net.minecraft.class_2312;
import net.minecraft.class_2323;
import net.minecraft.class_2333;
import net.minecraft.class_2334;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2354;
import net.minecraft.class_2387;
import net.minecraft.class_2389;
import net.minecraft.class_239;
import net.minecraft.class_2399;
import net.minecraft.class_2401;
import net.minecraft.class_243;
import net.minecraft.class_2445;
import net.minecraft.class_2457;
import net.minecraft.class_2482;
import net.minecraft.class_2488;
import net.minecraft.class_2490;
import net.minecraft.class_2510;
import net.minecraft.class_2527;
import net.minecraft.class_2530;
import net.minecraft.class_2533;
import net.minecraft.class_2537;
import net.minecraft.class_2538;
import net.minecraft.class_2541;
import net.minecraft.class_2544;
import net.minecraft.class_2560;
import net.minecraft.class_2577;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4076;
import net.minecraft.class_631;
import java.util.ArrayList;
import java.util.List;

public class BlockUtil {
    private static final class_310 mc = class_310.method_1551();

    public static List<class_2586> getBlockEntities() {
        ArrayList<class_2586> list = new ArrayList<>();
        class_1937 world = BlockUtil.mc.field_1687;
        if (world == null) return list;
        class_631 chunkManager = (class_631) world.method_8398();
        for (long packedSection : chunkManager.method_62890()) {
            class_4076 sectionPos = class_4076.method_18677(packedSection);
            class_2818 chunk = chunkManager.method_12126(sectionPos.method_18674(), sectionPos.method_18687(), false);
            if (chunk != null) {
                list.addAll(chunk.method_12214().values());
            }
        }
        return list;
    }

    public static boolean isReplaceable(class_2338 blockPos) {
        return BlockUtil.isReplaceable(BlockUtil.mc.field_1687.method_8320(blockPos));
    }

    public static boolean isReplaceable(class_2680 blockState) {
        if (!blockState.method_45474()) return false;
        if (!(blockState.method_26204() instanceof class_2488)) return true;
        class_265 shape = blockState.method_26218(BlockUtil.mc.field_1687, class_2338.field_10980);
        return shape.method_1110() || shape.method_1105(class_2350.class_2351.field_11052) <= 0.125;
    }

    public static boolean isInteractable(class_2338 blockPos) {
        return BlockUtil.isInteractable(BlockUtil.mc.field_1687.method_8320(blockPos).method_26204());
    }

    public static boolean isInteractable(class_2248 block) {
        if (block instanceof class_2237) return true;
        if (block instanceof class_2304) return true;
        if (block instanceof class_2199) return true;
        if (block instanceof class_2244) return true;
        if (block instanceof class_2323) return true;
        if (block instanceof class_2533) return true;
        if (block instanceof class_2349) return true;
        if (block instanceof class_2354) return true;
        if (block instanceof class_2269) return true;
        if (block instanceof class_2401) return true;
        return block instanceof class_2387;
    }

    public static boolean isSolid(class_2248 block) {
        if (block instanceof class_2510) return false;
        if (block instanceof class_2482) return false;
        if (block instanceof class_2333) return false;
        if (block instanceof class_2334) return false;
        if (block instanceof class_2541) return false;
        if (block instanceof class_2445) return false;
        if (block instanceof class_2266) return false;
        if (block instanceof class_2261) return false;
        if (block instanceof class_2346) return false;
        if (block instanceof class_2560) return false;
        if (block instanceof class_2389) return false;
        if (block instanceof class_2577) return false;
        if (block instanceof class_2488) return false;
        if (block instanceof class_2354) return false;
        if (block instanceof class_2349) return false;
        if (block instanceof class_2544) return false;
        if (block instanceof class_2399) return false;
        if (block instanceof class_2527) return false;
        if (block instanceof class_2457) return false;
        if (block instanceof class_2312) return false;
        if (block instanceof class_2231) return false;
        if (block instanceof class_2538) return false;
        if (block instanceof class_2537) return false;
        if (block instanceof class_2241) return false;
        if (block instanceof class_2490) return false;
        return !(block instanceof class_2530);
    }

    public static class_243 getHitVec(class_2338 blockPos, class_2350 enumFacing, float yaw, float pitch) {
        class_239 movingObjectPosition = RotationUtil.rayTrace(yaw, pitch, 4.5, 1.0f);
        if (movingObjectPosition != null) {
            if (movingObjectPosition.method_17783() == class_239.class_240.field_1332) {
                class_3965 blockHit = (class_3965) movingObjectPosition;
                if (blockHit.method_17777().equals(blockPos)) {
                    if (blockHit.method_17780() == enumFacing) {
                        return blockHit.method_17784();
                    }
                }
            }
        }
        return BlockUtil.getClickVec(blockPos, enumFacing);
    }

    public static class_243 getClickVec(class_2338 blockPos, class_2350 enumFacing) {
        class_2680 blockState = BlockUtil.mc.field_1687.method_8320(blockPos);
        class_265 shape = blockState.method_26218(BlockUtil.mc.field_1687, blockPos);
        double minX = shape.method_1110() ? 0.0 : shape.method_1091(class_2350.class_2351.field_11048);
        double maxX = shape.method_1110() ? 1.0 : shape.method_1105(class_2350.class_2351.field_11048);
        double minY = shape.method_1110() ? 0.0 : shape.method_1091(class_2350.class_2351.field_11052);
        double maxY = shape.method_1110() ? 1.0 : shape.method_1105(class_2350.class_2351.field_11052);
        double minZ = shape.method_1110() ? 0.0 : shape.method_1091(class_2350.class_2351.field_11051);
        double maxZ = shape.method_1110() ? 1.0 : shape.method_1105(class_2350.class_2351.field_11051);
        class_243 vec3d = new class_243(blockPos.method_10263() + Math.min(Math.max(RandomUtil.nextDouble(0.0, 1.0), minX), maxX), blockPos.method_10264() + Math.min(Math.max(RandomUtil.nextDouble(0.0, 1.0), minY), maxY), blockPos.method_10260() + Math.min(Math.max(RandomUtil.nextDouble(0.0, 1.0), minZ), maxZ));
        switch (enumFacing) {
            default: {
                return new class_243(vec3d.field_1352, blockPos.method_10264() + minY, vec3d.field_1350);
            }
            case field_11036: {
                return new class_243(vec3d.field_1352, blockPos.method_10264() + maxY, vec3d.field_1350);
            }
            case field_11043: {
                return new class_243(vec3d.field_1352, vec3d.field_1351, blockPos.method_10260() + minZ);
            }
            case field_11034: {
                return new class_243(blockPos.method_10263() + maxX, vec3d.field_1351, vec3d.field_1350);
            }
            case field_11035: {
                return new class_243(vec3d.field_1352, vec3d.field_1351, blockPos.method_10260() + maxZ);
            }
            case field_11039:
        }
        return new class_243(blockPos.method_10263() + minX, vec3d.field_1351, vec3d.field_1350);
    }
}
