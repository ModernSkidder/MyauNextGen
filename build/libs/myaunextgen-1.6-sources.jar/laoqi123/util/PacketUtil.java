package laoqi123.util;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2620;
import net.minecraft.class_2623;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2672;
import net.minecraft.class_2673;
import net.minecraft.class_310;

public class PacketUtil {
    private static final class_310 mc = class_310.method_1551();
    private static final Queue<class_2596<class_2602>> pendingReplay = new ConcurrentLinkedQueue<>();

    public static void sendPacket(class_2596<?> packet) {
        if (mc.method_1562() != null) {
            mc.method_1562().method_52787(packet);
        }
    }

    public static boolean isWorldRenderPacket(class_2596<?> packet) {
        return packet instanceof class_2672
                || packet instanceof class_2637
                || packet instanceof class_2626
                || packet instanceof class_2623
                || packet instanceof class_2620
                || packet instanceof class_2673;
    }

    public static void sendPacketNoEvent(class_2596<?> packet) {
        PacketUtil.sendPacket(packet);
    }

    public static void receivePacket(class_2596<?> packet) {
        if (packet == null) return;
        pendingReplay.offer((class_2596<class_2602>) packet);
    }

    public static void drainPendingPackets() {
        if (pendingReplay.isEmpty()) return;
        class_2596<class_2602> packet;
        while ((packet = pendingReplay.poll()) != null) {
            try {
                if (mc.method_1562() != null) {
                    packet.method_65081(mc.method_1562());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
