package laoqi123.util;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class RotationUtil {
    private static final class_310 mc = class_310.method_1551();
    private static final float BORDER_SIZE = 0.3F;

    public static float wrapAngleDiff(float angle, float target) {
        return target + class_3532.method_15393(angle - target);
    }

    public static float clampAngle(float angle, float maxAngle) {
        maxAngle = Math.max(0.0f, Math.min(180.0f, maxAngle));
        if (angle > maxAngle) {
            angle = maxAngle;
        } else if (angle < -maxAngle) {
            angle = -maxAngle;
        }
        return angle;
    }

    public static boolean hasVisiblePoint(class_238 boundingBox) {
        class_243 eyePos = RotationUtil.mc.field_1724.method_33571();
        double centerX = (boundingBox.field_1323 + boundingBox.field_1320) / 2.0;
        double centerZ = (boundingBox.field_1321 + boundingBox.field_1324) / 2.0;
        double height = boundingBox.field_1325 - boundingBox.field_1322;
        double[] yRatios = new double[]{0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9};

        for (double ratio : yRatios) {
            double targetY = boundingBox.field_1322 + ratio * height;
            class_243 targetPoint = new class_243(centerX, targetY, centerZ);
            if (rayTraceBlocks(eyePos, targetPoint) == null) {
                return true;
            }
        }
        return false;
    }

    public static float smoothAngle(float angle, float smoothFactor) {
        return angle * (0.5f + 0.5f * (1.0f - Math.max(0.0f, Math.min(1.0f, smoothFactor + RandomUtil.nextFloat(-0.1f, 0.1f)))));
    }

    public static float quantizeAngle(float angle) {
        return (float) ((double) angle - (double) angle % (double) 0.0096f);
    }

    public static float[] getRotationsToBox(class_238 boundingBox, float yaw, float pitch, float maxAngle, float smoothFactor) {
        class_243 eyePos = RotationUtil.mc.field_1724.method_33571();
        double minTargetY = boundingBox.field_1322 + 0.05 * (boundingBox.field_1325 - boundingBox.field_1322);
        double maxTargetY = boundingBox.field_1322 + 0.75 * (boundingBox.field_1325 - boundingBox.field_1322);
        double deltaX = (boundingBox.field_1323 + boundingBox.field_1320) / 2.0 - eyePos.field_1352;
        double deltaY = eyePos.field_1351 >= maxTargetY ? maxTargetY - eyePos.field_1351 : (eyePos.field_1351 <= minTargetY ? minTargetY - eyePos.field_1351 : 0.0);
        double deltaZ = (boundingBox.field_1321 + boundingBox.field_1324) / 2.0 - eyePos.field_1350;
        return RotationUtil.getRotations(deltaX, deltaY, deltaZ, yaw, pitch, maxAngle, smoothFactor);
    }

    public static float[] getRotationsTo(double targetX, double targetY, double targetZ, float currentYaw, float currentPitch) {
        return RotationUtil.getRotations(targetX, targetY, targetZ, currentYaw, currentPitch, 180.0f, 0.0f);
    }

    public static float[] getRotations(double targetX, double targetY, double targetZ, float currentYaw, float currentPitch, float maxAngle, float smoothFactor) {
        double horizontalDistance = Math.sqrt(targetX * targetX + targetZ * targetZ);
        float yawDelta = class_3532.method_15393((float) (Math.atan2(targetZ, targetX) * 180.0 / Math.PI) - 90.0f - currentYaw);
        float pitchDelta = class_3532.method_15393((float) (-Math.atan2(targetY, horizontalDistance) * 180.0 / Math.PI) - currentPitch);
        yawDelta = Math.abs(yawDelta) <= 1.0f ? 0.0f : RotationUtil.smoothAngle(RotationUtil.clampAngle(yawDelta, maxAngle), smoothFactor);
        pitchDelta = Math.abs(pitchDelta) <= 1.0f ? 0.0f : RotationUtil.smoothAngle(RotationUtil.clampAngle(pitchDelta, maxAngle), smoothFactor);
        return new float[]{RotationUtil.quantizeAngle(currentYaw + yawDelta), RotationUtil.quantizeAngle(currentPitch + pitchDelta)};
    }

    public static class_243 clampVecToBox(class_243 vector, class_238 boundingBox) {
        double[] coords = new double[]{vector.field_1352, vector.field_1351, vector.field_1350};
        double[] minCoords = new double[]{boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1321};
        double[] maxCoords = new double[]{boundingBox.field_1320, boundingBox.field_1325, boundingBox.field_1324};
        for (int i = 0; i < 3; ++i) {
            if (coords[i] > maxCoords[i]) {
                coords[i] = maxCoords[i];
                continue;
            }
            if (!(coords[i] < minCoords[i])) continue;
            coords[i] = minCoords[i];
        }
        return new class_243(coords[0], coords[1], coords[2]);
    }

    public static double distanceToEntity(class_1297 entity) {
        class_238 boundingBox = entity.method_5829().method_1009(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE);
        return RotationUtil.distanceToBox(boundingBox);
    }

    public static double distanceToBox(class_1297 entity, class_243 point) {
        return RotationUtil.clampVecToBox(entity.method_5829().method_1009(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE), point);
    }

    public static double distanceToBox(class_238 boundingBox) {
        return RotationUtil.clampVecToBox(boundingBox, RotationUtil.mc.field_1724.method_33571());
    }

    public static double clampVecToBox(class_238 boundingBox, class_243 point) {
        if (boundingBox.method_1006(point)) {
            return 0.0;
        }
        class_243 clampedPoint = RotationUtil.clampVecToBox(point, boundingBox);
        double deltaX = clampedPoint.field_1352 - point.field_1352;
        double deltaY = clampedPoint.field_1351 - point.field_1351;
        double deltaZ = clampedPoint.field_1350 - point.field_1350;
        return Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
    }

    public static float angleToEntity(class_1297 entity) {
        class_243 eyePos = RotationUtil.mc.field_1724.method_33571();
        class_238 boundingBox = entity.method_5829().method_1009(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE);
        if (boundingBox.method_1006(eyePos)) {
            return 0.0f;
        }
        double deltaX = entity.method_23317() - eyePos.field_1352;
        double deltaZ = entity.method_23321() - eyePos.field_1350;
        return Math.abs(class_3532.method_15393((float) (Math.atan2(deltaZ, deltaX) * 180.0 / Math.PI) - 90.0f - RotationUtil.mc.field_1724.method_36454())) * 2.0f;
    }

    public static float getYawBetween(double x1, double z1, double x2, double z2) {
        return class_3532.method_15393((float) (Math.atan2(z2 - z1, x2 - x1) * 180.0 / Math.PI) - 90.0f - RotationUtil.mc.field_1724.method_36454());
    }

    public static class_239 rayTrace(float yaw, float pitch, double distance, float partialTicks) {
        class_243 eyePos = RotationUtil.mc.field_1724.method_33571();
        class_243 lookVec = getVectorForRotation(pitch, yaw);
        class_243 targetPos = eyePos.method_1031(lookVec.field_1352 * distance, lookVec.field_1351 * distance, lookVec.field_1350 * distance);
        return RotationUtil.mc.field_1687.method_17742(new class_3959(eyePos, targetPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, RotationUtil.mc.field_1724));
    }

    public static class_239 rayTrace(class_1297 entity) {
        class_243 eyePos = RotationUtil.mc.field_1724.method_33571();
        class_243 targetPos = RotationUtil.clampVecToBox(eyePos, entity.method_5829().method_1009(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE));
        return RotationUtil.mc.field_1687.method_17742(new class_3959(eyePos, targetPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, RotationUtil.mc.field_1724));
    }

    public static class_239 rayTrace(class_238 boundingBox, float yaw, float pitch, double distance) {
        class_243 eyePos = RotationUtil.mc.field_1724.method_33571();
        class_243 lookVec = getVectorForRotation(pitch, yaw);
        class_243 targetPos = eyePos.method_1031(lookVec.field_1352 * distance, lookVec.field_1351 * distance, lookVec.field_1350 * distance);
        return boundingBox.method_992(eyePos, targetPos).map(Vec3d -> new class_3965(Vec3d, net.minecraft.class_2350.method_10142(lookVec.field_1352, lookVec.field_1351, lookVec.field_1350).method_10153(), net.minecraft.class_2338.method_49637(boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1321), false)).orElse(null);
    }

    public static class_243 getVectorForRotation(float pitch, float yaw) {
        float f = class_3532.method_15362(-yaw * 0.017453292F - 3.1415927F);
        float f1 = class_3532.method_15374(-yaw * 0.017453292F - 3.1415927F);
        float f2 = -class_3532.method_15362(-pitch * 0.017453292F);
        float f3 = class_3532.method_15374(-pitch * 0.017453292F);
        return new class_243(f1 * f2, f3, f * f2);
    }

    private static class_239 rayTraceBlocks(class_243 start, class_243 end) {
        return RotationUtil.mc.field_1687.method_17742(new class_3959(start, end, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, RotationUtil.mc.field_1724));
    }

    public static final class RotationVec {
        public float x;
        public float y;

        public RotationVec(RotationVec vec) {
            this(vec.x, vec.y);
        }

        public RotationVec(float x, float y) {
            this.x = x;
            this.y = y;
        }

        public RotationVec add(float x, float y) {
            return new RotationVec(this.x + x, this.y + y);
        }

        public float getX() {
            return this.x;
        }

        public float getY() {
            return this.y;
        }

        public void setX(float x) {
            this.x = x;
        }

        public void setY(float y) {
            this.y = y;
        }
    }
}
