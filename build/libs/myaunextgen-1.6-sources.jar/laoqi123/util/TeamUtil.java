package laoqi123.util;

import laoqi123.Myau;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_268;
import net.minecraft.class_310;
import net.minecraft.class_640;
import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TeamUtil {
    private static final class_310 mc = class_310.method_1551();

    public static boolean isEntityLoaded(class_1297 entity) {
        if (entity == null) return false;
        for (class_1297 loaded : TeamUtil.mc.field_1687.method_18112()) {
            if (loaded == entity) return true;
        }
        return false;
    }

    public static List<class_1297> getLoadedEntitiesSorted() {
        List<class_1297> entities = new ArrayList<>();
        for (class_1297 entity : TeamUtil.mc.field_1687.method_18112()) {
            entities.add(entity);
        }
        net.minecraft.class_4184 camera = mc.field_1773.method_19418();
        entities.sort((entity1, entity2) -> {
            double dist1 = camera.method_19326().method_1025(entity1.method_19538());
            double dist2 = camera.method_19326().method_1025(entity2.method_19538());
            if (dist1 < dist2) {
                return 1;
            }
            if (dist1 > dist2) {
                return -1;
            }
            return entity1.method_5667().toString().compareTo(entity2.method_5667().toString());
        });
        return entities;
    }

    public static float getHealthScore(class_1309 livingEntity) {
        float armorValue = (float) livingEntity.method_45325(net.minecraft.class_5134.field_23724);
        return livingEntity.method_6032() * (20.0f / Math.max(armorValue, 1.0f));
    }

    public static String stripName(class_1297 entity) {
        return entity.method_5476().getString().replaceAll("§\\S$", "").replaceAll("(?i)§r", "§f").trim();
    }

    public static Color getTeamColor(class_1657 player, float alpha) {
        int colorCode = 0xFFFFFF;
        class_268 playerTeam = player.method_5781();
        if (playerTeam != null) {
            class_124 formatting = playerTeam.method_1202();
            if (formatting != null && formatting.method_532() != null) {
                colorCode = formatting.method_532();
            }
        }
        return new Color(colorCode & 0xFFFFFF | (int) (alpha * 255) << 24, true);
    }

    public static boolean isBot(class_1657 player) {
        if (player == TeamUtil.mc.field_1724) {
            return false;
        }
        class_640 playerInfo = mc.method_1562().method_2874(player.method_5477().getString());
        if (playerInfo == null) {
            return true;
        }
        if (!ServerUtil.isHypixel()) return false;
        if (player.method_5477().getString().startsWith("§k")) {
            return player.method_5767();
        }
        if (playerInfo.method_2959() < 1) {
            return true;
        }
        class_268 playerTeam = player.method_5781();
        if (playerTeam == null) return false;
        if (!playerTeam.method_1197().isEmpty()) return false;
        return playerTeam.method_1202() == class_124.field_1061;
    }

    public static boolean isSameTeam(class_1657 player) {
        if (player == TeamUtil.mc.field_1724) {
            return true;
        }
        class_640 selfInfo = mc.method_1562().method_2871(TeamUtil.mc.field_1724.method_5667());
        if (selfInfo == null) {
            return false;
        }
        class_268 selfTeam = mc.field_1724.method_5781();
        if (selfTeam == null) {
            return false;
        }
        class_640 targetInfo = mc.method_1562().method_2871(player.method_5667());
        if (targetInfo == null) {
            return false;
        }
        class_268 targetTeam = player.method_5781();
        if (targetTeam == null) {
            return false;
        }
        return selfTeam.method_1202() == targetTeam.method_1202();
    }

    public static boolean hasTeamColor(class_1309 entity) {
        if (entity == TeamUtil.mc.field_1724) {
            return true;
        }
        class_268 selfTeam = mc.field_1724.method_5781();
        if (selfTeam == null) {
            return false;
        }
        if (selfTeam.method_1202() == null) {
            return false;
        }
        class_1309 nearestArmorStand = findNearestArmorStand(entity.method_5829());
        if (nearestArmorStand != null) {
            String prefix = selfTeam.method_1202().toString();
            return nearestArmorStand.method_5477().getString().contains(prefix);
        }
        return false;
    }

    public static boolean isShop(class_1309 entity) {
        if (entity == TeamUtil.mc.field_1724) {
            return false;
        }
        class_1309 armorStand = findNearestArmorStand(entity.method_5829());
        if (armorStand == null) return false;
        String displayName = armorStand.method_5476().getString();
        if (displayName.contains("RIGHT CLICK")) return true;
        if (displayName.contains("ITEM SHOP")) return true;
        if (displayName.contains("UPGRADES")) return true;
        if (displayName.contains("BANKER")) return true;
        return displayName.contains("STREAK POWERS");
    }

    private static class_1309 findNearestArmorStand(class_238 box) {
        List<class_1531> armorStands = TeamUtil.mc.field_1687.method_18467(class_1531.class, box.method_1014(3.0));
        if (armorStands.isEmpty()) return null;
        return armorStands.stream()
                .min(Comparator.comparingDouble(stand -> stand.method_19538().method_1025(TeamUtil.mc.field_1724.method_19538())))
                .orElse(null);
    }

    public static boolean isTeammate(class_1297 entity) {
        if (!(entity instanceof class_1657)) return false;
        return isSameTeam((class_1657) entity);
    }

    public static boolean isFriend(class_1657 player) {
        return Myau.friendManager.isFriend(player.method_5477().getString());
    }

    public static boolean isTarget(class_1657 player) {
        return Myau.targetManager.isFriend(player.method_5477().getString());
    }
}
