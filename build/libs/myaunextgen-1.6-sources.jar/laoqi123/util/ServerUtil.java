package laoqi123.util;

import java.util.ArrayList;
import java.util.stream.Collectors;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_8646;

public class ServerUtil {
    private static final class_310 mc = class_310.method_1551();

    public static ArrayList<String> getScoreboardLines() {
        if (ServerUtil.mc.field_1687 == null) {
            return new ArrayList<>();
        }
        class_269 scoreboard = ServerUtil.mc.field_1687.method_8428();
        if (scoreboard == null) {
            return new ArrayList<>();
        }
        class_266 scoreObjective = scoreboard.method_1189(class_8646.field_45157);
        if (scoreObjective == null) {
            return new ArrayList<>();
        }
        return scoreboard.method_1184(scoreObjective).stream()
                .map(entry -> class_268.method_1142(scoreboard.method_1153(entry.comp_2127()), class_2561.method_43470(entry.comp_2127())).getString())
                .collect(Collectors.toCollection(ArrayList::new));
    }

    public static boolean isHypixel() {
        ArrayList<String> arrayList = ServerUtil.getScoreboardLines();
        if (arrayList.isEmpty()) return false;
        if (arrayList.get(0).equals("§ewww.hypixel.ne🎂§et")) return true;
        return arrayList.get(0).equals("§ewww.hypixel.ne§g§et");
    }

    public static boolean hasPlayerCountInfo() {
        for (String s : ServerUtil.getScoreboardLines()) {
            if (!s.matches(".*Players: §a\\d+/\\d+.*")) continue;
            return true;
        }
        return false;
    }
}
