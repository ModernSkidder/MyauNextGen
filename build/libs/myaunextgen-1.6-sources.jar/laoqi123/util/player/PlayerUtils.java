package laoqi123.util.player;

import laoqi123.event.EventTarget;
import laoqi123.event.types.EventType;
import net.minecraft.class_1294;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import laoqi123.event.impl.UpdateEvent;

public class PlayerUtils {
    private static final class_310 mc = class_310.method_1551();

    public static int onGroundTicks = 0;
    public static int offGroundTicks = 0;
    public static double lastPitchDiff = 0.0d;
    public static double lastPlacePitchDiff = 0.0d;
    public static float lastAppliedPitch = 0.0f;

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (event.getType() != EventType.PRE || mc.field_1724 == null) {
            return;
        }
        if (mc.field_1724.method_24828()) {
            onGroundTicks++;
            offGroundTicks = 0;
        } else {
            offGroundTicks++;
            onGroundTicks = 0;
        }
    }

    public static boolean isMoving() {
        return mc.field_1724 != null
                && (mc.field_1724.field_3913.field_3905 != 0.0f || mc.field_1724.field_3913.field_3907 != 0.0f);
    }

    public static class_2338 blockRelativeToPlayer(int x, int y, int z) {
        if (mc.field_1724 == null) {
            return class_2338.field_10980;
        }
        return class_2338.method_49637(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()).method_10069(x, y, z);
    }

    public static int getMoveSpeedEffectAmplifier() {
        if (mc.field_1724 == null) {
            return 0;
        }
        if (mc.field_1724.method_6059(class_1294.field_5904)) {
            return mc.field_1724.method_6112(class_1294.field_5904).method_5578();
        }
        return 0;
    }
}