package laoqi123.util.player;

import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class FallingPlayer {
    private final class_310 mc = class_310.method_1551();

    private double x;
    private double y;
    private double z;
    private class_243 motion;
    private class_243 eyePos;
    private float yaw;
    private float strafe;
    private float forward;
    private float jumpMovementFactor;
    private float movementSpeed;
    private boolean onGround;

    public FallingPlayer(class_1657 player) {
        this.x = player.method_23317();
        this.y = player.method_23318();
        this.z = player.method_23321();
        this.motion = player.method_18798();
        this.yaw = mc.field_1724.method_36454();
        this.strafe = mc.field_1724.field_3913.field_3907;
        this.forward = mc.field_1724.field_3913.field_3905;
        this.movementSpeed = player.method_6029();
        this.onGround = player.method_24828();
        this.jumpMovementFactor = player.method_5624() ? 0.026f : 0.02f;
        this.eyePos = mc.field_1724.method_33571();
    }

    private void calculateForTick() {
        float dragX = 0.91f;
        float dragZ = dragX;
        float dragY = 0.98f;
        float acceleration = this.jumpMovementFactor;

        updateVelocity(acceleration, new class_243(this.strafe, 0, this.forward));
        this.x += motion.field_1352;
        this.y += motion.field_1351;
        this.z += motion.field_1350;
        updateGroundState();
        double gravity = 0.08D;
        this.motion = this.motion.method_1031(0, -gravity, 0);
        this.eyePos = new class_243(this.x, this.y + mc.field_1724.method_5751(), this.z);
        this.motion = new class_243(
                this.motion.field_1352 * dragX,
                this.motion.field_1351 * dragY,
                this.motion.field_1350 * dragZ
        );
    }

    private void updateGroundState() {
        class_243 center = new class_243(x, y, z);
        class_243 down = center.method_1031(0, -0.2, 0);

        class_3965 result = rayTraceHit(center, down);
        if (result != null && result.method_17783() == class_239.class_240.field_1332 && result.method_17780() == class_2350.field_11036) {
            this.onGround = true;
        } else {
            this.onGround = false;
        }
    }

    private void updateVelocity(float speed, class_243 input) {
        double lengthSquared = input.method_1027();
        if (lengthSquared < 1.0E-7D) {
            return;
        }

        class_243 normalizedInput = (lengthSquared > 1.0D ? input.method_1029() : input).method_1021(speed);

        float f = class_3532.method_15374(this.yaw * ((float) Math.PI / 180F));
        float g = class_3532.method_15362(this.yaw * ((float) Math.PI / 180F));
        double inputX = normalizedInput.field_1352 * (double) g - normalizedInput.field_1350 * (double) f;
        double inputZ = normalizedInput.field_1350 * (double) g + normalizedInput.field_1352 * (double) f;

        this.motion = this.motion.method_1031(inputX, 0, inputZ);
    }

    public void calculate(int ticks) {
        for (int i = 0; i < ticks; i++) {
            calculateForTick();
        }
    }

    public class_2338 findCollision(int ticks) {
        float w = mc.field_1724 != null ? mc.field_1724.method_17681() / 2f : 0.3f;
        for (int i = 0; i < ticks; i++) {
            class_243 start = new class_243(x, y, z);
            calculateForTick();
            class_243 end = new class_243(x, y, z);

            class_2338 raytracedBlock;
            if ((raytracedBlock = rayTrace(start, end)) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.method_1031(w, 0, w), end.method_1031(w, 0, w))) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.method_1031(-w, 0, w), end.method_1031(-w, 0, w))) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.method_1031(w, 0, -w), end.method_1031(w, 0, -w))) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.method_1031(-w, 0, -w), end.method_1031(-w, 0, -w))) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.method_1031(w, 0, 0), end.method_1031(w, 0, 0))) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.method_1031(-w, 0, 0), end.method_1031(-w, 0, 0))) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.method_1031(0, 0, w), end.method_1031(0, 0, w))) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.method_1031(0, 0, -w), end.method_1031(0, 0, -w))) != null) return raytracedBlock;
        }
        return null;
    }

    private class_3965 rayTraceHit(class_243 start, class_243 end) {
        double distance = start.method_1022(end);
        if (distance < 1.0E-7D) {
            return null;
        }
        class_239 result = mc.field_1687.method_17742(new class_3959(
                start, end, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, mc.field_1724
        ));
        return result instanceof class_3965 ? (class_3965) result : null;
    }

    private class_2338 rayTrace(class_243 start, class_243 end) {
        class_3965 result = rayTraceHit(start, end);
        if (result != null && result.method_17783() == class_239.class_240.field_1332 && result.method_17780() == class_2350.field_11036) {
            return result.method_17777();
        }
        return null;
    }

    public class_243 getEyePos() {
        return eyePos.method_61889(0);
    }

    public class_243 getPos() {
        return new class_243(x, y, z);
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }

    public class_243 getMotion() {
        return motion;
    }

    public float getYaw() {
        return yaw;
    }

    public float getStrafe() {
        return strafe;
    }

    public float getForward() {
        return forward;
    }

    public float getJumpMovementFactor() {
        return jumpMovementFactor;
    }

    public float getMovementSpeed() {
        return movementSpeed;
    }

    public boolean isOnGround() {
        return onGround;
    }
}