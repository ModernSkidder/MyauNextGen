package laoqi123.util;

import laoqi123.enums.ChatColors;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class ChatUtil {
    private static final class_310 mc = class_310.method_1551();

    public static void send(class_2561 text) {
        if (ChatUtil.mc.field_1724 != null) {
            ChatUtil.mc.field_1724.method_7353(text, false);
        }
    }

    public static void sendFormatted(String string) {
        ChatUtil.send(class_2561.method_43470(ChatColors.formatColor(string)));
    }

    public static void sendRaw(String string) {
        ChatUtil.send(class_2561.method_43470(string));
    }

    public static void sendMessage(String string) {
        if (ChatUtil.mc.field_1724 != null) {
            ChatUtil.mc.field_1724.field_3944.method_45729(string);
        }
    }
}
