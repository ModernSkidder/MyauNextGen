package laoqi123.util;

import net.minecraft.class_2338;
import net.minecraft.class_2350;

public record BlockData(class_2338 pos, class_2350 facing) {
}