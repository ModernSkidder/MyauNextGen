package laoqi123.util.clicking;

import laoqi123.mixin.LivingEntityAccessor;
import laoqi123.value.properties.FloatRangeValue;
import net.minecraft.class_310;
import laoqi123.util.config.Configurable;

public class ItemCooldown extends Configurable {
    private static final class_310 mc = class_310.method_1551();

    public final FloatRangeValue minimumCooldown;
    private float nextCooldown;

    public ItemCooldown() {
        super("ItemCooldown");
        this.minimumCooldown = this.register(new FloatRangeValue("Minimum", 1.0f, 1.0f, 0.0f, 2.0f));
        this.nextCooldown = this.randomCooldown();
    }

    public boolean isCooldownPassed(int ticks) {
        return this.cooldownProgress(ticks) >= this.nextCooldown;
    }

    public float cooldownProgress(int baseTime) {
        return (float) (((LivingEntityAccessor) mc.field_1724).getLastAttackedTicks() + baseTime) * mc.field_1724.method_7279();
    }

    public void newCooldown() {
        this.nextCooldown = this.randomCooldown();
    }

    private float randomCooldown() {
        return this.minimumCooldown.random();
    }
}
