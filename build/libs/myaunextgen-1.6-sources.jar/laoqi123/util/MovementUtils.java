package laoqi123.util;

import net.minecraft.class_310;

public class MovementUtils {
    private static final class_310 mc = class_310.method_1551();

    public static boolean cancelMove = false;

    public static void cancelMove() {
        cancelMove = true;
        if (mc.field_1724 != null) {
            mc.field_1724.method_18800(0.0, mc.field_1724.method_18798().field_1351, 0.0);
        }
    }

    public static void resetMove() {
        cancelMove = false;
    }
}