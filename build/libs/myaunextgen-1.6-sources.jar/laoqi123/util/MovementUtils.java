package laoqi123.util;

import laoqi123.event.EventTarget;
import laoqi123.event.impl.MoveInputEvent;
import laoqi123.event.impl.PacketEvent;
import laoqi123.event.impl.TickEvent;
import laoqi123.event.impl.UpdateEvent;
import laoqi123.event.types.EventType;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_310;

/**
 * 冻结玩家移动的工具类(用于 Scaffold 的 clutch / 不可达放置场景)。
 * 与 Southside 的 MovementUtils 语义一致:取消移动时【钉住】保存的速度,
 * 而不是把速度清零 —— 清零速度会被 Grim 的 Simulation 判定为速度异常。
 */
public class MovementUtils {
    public static final MovementUtils INSTANCE = new MovementUtils();
    private static final class_310 mc = class_310.method_1551();

    public static boolean cancelMove = false;
    private static class_243 savedVelocity = class_243.field_1353;
    private static float savedFallDistance = 0f;
    private static int moveTicks = 0;
    private static int noMovePackets = 0;

    public static void cancelMove() {
        if (mc.field_1724 == null) return;
        if (cancelMove) return;
        cancelMove = true;
        // 只保存,不清零
        savedVelocity = mc.field_1724.method_18798();
        savedFallDistance = mc.field_1724.field_6017;
    }

    public static void resetMove() {
        cancelMove = false;
        moveTicks = 0;
        noMovePackets = 0;
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (event.getType() != EventType.PRE) return;
        if (mc.field_1724 == null) {
            resetMove();
            return;
        }
        if (!cancelMove || moveTicks > 0) return;
        // 每 tick 恢复保存的速度:速度值保持不变,Grim 不会判定速度异常
        mc.field_1724.method_18799(savedVelocity);
        mc.field_1724.field_6017 = savedFallDistance;
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (cancelMove && moveTicks <= 0) {
            event.setForward(0f);
            event.setStrafe(0f);
            event.setJump(false);
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null) {
            resetMove();
            return;
        }
        if (!cancelMove) {
            noMovePackets = 0;
            return;
        }
        if (moveTicks > 0) {
            moveTicks--;
            if (moveTicks <= 0) resetMove();
            return;
        }
        // 连续很多 tick 没有发送位置变化包 → 开始释放冻结,避免一直卡在空中
        if (noMovePackets >= 20) {
            moveTicks = 10;
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getType() != EventType.SEND) return;
        if (!(event.getPacket() instanceof class_2828 movePacket)) return;
        if (movePacket.method_36171()) {
            noMovePackets = 0;
        } else {
            noMovePackets++;
        }
    }
}
