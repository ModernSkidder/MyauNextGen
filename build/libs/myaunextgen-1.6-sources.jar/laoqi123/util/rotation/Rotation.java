package laoqi123.util.rotation;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class Rotation {
    public static final Rotation ZERO = new Rotation(0.0f, 0.0f);
    private static final class_310 mc = class_310.method_1551();

    private final float yaw;
    private final float pitch;
    private final boolean normalized;

    public Rotation(float yaw, float pitch) {
        this(yaw, pitch, false);
    }

    public Rotation(float yaw, float pitch, boolean normalized) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.normalized = normalized;
    }

    public float getYaw() {
        return this.yaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public boolean isNormalized() {
        return this.normalized;
    }

    public static Rotation lookingAt(class_243 point, class_243 from) {
        return Rotation.fromRotationVec(point.method_1020(from));
    }

    public static Rotation fromRotationVec(class_243 vec) {
        return Rotation.fromRotationVec(vec.field_1352, vec.field_1351, vec.field_1350);
    }

    public static Rotation fromRotationVec(double x, double y, double z) {
        return new Rotation(
                class_3532.method_15393((float) (Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f),
                class_3532.method_15393((float) (-Math.atan2(y, Math.hypot(x, z)) * 180.0 / Math.PI))
        );
    }

    public class_243 directionVector() {
        float f = class_3532.method_15362(-this.yaw * 0.017453292F - 3.1415927F);
        float f1 = class_3532.method_15374(-this.yaw * 0.017453292F - 3.1415927F);
        float f2 = -class_3532.method_15362(-this.pitch * 0.017453292F);
        float f3 = class_3532.method_15374(-this.pitch * 0.017453292F);
        return new class_243(f1 * f2, f3, f * f2);
    }

    public static double gcd() {
        float f = (float) (mc.field_1690.method_42495().method_41753() * 0.6 + 0.2);
        return f * f * f * 8.0 * 0.15;
    }

    public Rotation normalize(Rotation baseRotation) {
        if (this.normalized) {
            return this;
        }
        double gcd = Rotation.gcd();
        RotationDelta diff = baseRotation.rotationDeltaTo(this);
        double g1 = Math.round(diff.getDeltaYaw() / gcd) * gcd;
        double g2 = Math.round(diff.getDeltaPitch() / gcd) * gcd;
        float yaw = baseRotation.getYaw() + (float) g1;
        float pitch = Math.max(-90.0f, Math.min(90.0f, baseRotation.getPitch() + (float) g2));
        return new Rotation(yaw, pitch, true);
    }

    public Rotation normalize() {
        if (Rotation.mc.field_1724 == null) {
            return this;
        }
        return this.normalize(new Rotation(Rotation.mc.field_1724.method_36454(), Rotation.mc.field_1724.method_36455()));
    }

    public static float angleDifference(float a, float b) {
        return class_3532.method_15393(a - b);
    }

    public RotationDelta rotationDeltaTo(Rotation other) {
        return new RotationDelta(
                Rotation.angleDifference(other.getYaw(), this.getYaw()),
                Rotation.angleDifference(other.getPitch(), this.getPitch())
        );
    }

    public float angleTo(Rotation other) {
        return Math.min(this.rotationDeltaTo(other).length(), 180.0f);
    }

    public Rotation towardsLinear(Rotation other, float horizontalFactor, float verticalFactor) {
        RotationDelta diff = this.rotationDeltaTo(other);
        float rotationDifference = diff.length();
        if (rotationDifference <= 0.001f) {
            return this;
        }
        float straightLineYaw = Math.abs(diff.getDeltaYaw() / rotationDifference) * horizontalFactor;
        float straightLinePitch = Math.abs(diff.getDeltaPitch() / rotationDifference) * verticalFactor;
        return new Rotation(
                this.yaw + class_3532.method_15363(diff.getDeltaYaw(), -straightLineYaw, straightLineYaw),
                this.pitch + class_3532.method_15363(diff.getDeltaPitch(), -straightLinePitch, straightLinePitch)
        );
    }

    public boolean approximatelyEquals(Rotation other, float tolerance) {
        return this.angleTo(other) <= tolerance;
    }

    public boolean approximatelyEquals(Rotation other) {
        return this.approximatelyEquals(other, 2.0f);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Rotation)) {
            return false;
        }
        Rotation other = (Rotation) obj;
        return Float.floatToIntBits(this.yaw) == Float.floatToIntBits(other.yaw)
                && Float.floatToIntBits(this.pitch) == Float.floatToIntBits(other.pitch);
    }

    @Override
    public int hashCode() {
        int result = Float.floatToIntBits(this.yaw);
        result = 31 * result + Float.floatToIntBits(this.pitch);
        return result;
    }

    @Override
    public String toString() {
        return "Rotation(yaw=" + this.yaw + ", pitch=" + this.pitch + ")";
    }
}
