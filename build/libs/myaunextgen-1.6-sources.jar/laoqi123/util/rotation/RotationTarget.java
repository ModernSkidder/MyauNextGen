package laoqi123.util.rotation;

import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_310;

public class RotationTarget {
    private static final class_310 mc = class_310.method_1551();

    private Rotation rotation;
    private class_1309 entity;
    private final List<RotationProcessor> processors;
    private final int ticksUntilReset;
    private final float resetThreshold;
    private final boolean considerInventory;
    private final MovementCorrection movementCorrection;

    public RotationTarget(Rotation rotation,
                          class_1309 entity,
                          List<RotationProcessor> processors,
                          int ticksUntilReset,
                          float resetThreshold,
                          boolean considerInventory,
                          MovementCorrection movementCorrection) {
        this.rotation = rotation;
        this.entity = entity;
        this.processors = processors;
        this.ticksUntilReset = ticksUntilReset;
        this.resetThreshold = resetThreshold;
        this.considerInventory = considerInventory;
        this.movementCorrection = movementCorrection;
    }

    public Rotation towards(Rotation currentRotation, boolean isResetting) {
        if (isResetting) {
            this.entity = null;
        }
        Rotation target = isResetting ? new Rotation(mc.field_1724.method_36454(), mc.field_1724.method_36455()) : this.rotation;
        if (this.processors.isEmpty()) {
            return target;
        }
        Rotation processed = target;
        for (RotationProcessor processor : this.processors) {
            processed = processor.process(this, currentRotation, processed);
        }
        return processed;
    }

    public Rotation getRotation() {
        return this.rotation;
    }

    public void setRotation(Rotation rotation) {
        this.rotation = rotation;
    }

    public class_1309 getEntity() {
        return this.entity;
    }

    public int getTicksUntilReset() {
        return this.ticksUntilReset;
    }

    public float getResetThreshold() {
        return this.resetThreshold;
    }

    public boolean isConsiderInventory() {
        return this.considerInventory;
    }

    public MovementCorrection getMovementCorrection() {
        return this.movementCorrection;
    }
}
