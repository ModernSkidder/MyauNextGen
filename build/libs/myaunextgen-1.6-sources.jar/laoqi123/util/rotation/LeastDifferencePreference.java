package laoqi123.util.rotation;

import net.minecraft.class_238;
import net.minecraft.class_243;

public class LeastDifferencePreference implements RotationPreference {
    private final Rotation baseRotation;
    private final class_243 basePoint;

    public LeastDifferencePreference(Rotation baseRotation, class_243 basePoint) {
        this.baseRotation = baseRotation;
        this.basePoint = basePoint;
    }

    public static LeastDifferencePreference leastDifferenceToLastPoint(class_243 eyes, class_243 point) {
        return new LeastDifferencePreference(Rotation.lookingAt(point, eyes), point);
    }

    @Override
    public class_243 getPreferredSpot(class_243 eyesPos, double range) {
        if (this.basePoint != null) {
            return this.basePoint;
        }
        Rotation rotation = this.baseRotation;
        return eyesPos.method_1019(rotation.directionVector().method_1021(range));
    }

    @Override
    public class_243 getPreferredSpotOnBox(class_238 box, class_243 eyesPos, double range) {
        if (this.basePoint != null) {
            return this.basePoint;
        }
        class_243 preferred = this.getPreferredSpot(eyesPos, range);
        if (box.method_1006(preferred)) {
            return preferred;
        }
        class_243 spotOnBox = AimUtil.firstHit(box, eyesPos, preferred);
        if (spotOnBox != null && eyesPos.method_1025(spotOnBox) <= range * range) {
            return spotOnBox;
        }
        return preferred;
    }

    @Override
    public int compare(Rotation o1, Rotation o2) {
        return Float.compare(this.baseRotation.angleTo(o1), this.baseRotation.angleTo(o2));
    }
}
