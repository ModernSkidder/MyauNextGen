package laoqi123.util.rotation;

import laoqi123.util.RotationUtil;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class AimUtil {
    private static final class_310 mc = class_310.method_1551();

    public static class_243 firstHit(class_238 box, class_243 start, class_243 end) {
        Optional<class_243> hit = box.method_992(start, end);
        return hit.orElse(null);
    }

    public static boolean canSeePointFrom(class_243 eyes, class_243 point) {
        class_239 result = mc.field_1687.method_17742(new class_3959(
                eyes,
                point,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                mc.field_1724
        ));
        return result.method_17783() == class_239.class_240.field_1333;
    }

    public static boolean facingEnemy(class_1309 entity, double range, Rotation rotation) {
        return RotationUtil.rayTrace(
                entity.method_5829().method_1009(0.1, 0.1, 0.1),
                rotation.getYaw(),
                rotation.getPitch(),
                range
        ) != null;
    }

    public static class_243 getNearestPoint(class_238 box, class_243 point) {
        return new class_243(
                Math.max(box.field_1323, Math.min(point.field_1352, box.field_1320)),
                Math.max(box.field_1322, Math.min(point.field_1351, box.field_1325)),
                Math.max(box.field_1321, Math.min(point.field_1350, box.field_1324))
        );
    }

    public static RotationWithVector raytraceBox(class_243 eyes,
                                                 class_238 box,
                                                 double range,
                                                 double wallsRange,
                                                 RotationPreference preference,
                                                 boolean prioritizeVisible) {
        double rangeSq = range * range;
        double wallsRangeSq = wallsRange * wallsRange;

        class_243 preferredSpot = preference.getPreferredSpotOnBox(box, eyes, range);
        class_243 preferredSpotOnBox = AimUtil.firstHit(box, eyes, preferredSpot);
        if (preferredSpotOnBox != null) {
            double preferredSpotDistance = eyes.method_1025(preferredSpotOnBox);
            boolean validCauseBelowWallsRange = preferredSpotDistance < wallsRangeSq;
            boolean validCauseVisible = AimUtil.canSeePointFrom(eyes, preferredSpotOnBox);
            if (validCauseBelowWallsRange || (validCauseVisible && preferredSpotDistance < rangeSq)) {
                return new RotationWithVector(Rotation.lookingAt(preferredSpot, eyes), preferredSpotOnBox);
            }
        }

        BestRotationTracker tracker = new BestRotationTracker(preference, !prioritizeVisible);
        class_243 nearestSpot = AimUtil.getNearestPoint(box, eyes);
        if (nearestSpot != null) {
            considerSpot(tracker, preferredSpot, box, eyes, rangeSq, wallsRangeSq, nearestSpot);
        }
        List<class_243> points = AimUtil.projectPointsOnBox(eyes, box, 256);
        if (points != null) {
            for (class_243 spot : points) {
                considerSpot(tracker, preferredSpot, box, eyes, rangeSq, wallsRangeSq, spot);
            }
        } else {
            double sizeX = box.method_17939();
            double sizeY = box.method_17940();
            double sizeZ = box.method_17941();
            for (double x = 0.05; x < 0.95; x += 0.1) {
                for (double y = 0.05; y < 0.95; y += 0.1) {
                    for (double z = 0.05; z < 0.95; z += 0.1) {
                        considerSpot(tracker, preferredSpot, box, eyes, rangeSq, wallsRangeSq,
                                new class_243(box.field_1323 + sizeX * x, box.field_1322 + sizeY * y, box.field_1321 + sizeZ * z));
                    }
                }
            }
        }
        return tracker.getBestVisible() != null ? tracker.getBestVisible() : tracker.getBestInvisible();
    }

    private static void considerSpot(BestRotationTracker tracker,
                                     class_243 preferredSpot,
                                     class_238 box,
                                     class_243 eyes,
                                     double rangeSq,
                                     double wallsRangeSq,
                                     class_243 spot) {
        class_243 raycastTarget = preferredSpot.method_1020(eyes).method_1021(2.0).method_1019(eyes);
        class_243 spotOnBox = AimUtil.firstHit(box, eyes, raycastTarget);
        if (spotOnBox == null) {
            return;
        }
        double distSq = eyes.method_1025(spotOnBox);
        boolean visible = AimUtil.canSeePointFrom(eyes, spotOnBox);
        if ((!visible || distSq >= rangeSq) && distSq >= wallsRangeSq) {
            return;
        }
        Rotation rotation = Rotation.lookingAt(spot, eyes);
        tracker.considerRotation(new RotationWithVector(rotation, spot), visible);
    }

    /**
     * Simplified port of LB's projectPointsOnBox: generates a grid of points on
     * the box faces that face the observer. Returns null when the eyes are inside the box.
     */
    public static List<class_243> projectPointsOnBox(class_243 eyes, class_238 box, int maxPoints) {
        if (box.method_1006(eyes)) {
            return null;
        }
        List<class_243> points = new ArrayList<>();
        double[] grid = new double[10];
        for (int i = 0; i < 10; i++) {
            grid[i] = 0.05 + 0.1 * i;
        }
        double sizeX = box.method_17939();
        double sizeY = box.method_17940();
        double sizeZ = box.method_17941();

        // +X / -X faces
        if (box.field_1320 < eyes.field_1352) {
            for (double y : grid) {
                for (double z : grid) {
                    points.add(new class_243(box.field_1320, box.field_1322 + sizeY * y, box.field_1321 + sizeZ * z));
                }
            }
        } else if (box.field_1323 > eyes.field_1352) {
            for (double y : grid) {
                for (double z : grid) {
                    points.add(new class_243(box.field_1323, box.field_1322 + sizeY * y, box.field_1321 + sizeZ * z));
                }
            }
        }
        // +Y / -Y faces
        if (box.field_1325 < eyes.field_1351) {
            for (double x : grid) {
                for (double z : grid) {
                    points.add(new class_243(box.field_1323 + sizeX * x, box.field_1325, box.field_1321 + sizeZ * z));
                }
            }
        } else if (box.field_1322 > eyes.field_1351) {
            for (double x : grid) {
                for (double z : grid) {
                    points.add(new class_243(box.field_1323 + sizeX * x, box.field_1322, box.field_1321 + sizeZ * z));
                }
            }
        }
        // +Z / -Z faces
        if (box.field_1324 < eyes.field_1350) {
            for (double x : grid) {
                for (double y : grid) {
                    points.add(new class_243(box.field_1323 + sizeX * x, box.field_1322 + sizeY * y, box.field_1324));
                }
            }
        } else if (box.field_1321 > eyes.field_1350) {
            for (double x : grid) {
                for (double y : grid) {
                    points.add(new class_243(box.field_1323 + sizeX * x, box.field_1322 + sizeY * y, box.field_1321));
                }
            }
        }

        if (points.size() > maxPoints) {
            List<class_243> sampled = new ArrayList<>(maxPoints);
            double step = (double) points.size() / maxPoints;
            for (int i = 0; i < maxPoints; i++) {
                sampled.add(points.get(Math.min(points.size() - 1, (int) ((i + 0.5) * step))));
            }
            return sampled;
        }
        return points;
    }

    private static class BestRotationTracker {
        private final Comparator<Rotation> comparator;
        private final boolean ignoreVisibility;
        private RotationWithVector bestVisible;
        private RotationWithVector bestInvisible;

        BestRotationTracker(Comparator<Rotation> comparator, boolean ignoreVisibility) {
            this.comparator = comparator;
            this.ignoreVisibility = ignoreVisibility;
        }

        void considerRotation(RotationWithVector rotation, boolean visible) {
            if (visible || this.ignoreVisibility) {
                if (this.isRotationBetter(this.bestVisible, rotation)) {
                    this.bestVisible = rotation;
                }
            } else {
                if (this.isRotationBetter(this.bestInvisible, rotation)) {
                    this.bestInvisible = rotation;
                }
            }
        }

        private boolean isRotationBetter(RotationWithVector base, RotationWithVector candidate) {
            return base == null || this.comparator.compare(base.getRotation(), candidate.getRotation()) > 0;
        }

        RotationWithVector getBestVisible() {
            return this.bestVisible;
        }

        RotationWithVector getBestInvisible() {
            return this.bestInvisible;
        }
    }
}
