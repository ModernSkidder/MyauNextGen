package laoqi123.util.rotation;

import net.minecraft.class_243;

public class RotationWithVector {
    private final Rotation rotation;
    private final class_243 vec;

    public RotationWithVector(Rotation rotation, class_243 vec) {
        this.rotation = rotation;
        this.vec = vec;
    }

    public Rotation getRotation() {
        return this.rotation;
    }

    public class_243 getVec() {
        return this.vec;
    }
}
