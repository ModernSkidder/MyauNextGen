package laoqi123.util.rotation;

import java.util.Comparator;
import net.minecraft.class_238;
import net.minecraft.class_243;

public interface RotationPreference extends Comparator<Rotation> {
    class_243 getPreferredSpot(class_243 eyesPos, double range);

    default class_243 getPreferredSpotOnBox(class_238 box, class_243 eyesPos, double range) {
        return this.getPreferredSpot(eyesPos, range);
    }
}
