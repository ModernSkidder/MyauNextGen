package laoqi123.util;

import net.minecraft.class_10192;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1747;
import net.minecraft.class_1753;
import net.minecraft.class_1766;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1778;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1803;
import net.minecraft.class_1810;
import net.minecraft.class_1812;
import net.minecraft.class_1821;
import net.minecraft.class_1823;
import net.minecraft.class_1826;
import net.minecraft.class_1828;
import net.minecraft.class_1829;
import net.minecraft.class_1839;
import net.minecraft.class_1844;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9239;
import net.minecraft.class_9279;
import net.minecraft.class_9285;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import net.minecraft.class_9362;
import net.minecraft.item.*;
import java.util.ArrayList;

public class ItemUtil {
    private static final class_310 mc = class_310.method_1551();
    private static final ArrayList<Integer> specialItems = new SpecialItems();

    public static boolean isNotSpecialItem(class_1799 itemStack) {
        if (itemStack == null || itemStack.method_7960()) {
            return false;
        }
        class_1792 item = itemStack.method_7909();
        if (item instanceof class_1812 || item instanceof class_1828 || item instanceof class_1803) {
            class_1844 contents = itemStack.method_57824(class_9334.field_49651);
            if (contents == null) {
                return true;
            }
            for (class_1293 effect : contents.method_57397()) {
                if (specialItems.contains(getPotionId(effect))) {
                    return false;
                }
            }
            return true;
        }
        if (item instanceof class_1776) return false;
        if (item == class_1802.field_8288) return false;
        if (itemStack.method_57824(class_9334.field_50075) != null && item != class_1802.field_8680) return false;
        if (item instanceof class_1826) return false;
        return item != class_1802.field_8137;
    }

    private static int getPotionId(class_1293 effect) {
        class_6880<class_1291> type = effect.method_5579();
        if (type.method_55838(class_1294.field_5904)) return 1;
        if (type.method_55838(class_1294.field_5917)) return 3;
        if (type.method_55838(class_1294.field_5910)) return 5;
        if (type.method_55838(class_1294.field_5915)) return 6;
        if (type.method_55838(class_1294.field_5913)) return 8;
        if (type.method_55838(class_1294.field_5924)) return 10;
        if (type.method_55838(class_1294.field_5907)) return 11;
        if (type.method_55838(class_1294.field_5918)) return 12;
        if (type.method_55838(class_1294.field_5905)) return 14;
        if (type.method_55838(class_1294.field_5926)) return 21;
        return -1;
    }

    public static boolean isBlock(class_1799 itemStack) {
        if (itemStack == null || itemStack.method_7947() < 1) {
            return false;
        }
        class_1792 item = itemStack.method_7909();
        if (item instanceof class_1747) {
            return ItemUtil.isContainerBlock((class_1747) item);
        }
        return false;
    }

    public static boolean isProjectile(class_1799 itemStack) {
        if (itemStack == null || itemStack.method_7947() < 1) {
            return false;
        }
        class_1792 item = itemStack.method_7909();
        if (item instanceof class_1771) return true;
        if (item instanceof class_1823) return true;
        return false;
    }

    public static boolean isContainerBlock(class_1747 itemBlock) {
        class_2248 block = itemBlock.method_7711();
        if (BlockUtil.isInteractable(block)) return false;
        return BlockUtil.isSolid(block);
    }

    public static double getAttackBonus(class_1799 itemStack) {
        double attackBonus = 0.0;
        if (itemStack == null || itemStack.method_7960()) {
            return 0.0;
        }
        class_9285 modifiers = itemStack.method_57825(class_9334.field_49636, class_9285.field_49326);
        for (class_9285.class_9287 modifier : modifiers.comp_2393()) {
            if (modifier.comp_2395().method_55838(class_5134.field_23721)) {
                attackBonus += modifier.comp_2396().comp_2449();
                break;
            }
        }
        attackBonus += (double) ItemUtil.getEnchantLevel(itemStack, class_1893.field_9124);
        attackBonus += (double) ItemUtil.getEnchantLevel(itemStack, class_1893.field_9118) * 1.25;
        return attackBonus;
    }

    public static float getToolEfficiency(class_1799 itemStack) {
        float efficiency = 1.0f;
        if (itemStack != null && !itemStack.method_7960()) {
            if (itemStack.method_7909() instanceof class_1766) {
                efficiency = getBaseToolSpeed(itemStack);
                int enchantLevel = ItemUtil.getEnchantLevel(itemStack, class_1893.field_9131);
                if (efficiency > 1.0f && enchantLevel > 0) {
                    efficiency += (float) (enchantLevel * enchantLevel + 1);
                }
            }
        }
        return efficiency;
    }

    public static float getToolEfficiency(class_1799 itemStack, class_2248 block) {
        float efficiency = 1.0f;
        if (itemStack != null && !itemStack.method_7960()) {
            class_2680 state = block.method_9564();
            boolean isPickaxe = itemStack.method_7909() instanceof class_1810;
            efficiency = itemStack.method_7951(state) || !isPickaxe
                    ? itemStack.method_7924(state) : 1.0f;
            if (itemStack.method_7909() instanceof class_1766) {
                int enchantLevel = ItemUtil.getEnchantLevel(itemStack, class_1893.field_9131);
                if (efficiency > 1.0f && enchantLevel > 0) {
                    efficiency += (float) (enchantLevel * enchantLevel + 1);
                }
            }
        }
        return efficiency;
    }

    private static float getBaseToolSpeed(class_1799 itemStack) {
        class_2960 id = class_7923.field_41178.method_10221(itemStack.method_7909());
        String path = id.method_12832();
        if (path.contains("netherite")) return 9.0f;
        if (path.contains("golden")) return 12.0f;
        if (path.contains("diamond")) return 8.0f;
        if (path.contains("iron")) return 6.0f;
        if (path.contains("stone")) return 4.0f;
        if (path.contains("wooden")) return 2.0f;
        return 1.0f;
    }

    public static double getArmorProtection(class_1799 itemStack) {
        double protection = 0.0;
        if (itemStack != null && !itemStack.method_7960()) {
            class_9285 modifiers = itemStack.method_57825(class_9334.field_49636, class_9285.field_49326);
            for (class_9285.class_9287 modifier : modifiers.comp_2393()) {
                if (modifier.comp_2395().method_55838(class_5134.field_23724)) {
                    protection += modifier.comp_2396().comp_2449();
                }
            }
            protection += (double) ItemUtil.getEnchantLevel(itemStack, class_1893.field_9111) * 0.8;
            protection += (double) ItemUtil.getEnchantLevel(itemStack, class_1893.field_9129) * 0.05;
            protection += (double) ItemUtil.getEnchantLevel(itemStack, class_1893.field_9096) * 0.01;
        }
        return protection;
    }

    public static double getBowAttackBonus(class_1799 itemStack) {
        double attackBonus = 0.0;
        if (itemStack != null && !itemStack.method_7960()) {
            if (itemStack.method_7909() instanceof class_1753) {
                attackBonus = 2.0;
                int power = ItemUtil.getEnchantLevel(itemStack, class_1893.field_9103);
                if (power > 0) {
                    attackBonus += (double) (power + 1) * 0.25;
                }
                attackBonus += (double) ItemUtil.getEnchantLevel(itemStack, class_1893.field_9126) * 0.25;
                attackBonus += (double) ItemUtil.getEnchantLevel(itemStack, class_1893.field_9125) * 0.05;
            }
        }
        return attackBonus;
    }

    public static int findSwordInInventorySlot(int startSlot, boolean checkDurability) {
        int bestSlot = -1;
        double bestAttackBonus = 0.0;
        if (startSlot < 0) return bestSlot;
        for (int i = 0; i < 36; ++i) {
            int currentSlot = (startSlot + i) % 36;
            class_1799 itemStack = ItemUtil.mc.field_1724.method_31548().method_5438(currentSlot);
            if (itemStack == null || itemStack.method_7960()) continue;
            if (!(itemStack.method_7909() instanceof class_1829)) continue;
            if (checkDurability) {
                if (itemStack.method_7963() && itemStack.method_7919() > 0
                        && itemStack.method_7936() - itemStack.method_7919() < 30) {
                    continue;
                }
            }
            double attackBonus = ItemUtil.getAttackBonus(itemStack);
            if (!(attackBonus > bestAttackBonus)) continue;
            bestSlot = currentSlot;
            bestAttackBonus = attackBonus;
        }
        return bestSlot;
    }

    public static int findBowInventorySlot(int startSlot, boolean checkDurability) {
        int bestSlot = -1;
        double bestAttackBonus = 0.0;
        if (startSlot < 0) return bestSlot;
        for (int i = 0; i < 36; ++i) {
            int currentSlot = (startSlot + i) % 36;
            class_1799 itemStack = ItemUtil.mc.field_1724.method_31548().method_5438(currentSlot);
            if (itemStack == null || itemStack.method_7960()) continue;
            if (!(itemStack.method_7909() instanceof class_1753)) continue;
            if (checkDurability) {
                if (itemStack.method_7963() && itemStack.method_7919() > 0
                        && itemStack.method_7936() - itemStack.method_7919() < 30) {
                    continue;
                }
            }
            double attackBonus = ItemUtil.getBowAttackBonus(itemStack);
            if (!(attackBonus > bestAttackBonus)) continue;
            bestSlot = currentSlot;
            bestAttackBonus = attackBonus;
        }
        return bestSlot;
    }

    public static int findInventorySlot(String toolClass, int startSlot, boolean checkDurability) {
        int bestSlot = -1;
        float bestEfficiency = 1.0f;
        if (startSlot < 0) return bestSlot;
        for (int i = 0; i < 36; ++i) {
            int currentSlot = (startSlot + i) % 36;
            class_1799 itemStack = ItemUtil.mc.field_1724.method_31548().method_5438(currentSlot);
            if (itemStack == null || itemStack.method_7960()) continue;
            if (!(itemStack.method_7909() instanceof class_1766)) continue;
            if (!isToolOfClass(itemStack.method_7909(), toolClass)) continue;
            if (checkDurability) {
                if (itemStack.method_7963() && itemStack.method_7919() > 0
                        && itemStack.method_7936() - itemStack.method_7919() < 30) {
                    continue;
                }
            }
            float efficiency = ItemUtil.getToolEfficiency(itemStack);
            if (!(efficiency > bestEfficiency)) continue;
            bestSlot = currentSlot;
            bestEfficiency = efficiency;
        }
        return bestSlot;
    }

    private static boolean isToolOfClass(class_1792 item, String toolClass) {
        if ("pickaxe".equals(toolClass)) return item instanceof class_1810;
        if ("axe".equals(toolClass)) return item instanceof class_1743;
        if ("shovel".equals(toolClass)) return item instanceof class_1821;
        return item instanceof class_1766;
    }

    public static int findInventorySlot(int currentSlot, class_2248 block) {
        class_1799 currentItem = ItemUtil.mc.field_1724.method_31548().method_5438(currentSlot);
        int bestSlot = currentSlot;
        float bestStrength = getToolEfficiency(currentItem, block);
        for (int i = 0; i < 9; ++i) {
            class_1799 itemStack = ItemUtil.mc.field_1724.method_31548().method_5438(i);
            if (itemStack == null || itemStack.method_7960()) continue;
            float strength = getToolEfficiency(itemStack, block);
            if (!(strength > bestStrength)) continue;
            bestSlot = i;
            bestStrength = strength;
        }
        return bestSlot;
    }

    public static int findAndurilHotbarSlot(int currentSlot) {
        for (int i = currentSlot; i < currentSlot + 9; ++i) {
            int slot = i % 9;
            class_1799 itemStack = ItemUtil.mc.field_1724.method_31548().method_5438(slot);
            if (itemStack == null || itemStack.method_7960()) continue;
            if (itemStack.method_7909() == class_1802.field_8371) {
                class_9290 lore = itemStack.method_57824(class_9334.field_49632);
                if (lore != null) {
                    for (class_2561 line : lore.comp_2400()) {
                        if (line.getString().contains("§9Justice")) {
                            return slot;
                        }
                    }
                }
            }
        }
        return -1;
    }

    public static int findArmorInventorySlot(int armorType, boolean checkDurability) {
        int bestSlot = -1;
        double bestProtection = 0.0;
        int limit = checkDurability ? 40 : 36;
        for (int i = 0; i < limit; ++i) {
            class_1799 itemStack = ItemUtil.mc.field_1724.method_31548().method_5438(i);
            if (itemStack == null || itemStack.method_7960()) continue;
            if (!(itemStack.method_7909() instanceof class_1738)) continue;
            class_10192 equippable = itemStack.method_57824(class_9334.field_54196);
            class_1304 slot = equippable == null ? null : equippable.comp_3174();
            if (slot != getArmorSlot(armorType)) continue;
            if (checkDurability) {
                if (itemStack.method_7963() && itemStack.method_7919() > 0
                        && itemStack.method_7936() - itemStack.method_7919() < 30) {
                    continue;
                }
            }
            double protection = ItemUtil.getArmorProtection(itemStack);
            if (!(protection >= bestProtection)) continue;
            bestSlot = i;
            bestProtection = protection;
        }
        return bestSlot;
    }

    private static class_1304 getArmorSlot(int armorType) {
        switch (armorType) {
            case 0: return class_1304.field_6169;
            case 1: return class_1304.field_6174;
            case 2: return class_1304.field_6172;
            case 3: return class_1304.field_6166;
            default: return null;
        }
    }

    public static int findInventorySlot(int startSlot, ItemType itemType) {
        int bestSlot = -1;
        int maxStackSize = 0;
        if (startSlot < 0) startSlot = 0;
        for (int i = 0; i < 36; ++i) {
            int currentSlot = (startSlot + i) % 36;
            class_1799 itemStack = ItemUtil.mc.field_1724.method_31548().method_5438(currentSlot);
            if (itemStack == null || itemStack.method_7960()) continue;
            if (!itemType.contains(itemStack)) continue;
            if (maxStackSize >= itemStack.method_7947()) continue;
            bestSlot = currentSlot;
            maxStackSize = itemStack.method_7947();
        }
        return bestSlot;
    }

    public static int findInventorySlot(ItemType itemType) {
        int stackSize = 0;
        for (int i = 0; i < 36; ++i) {
            class_1799 itemStack = ItemUtil.mc.field_1724.method_31548().method_5438(i);
            if (itemStack == null || itemStack.method_7960()) continue;
            if (!itemType.contains(itemStack)) continue;
            stackSize += itemStack.method_7947();
        }
        return stackSize;
    }

    public static boolean hasRawUnbreakingEnchant() {
        class_1799 itemStack = ItemUtil.mc.field_1724.method_6047();
        if (itemStack == null || itemStack.method_7960()) {
            return false;
        }
        class_9279 customData = itemStack.method_57824(class_9334.field_49628);
        if (customData != null) {
            class_2487 tag = customData.method_57463();
            if (tag.method_10545("ExtraAttributes")) {
                class_2487 extra = tag.method_10562("ExtraAttributes");
                if (extra.method_10545("UHCid")) {
                    long id = extra.method_10537("UHCid");
                    if (id == 50006L || id == 50009L) {
                        return true;
                    }
                }
            }
            if (itemStack.method_57826(class_9334.field_49638)
                    && itemStack.method_7909() == class_1802.field_8250) {
                return true;
            }
        }
        if (itemStack.method_57826(class_9334.field_49643)) {
            return false;
        }
        if (ItemUtil.getEnchantLevel(itemStack, class_1893.field_9119) > 0) {
            return true;
        }
        return itemStack.method_7909() instanceof class_1829;
    }

    public static boolean isHoldingSword() {
        class_1799 itemStack = ItemUtil.mc.field_1724.method_6047();
        if (itemStack == null || itemStack.method_7960()) {
            return false;
        }
        return itemStack.method_7909() instanceof class_1829;
    }

    public static boolean isHoldingTool() {
        class_1799 itemStack = ItemUtil.mc.field_1724.method_6047();
        if (itemStack == null || itemStack.method_7960()) {
            return false;
        }
        return itemStack.method_7909() instanceof class_1766;
    }

    public static boolean isEating() {
        class_1799 itemStack = ItemUtil.mc.field_1724.method_6047();
        if (itemStack == null || itemStack.method_7960()) {
            return false;
        }
        if (itemStack.method_7909() instanceof class_1828 || itemStack.method_7909() instanceof class_1803) {
            return false;
        }
        class_1839 action = itemStack.method_7976();
        return action == class_1839.field_8950 || action == class_1839.field_8946;
    }

    public static boolean isUsingBow() {
        class_1799 itemStack = ItemUtil.mc.field_1724.method_6047();
        if (itemStack == null || itemStack.method_7960()) {
            return false;
        }
        return itemStack.method_7909() instanceof class_1753;
    }

    public static boolean isHoldingNonEmpty() {
        class_1799 itemStack = ItemUtil.mc.field_1724.method_6047();
        if (itemStack == null || itemStack.method_7947() < 1) {
            return false;
        }
        return itemStack.method_7909() instanceof class_1747;
    }

    public static boolean isHoldingBlock() {
        return ItemUtil.isBlock(ItemUtil.mc.field_1724.method_6047());
    }

    public static boolean hasHoldItem() {
        class_1799 itemStack = ItemUtil.mc.field_1724.method_6047();
        if (itemStack == null || itemStack.method_7947() < 1) {
            return false;
        }
        return itemStack.method_7909() instanceof class_1778;
    }

    private static int getEnchantLevel(class_1799 itemStack, class_5321<class_1887> enchantment) {
        if (ItemUtil.mc.field_1687 == null || itemStack == null || itemStack.method_7960()) return 0;
        return class_1890.method_8225(
                ItemUtil.mc.field_1687.method_30349().method_30530(class_7924.field_41265).method_46747(enchantment),
                itemStack);
    }

    static final class SpecialItems extends ArrayList<Integer> {
        SpecialItems() {
            this.add(1);
            this.add(3);
            this.add(5);
            this.add(6);
            this.add(8);
            this.add(10);
            this.add(11);
            this.add(12);
            this.add(14);
            this.add(21);
            this.add(22);
        }
    }

    public enum ItemType {
        Block {
            public boolean contains(class_1799 itemStack) {
                return isBlock(itemStack);
            }
        },
        Projectile {
            public boolean contains(class_1799 itemStack) {
                return isProjectile(itemStack);
            }
        },
        FishRod {
            public boolean contains(class_1799 itemStack) {
                return itemStack.method_7909() instanceof class_1787;
            }
        },
        GoldApple {
            public boolean contains(class_1799 itemStack) {
                return itemStack.method_7909() == class_1802.field_8463 || itemStack.method_7909() == class_1802.field_8367;
            }
        },
        Arrow {
            public boolean contains(class_1799 itemStack) {
                return itemStack.method_7909() == class_1802.field_8107;
            }
        },
        FireCharge {
            public boolean contains(class_1799 itemStack) {
                return itemStack.method_7909() instanceof class_1778;
            }
        },
        WindCharge {
            public boolean contains(class_1799 itemStack) {
                return itemStack.method_7909() instanceof class_9239;
            }
        },
        Mace {
            public boolean contains(class_1799 itemStack) {
                return itemStack.method_7909() instanceof class_9362;
            }
        };
        abstract public boolean contains(class_1799 itemStack);
    }
}
