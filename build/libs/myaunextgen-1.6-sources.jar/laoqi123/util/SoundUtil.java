package laoqi123.util;

import net.minecraft.class_1109;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class SoundUtil {
    private static final class_310 mc = class_310.method_1551();

    public static void playSound(String soundName) {
        class_2960 id = class_2960.method_12829(soundName);
        if (id == null) {
            return;
        }
        class_3414 soundEvent = class_7923.field_41172.method_63535(id);
        if (soundEvent == null) {
            return;
        }
        mc.method_1483().method_4873(class_1109.method_4757(soundEvent, 1.0F, 1.0F));
    }
}
