package laoqi123.util;

import laoqi123.Myau;
import laoqi123.management.RotationState;
import laoqi123.module.modules.combat.TargetStrafe;
import net.minecraft.class_1294;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class MoveUtil {
    private static final class_310 mc = class_310.method_1551();

    public static boolean isForwardPressed() {
        if (MoveUtil.mc.field_1690.field_1894.method_1434() != MoveUtil.mc.field_1690.field_1881.method_1434())
            return true;
        return MoveUtil.mc.field_1690.field_1913.method_1434() != MoveUtil.mc.field_1690.field_1849.method_1434();
    }

    public static int getForwardValue() {
        int forwardValue = 0;
        if (MoveUtil.mc.field_1690.field_1894.method_1434()) {
            ++forwardValue;
        }
        if (MoveUtil.mc.field_1690.field_1881.method_1434()) {
            --forwardValue;
        }
        return forwardValue;
    }

    public static int getLeftValue() {
        int leftValue = 0;
        if (MoveUtil.mc.field_1690.field_1913.method_1434()) {
            ++leftValue;
        }
        if (MoveUtil.mc.field_1690.field_1849.method_1434()) {
            --leftValue;
        }
        return leftValue;
    }

    public static float getMoveYaw() {
        return MoveUtil.adjustYaw(RotationState.isActived() ? RotationState.getSmoothedYaw() : MoveUtil.mc.field_1724.method_36454(), MoveUtil.mc.field_1724.field_3913.field_3905, MoveUtil.mc.field_1724.field_3913.field_3907);
    }

    public static float adjustYaw(float yaw, float forward, float strafe) {
        TargetStrafe targetStrafe = (TargetStrafe) Myau.moduleManager.modules.get(TargetStrafe.class);
        if (targetStrafe.isEnabled()) {
            if (!Float.isNaN(targetStrafe.getTargetYaw())) {
                return targetStrafe.getTargetYaw();
            }
        }
        if (forward < 0.0f) {
            yaw += 180.0f;
        }
        if (strafe != 0.0f) {
            float multiplier = forward == 0.0f ? 1.0f : 0.5f * Math.signum(forward);
            yaw += -90.0f * multiplier * Math.signum(strafe);
        }
        return class_3532.method_15393(yaw);
    }

    public static float getDirectionYaw() {
        if (MoveUtil.getSpeed() == 0.0) {
            return class_3532.method_15393(MoveUtil.mc.field_1724.method_36454());
        }
        return class_3532.method_15393((float) Math.toDegrees(Math.atan2(MoveUtil.mc.field_1724.method_18798().field_1350, MoveUtil.mc.field_1724.method_18798().field_1352)) - 90.0f);
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.28015;
        if (MoveUtil.getSpeedTime() > 0) {
            baseSpeed = 0.28015 * (1.0 + 0.15 * (double) MoveUtil.getSpeedLevel());
        }
        return baseSpeed;
    }

    public static double getBaseJumpHigh(int speedLevel) {
        double jumpHeight = 0.452;
        if (speedLevel == 1) {
            jumpHeight = 0.49720000000000003;
        } else if (speedLevel >= 2) {
            jumpHeight *= 1.2;
        }
        return jumpHeight;
    }

    public static double getJumpMotion() {
        int speedLevel = 0;
        if (MoveUtil.getSpeedTime() > 0) {
            speedLevel = MoveUtil.getSpeedLevel();
        }
        return MoveUtil.getBaseJumpHigh(speedLevel);
    }

    public static double getSpeed() {
        return MoveUtil.getSpeed(MoveUtil.mc.field_1724.method_18798().field_1352, MoveUtil.mc.field_1724.method_18798().field_1350);
    }

    public static boolean isMoving() {
        return mc.field_1724.field_3913.field_3905 != 0.0F
                || mc.field_1724.field_3913.field_3907 != 0.0F
                || Math.abs(mc.field_1724.method_18798().field_1352) > 0.01
                || Math.abs(mc.field_1724.method_18798().field_1350) > 0.01;
    }

    public static double getSpeed(double motionX, double motionZ) {
        return Math.hypot(motionX, motionZ);
    }

    public static void setSpeed(double speed) {
        MoveUtil.setSpeed(speed, MoveUtil.getDirectionYaw());
    }

    public static void setSpeed(double speed, float yaw) {
        MoveUtil.mc.field_1724.method_18800(-Math.sin(Math.toRadians(yaw)) * speed, MoveUtil.mc.field_1724.method_18798().field_1351, Math.cos(Math.toRadians(yaw)) * speed);
    }

    public static void addSpeed(double speed, float yaw) {
        MoveUtil.mc.field_1724.method_18800(
                MoveUtil.mc.field_1724.method_18798().field_1352 + -Math.sin(Math.toRadians(yaw)) * speed,
                MoveUtil.mc.field_1724.method_18798().field_1351,
                MoveUtil.mc.field_1724.method_18798().field_1350 + Math.cos(Math.toRadians(yaw)) * speed);
    }

    public static int getSpeedLevel() {
        int speedLevel = 0;
        if (MoveUtil.mc.field_1724.method_6059(class_1294.field_5904)) {
            speedLevel = (MoveUtil.mc.field_1724.method_6112(class_1294.field_5904).method_5578() + 1);
        }
        return speedLevel;
    }

    public static int getSpeedTime() {
        if (MoveUtil.mc.field_1724.method_6059(class_1294.field_5904)) {
            return MoveUtil.mc.field_1724.method_6112(class_1294.field_5904).method_5584();
        }
        return 0;
    }

    public static float getAllowedHorizontalDistance() {
        float slipperiness = MoveUtil.mc.field_1687.method_8320(new class_2338(class_3532.method_15357(MoveUtil.mc.field_1724.method_23317()), class_3532.method_15357(MoveUtil.mc.field_1724.method_5829().field_1322) - 1, class_3532.method_15357(MoveUtil.mc.field_1724.method_23321()))).method_26204().method_9499() * 0.91f;
        return MoveUtil.mc.field_1724.method_6029() * (0.16277136f / (slipperiness * slipperiness * slipperiness));
    }

    public static double[] predictMovement() {
        float strafeInput = (float) MoveUtil.getLeftValue() * 0.98f;
        float forwardInput = (float) MoveUtil.getForwardValue() * 0.98f;
        float inputMagnitude = strafeInput * strafeInput + forwardInput * forwardInput;
        if (inputMagnitude >= 1.0E-4f) {
            inputMagnitude = class_3532.method_15355(inputMagnitude);
            if (inputMagnitude < 1.0f) {
                inputMagnitude = 1.0f;
            }
            inputMagnitude = MoveUtil.getAllowedHorizontalDistance() / inputMagnitude;
            float sinYaw = class_3532.method_15374(MoveUtil.mc.field_1724.method_36454() * (float) Math.PI / 180.0f);
            float cosYaw = class_3532.method_15362(MoveUtil.mc.field_1724.method_36454() * (float) Math.PI / 180.0f);
            strafeInput *= inputMagnitude;
            forwardInput *= inputMagnitude;
            return new double[]{strafeInput * cosYaw - forwardInput * sinYaw, forwardInput * cosYaw + strafeInput * sinYaw};
        }
        return new double[]{0.0, 0.0};
    }

    public static void fixStrafe(float targetYaw) {
        float angle = class_3532.method_15393(MoveUtil.adjustYaw(MoveUtil.mc.field_1724.method_36454(), MoveUtil.getForwardValue(), MoveUtil.getLeftValue()) - targetYaw + 22.5f);
        switch ((int) (angle + 180.0f) / 45 % 8) {
            case 0: {
                MoveUtil.mc.field_1724.field_3913.field_3905 = -1.0f;
                MoveUtil.mc.field_1724.field_3913.field_3907 = 0.0f;
                break;
            }
            case 1: {
                MoveUtil.mc.field_1724.field_3913.field_3905 = -1.0f;
                MoveUtil.mc.field_1724.field_3913.field_3907 = 1.0f;
                break;
            }
            case 2: {
                MoveUtil.mc.field_1724.field_3913.field_3905 = 0.0f;
                MoveUtil.mc.field_1724.field_3913.field_3907 = 1.0f;
                break;
            }
            case 3: {
                MoveUtil.mc.field_1724.field_3913.field_3905 = 1.0f;
                MoveUtil.mc.field_1724.field_3913.field_3907 = 1.0f;
                break;
            }
            case 4: {
                MoveUtil.mc.field_1724.field_3913.field_3905 = 1.0f;
                MoveUtil.mc.field_1724.field_3913.field_3907 = 0.0f;
                break;
            }
            case 5: {
                MoveUtil.mc.field_1724.field_3913.field_3905 = 1.0f;
                MoveUtil.mc.field_1724.field_3913.field_3907 = -1.0f;
                break;
            }
            case 6: {
                MoveUtil.mc.field_1724.field_3913.field_3905 = 0.0f;
                MoveUtil.mc.field_1724.field_3913.field_3907 = -1.0f;
                break;
            }
            case 7: {
                MoveUtil.mc.field_1724.field_3913.field_3905 = -1.0f;
                MoveUtil.mc.field_1724.field_3913.field_3907 = -1.0f;
                break;
            }
        }
        if (MoveUtil.mc.field_1724.field_3913.field_54155.comp_3164()) {
            MoveUtil.mc.field_1724.field_3913.field_3905 *= 0.3f;
            MoveUtil.mc.field_1724.field_3913.field_3907 *= 0.3f;
        }
    }
}
