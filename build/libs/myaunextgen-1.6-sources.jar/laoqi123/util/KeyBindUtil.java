package laoqi123.util;

import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeyBindUtil {
    public static String getKeyName(int keyCode) {
        if (keyCode < 0) {
            int mouseButton = keyCode + 100;
            class_3675.class_306 mouseKey = class_3675.class_307.field_1672.method_1447(mouseButton);
            return mouseKey.method_27445().getString();
        }
        class_3675.class_306 key = class_3675.method_15985(keyCode, -1);
        return key.method_27445().getString();
    }

    public static boolean isKeyDown(int keyCode) {
        long handle = class_310.method_1551().method_22683().method_4490();
        return keyCode < 0 ? GLFW.glfwGetMouseButton(handle, keyCode + 100) == GLFW.GLFW_PRESS
                : class_3675.method_15987(handle, keyCode);
    }

    public static boolean isKeyDown(class_3675.class_306 key) {
        long handle = class_310.method_1551().method_22683().method_4490();
        if (key.method_1442() == class_3675.class_307.field_1672) {
            return GLFW.glfwGetMouseButton(handle, key.method_1444()) == GLFW.GLFW_PRESS;
        }
        return class_3675.method_15987(handle, key.method_1444());
    }

    public static boolean isKeyDown(net.minecraft.class_304 keyBinding) {
        return isKeyDown(class_3675.method_15981(keyBinding.method_1428()));
    }

    public static void updateKeyState(int keyCode) {
        KeyBindUtil.setKeyBindState(keyCode, KeyBindUtil.isKeyDown(keyCode));
    }

    public static void updateKeyState(net.minecraft.class_304 keyBinding) {
        KeyBindUtil.setKeyBindState(keyBinding, KeyBindUtil.isKeyDown(keyBinding));
    }

    public static void setKeyBindState(int keyCode, boolean pressed) {
        class_3675.class_306 key = KeyBindUtil.fromKeyCode(keyCode);
        if (key != null) {
            class_304.method_1416(key, pressed);
        }
    }

    public static void setKeyBindState(net.minecraft.class_304 keyBinding, boolean pressed) {
        class_3675.class_306 key = class_3675.method_15981(keyBinding.method_1428());
        class_304.method_1416(key, pressed);
    }

    public static void pressKeyOnce(int keyCode) {
        class_3675.class_306 key = KeyBindUtil.fromKeyCode(keyCode);
        if (key != null) {
            class_304.method_1420(key);
        }
    }

    public static class_3675.class_306 fromKeyCode(int keyCode) {
        if (keyCode < 0) {
            return class_3675.class_307.field_1672.method_1447(keyCode + 100);
        }
        return class_3675.method_15985(keyCode, -1);
    }
}
