package laoqi123.util;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public final class RayCastUtil {
    private static final class_310 mc = class_310.method_1551();

    public static RayCastResult rayCast(RotationUtil.RotationVec rotation, double distance) {
        return rayCast(rotation, distance, 0.0F);
    }

    public static boolean inView(class_1297 entity) {
        RotationUtil.RotationVec rotation = calculateRotationToEntity(entity);
        int renderDistance = 16 * mc.field_1690.method_42503().method_41753();
        if (!(entity.method_5739(mc.field_1724) > 100.0D) && entity instanceof class_1657) {
            class_238 boundingBox = entity.method_5829();
            for (double yOffset = 1.0D; yOffset >= -1.0D; yOffset -= 0.5D) {
                for (double xOffset = 1.0D; xOffset >= -1.0D; --xOffset) {
                    for (double zOffset = 1.0D; zOffset >= -1.0D; --zOffset) {
                        double scanX = entity.method_23317() + (boundingBox.field_1320 - boundingBox.field_1323) * xOffset;
                        double scanY = entity.method_23318() + (boundingBox.field_1325 - boundingBox.field_1322) * yOffset;
                        double scanZ = entity.method_23321() + (boundingBox.field_1324 - boundingBox.field_1321) * zOffset;
                        RotationUtil.RotationVec scanRotation = calculateRotationTo(scanX, scanY, scanZ);
                        RayCastResult result = rayCast(scanRotation, renderDistance, 0.2F);
                        if (result != null && result.typeOfHit == RayCastResult.Type.ENTITY) {
                            return true;
                        }
                    }
                }
            }
            return false;
        } else {
            RayCastResult result = rayCast(rotation, renderDistance, 0.3F);
            return result != null && result.typeOfHit == RayCastResult.Type.ENTITY;
        }
    }

    public static RayCastResult rayCast(RotationUtil.RotationVec rotation, double distance, float expandSize) {
        return rayCast(rotation, distance, expandSize, mc.field_1724);
    }

    public static RayCastResult rayCast(RotationUtil.RotationVec rotation, double distance, float expandSize, class_1297 sourceEntity) {
        if (sourceEntity != null && mc.field_1687 != null) {
            float partialTicks = 1.0F;
            class_3965 blockHit = rayTraceCustom(sourceEntity, rotation.x, rotation.y, distance);
            double maxDistance = distance;
            class_243 eyePos = sourceEntity.method_33571();
            if (blockHit != null && blockHit.method_17783() == class_239.class_240.field_1332) {
                maxDistance = blockHit.method_17784().method_1022(eyePos);
            }

            class_243 lookVec = getVectorForRotation(rotation.y, rotation.x);
            class_243 endPos = eyePos.method_1031(lookVec.field_1352 * distance, lookVec.field_1351 * distance, lookVec.field_1350 * distance);
            class_1297 hitEntity = null;
            class_243 hitVec = null;
            List<class_1297> entities = mc.field_1687.method_8333(sourceEntity, sourceEntity.method_5829().method_1009(lookVec.field_1352 * distance, lookVec.field_1351 * distance, lookVec.field_1350 * distance).method_1009(1.0D, 1.0D, 1.0D), class_1297::method_30948);
            double currentDistance = maxDistance;

            for (class_1297 entity : entities) {
                float entityExpand = 0.3F + expandSize;
                class_238 expandedBB = entity.method_5829().method_1009(entityExpand, entityExpand, entityExpand);
                Optional<class_243> entityHit = expandedBB.method_992(eyePos, endPos);
                if (expandedBB.method_1006(eyePos)) {
                    if (currentDistance >= 0.0D) {
                        hitEntity = entity;
                        hitVec = entityHit.orElse(eyePos);
                        currentDistance = 0.0D;
                    }
                } else if (entityHit.isPresent()) {
                    double distanceToHit = eyePos.method_1022(entityHit.get());
                    if (distanceToHit < currentDistance || currentDistance == 0.0D) {
                        hitEntity = entity;
                        hitVec = entityHit.get();
                        currentDistance = distanceToHit;
                    }
                }
            }

            if (hitEntity != null && (currentDistance < maxDistance || blockHit == null)) {
                return new RayCastResult(hitEntity, hitVec);
            }

            if (blockHit != null) {
                return new RayCastResult(blockHit.method_17784(), blockHit.method_17780(), blockHit.method_17777());
            }
        }
        return null;
    }

    private static class_3965 rayTraceCustom(class_1297 entity, float yaw, float pitch, double distance) {
        class_243 eyePos = entity.method_33571();
        class_243 lookVec = getVectorForRotation(pitch, yaw);
        class_243 targetPos = eyePos.method_1031(lookVec.field_1352 * distance, lookVec.field_1351 * distance, lookVec.field_1350 * distance);
        return entity.method_37908().method_17742(new class_3959(eyePos, targetPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, entity));
    }

    public static boolean overBlock(RotationUtil.RotationVec rotation, class_2350 side, net.minecraft.class_2338 pos, boolean checkSide) {
        RayCastResult hit = rayCast(rotation, 4.5D);
        if (hit != null && hit.hitVec != null) {
            return hit.getBlockPos() != null && hit.getBlockPos().equals(pos) && (!checkSide || hit.sideHit == side);
        } else {
            return false;
        }
    }

    public static RotationUtil.RotationVec calculateRotationToEntity(class_1297 entity) {
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 entityPos = new class_243(entity.method_23317(), entity.method_23318() + entity.method_18381(entity.method_18376()), entity.method_23321());
        double deltaX = entityPos.field_1352 - eyePos.field_1352;
        double deltaY = entityPos.field_1351 - eyePos.field_1351;
        double deltaZ = entityPos.field_1350 - eyePos.field_1350;
        double horizontalDist = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        float yaw = (float) (Math.atan2(deltaZ, deltaX) * 180.0D / 3.141592653589793D) - 90.0F;
        float pitch = (float) (-(Math.atan2(deltaY, horizontalDist) * 180.0D / 3.141592653589793D));
        return new RotationUtil.RotationVec(yaw, pitch);
    }

    private static RotationUtil.RotationVec calculateRotationTo(double x, double y, double z) {
        class_243 eyePos = mc.field_1724.method_33571();
        double deltaX = x - eyePos.field_1352;
        double deltaY = y - eyePos.field_1351;
        double deltaZ = z - eyePos.field_1350;
        double horizontalDist = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        float yaw = (float) (Math.atan2(deltaZ, deltaX) * 180.0D / 3.141592653589793D) - 90.0F;
        float pitch = (float) (-(Math.atan2(deltaY, horizontalDist) * 180.0D / 3.141592653589793D));
        return new RotationUtil.RotationVec(yaw, pitch);
    }

    private static class_243 getVectorForRotation(float pitch, float yaw) {
        float f = class_3532.method_15362(-yaw * 0.017453292F - 3.1415927F);
        float f1 = class_3532.method_15374(-yaw * 0.017453292F - 3.1415927F);
        float f2 = -class_3532.method_15362(-pitch * 0.017453292F);
        float f3 = class_3532.method_15374(-pitch * 0.017453292F);
        return new class_243(f1 * f2, f3, f * f2);
    }

    public static class RayCastResult {
        public Type typeOfHit;
        public class_243 hitVec;
        public class_1297 entityHit;
        public class_2350 sideHit;
        private net.minecraft.class_2338 blockPos;

        public RayCastResult(class_243 hitVec, Type type) {
            this.hitVec = hitVec;
            this.typeOfHit = type;
        }

        public RayCastResult(class_1297 entity, class_243 hitVec) {
            this.entityHit = entity;
            this.hitVec = hitVec;
            this.typeOfHit = Type.ENTITY;
        }

        public RayCastResult(class_243 hitVec, class_2350 sideHit, net.minecraft.class_2338 blockPos) {
            this.hitVec = hitVec;
            this.sideHit = sideHit;
            this.blockPos = blockPos;
            this.typeOfHit = Type.BLOCK;
        }

        public RayCastResult(class_243 hitVec, class_2350 sideHit, Type type) {
            this.hitVec = hitVec;
            this.sideHit = sideHit;
            this.typeOfHit = type;
        }

        public net.minecraft.class_2338 getBlockPos() {
            return this.blockPos;
        }

        public void setBlockPos(net.minecraft.class_2338 blockPos) {
            this.blockPos = blockPos;
        }

        public static enum Type {
            MISS,
            BLOCK,
            ENTITY;
        }
    }
}
