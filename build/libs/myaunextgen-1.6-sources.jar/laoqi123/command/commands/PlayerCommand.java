package laoqi123.command.commands;

import laoqi123.Myau;
import laoqi123.command.Command;
import laoqi123.enums.ChatColors;
import laoqi123.util.ChatUtil;
import net.minecraft.class_310;
import net.minecraft.class_640;
import java.util.ArrayList;
import java.util.Arrays;

public class PlayerCommand extends Command {
    private static final class_310 mc = class_310.method_1551();

    public PlayerCommand() {
        super(new ArrayList<>(Arrays.asList("playerlist", "players")));
    }

    @Override
    public void runCommand(ArrayList<String> args) {
        ArrayList<String> players = new ArrayList<>();
        for (class_640 playerInfo : mc.method_1562().method_2880()) {
            players.add(playerInfo.method_2966().getName().replace("§", "&"));
        }
        if (players.isEmpty()) {
            ChatUtil.sendFormatted(String.format("%sNo players&r", Myau.clientName));
        } else {
            ChatUtil.sendRaw(
                    String.format(
                            ChatColors.formatColor("%sPlayers:&r %s"),
                            ChatColors.formatColor(Myau.clientName),
                            String.join(", ", players)
                    )
            );
        }
    }
}
