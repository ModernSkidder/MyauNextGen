package laoqi123.command.commands;

import laoqi123.Myau;
import laoqi123.command.Command;
import laoqi123.enums.ChatColors;
import laoqi123.util.ChatUtil;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.Arrays;

public class ItemCommand extends Command {
    private static final class_310 mc = class_310.method_1551();

    public ItemCommand() {
        super(new ArrayList<>(Arrays.asList("itemname", "item")));
    }

    @Override
    public void runCommand(ArrayList<String> args) {
        class_1799 stack = mc.field_1724.method_6047();
        if (stack != null) {
            String display = stack.method_7964().getString().replace('§', '&');
            String registryName = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            String compound = stack.method_57826(class_9334.field_49628) ? stack.method_57824(class_9334.field_49628).method_57463().toString().replace('§', '&') : "";
            ChatUtil.sendRaw(String.format("%s%s (%s) %s", ChatColors.formatColor(Myau.clientName), display, registryName, compound));
        }
    }
}
