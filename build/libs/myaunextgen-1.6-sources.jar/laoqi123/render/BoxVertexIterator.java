package laoqi123.render;

import net.minecraft.class_2350;
import net.minecraft.class_238;

public enum BoxVertexIterator {
    FACE {
        @Override
        public void forEachVertex(class_238 box, Consumer consumer) {
            int i = 0;
            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1324);
            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1324);

            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1321);
            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1324);
            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1324);
            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1321);

            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1321);
            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1321);

            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1324);
            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1324);

            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1324);
            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1324);
            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1324);
            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1324);

            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1321);
            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1324);
            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1324);
            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1321);
        }

        @Override
        public int sideMask(class_2350 side) {
            return switch (side) {
                case field_11033 -> 0x00000F;
                case field_11036 -> 0x0000F0;
                case field_11043 -> 0x000F00;
                case field_11034 -> 0x00F000;
                case field_11035 -> 0x0F0000;
                case field_11039 -> 0xF00000;
            };
        }
    },
    OUTLINE {
        @Override
        public void forEachVertex(class_238 box, Consumer consumer) {
            int i = 0;
            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1321);

            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1324);

            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1324);
            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1324);

            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1324);
            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1321);

            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1321);
            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1321);

            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1321);

            consumer.accept(i++, box.field_1320, box.field_1322, box.field_1324);
            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1324);

            consumer.accept(i++, box.field_1323, box.field_1322, box.field_1324);
            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1324);

            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1321);

            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1321);
            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1324);

            consumer.accept(i++, box.field_1320, box.field_1325, box.field_1324);
            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1324);

            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1324);
            consumer.accept(i++, box.field_1323, box.field_1325, box.field_1321);
        }

        @Override
        public int sideMask(class_2350 side) {
            return switch (side) {
                case field_11033 -> 0b0000_0000_0000_0000_1111_1111;
                case field_11036 -> 0b1111_1111_0000_0000_0000_0000;
                case field_11043 -> 0b0000_0011_0000_1111_0000_0011;
                case field_11034 -> 0b0000_1100_0011_1100_0000_1100;
                case field_11035 -> 0b0011_0000_1111_0000_0011_0000;
                case field_11039 -> 0b1100_0000_1100_0011_1100_0000;
            };
        }
    };

    public abstract void forEachVertex(class_238 box, Consumer consumer);

    public abstract int sideMask(class_2350 side);

    @FunctionalInterface
    public interface Consumer {
        void accept(int index, double x, double y, double z);
    }
}
