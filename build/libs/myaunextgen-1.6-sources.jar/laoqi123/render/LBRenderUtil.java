package laoqi123.render;

import com.mojang.blaze3d.systems.RenderSystem;
import laoqi123.render.type.Color4b;
import laoqi123.render.type.Vec3f;
import net.minecraft.class_10142;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

public class LBRenderUtil {
    private static final int CIRCLE_RES = 40;

    private static final List<Vector3f> circlePoints = new ArrayList<>(CIRCLE_RES + 1);

    static {
        for (int i = 0; i <= CIRCLE_RES; i++) {
            double theta = Math.PI * 2f * i / CIRCLE_RES;
            circlePoints.add(new Vector3f((float) Math.cos(theta), 0f, (float) Math.sin(theta)));
        }
    }

    public static void enableWorldRenderState() {
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(
                com.mojang.blaze3d.platform.GlStateManager.class_4535.SRC_ALPHA,
                com.mojang.blaze3d.platform.GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA,
                com.mojang.blaze3d.platform.GlStateManager.class_4535.ONE,
                com.mojang.blaze3d.platform.GlStateManager.class_4534.ZERO);
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
    }

    public static void disableWorldRenderState() {
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    public static void drawLine(Vec3f p1, Vec3f p2, int argb) {
        RenderSystem.setShader(class_10142.field_53876);
        RenderSystem.lineWidth(1.5F);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27377, class_290.field_1576);
        bufferBuilder.method_22912(p1.x(), p1.y(), p1.z()).method_39415(argb);
        bufferBuilder.method_22912(p2.x(), p2.y(), p2.z()).method_39415(argb);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0F);
    }

    public static void drawLines(int argb, Vec3f... lines) {
        if (lines.length == 0) return;
        RenderSystem.setShader(class_10142.field_53876);
        RenderSystem.lineWidth(1.5F);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27377, class_290.field_1576);
        for (Vec3f line : lines) {
            bufferBuilder.method_22912(line.x(), line.y(), line.z()).method_39415(argb);
        }
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0F);
    }

    public static void drawLineStrip(int argb, Vec3f... positions) {
        if (positions.length == 0) return;
        RenderSystem.setShader(class_10142.field_53876);
        RenderSystem.lineWidth(1.5F);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_29345, class_290.field_1576);
        for (Vec3f position : positions) {
            bufferBuilder.method_22912(position.x(), position.y(), position.z()).method_39415(argb);
        }
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0F);
    }

    private static void drawBoxVertices(class_238 box, BoxVertexIterator iterator, int argb, int verticesToUse) {
        RenderSystem.setShader(class_10142.field_53876);
        boolean check = (verticesToUse & 0xFFFFFF) != 0xFFFFFF;
        class_287 bufferBuilder;
        if (iterator == BoxVertexIterator.OUTLINE) {
            RenderSystem.lineWidth(1.5F);
            bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        } else {
            bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        }
        iterator.forEachVertex(box, (index, x, y, z) -> {
            if (check && (verticesToUse & (1 << index)) == 0) return;
            bufferBuilder.method_22912((float) x, (float) y, (float) z).method_39415(argb);
        });
        class_286.method_43433(bufferBuilder.method_60800());
        if (iterator == BoxVertexIterator.OUTLINE) {
            RenderSystem.lineWidth(2.0F);
        }
    }

    public static void drawBoxOutlined(class_238 box, Color4b color) {
        if (color.isTransparent()) return;
        drawBoxVertices(box, BoxVertexIterator.OUTLINE, color.toARGB(), -1);
    }

    public static void drawBox(class_238 box, Color4b faceColor, Color4b outlineColor) {
        if (faceColor != null && !faceColor.isTransparent()) {
            drawBoxVertices(box, BoxVertexIterator.FACE, faceColor.toARGB(), -1);
        }
        if (outlineColor != null && !outlineColor.isTransparent()) {
            drawBoxVertices(box, BoxVertexIterator.OUTLINE, outlineColor.toARGB(), -1);
        }
    }

    public static void drawBoxSide(class_238 box, class_2350 side, Color4b faceColor, Color4b outlineColor) {
        if (faceColor != null && !faceColor.isTransparent()) {
            drawBoxVertices(box, BoxVertexIterator.FACE, faceColor.toARGB(), BoxVertexIterator.FACE.sideMask(side));
        }
        if (outlineColor != null && !outlineColor.isTransparent()) {
            drawBoxVertices(box, BoxVertexIterator.OUTLINE, outlineColor.toARGB(), BoxVertexIterator.OUTLINE.sideMask(side));
        }
    }

    public static void drawBoxSides(class_238 box, Iterable<class_2350> sides, Color4b faceColor, Color4b outlineColor) {
        int faceMask = 0;
        int outlineMask = 0;
        for (class_2350 side : sides) {
            faceMask |= BoxVertexIterator.FACE.sideMask(side);
            outlineMask |= BoxVertexIterator.OUTLINE.sideMask(side);
        }
        if (faceColor != null && !faceColor.isTransparent()) {
            drawBoxVertices(box, BoxVertexIterator.FACE, faceColor.toARGB(), faceMask);
        }
        if (outlineColor != null && !outlineColor.isTransparent()) {
            drawBoxVertices(box, BoxVertexIterator.OUTLINE, outlineColor.toARGB(), outlineMask);
        }
    }

    public static void drawPlane(float sizeX, float sizeZ, Color4b fillColor, Color4b outlineColor) {
        if (fillColor != null && !fillColor.isTransparent()) {
            int argb = fillColor.toARGB();
            RenderSystem.setShader(class_10142.field_53876);
            class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
            bufferBuilder.method_22912(0f, 0f, 0f).method_39415(argb);
            bufferBuilder.method_22912(0f, 0f, sizeZ).method_39415(argb);
            bufferBuilder.method_22912(sizeX, 0f, sizeZ).method_39415(argb);
            bufferBuilder.method_22912(sizeX, 0f, 0f).method_39415(argb);
            class_286.method_43433(bufferBuilder.method_60800());
        }
        if (outlineColor != null && !outlineColor.isTransparent()) {
            int argb = outlineColor.toARGB();
            RenderSystem.setShader(class_10142.field_53876);
            RenderSystem.lineWidth(1.5F);
            class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27377, class_290.field_1576);
            bufferBuilder.method_22912(0f, 0f, 0f).method_39415(argb);
            bufferBuilder.method_22912(0f, 0f, sizeZ).method_39415(argb);
            bufferBuilder.method_22912(0f, 0f, sizeZ).method_39415(argb);
            bufferBuilder.method_22912(sizeX, 0f, sizeZ).method_39415(argb);
            bufferBuilder.method_22912(sizeX, 0f, sizeZ).method_39415(argb);
            bufferBuilder.method_22912(sizeX, 0f, 0f).method_39415(argb);
            bufferBuilder.method_22912(sizeX, 0f, 0f).method_39415(argb);
            bufferBuilder.method_22912(0f, 0f, 0f).method_39415(argb);
            class_286.method_43433(bufferBuilder.method_60800());
            RenderSystem.lineWidth(2.0F);
        }
    }

    public static void drawCircleOutline(float radius, Color4b color4b) {
        int argb = color4b.toARGB();
        RenderSystem.setShader(class_10142.field_53876);
        RenderSystem.lineWidth(1.5F);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_29345, class_290.field_1576);
        for (Vector3f point : circlePoints) {
            bufferBuilder.method_22912(point.x * radius, point.y, point.z * radius).method_39415(argb);
        }
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.lineWidth(2.0F);
    }

    public static void drawGradientCircle(float outerRadius, float innerRadius, Color4b outerColor4b, Color4b innerColor4b) {
        drawGradientCircle(outerRadius, innerRadius, outerColor4b, innerColor4b, new Vector3f());
    }

    public static void drawGradientCircle(float outerRadius, float innerRadius, Color4b outerColor4b, Color4b innerColor4b, Vector3f innerOffset) {
        RenderSystem.setShader(class_10142.field_53876);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        Vector3f innerP = new Vector3f();
        Vector3f outerP = new Vector3f();
        for (Vector3f p : circlePoints) {
            outerP.set(p).mul(outerRadius);
            innerP.set(p).mul(innerRadius).add(innerOffset);
            bufferBuilder.method_22912(outerP.x, outerP.y, outerP.z).method_39415(outerColor4b.toARGB());
            bufferBuilder.method_22912(innerP.x, innerP.y, innerP.z).method_39415(innerColor4b.toARGB());
        }
        class_286.method_43433(bufferBuilder.method_60800());
    }

    public static void drawGradientSides(double height, Color4b baseColor, Color4b topColor, class_238 box) {
        if (height == 0.0) {
            return;
        }
        drawGradientQuad(
                new Vec3f(box.field_1323, 0.0, box.field_1321),
                new Vec3f(box.field_1323, height, box.field_1321),
                new Vec3f(box.field_1320, height, box.field_1321),
                new Vec3f(box.field_1320, 0.0, box.field_1321),
                baseColor, topColor
        );
        drawGradientQuad(
                new Vec3f(box.field_1320, 0.0, box.field_1321),
                new Vec3f(box.field_1320, height, box.field_1321),
                new Vec3f(box.field_1320, height, box.field_1324),
                new Vec3f(box.field_1320, 0.0, box.field_1324),
                baseColor, topColor
        );
        drawGradientQuad(
                new Vec3f(box.field_1320, 0.0, box.field_1324),
                new Vec3f(box.field_1320, height, box.field_1324),
                new Vec3f(box.field_1323, height, box.field_1324),
                new Vec3f(box.field_1323, 0.0, box.field_1324),
                baseColor, topColor
        );
        drawGradientQuad(
                new Vec3f(box.field_1323, 0.0, box.field_1324),
                new Vec3f(box.field_1323, height, box.field_1324),
                new Vec3f(box.field_1323, height, box.field_1321),
                new Vec3f(box.field_1323, 0.0, box.field_1321),
                baseColor, topColor
        );
    }

    private static void drawGradientQuad(Vec3f p1, Vec3f p2, Vec3f p3, Vec3f p4, Color4b baseColor, Color4b topColor) {
        RenderSystem.setShader(class_10142.field_53876);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22912(p1.x(), p1.y(), p1.z()).method_39415(baseColor.toARGB());
        bufferBuilder.method_22912(p2.x(), p2.y(), p2.z()).method_39415(topColor.toARGB());
        bufferBuilder.method_22912(p3.x(), p3.y(), p3.z()).method_39415(topColor.toARGB());
        bufferBuilder.method_22912(p4.x(), p4.y(), p4.z()).method_39415(baseColor.toARGB());
        class_286.method_43433(bufferBuilder.method_60800());
    }

    public static Vec3f relativeToCamera(Vec3f pos) {
        net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
        var cameraPos = mc.field_1773.method_19418().method_19326();
        return new Vec3f(
                pos.x() - (float) cameraPos.field_1352,
                pos.y() - (float) cameraPos.field_1351,
                pos.z() - (float) cameraPos.field_1350
        );
    }
}
