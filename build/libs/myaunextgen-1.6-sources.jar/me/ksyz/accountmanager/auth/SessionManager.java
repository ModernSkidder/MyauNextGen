package me.ksyz.accountmanager.auth;

import java.lang.reflect.Field;
import net.minecraft.class_310;
import net.minecraft.class_320;

/*
 * This file is derived from https://github.com/ksyzov/AccountManager.
 * Originally licensed under the GNU LGPL.
 *
 * This modified version is licensed under the GNU GPL v3.
 */
public class SessionManager {
    private static final class_310 mc = class_310.method_1551();

    private static Field field = null;

    private static Field getField() {
        if (field == null) {
            try {
                for (Field f : class_310.class.getDeclaredFields()) {
                    if (f.getType().isAssignableFrom(class_320.class)) {
                        field = f;
                        field.setAccessible(true);
                        break;
                    }
                }
            } catch (Exception e) {
                field = null;
            }
        }

        return field;
    }

    public static class_320 get() {
        return mc.method_1548();
    }

    public static void set(class_320 session) {
        try {
            getField().set(mc, session);
        } catch (Exception e) {
            //
        }
    }
}
