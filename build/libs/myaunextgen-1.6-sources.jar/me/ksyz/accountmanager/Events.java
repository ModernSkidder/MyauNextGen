package me.ksyz.accountmanager;

import me.ksyz.accountmanager.auth.Account;
import me.ksyz.accountmanager.auth.SessionManager;
import me.ksyz.accountmanager.gui.GuiAccountManager;
import me.ksyz.accountmanager.utils.TextFormatting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_419;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_526;
import net.minecraft.class_6379;
import net.minecraft.class_642;
import net.minecraft.class_9812;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.util.List;
import java.util.WeakHashMap;

/*
 * This file is derived from https://github.com/ksyzov/AccountManager.
 * Originally licensed under the GNU LGPL.
 *
 * This modified version is licensed under the GNU GPL v3.
 */
public class Events {
    private static final class_310 mc = class_310.method_1551();

    private static final WeakHashMap<class_437, class_4185> accountsButtons = new WeakHashMap<>();
    private static final WeakHashMap<class_437, class_4068> usernameOverlays = new WeakHashMap<>();
    private static final WeakHashMap<class_437, Boolean> disconnectedScreens = new WeakHashMap<>();
    private static boolean wasInWorld = false;
    private static boolean registered = false;
    private static Field drawablesField = null;
    private static Field childrenField = null;
    private static Field selectablesField = null;
    private static Field infoField = null;

    public static void init() {
        if (registered) {
            return;
        }
        registered = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> onTick());
    }

    private static void onTick() {
        class_437 currentScreen = mc.field_1755;

        if (currentScreen instanceof class_526 || currentScreen instanceof class_500) {
            injectAccountButton(currentScreen);
        }

        if (currentScreen instanceof class_419) {
            handleDisconnected((class_419) currentScreen);
        }

        boolean inWorld = mc.field_1687 != null;
        if (inWorld && !wasInWorld) {
            onWorldLoad();
        }
        wasInWorld = inWorld;
    }

    private static void injectAccountButton(class_437 screen) {
        class_4185 button = accountsButtons.get(screen);
        class_4068 overlay = usernameOverlays.get(screen);
        if (button == null) {
            try {
                button = class_4185.method_46430(class_2561.method_43470("Accounts"), b -> mc.method_1507(new GuiAccountManager(screen)))
                        .method_46434(screen.field_22789 - 106, 6, 100, 20)
                        .method_46431();
                overlay = (context, mouseX, mouseY, delta) -> {
                    String text = TextFormatting.translate(String.format(
                            "&7Username: &3%s&r", SessionManager.get().method_1676()
                    ));
                    context.method_25303(mc.field_1772, text, 3, 3, -1);
                };
                addToScreen(screen, button);
                addDrawable(screen, overlay);
                accountsButtons.put(screen, button);
                usernameOverlays.put(screen, overlay);
            } catch (Exception ignored) {
                //
            }
        } else {
            try {
                List<class_4068> drawables = getDrawables(screen);
                if (!drawables.contains(button)) {
                    addToScreen(screen, button);
                }
                if (!drawables.contains(overlay)) {
                    addDrawable(screen, overlay);
                }
            } catch (Exception ignored) {
                //
            }
        }
    }

    private static void handleDisconnected(class_419 screen) {
        if (disconnectedScreens.containsKey(screen)) {
            return;
        }
        disconnectedScreens.put(screen, true);
        try {
            if (infoField == null) {
                infoField = class_419.class.getDeclaredField("info");
                infoField.setAccessible(true);
            }
            class_9812 info = (class_9812) infoField.get(screen);
            String text = info.comp_2853().getString().split("\n\n")[0];
            if (
                    text.equals("§r§cYou are permanently banned from this server!") ||
                            text.equals("§r§cYour account has been blocked.")
            ) {
                AccountManager.load();
                for (Account account : AccountManager.accounts) {
                    if (mc.method_1548().method_1676().equals(account.getUsername())) {
                        account.setUnban(-1L);
                    }
                }
                AccountManager.save();
                return;
            }

            if (
                    text.matches("§r§cYou are temporarily banned for §r§f.*§r§c from this server!") ||
                            text.matches("§r§cYour account is temporarily blocked for §r§f.*§r§c from this server!")
            ) {
                String unban = StringUtils.substringBetween(text, "§r§f", "§r§c");
                if (unban != null) {
                    long time = System.currentTimeMillis();
                    for (String duration : unban.split(" ")) {
                        String type = duration.substring(duration.length() - 1);
                        long value = Long.parseLong(duration.substring(0, duration.length() - 1));
                        switch (type) {
                            case "d": {
                                time += value * 86400000L;
                            }
                            break;
                            case "h": {
                                time += value * 3600000L;
                            }
                            break;
                            case "m": {
                                time += value * 60000L;
                            }
                            break;
                            case "s": {
                                time += value * 1000L;
                            }
                            break;
                        }
                    }

                    AccountManager.load();
                    for (Account account : AccountManager.accounts) {
                        if (mc.method_1548().method_1676().equals(account.getUsername())) {
                            account.setUnban(time);
                        }
                    }
                    AccountManager.save();
                }
            }
        } catch (Exception e) {
            //
        }
    }

    private static void onWorldLoad() {
        class_642 serverInfo = mc.method_1558();
        if (serverInfo != null) {
            String serverIP = serverInfo.field_3761;
            if (serverIP.endsWith("hypixel.net") || serverIP.endsWith("hypixel.io")) {
                AccountManager.load();
                for (Account account : AccountManager.accounts) {
                    if (mc.method_1548().method_1676().equals(account.getUsername())) {
                        account.setUnban(0L);
                    }
                }
                AccountManager.save();
            }
        }
    }

    private static List<class_4068> getDrawables(class_437 screen) throws Exception {
        if (drawablesField == null) {
            drawablesField = class_437.class.getDeclaredField("drawables");
            drawablesField.setAccessible(true);
        }
        return (List<class_4068>) drawablesField.get(screen);
    }

    private static void addDrawable(class_437 screen, class_4068 drawable) throws Exception {
        getDrawables(screen).add(drawable);
    }

    private static void addToScreen(class_437 screen, class_4185 button) throws Exception {
        addDrawable(screen, button);
        if (childrenField == null) {
            childrenField = class_437.class.getDeclaredField("children");
            childrenField.setAccessible(true);
        }
        if (selectablesField == null) {
            selectablesField = class_437.class.getDeclaredField("selectables");
            selectablesField.setAccessible(true);
        }
        ((List<class_364>) childrenField.get(screen)).add(button);
        ((List<class_6379>) selectablesField.get(screen)).add(button);
    }
}
