package me.ksyz.accountmanager.gui;

import me.ksyz.accountmanager.AccountManager;
import me.ksyz.accountmanager.auth.Account;
import me.ksyz.accountmanager.auth.MicrosoftAuth;
import me.ksyz.accountmanager.auth.SessionManager;
import me.ksyz.accountmanager.utils.Notification;
import me.ksyz.accountmanager.utils.TextFormatting;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.apache.commons.lang3.RandomStringUtils;
import org.lwjgl.glfw.GLFW;

import java.util.NoSuchElementException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

/*
 * This file is derived from https://github.com/ksyzov/AccountManager.
 * Originally licensed under the GNU LGPL.
 *
 * This modified version is licensed under the GNU GPL v3.
 */
public class GuiAddToken extends class_437 {
    private final class_437 previousScreen;
    private final String state;

    private class_4185 openButton = null;
    private boolean openButtonEnabled = true;
    private class_4185 cancelButton = null;
    private String status = null;
    private String cause = null;
    private ExecutorService executor = null;
    private CompletableFuture<Void> task = null;
    private boolean success = false;
    private class_342 tokenField;

    public GuiAddToken(class_437 previousScreen) {
        super(class_2561.method_43470("Add Token"));
        this.previousScreen = previousScreen;
        this.state = RandomStringUtils.randomAlphanumeric(8);
    }

    @Override
    public void method_25426() {
        tokenField = this.method_37063(new class_342(
                this.field_22793, field_22789 / 2 - 100, field_22790 / 2, 200, 20, class_2561.method_43470("")
        ));
        tokenField.method_1880(32767);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Add"), button -> actionPerformed(998))
                .method_46434(field_22789 / 2 - 100, field_22790 / 2 + 30, 200, 20)
                .method_46431());
    }

    @Override
    protected void method_56131() {
        this.method_48265(tokenField);
    }

    @Override
    public void method_25432() {
        if (task != null && !task.isDone()) {
            task.cancel(true);
            executor.shutdownNow();
        }
    }

    @Override
    public void method_25393() {
        if (success) {
            field_22787.method_1507(new GuiAccountManager(
                    previousScreen,
                    new Notification(
                            TextFormatting.translate(String.format(
                                    "&aSuccessful login! (%s)&r",
                                    SessionManager.get().method_1676()
                            )),
                            5000L
                    )
            ));
            success = false;
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (openButton != null) {
            openButton.field_22763 = openButtonEnabled;
        }
        this.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_25300(
                this.field_22793, "Add Token",
                field_22789 / 2, field_22790 / 2 - field_22793.field_2000 / 2 - field_22793.field_2000 * 2 - 14, 11184810
        );

        if (status != null) {
            context.method_25300(
                    this.field_22793, TextFormatting.translate(status),
                    field_22789 / 2, field_22790 / 2 - field_22793.field_2000 / 2 - 14, -1
            );
        }

        if (cause != null) {
            String causeText = TextFormatting.translate(cause);
            context.method_25294(
                    0, field_22790 - 2 - field_22793.field_2000 - 3,
                    3 + this.field_22793.method_1727(causeText) + 3, field_22790,
                    0x64000000
            );
            context.method_25303(
                    this.field_22793, TextFormatting.translate(cause),
                    3, field_22790 - 2 - field_22793.field_2000, -1
            );
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (task == null || task.isDone() || task.isCancelled() || task.isCompletedExceptionally()) {
                field_22787.method_1507(previousScreen);
            }
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private void actionPerformed(int id) {
        if (id == 998) {
            if (task == null) {
                if (executor == null) {
                    executor = Executors.newSingleThreadExecutor();
                }
                AtomicReference<String> refreshToken = new AtomicReference<>("");
                AtomicReference<String> accessToken = new AtomicReference<>("");
                MicrosoftAuth.CLIENT_ID = "00000000402b5328";
                MicrosoftAuth.SCOPE = "service::user.auth.xboxlive.com::MBI_SSL";
                task = MicrosoftAuth.login(tokenField.method_1882(), executor)
                        .handle((session, error) -> session != null)
                        .thenComposeAsync(completed -> {
                            if (completed) {
                                throw new NoSuchElementException();
                            }
                            status = "&7Refreshing Microsoft access tokens...&r";
                            return MicrosoftAuth.refreshMSAccessTokens(tokenField.method_1882(), executor);
                        })
                        .thenComposeAsync(msAccessTokens -> {
                            status = "&fAcquiring Xbox access token&r";
                            refreshToken.set(msAccessTokens.get("refresh_token"));
                            return MicrosoftAuth.acquireXboxAccessToken(msAccessTokens.get("access_token"), executor);
                        })
                        .thenComposeAsync(xboxAccessToken -> {
                            status = "&fAcquiring Xbox XSTS token&r";
                            return MicrosoftAuth.acquireXboxXstsToken(xboxAccessToken, executor);
                        })
                        .thenComposeAsync(xboxXstsData -> {
                            status = "&fAcquiring Minecraft access token&r";
                            return MicrosoftAuth.acquireMCAccessToken(
                                    xboxXstsData.get("Token"), xboxXstsData.get("uhs"), executor
                            );
                        })
                        .thenComposeAsync(mcToken -> {
                            status = "&fFetching your Minecraft profile&r";
                            accessToken.set(mcToken);
                            return MicrosoftAuth.login(mcToken, executor);
                        })
                        .thenAccept(session -> {
                            status = null;
                            Account acc = new Account(
                                    refreshToken.get(), accessToken.get(), session.method_1676(), "00000000402b5328", "service::user.auth.xboxlive.com::MBI_SSL"
                            );
                            for (Account account : AccountManager.accounts) {
                                if (acc.getUsername().equals(account.getUsername())) {
                                    acc.setUnban(account.getUnban());
                                    break;
                                }
                            }
                            AccountManager.accounts.add(acc);
                            AccountManager.save();
                            SessionManager.set(session);
                            success = true;
                        })
                        .exceptionally(error -> {
                            openButtonEnabled = false;
                            status = String.format("&c%s&r", error.getMessage());
                            cause = String.format("&c%s&r", error.getCause().getMessage());
                            task.cancel(true);
                            task = null;
                            return null;
                        });
            }
        }
    }
}
