package me.ksyz.accountmanager.gui;

import me.ksyz.accountmanager.AccountManager;
import me.ksyz.accountmanager.auth.Account;
import me.ksyz.accountmanager.auth.MicrosoftAuth;
import me.ksyz.accountmanager.auth.SessionManager;
import me.ksyz.accountmanager.utils.Notification;
import me.ksyz.accountmanager.utils.TextFormatting;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_6382;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.glfw.GLFW;

import java.util.Collections;
import java.util.NoSuchElementException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

/*
 * This file is derived from https://github.com/ksyzov/AccountManager.
 * Originally licensed under the GNU LGPL.
 *
 * This modified version is licensed under the GNU GPL v3.
 */
public class GuiAccountManager extends class_437 {
    private final class_437 previousScreen;

    private class_4185 loginButton = null;
    private class_4185 deleteButton = null;
    private class_4185 cancelButton = null;
    private GuiAccountList guiAccountList = null;
    private Notification notification = null;
    private int selectedAccount = -1;
    private ExecutorService executor = null;
    private CompletableFuture<Void> task = null;

    public GuiAccountManager(class_437 previousScreen) {
        super(class_2561.method_43470("Account Manager"));
        this.previousScreen = previousScreen;
    }

    public GuiAccountManager(class_437 previousScreen, Notification notification) {
        this(previousScreen);
        this.notification = notification;
    }

    @Override
    public void method_25426() {
        AccountManager.load();

        guiAccountList = new GuiAccountList();
        this.method_37063(guiAccountList);

        this.loginButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Login"), button -> actionPerformed(0)).method_46434(field_22789 / 2 - 150, field_22790 - 52, 95, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Add"), button -> actionPerformed(1)).method_46434(field_22789 / 2 - 50, field_22790 - 52, 95, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Session"), button -> actionPerformed(4)).method_46434(field_22789 / 2 + 50, field_22790 - 52, 95, 20).method_46431());

        this.deleteButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Delete"), button -> actionPerformed(2)).method_46434(field_22789 / 2 - 150, field_22790 - 28, 95, 20).method_46431());
        this.cancelButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> actionPerformed(3)).method_46434(field_22789 / 2 + 50, field_22790 - 28, 95, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Add Token"), button -> actionPerformed(5)).method_46434(field_22789 / 2 - 50, field_22790 - 28, 95, 20).method_46431());

        this.method_25393();
    }

    @Override
    public void method_25432() {
        if (task != null && !task.isDone()) {
            task.cancel(true);
            executor.shutdownNow();
        }
    }

    @Override
    public void method_25393() {
        if (loginButton != null && deleteButton != null) {
            loginButton.field_22763 = deleteButton.field_22763 = selectedAccount >= 0;
            if (task != null && !task.isDone()) {
                loginButton.field_22763 = false;
            }
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_25300(
                this.field_22793,
                TextFormatting.translate(String.format(
                        "&rAccount Manager &8(&7%s&8)&r", AccountManager.accounts.size()
                )),
                field_22789 / 2, 20, -1
        );

        String text = TextFormatting.translate(String.format(
                "&7Username: &3%s&r", SessionManager.get().method_1676()
        ));
        context.method_25303(this.field_22793, text, 3, 3, -1);

        if (notification != null && !notification.isExpired()) {
            String notificationText = notification.getMessage();
            context.method_25294(
                    field_22789 / 2 - this.field_22793.method_1727(notificationText) / 2 - 3, 4,
                    field_22789 / 2 + this.field_22793.method_1727(notificationText) / 2 + 3, 4 + 3 + this.field_22793.field_2000 + 2,
                    0x64000000
            );
            context.method_25300(
                    this.field_22793, notification.getMessage(),
                    field_22789 / 2, 4 + 3, -1
            );
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        switch (keyCode) {
            case GLFW.GLFW_KEY_UP: {
                if (selectedAccount > 0) {
                    --selectedAccount;
                    if (method_25441()) {
                        Collections.swap(AccountManager.accounts, selectedAccount, selectedAccount + 1);
                        AccountManager.save();
                    }
                }
            }
            return true;
            case GLFW.GLFW_KEY_DOWN: {
                if (selectedAccount < AccountManager.accounts.size() - 1) {
                    ++selectedAccount;
                    if (method_25441()) {
                        Collections.swap(AccountManager.accounts, selectedAccount, selectedAccount - 1);
                        AccountManager.save();
                    }
                }
            }
            return true;
            case GLFW.GLFW_KEY_ENTER: {
                if (loginButton != null && loginButton.field_22763) {
                    actionPerformed(0);
                }
            }
            return true;
            case GLFW.GLFW_KEY_DELETE: {
                if (deleteButton != null && deleteButton.field_22763) {
                    actionPerformed(2);
                }
            }
            return true;
            case GLFW.GLFW_KEY_ESCAPE: {
                actionPerformed(3);
            }
            return true;
        }

        if (method_25438(keyCode) && selectedAccount >= 0) {
            field_22787.field_1774.method_1455(AccountManager.accounts.get(selectedAccount).getUsername());
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private void actionPerformed(int id) {
        switch (id) {
            case 0: { // Login
                if (task == null || task.isDone()) {
                    if (executor == null) {
                        executor = Executors.newSingleThreadExecutor();
                    }
                    Account account = AccountManager.accounts.get(selectedAccount);
                    String username = StringUtils.isBlank(account.getUsername()) ? "???" : account.getUsername();
                    AtomicReference<String> refreshToken = new AtomicReference<>("");
                    AtomicReference<String> accessToken = new AtomicReference<>("");
                    notification = new Notification(TextFormatting.translate(String.format(
                            "&7Fetching your Minecraft profile... (%s)&r", username
                    )), -1L);
                    MicrosoftAuth.CLIENT_ID = account.getClientId();
                    MicrosoftAuth.SCOPE = account.getScope();
                    task = MicrosoftAuth.login(account.getAccessToken(), executor)
                            .handle((session, error) -> {
                                if (session != null) {
                                    account.setUsername(session.method_1676());
                                    AccountManager.save();
                                    SessionManager.set(session);
                                    notification = new Notification(TextFormatting.translate(String.format(
                                            "&aSuccessful login! (%s)&r", account.getUsername()
                                    )), 5000L);
                                    return true;
                                }
                                return false;
                            })
                            .thenComposeAsync(completed -> {
                                if (completed) {
                                    throw new NoSuchElementException();
                                }
                                notification = new Notification(TextFormatting.translate(String.format(
                                        "&7Refreshing Microsoft access tokens... (%s)&r", username
                                )), -1L);
                                return MicrosoftAuth.refreshMSAccessTokens(account.getRefreshToken(), executor);
                            })
                            .thenComposeAsync(msAccessTokens -> {
                                notification = new Notification(TextFormatting.translate(String.format(
                                        "&7Acquiring Xbox access token... (%s)&r", username
                                )), -1L);
                                refreshToken.set(msAccessTokens.get("refresh_token"));
                                return MicrosoftAuth.acquireXboxAccessToken(msAccessTokens.get("access_token"), executor);
                            })
                            .thenComposeAsync(xboxAccessToken -> {
                                notification = new Notification(TextFormatting.translate(String.format(
                                        "&7Acquiring Xbox XSTS token... (%s)&r", username
                                )), -1L);
                                return MicrosoftAuth.acquireXboxXstsToken(xboxAccessToken, executor);
                            })
                            .thenComposeAsync(xboxXstsData -> {
                                notification = new Notification(TextFormatting.translate(String.format(
                                        "&7Acquiring Minecraft access token... (%s)&r", username
                                )), -1L);
                                return MicrosoftAuth.acquireMCAccessToken(
                                        xboxXstsData.get("Token"), xboxXstsData.get("uhs"), executor
                                );
                            })
                            .thenComposeAsync(mcToken -> {
                                notification = new Notification(TextFormatting.translate(String.format(
                                        "&7Fetching your Minecraft profile... (%s)&r", username
                                )), -1L);
                                accessToken.set(mcToken);
                                return MicrosoftAuth.login(mcToken, executor);
                            })
                            .thenAccept(session -> {
                                account.setRefreshToken(refreshToken.get());
                                account.setAccessToken(accessToken.get());
                                account.setUsername(session.method_1676());
                                AccountManager.save();
                                SessionManager.set(session);
                                notification = new Notification(TextFormatting.translate(String.format(
                                        "&aSuccessful login! (%s)&r", account.getUsername()
                                )), 5000L);
                            })
                            .exceptionally(error -> {
                                if (!(error.getCause() instanceof NoSuchElementException)) {
                                    notification = new Notification(TextFormatting.translate(String.format(
                                            "&c%s (%s)&r", error.getMessage(), username
                                    )), 5000L);
                                }
                                return null;
                            });
                }
            }
            break;
            case 1: { // Add
                field_22787.method_1507(new GuiMicrosoftAuth(previousScreen));
            }
            break;
            case 2: { // Delete
                if (selectedAccount > -1 && selectedAccount < AccountManager.accounts.size()) {
                    AccountManager.accounts.remove(selectedAccount);
                    AccountManager.save();
                    selectedAccount = -1;
                    method_25393();
                }
            }
            break;
            case 3: { // Cancel
                field_22787.method_1507(previousScreen);
            }
            break;
            case 4: { // Session
                field_22787.method_1507(new GuiSessionLogin(this));
            }
            break;
            case 5: { // Add Token
                field_22787.method_1507(new GuiAddToken(this));
            }
            break;
        }
    }

    class GuiAccountList extends class_339 {
        private final int slotHeight = 16;
        private int scrollAmount = 0;
        private long lastClickTime = 0;

        public GuiAccountList() {
            super(
                    GuiAccountManager.this.field_22789 / 2 - (150 + 4) * 2 / 2,
                    32,
                    (150 + 4) * 2,
                    GuiAccountManager.this.field_22790 - 64 - 32,
                    class_2561.method_43470("")
            );
        }

        protected int getListWidth() {
            return (150 + 4) * 2;
        }

        protected int getScrollBarX() {
            return (GuiAccountManager.this.field_22789 + getListWidth()) / 2 + 2;
        }

        protected int getContentHeight() {
            return AccountManager.accounts.size() * slotHeight;
        }

        private int getMaxScroll() {
            return Math.max(0, getContentHeight() - method_25364());
        }

        @Override
        protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
            int x = method_46426();
            int y = method_46427();
            context.method_25294(x - 2, y - 2, x + getListWidth() + 2, y + method_25364() + 2, 0xFF000000);
            context.method_25294(x - 1, y - 1, x + getListWidth() + 1, y + method_25364() + 1, 0x80282828);
            for (int i = 0; i < AccountManager.accounts.size(); i++) {
                int slotY = y + i * slotHeight - scrollAmount;
                if (slotY + slotHeight < y || slotY > y + method_25364()) {
                    continue;
                }
                if (i == GuiAccountManager.this.selectedAccount) {
                    context.method_25294(x - 2, slotY - 2, x + getListWidth() + 2, slotY + slotHeight - 2, 0xFF808080);
                    context.method_25294(x - 1, slotY - 1, x + getListWidth() + 1, slotY + slotHeight - 1, 0xFF2C2C2C);
                }
                drawSlot(context, i, x, slotY, slotHeight, mouseX, mouseY);
            }
        }

        @Override
        protected void method_47399(class_6382 builder) {
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            if (method_25405(mouseX, mouseY)) {
                int slotIndex = (int) ((mouseY - method_46427() + scrollAmount) / slotHeight);
                if (slotIndex >= 0 && slotIndex < AccountManager.accounts.size()) {
                    boolean isDoubleClick = System.currentTimeMillis() - lastClickTime < 250;
                    lastClickTime = System.currentTimeMillis();
                    elementClicked(slotIndex, isDoubleClick, (int) mouseX, (int) mouseY);
                    return true;
                }
            }
            return false;
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
            scrollAmount = class_3532.method_15340((int) (scrollAmount - verticalAmount * 10), 0, getMaxScroll());
            return true;
        }

        protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY) {
            GuiAccountManager.this.selectedAccount = slotIndex;
            GuiAccountManager.this.method_25393();
            if (isDoubleClick) {
                if (loginButton != null && loginButton.field_22763) {
                    GuiAccountManager.this.actionPerformed(0);
                }
            }
        }

        protected void drawSlot(class_332 context, int entryID, int x, int y, int k, int mouseXIn, int mouseYIn) {
            class_327 fr = GuiAccountManager.this.field_22793;
            Account account = AccountManager.accounts.get(entryID);

            String username = account.getUsername();
            if (StringUtils.isBlank(username)) {
                username = "&7&l?";
            } else if (account.getAccessToken().equals(SessionManager.get().method_1674())) {
                username = String.format("&a&l%s", username);
            } else if (username.equals(SessionManager.get().method_1676())) {
                username = String.format("&a%s", username);
            }
            username = TextFormatting.translate(
                    String.format("&r%s&r", username)
            );
            context.method_25303(fr, username, x + 2, y + 2, -1);

            long currentTime = System.currentTimeMillis();
            long unbanTime = account.getUnban();
            String unban;
            if (unbanTime < 0L) {
                unban = "&4&l⚠";
            } else if (unbanTime <= currentTime) {
                unban = "&2&l✔";
            } else {
                long diff = unbanTime - currentTime;
                long s = (diff / 1000L) % 60L;
                long m = (diff / 60000L) % 60L;
                long h = (diff / 3600000L) % 24L;
                long d = (diff / 86400000L);
                unban = String.format(
                        "%s%s%s%s",
                        d > 0L ? String.format("%dd", d) : "",
                        h > 0L ? String.format(" %dh", h) : "",
                        m > 0L ? String.format(" %dm", m) : "",
                        s > 0L ? String.format(" %ds", s) : ""
                );
                unban = unban.trim();
                unban = String.format("%s &c&l⚠", unban);
            }
            unban = TextFormatting.translate(
                    String.format("&r%s&r", unban)
            );
            context.method_25303(
                    fr, unban, x + getListWidth() - 5 - fr.method_1727(unban), y + 2, -1
            );
        }
    }
}
