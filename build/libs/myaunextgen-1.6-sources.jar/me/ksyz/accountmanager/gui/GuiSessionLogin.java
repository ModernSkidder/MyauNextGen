package me.ksyz.accountmanager.gui;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.util.UndashedUuid;
import me.ksyz.accountmanager.auth.SessionManager;
import net.minecraft.class_2561;
import net.minecraft.class_320;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.apache.commons.io.IOUtils;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Optional;

/*
 * This file is derived from https://github.com/ksyzov/AccountManager.
 * Originally licensed under the GNU LGPL.
 *
 * This modified version is licensed under the GNU GPL v3.
 */
public class GuiSessionLogin extends class_437 {
    private class_437 previousScreen;

    private String status = "Session Login";
    private class_342 sessionField;

    public GuiSessionLogin(class_437 previousScreen) {
        super(class_2561.method_43470("Session Login"));
        this.previousScreen = previousScreen;
    }

    @Override
    public void method_25426() {
        sessionField = this.method_37063(new class_342(
                this.field_22793, field_22789 / 2 - 100, field_22790 / 2, 200, 20, class_2561.method_43470("")
        ));
        sessionField.method_1880(32767);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Login"), button -> actionPerformed(998))
                .method_46434(field_22789 / 2 - 100, field_22790 / 2 + 30, 200, 20)
                .method_46431());
    }

    @Override
    protected void method_56131() {
        this.method_48265(sessionField);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);

        context.method_25303(
                this.field_22793, status, field_22789 / 2 - field_22793.method_1727(status) / 2, field_22790 / 2 - 30, Color.WHITE.getRGB()
        );

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void actionPerformed(int id) {
        //login button
        if (id == 998) {
            try {
                String username, uuid, token, session = sessionField.method_1882();

                if (session.contains(":")) { //if fully formatted string (ign:uuid:token)
                    //split string to data
                    username = session.split(":")[0];
                    uuid = session.split(":")[1];
                    token = session.split(":")[2];
                } else { //if only token
                    //make request
                    HttpURLConnection c = (HttpURLConnection) new URL("https://api.minecraftservices.com/minecraft/profile/").openConnection();
                    c.setRequestProperty("Content-type", "application/json");
                    c.setRequestProperty("Authorization", "Bearer " + sessionField.method_1882());
                    c.setDoOutput(true);

                    //get json
                    JsonObject json = new JsonParser().parse(IOUtils.toString(c.getInputStream())).getAsJsonObject();

                    //get data
                    username = json.get("name").getAsString();
                    uuid = json.get("id").getAsString();
                    token = session;
                }

                SessionManager.set(new class_320(username, UndashedUuid.fromStringLenient(uuid), token, Optional.empty(), Optional.empty(), class_320.class_321.field_1988));
                field_22787.method_1507(previousScreen);
            } catch (IOException IOException) {
                if (IOException.getMessage().contains("401")) {
                    status = "§cError: Invalid session.";
                } else {
                    IOException.printStackTrace();
                }
            } catch (Exception e) {
                status = "§cError: Couldn't set session (check mc logs)";
                e.printStackTrace();
            }
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (GLFW.GLFW_KEY_ESCAPE == keyCode) {
            field_22787.method_1507(previousScreen);
        } else {
            return super.method_25404(keyCode, scanCode, modifiers);
        }
        return true;
    }
}
